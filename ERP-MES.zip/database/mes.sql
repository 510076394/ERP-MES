/*
 Navicat Premium Dump SQL

 Source Server         : 华为
 Source Server Type    : MySQL
 Source Server Version : 80404 (8.4.4)
 Source Host           : 1.94.98.8:3306
 Source Schema         : mes

 Target Server Type    : MySQL
 Target Server Version : 80404 (8.4.4)
 File Encoding         : 65001

 Date: 12/05/2025 08:24:16
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for ap_invoice_items
-- ----------------------------
DROP TABLE IF EXISTS `ap_invoice_items`;
CREATE TABLE `ap_invoice_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int NOT NULL,
  `material_id` int NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `quantity` decimal(15, 2) NOT NULL,
  `unit_price` decimal(15, 2) NOT NULL,
  `amount` decimal(15, 2) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `invoice_id`(`invoice_id` ASC) USING BTREE,
  INDEX `material_id`(`material_id` ASC) USING BTREE,
  CONSTRAINT `ap_invoice_items_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `ap_invoices` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ap_invoice_items
-- ----------------------------
INSERT INTO `ap_invoice_items` VALUES (1, 6, 52, '', 30254.00, 10.00, 302540.00, '2025-04-16 19:08:23', '2025-04-16 19:08:23');
INSERT INTO `ap_invoice_items` VALUES (3, 7, 52, '', 2000.00, 20.00, 40000.00, '2025-04-16 19:26:17', '2025-04-16 19:26:17');
INSERT INTO `ap_invoice_items` VALUES (4, 8, 55, '', 1000.00, 10.00, 10000.00, '2025-04-16 22:13:53', '2025-04-16 22:13:53');
INSERT INTO `ap_invoice_items` VALUES (5, 9, 53, '', 1000.00, 36.00, 36000.00, '2025-04-16 22:19:50', '2025-04-16 22:19:50');
INSERT INTO `ap_invoice_items` VALUES (6, 10, 53, '', 1.00, 1.00, 1.00, '2025-04-16 22:24:33', '2025-04-16 22:24:33');
INSERT INTO `ap_invoice_items` VALUES (7, 11, 55, '', 244.00, 12.00, 2928.00, '2025-04-16 22:28:19', '2025-04-16 22:28:19');
INSERT INTO `ap_invoice_items` VALUES (8, 12, 54, '', 1000.00, 10.00, 10000.00, '2025-04-16 22:32:30', '2025-04-16 22:32:30');

-- ----------------------------
-- Table structure for ap_invoices
-- ----------------------------
DROP TABLE IF EXISTS `ap_invoices`;
CREATE TABLE `ap_invoices`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '发票编号',
  `supplier_id` int NOT NULL COMMENT '供应商ID',
  `invoice_date` date NOT NULL COMMENT '发票日期',
  `due_date` date NOT NULL COMMENT '到期日期',
  `total_amount` decimal(15, 2) NOT NULL COMMENT '总金额',
  `paid_amount` decimal(15, 2) NULL DEFAULT 0.00 COMMENT '已付金额',
  `balance_amount` decimal(15, 2) NOT NULL COMMENT '余额',
  `currency_code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'CNY' COMMENT '货币代码',
  `exchange_rate` decimal(15, 6) NULL DEFAULT 1.000000 COMMENT '汇率',
  `status` enum('草稿','已确认','部分付款','已付款','逾期','已取消') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '草稿' COMMENT '状态',
  `terms` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '付款条件',
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `invoice_number`(`invoice_number` ASC) USING BTREE,
  INDEX `supplier_id`(`supplier_id` ASC) USING BTREE,
  INDEX `invoice_date`(`invoice_date` ASC) USING BTREE,
  INDEX `due_date`(`due_date` ASC) USING BTREE,
  INDEX `status`(`status` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '应付账款发票表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ap_invoices
-- ----------------------------
INSERT INTO `ap_invoices` VALUES (1, '6564585', 13, '2025-04-16', '2025-04-30', 29380.00, 29380.00, 0.00, 'CNY', 1.000000, '已付款', NULL, NULL, '2025-04-16 19:04:22', '2025-04-16 22:12:05');
INSERT INTO `ap_invoices` VALUES (3, '300302024', 12, '2025-04-16', '2025-05-10', 341870.20, 341870.20, 0.00, 'CNY', 1.000000, '已付款', NULL, NULL, '2025-04-16 19:06:42', '2025-04-16 22:09:54');
INSERT INTO `ap_invoices` VALUES (5, '3003020241', 12, '2025-04-16', '2025-05-10', 341870.20, 341870.20, 0.00, 'CNY', 1.000000, '已付款', NULL, NULL, '2025-04-16 19:07:04', '2025-04-16 21:27:13');
INSERT INTO `ap_invoices` VALUES (6, '3003020242', 12, '2025-04-16', '2025-05-10', 341870.20, 341870.20, 0.00, 'CNY', 1.000000, '已付款', NULL, NULL, '2025-04-16 19:08:22', '2025-04-16 21:04:27');
INSERT INTO `ap_invoices` VALUES (7, '2545854', 13, '2025-04-16', '2025-04-30', 45200.00, 45200.00, 0.00, 'CNY', 1.000000, '已付款', NULL, NULL, '2025-04-16 19:19:51', '2025-04-16 19:31:08');
INSERT INTO `ap_invoices` VALUES (8, '65485479', 11, '2025-04-16', '2025-05-10', 11300.00, 11300.00, 0.00, 'CNY', 1.000000, '已付款', NULL, NULL, '2025-04-16 22:13:53', '2025-04-16 22:15:47');
INSERT INTO `ap_invoices` VALUES (9, '54875125', 12, '2025-04-16', '2025-04-30', 40680.00, 40680.00, 0.00, 'CNY', 1.000000, '已付款', NULL, NULL, '2025-04-16 22:19:50', '2025-04-16 22:19:56');
INSERT INTO `ap_invoices` VALUES (10, '98746584', 13, '2025-04-16', '2025-04-17', 1.13, 1.13, 0.00, 'CNY', 1.000000, '已付款', NULL, NULL, '2025-04-16 22:24:33', '2025-04-16 22:24:40');
INSERT INTO `ap_invoices` VALUES (11, '32423425', 12, '2025-04-16', '2025-04-30', 3308.64, 0.00, 3308.64, 'CNY', 1.000000, '草稿', NULL, NULL, '2025-04-16 22:28:19', '2025-04-16 22:28:19');
INSERT INTO `ap_invoices` VALUES (12, '8465465', 13, '2025-04-16', '2025-04-17', 11300.00, 11300.00, 0.00, 'CNY', 1.000000, '已付款', NULL, NULL, '2025-04-16 22:32:30', '2025-04-16 22:46:28');

-- ----------------------------
-- Table structure for ap_payment_items
-- ----------------------------
DROP TABLE IF EXISTS `ap_payment_items`;
CREATE TABLE `ap_payment_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `payment_id` int NOT NULL COMMENT '付款ID',
  `invoice_id` int NOT NULL COMMENT '发票ID',
  `amount` decimal(15, 2) NOT NULL COMMENT '金额',
  `discount_amount` decimal(15, 2) NULL DEFAULT 0.00 COMMENT '折扣金额',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `payment_id`(`payment_id` ASC) USING BTREE,
  INDEX `invoice_id`(`invoice_id` ASC) USING BTREE,
  CONSTRAINT `ap_payment_items_ibfk_1` FOREIGN KEY (`payment_id`) REFERENCES `ap_payments` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `ap_payment_items_ibfk_2` FOREIGN KEY (`invoice_id`) REFERENCES `ap_invoices` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '应付账款付款明细表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ap_payment_items
-- ----------------------------
INSERT INTO `ap_payment_items` VALUES (1, 1, 7, 45200.00, 0.00, '2025-04-16 19:31:08');
INSERT INTO `ap_payment_items` VALUES (2, 2, 6, 341870.20, 0.00, '2025-04-16 21:04:27');
INSERT INTO `ap_payment_items` VALUES (3, 3, 5, 341870.20, 0.00, '2025-04-16 21:27:13');
INSERT INTO `ap_payment_items` VALUES (4, 4, 3, 341870.20, 0.00, '2025-04-16 22:09:54');
INSERT INTO `ap_payment_items` VALUES (5, 5, 1, 29380.00, 0.00, '2025-04-16 22:12:05');
INSERT INTO `ap_payment_items` VALUES (6, 6, 8, 11300.00, 0.00, '2025-04-16 22:15:47');
INSERT INTO `ap_payment_items` VALUES (7, 7, 9, 40680.00, 0.00, '2025-04-16 22:19:56');
INSERT INTO `ap_payment_items` VALUES (8, 8, 10, 1.13, 0.00, '2025-04-16 22:24:40');
INSERT INTO `ap_payment_items` VALUES (9, 9, 12, 11300.00, 0.00, '2025-04-16 22:46:27');

-- ----------------------------
-- Table structure for ap_payments
-- ----------------------------
DROP TABLE IF EXISTS `ap_payments`;
CREATE TABLE `ap_payments`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `payment_number` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '付款编号',
  `supplier_id` int NOT NULL COMMENT '供应商ID',
  `payment_date` date NOT NULL COMMENT '付款日期',
  `total_amount` decimal(15, 2) NOT NULL COMMENT '总金额',
  `payment_method` enum('现金','银行转账','支票','电子支付','其他') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '付款方式',
  `reference_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '参考编号',
  `bank_account_id` int NULL DEFAULT NULL COMMENT '银行账户ID',
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `payment_number`(`payment_number` ASC) USING BTREE,
  INDEX `supplier_id`(`supplier_id` ASC) USING BTREE,
  INDEX `payment_date`(`payment_date` ASC) USING BTREE,
  INDEX `payment_method`(`payment_method` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '应付账款付款表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ap_payments
-- ----------------------------
INSERT INTO `ap_payments` VALUES (1, 'PAY-1744803075495', 13, '2025-04-16', 45200.00, '银行转账', NULL, NULL, NULL, '2025-04-16 19:31:08', '2025-04-16 19:31:08');
INSERT INTO `ap_payments` VALUES (2, 'PAY-1744808674609', 12, '2025-04-16', 341870.20, '银行转账', NULL, NULL, NULL, '2025-04-16 21:04:27', '2025-04-16 21:04:27');
INSERT INTO `ap_payments` VALUES (3, 'PAY-1744810040204', 12, '2025-04-16', 341870.20, '银行转账', NULL, 1, NULL, '2025-04-16 21:27:13', '2025-04-16 21:27:13');
INSERT INTO `ap_payments` VALUES (4, 'PAY-1744812601681', 12, '2025-04-16', 341870.20, '银行转账', NULL, 1, NULL, '2025-04-16 22:09:54', '2025-04-16 22:09:54');
INSERT INTO `ap_payments` VALUES (5, 'PAY-1744812732410', 13, '2025-04-16', 29380.00, '银行转账', NULL, 1, NULL, '2025-04-16 22:12:05', '2025-04-16 22:12:05');
INSERT INTO `ap_payments` VALUES (6, 'PAY-1744812954675', 11, '2025-04-16', 11300.00, '银行转账', NULL, 3, NULL, '2025-04-16 22:15:47', '2025-04-16 22:15:47');
INSERT INTO `ap_payments` VALUES (7, 'PAY-1744813203511', 12, '2025-04-16', 40680.00, '银行转账', NULL, 3, NULL, '2025-04-16 22:19:56', '2025-04-16 22:19:56');
INSERT INTO `ap_payments` VALUES (8, 'PAY-1744813486903', 13, '2025-04-16', 1.13, '银行转账', NULL, 1, NULL, '2025-04-16 22:24:40', '2025-04-16 22:24:40');
INSERT INTO `ap_payments` VALUES (9, 'PAY-1744814790148', 13, '2025-04-16', 11300.00, '银行转账', NULL, 2, NULL, '2025-04-16 22:46:26', '2025-04-16 22:46:26');

-- ----------------------------
-- Table structure for ar_invoices
-- ----------------------------
DROP TABLE IF EXISTS `ar_invoices`;
CREATE TABLE `ar_invoices`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '发票编号',
  `customer_id` int NOT NULL COMMENT '客户ID',
  `invoice_date` date NOT NULL COMMENT '发票日期',
  `due_date` date NOT NULL COMMENT '到期日期',
  `total_amount` decimal(15, 2) NOT NULL COMMENT '总金额',
  `paid_amount` decimal(15, 2) NULL DEFAULT 0.00 COMMENT '已付金额',
  `balance_amount` decimal(15, 2) NOT NULL COMMENT '余额',
  `currency_code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'CNY' COMMENT '货币代码',
  `exchange_rate` decimal(15, 6) NULL DEFAULT 1.000000 COMMENT '汇率',
  `status` enum('草稿','已确认','部分付款','已付款','逾期','已取消') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '草稿' COMMENT '状态',
  `terms` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '付款条件',
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `invoice_number`(`invoice_number` ASC) USING BTREE,
  INDEX `customer_id`(`customer_id` ASC) USING BTREE,
  INDEX `invoice_date`(`invoice_date` ASC) USING BTREE,
  INDEX `due_date`(`due_date` ASC) USING BTREE,
  INDEX `status`(`status` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '应收账款发票表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ar_invoices
-- ----------------------------

-- ----------------------------
-- Table structure for ar_receipt_items
-- ----------------------------
DROP TABLE IF EXISTS `ar_receipt_items`;
CREATE TABLE `ar_receipt_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `receipt_id` int NOT NULL COMMENT '收款ID',
  `invoice_id` int NOT NULL COMMENT '发票ID',
  `amount` decimal(15, 2) NOT NULL COMMENT '金额',
  `discount_amount` decimal(15, 2) NULL DEFAULT 0.00 COMMENT '折扣金额',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `receipt_id`(`receipt_id` ASC) USING BTREE,
  INDEX `invoice_id`(`invoice_id` ASC) USING BTREE,
  CONSTRAINT `ar_receipt_items_ibfk_1` FOREIGN KEY (`receipt_id`) REFERENCES `ar_receipts` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `ar_receipt_items_ibfk_2` FOREIGN KEY (`invoice_id`) REFERENCES `ar_invoices` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '应收账款收款明细表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ar_receipt_items
-- ----------------------------

-- ----------------------------
-- Table structure for ar_receipts
-- ----------------------------
DROP TABLE IF EXISTS `ar_receipts`;
CREATE TABLE `ar_receipts`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `receipt_number` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '收款编号',
  `customer_id` int NOT NULL COMMENT '客户ID',
  `receipt_date` date NOT NULL COMMENT '收款日期',
  `total_amount` decimal(15, 2) NOT NULL COMMENT '总金额',
  `payment_method` enum('现金','银行转账','支票','电子支付','其他') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '付款方式',
  `reference_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '参考编号',
  `bank_account_id` int NULL DEFAULT NULL COMMENT '银行账户ID',
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `receipt_number`(`receipt_number` ASC) USING BTREE,
  INDEX `customer_id`(`customer_id` ASC) USING BTREE,
  INDEX `receipt_date`(`receipt_date` ASC) USING BTREE,
  INDEX `payment_method`(`payment_method` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '应收账款收款表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ar_receipts
-- ----------------------------

-- ----------------------------
-- Table structure for asset_categories
-- ----------------------------
DROP TABLE IF EXISTS `asset_categories`;
CREATE TABLE `asset_categories`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '类别名称',
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '类别编码',
  `default_useful_life` int NOT NULL DEFAULT 5 COMMENT '默认使用年限',
  `default_depreciation_method` enum('straight_line','double_declining','sum_of_years','no_depreciation') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'straight_line' COMMENT '默认折旧方法',
  `default_salvage_rate` decimal(5, 2) NOT NULL DEFAULT 5.00 COMMENT '默认残值率(%)',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '描述',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `code`(`code` ASC) USING BTREE,
  INDEX `idx_name`(`name` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '资产类别' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of asset_categories
-- ----------------------------
INSERT INTO `asset_categories` VALUES (1, '电子设备', 'ELV', 3, 'straight_line', 5.00, '包括计算机、打印机等电子设备', '2025-04-16 13:42:42', '2025-04-16 13:51:52');
INSERT INTO `asset_categories` VALUES (2, '办公家具', 'FUR', 5, 'straight_line', 5.00, '包括办公桌椅、文件柜等办公家具', '2025-04-16 13:42:42', '2025-04-16 13:42:42');
INSERT INTO `asset_categories` VALUES (3, '机器设备', 'MAC', 10, 'straight_line', 5.00, '包括生产机器、加工设备等', '2025-04-16 13:42:42', '2025-04-16 13:42:42');
INSERT INTO `asset_categories` VALUES (4, '运输设备', 'VEH', 4, 'double_declining', 3.00, '包括汽车、货车等运输工具', '2025-04-16 13:42:42', '2025-04-16 13:42:42');
INSERT INTO `asset_categories` VALUES (5, '房屋建筑', 'BLD', 20, 'straight_line', 5.00, '包括办公楼、仓库等建筑物', '2025-04-16 13:42:42', '2025-04-16 13:42:42');

-- ----------------------------
-- Table structure for asset_depreciation
-- ----------------------------
DROP TABLE IF EXISTS `asset_depreciation`;
CREATE TABLE `asset_depreciation`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `asset_id` int NOT NULL COMMENT '资产ID',
  `period_id` int NOT NULL COMMENT '会计期间ID',
  `depreciation_date` date NOT NULL COMMENT '折旧日期',
  `depreciation_amount` decimal(15, 2) NOT NULL COMMENT '折旧金额',
  `book_value_before` decimal(15, 2) NOT NULL COMMENT '折旧前账面价值',
  `book_value_after` decimal(15, 2) NOT NULL COMMENT '折旧后账面价值',
  `is_posted` tinyint(1) NULL DEFAULT 0 COMMENT '是否已过账',
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `asset_id`(`asset_id` ASC) USING BTREE,
  INDEX `period_id`(`period_id` ASC) USING BTREE,
  INDEX `depreciation_date`(`depreciation_date` ASC) USING BTREE,
  CONSTRAINT `asset_depreciation_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `fixed_assets` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `asset_depreciation_ibfk_2` FOREIGN KEY (`period_id`) REFERENCES `gl_periods` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '固定资产折旧表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of asset_depreciation
-- ----------------------------
INSERT INTO `asset_depreciation` VALUES (1, 6, 12, '2025-04-16', 578.58, 36542.00, 35963.42, 0, '资产6的手动折旧计提', '2025-04-16 16:14:24');
INSERT INTO `asset_depreciation` VALUES (2, 6, 12, '2025-04-16', 578.58, 34806.26, 34227.68, 0, '资产6的手动折旧计提', '2025-04-16 16:14:37');
INSERT INTO `asset_depreciation` VALUES (3, 6, 12, '2025-04-16', 578.58, 33649.10, 33070.52, 0, '资产6的手动折旧计提', '2025-04-16 16:14:48');
INSERT INTO `asset_depreciation` VALUES (4, 2, 12, '2025-04-16', 45.00, 3000.00, 2955.00, 0, '资产2的手动折旧计提', '2025-04-16 16:15:19');
INSERT INTO `asset_depreciation` VALUES (5, 6, 12, '2025-04-16', 578.58, 32491.94, 31913.36, 0, '资产6的手动折旧计提', '2025-04-16 16:15:26');
INSERT INTO `asset_depreciation` VALUES (6, 2, 12, '2025-04-16', 45.00, 2865.00, 2820.00, 0, '资产2的手动折旧计提', '2025-04-16 16:16:04');
INSERT INTO `asset_depreciation` VALUES (7, 6, 12, '2025-04-16', 578.58, 31334.78, 30756.20, 0, '资产6的手动折旧计提', '2025-04-16 16:22:57');

-- ----------------------------
-- Table structure for asset_disposal
-- ----------------------------
DROP TABLE IF EXISTS `asset_disposal`;
CREATE TABLE `asset_disposal`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `asset_id` int NOT NULL COMMENT '资产ID',
  `disposal_date` date NOT NULL COMMENT '处置日期',
  `disposal_type` enum('出售','报废','捐赠','转让') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '处置类型',
  `disposal_amount` decimal(15, 2) NOT NULL DEFAULT 0.00 COMMENT '处置收入',
  `gain_loss` decimal(15, 2) NOT NULL DEFAULT 0.00 COMMENT '处置损益',
  `approver` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '审批人',
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_asset_id`(`asset_id` ASC) USING BTREE,
  INDEX `idx_disposal_date`(`disposal_date` ASC) USING BTREE,
  CONSTRAINT `asset_disposal_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `fixed_assets` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '资产处置记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of asset_disposal
-- ----------------------------

-- ----------------------------
-- Table structure for asset_transfer
-- ----------------------------
DROP TABLE IF EXISTS `asset_transfer`;
CREATE TABLE `asset_transfer`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `asset_id` int NOT NULL COMMENT '资产ID',
  `transfer_date` date NOT NULL COMMENT '转移日期',
  `source_location_id` int NULL DEFAULT NULL COMMENT '原地点ID',
  `target_location_id` int NULL DEFAULT NULL COMMENT '目标地点ID',
  `source_department_id` int NULL DEFAULT NULL COMMENT '原部门ID',
  `target_department_id` int NULL DEFAULT NULL COMMENT '目标部门ID',
  `source_custodian` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '原保管人',
  `target_custodian` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '新保管人',
  `approver` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '审批人',
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_asset_id`(`asset_id` ASC) USING BTREE,
  INDEX `idx_transfer_date`(`transfer_date` ASC) USING BTREE,
  CONSTRAINT `asset_transfer_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `fixed_assets` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '资产转移记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of asset_transfer
-- ----------------------------

-- ----------------------------
-- Table structure for bank_accounts
-- ----------------------------
DROP TABLE IF EXISTS `bank_accounts`;
CREATE TABLE `bank_accounts`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '账号',
  `account_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '账户名称',
  `bank_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '银行名称',
  `branch_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '支行名称',
  `currency_code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'CNY' COMMENT '货币代码',
  `current_balance` decimal(15, 2) NULL DEFAULT 0.00 COMMENT '当前余额',
  `account_type` enum('活期','定期','信用卡','其他') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '活期' COMMENT '账户类型',
  `is_active` tinyint(1) NULL DEFAULT 1 COMMENT '是否活跃',
  `contact_person` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '联系人',
  `contact_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '联系电话',
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_transaction_date` date NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `account_number`(`account_number` ASC) USING BTREE,
  INDEX `bank_name`(`bank_name` ASC) USING BTREE,
  INDEX `currency_code`(`currency_code` ASC) USING BTREE,
  INDEX `is_active`(`is_active` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '银行账户表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bank_accounts
-- ----------------------------
INSERT INTO `bank_accounts` VALUES (1, '8888888888', '中国工商银行', '中国工商银行', '浙江省乐清市', 'CNY', 99372739.87, '活期', 1, NULL, NULL, NULL, '2025-04-16 09:50:52', '2025-04-16 22:24:40', NULL);
INSERT INTO `bank_accounts` VALUES (2, '666666666', '中国农业银行', '中国农业银行', '浙江省乐清市', 'CNY', 2051245.00, '活期', 1, NULL, NULL, NULL, '2025-04-16 10:36:45', '2025-04-16 22:46:31', NULL);
INSERT INTO `bank_accounts` VALUES (3, '99999999999', '中国人民银行', '中国人民银行', '浙江省乐清市', 'USD', 959320.00, '活期', 1, NULL, NULL, NULL, '2025-04-16 10:40:15', '2025-04-16 22:19:56', '2025-04-16');

-- ----------------------------
-- Table structure for bank_transactions
-- ----------------------------
DROP TABLE IF EXISTS `bank_transactions`;
CREATE TABLE `bank_transactions`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `transaction_number` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '交易编号',
  `bank_account_id` int NOT NULL COMMENT '银行账户ID',
  `transaction_date` date NOT NULL COMMENT '交易日期',
  `transaction_type` enum('存款','取款','转入','转出','利息','费用','其他') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '交易类型',
  `amount` decimal(15, 2) NOT NULL COMMENT '金额',
  `reference_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '参考编号',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '描述',
  `is_reconciled` tinyint(1) NULL DEFAULT 0 COMMENT '是否已对账',
  `reconciliation_date` date NULL DEFAULT NULL COMMENT '对账日期',
  `related_party` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '相关方',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `transaction_number`(`transaction_number` ASC) USING BTREE,
  INDEX `bank_account_id`(`bank_account_id` ASC) USING BTREE,
  INDEX `transaction_date`(`transaction_date` ASC) USING BTREE,
  INDEX `transaction_type`(`transaction_type` ASC) USING BTREE,
  INDEX `is_reconciled`(`is_reconciled` ASC) USING BTREE,
  CONSTRAINT `bank_transactions_ibfk_1` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '银行交易表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bank_transactions
-- ----------------------------
INSERT INTO `bank_transactions` VALUES (5, 'TX20250416110954', 1, '2025-04-16', '取款', 625249.00, NULL, '水电费 - 中国水利局 (银行转账)', 0, NULL, '中国水利局', '2025-04-16 11:09:54', '2025-04-16 11:09:54');
INSERT INTO `bank_transactions` VALUES (6, 'TX20250416111029', 2, '2025-04-16', '存款', 62545.00, NULL, '销售收入 -  (银行转账)', 0, NULL, '浙江凯昆机电', '2025-04-16 11:10:28', '2025-04-16 11:10:28');
INSERT INTO `bank_transactions` VALUES (8, 'PAY-1744810040204', 1, '2025-04-15', '取款', 341870.20, NULL, '采购支出 - 应付账款付款 - 供应商: 常州市瑞发电子有限公司 (电子支付)', 0, NULL, '常州市瑞发电子有限公司', '2025-04-16 21:28:25', '2025-04-16 21:28:25');
INSERT INTO `bank_transactions` VALUES (9, 'TX20250416110618', 1, '2025-04-14', '取款', 2010.00, NULL, '其他支出 -  (银行转账)', 0, NULL, '中国质量认证中心有限公司', '2025-04-16 21:47:20', '2025-04-16 21:47:20');
INSERT INTO `bank_transactions` VALUES (10, 'PAY-1744812601681', 1, '2025-04-16', '转出', 341870.20, NULL, '应付账款付款 - 供应商: 常州市瑞发电子有限公司', 0, NULL, '常州市瑞发电子有限公司', '2025-04-16 22:09:55', '2025-04-16 22:09:55');
INSERT INTO `bank_transactions` VALUES (11, 'PAY-1744812732410', 1, '2025-04-16', '转出', 29380.00, NULL, '应付账款付款 - 供应商: 乐清市朗盛电子科技有限公司', 0, NULL, '乐清市朗盛电子科技有限公司', '2025-04-16 22:12:05', '2025-04-16 22:12:05');
INSERT INTO `bank_transactions` VALUES (12, 'PAY-1744812954675', 3, '2025-04-16', '转出', 11300.00, NULL, '应付账款付款 - 供应商: 乐清市通达有线电厂', 0, NULL, '乐清市通达有线电厂', '2025-04-16 22:15:47', '2025-04-16 22:15:47');
INSERT INTO `bank_transactions` VALUES (13, 'PAY-1744813203511', 3, '2025-04-16', '转出', 40680.00, NULL, '应付账款付款 - 供应商: 常州市瑞发电子有限公司', 0, NULL, '常州市瑞发电子有限公司', '2025-04-16 22:19:56', '2025-04-16 22:19:56');
INSERT INTO `bank_transactions` VALUES (14, 'PAY-1744813486903', 1, '2025-04-16', '转出', 1.13, NULL, '应付账款付款 - 供应商: 乐清市朗盛电子科技有限公司', 0, NULL, '乐清市朗盛电子科技有限公司', '2025-04-16 22:24:40', '2025-04-16 22:24:40');
INSERT INTO `bank_transactions` VALUES (15, 'PAY-1744814790148', 2, '2025-04-16', '转出', 11300.00, NULL, '应付账款付款 - 供应商: 乐清市朗盛电子科技有限公司', 0, NULL, '乐清市朗盛电子科技有限公司', '2025-04-16 22:46:30', '2025-04-16 22:46:30');

-- ----------------------------
-- Table structure for bom_details
-- ----------------------------
DROP TABLE IF EXISTS `bom_details`;
CREATE TABLE `bom_details`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '明细ID',
  `bom_id` int NOT NULL COMMENT 'BOM ID',
  `material_id` int NOT NULL COMMENT '物料ID',
  `quantity` decimal(10, 2) NOT NULL COMMENT '用量',
  `unit_id` int NOT NULL COMMENT '单位ID',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_bom_id`(`bom_id` ASC) USING BTREE,
  INDEX `idx_material_id`(`material_id` ASC) USING BTREE,
  INDEX `idx_unit_id`(`unit_id` ASC) USING BTREE,
  CONSTRAINT `fk_bom_detail_bom` FOREIGN KEY (`bom_id`) REFERENCES `bom_masters` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `fk_bom_detail_material` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_bom_detail_unit` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 282 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = 'BOM明细表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bom_details
-- ----------------------------
INSERT INTO `bom_details` VALUES (208, 57, 60, 1.00, 1, NULL, '2025-04-28 11:09:11', '2025-04-28 11:09:11');
INSERT INTO `bom_details` VALUES (209, 57, 61, 1.00, 1, NULL, '2025-04-28 11:09:11', '2025-04-28 11:09:11');
INSERT INTO `bom_details` VALUES (210, 57, 62, 1.00, 1, NULL, '2025-04-28 11:09:11', '2025-04-28 11:09:11');
INSERT INTO `bom_details` VALUES (211, 57, 63, 1.00, 1, NULL, '2025-04-28 11:09:12', '2025-04-28 11:09:12');
INSERT INTO `bom_details` VALUES (212, 57, 64, 1.00, 1, NULL, '2025-04-28 11:09:12', '2025-04-28 11:09:12');
INSERT INTO `bom_details` VALUES (213, 57, 65, 1.00, 1, NULL, '2025-04-28 11:09:12', '2025-04-28 11:09:12');
INSERT INTO `bom_details` VALUES (214, 57, 66, 1.00, 1, NULL, '2025-04-28 11:09:12', '2025-04-28 11:09:12');
INSERT INTO `bom_details` VALUES (215, 57, 67, 1.00, 1, NULL, '2025-04-28 11:09:12', '2025-04-28 11:09:12');
INSERT INTO `bom_details` VALUES (216, 57, 68, 1.00, 1, NULL, '2025-04-28 11:09:12', '2025-04-28 11:09:12');
INSERT INTO `bom_details` VALUES (217, 57, 69, 1.00, 1, NULL, '2025-04-28 11:09:12', '2025-04-28 11:09:12');
INSERT INTO `bom_details` VALUES (218, 57, 70, 0.04, 1, NULL, '2025-04-28 11:09:12', '2025-04-28 11:09:12');
INSERT INTO `bom_details` VALUES (219, 57, 71, 0.10, 1, NULL, '2025-04-28 11:09:12', '2025-04-28 11:09:12');
INSERT INTO `bom_details` VALUES (220, 57, 72, 1.00, 1, NULL, '2025-04-28 11:09:12', '2025-04-28 11:09:12');
INSERT INTO `bom_details` VALUES (221, 57, 73, 1.00, 1, NULL, '2025-04-28 11:09:12', '2025-04-28 11:09:12');
INSERT INTO `bom_details` VALUES (222, 57, 74, 1.00, 10, NULL, '2025-04-28 11:09:12', '2025-04-28 11:09:12');
INSERT INTO `bom_details` VALUES (223, 57, 75, 1.00, 10, NULL, '2025-04-28 11:09:12', '2025-04-28 11:09:12');
INSERT INTO `bom_details` VALUES (224, 57, 76, 1.00, 7, NULL, '2025-04-28 11:09:12', '2025-04-28 11:09:12');
INSERT INTO `bom_details` VALUES (225, 58, 77, 1.00, 1, NULL, '2025-04-28 11:22:13', '2025-04-28 11:22:13');
INSERT INTO `bom_details` VALUES (226, 58, 78, 1.00, 1, NULL, '2025-04-28 11:22:13', '2025-04-28 11:22:13');
INSERT INTO `bom_details` VALUES (227, 58, 79, 1.00, 1, NULL, '2025-04-28 11:22:13', '2025-04-28 11:22:13');
INSERT INTO `bom_details` VALUES (228, 58, 80, 1.00, 1, NULL, '2025-04-28 11:22:13', '2025-04-28 11:22:13');
INSERT INTO `bom_details` VALUES (229, 58, 81, 1.00, 1, NULL, '2025-04-28 11:22:13', '2025-04-28 11:22:13');
INSERT INTO `bom_details` VALUES (230, 58, 82, 1.00, 1, NULL, '2025-04-28 11:22:13', '2025-04-28 11:22:13');
INSERT INTO `bom_details` VALUES (231, 58, 83, 1.00, 1, NULL, '2025-04-28 11:22:13', '2025-04-28 11:22:13');
INSERT INTO `bom_details` VALUES (232, 58, 84, 1.00, 1, NULL, '2025-04-28 11:22:13', '2025-04-28 11:22:13');
INSERT INTO `bom_details` VALUES (233, 58, 85, 1.00, 1, NULL, '2025-04-28 11:22:13', '2025-04-28 11:22:13');
INSERT INTO `bom_details` VALUES (234, 58, 86, 1.00, 1, NULL, '2025-04-28 11:22:13', '2025-04-28 11:22:13');
INSERT INTO `bom_details` VALUES (235, 58, 87, 1.00, 1, NULL, '2025-04-28 11:22:13', '2025-04-28 11:22:13');
INSERT INTO `bom_details` VALUES (236, 58, 88, 1.00, 1, NULL, '2025-04-28 11:22:13', '2025-04-28 11:22:13');
INSERT INTO `bom_details` VALUES (237, 58, 89, 1.00, 1, NULL, '2025-04-28 11:22:13', '2025-04-28 11:22:13');
INSERT INTO `bom_details` VALUES (238, 58, 90, 1.00, 1, NULL, '2025-04-28 11:22:13', '2025-04-28 11:22:13');
INSERT INTO `bom_details` VALUES (239, 58, 91, 1.00, 1, NULL, '2025-04-28 11:22:13', '2025-04-28 11:22:13');
INSERT INTO `bom_details` VALUES (240, 58, 92, 1.00, 1, NULL, '2025-04-28 11:22:13', '2025-04-28 11:22:13');
INSERT INTO `bom_details` VALUES (241, 58, 93, 1.00, 1, NULL, '2025-04-28 11:22:13', '2025-04-28 11:22:13');
INSERT INTO `bom_details` VALUES (242, 58, 94, 1.00, 1, NULL, '2025-04-28 11:22:13', '2025-04-28 11:22:13');
INSERT INTO `bom_details` VALUES (243, 58, 95, 1.00, 10, NULL, '2025-04-28 11:22:13', '2025-04-28 11:22:13');
INSERT INTO `bom_details` VALUES (263, 59, 77, 1.00, 1, NULL, '2025-04-28 11:25:43', '2025-04-28 11:25:43');
INSERT INTO `bom_details` VALUES (264, 59, 78, 1.00, 1, NULL, '2025-04-28 11:25:43', '2025-04-28 11:25:43');
INSERT INTO `bom_details` VALUES (265, 59, 79, 1.00, 1, NULL, '2025-04-28 11:25:43', '2025-04-28 11:25:43');
INSERT INTO `bom_details` VALUES (266, 59, 80, 1.00, 1, NULL, '2025-04-28 11:25:43', '2025-04-28 11:25:43');
INSERT INTO `bom_details` VALUES (267, 59, 81, 1.00, 1, NULL, '2025-04-28 11:25:43', '2025-04-28 11:25:43');
INSERT INTO `bom_details` VALUES (268, 59, 98, 1.00, 1, NULL, '2025-04-28 11:25:43', '2025-04-28 11:25:43');
INSERT INTO `bom_details` VALUES (269, 59, 83, 1.00, 1, NULL, '2025-04-28 11:25:43', '2025-04-28 11:25:43');
INSERT INTO `bom_details` VALUES (270, 59, 84, 1.00, 1, NULL, '2025-04-28 11:25:43', '2025-04-28 11:25:43');
INSERT INTO `bom_details` VALUES (271, 59, 85, 1.00, 1, NULL, '2025-04-28 11:25:43', '2025-04-28 11:25:43');
INSERT INTO `bom_details` VALUES (272, 59, 86, 1.00, 1, NULL, '2025-04-28 11:25:43', '2025-04-28 11:25:43');
INSERT INTO `bom_details` VALUES (273, 59, 87, 1.00, 1, NULL, '2025-04-28 11:25:43', '2025-04-28 11:25:43');
INSERT INTO `bom_details` VALUES (274, 59, 88, 1.00, 1, NULL, '2025-04-28 11:25:43', '2025-04-28 11:25:43');
INSERT INTO `bom_details` VALUES (275, 59, 89, 1.00, 1, NULL, '2025-04-28 11:25:43', '2025-04-28 11:25:43');
INSERT INTO `bom_details` VALUES (276, 59, 90, 1.00, 1, NULL, '2025-04-28 11:25:43', '2025-04-28 11:25:43');
INSERT INTO `bom_details` VALUES (277, 59, 91, 1.00, 1, NULL, '2025-04-28 11:25:43', '2025-04-28 11:25:43');
INSERT INTO `bom_details` VALUES (278, 59, 92, 1.00, 1, NULL, '2025-04-28 11:25:43', '2025-04-28 11:25:43');
INSERT INTO `bom_details` VALUES (279, 59, 93, 1.00, 1, NULL, '2025-04-28 11:25:43', '2025-04-28 11:25:43');
INSERT INTO `bom_details` VALUES (280, 59, 94, 1.00, 1, NULL, '2025-04-28 11:25:43', '2025-04-28 11:25:43');
INSERT INTO `bom_details` VALUES (281, 59, 95, 1.00, 10, NULL, '2025-04-28 11:25:43', '2025-04-28 11:25:43');

-- ----------------------------
-- Table structure for bom_masters
-- ----------------------------
DROP TABLE IF EXISTS `bom_masters`;
CREATE TABLE `bom_masters`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'BOM ID',
  `product_id` int NOT NULL COMMENT '产品ID',
  `version` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'BOM版本号',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态：1-启用，0-禁用',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_product_version`(`product_id` ASC, `version` ASC) USING BTREE,
  INDEX `idx_status`(`status` ASC) USING BTREE,
  CONSTRAINT `fk_bom_product` FOREIGN KEY (`product_id`) REFERENCES `materials` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 60 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = 'BOM主表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bom_masters
-- ----------------------------
INSERT INTO `bom_masters` VALUES (57, 97, 'A', 1, NULL, '2025-04-28 11:09:11', '2025-04-28 11:09:11');
INSERT INTO `bom_masters` VALUES (58, 96, 'A', 1, NULL, '2025-04-28 11:22:12', '2025-04-28 11:22:12');
INSERT INTO `bom_masters` VALUES (59, 99, 'A', 1, NULL, '2025-04-28 11:24:16', '2025-04-28 11:24:16');

-- ----------------------------
-- Table structure for budget_items
-- ----------------------------
DROP TABLE IF EXISTS `budget_items`;
CREATE TABLE `budget_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `budget_id` int NOT NULL COMMENT '预算ID',
  `account_id` int NOT NULL COMMENT '科目ID',
  `period_id` int NOT NULL COMMENT '会计期间ID',
  `budget_amount` decimal(15, 2) NOT NULL COMMENT '预算金额',
  `actual_amount` decimal(15, 2) NULL DEFAULT 0.00 COMMENT '实际金额',
  `variance_amount` decimal(15, 2) NULL DEFAULT 0.00 COMMENT '差异金额',
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `budget_id_2`(`budget_id` ASC, `account_id` ASC, `period_id` ASC) USING BTREE,
  INDEX `budget_id`(`budget_id` ASC) USING BTREE,
  INDEX `account_id`(`account_id` ASC) USING BTREE,
  INDEX `period_id`(`period_id` ASC) USING BTREE,
  CONSTRAINT `budget_items_ibfk_1` FOREIGN KEY (`budget_id`) REFERENCES `budgets` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `budget_items_ibfk_2` FOREIGN KEY (`account_id`) REFERENCES `gl_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `budget_items_ibfk_3` FOREIGN KEY (`period_id`) REFERENCES `gl_periods` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '预算明细表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of budget_items
-- ----------------------------

-- ----------------------------
-- Table structure for budgets
-- ----------------------------
DROP TABLE IF EXISTS `budgets`;
CREATE TABLE `budgets`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `budget_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '预算名称',
  `fiscal_year` int NOT NULL COMMENT '财政年度',
  `start_date` date NOT NULL COMMENT '开始日期',
  `end_date` date NOT NULL COMMENT '结束日期',
  `status` enum('草稿','已提交','已审批','已拒绝','已关闭') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '草稿' COMMENT '状态',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '描述',
  `department_id` int NULL DEFAULT NULL COMMENT '部门ID',
  `created_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '创建人',
  `approved_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '审批人',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `budget_name`(`budget_name` ASC, `fiscal_year` ASC) USING BTREE,
  INDEX `fiscal_year`(`fiscal_year` ASC) USING BTREE,
  INDEX `start_date`(`start_date` ASC) USING BTREE,
  INDEX `end_date`(`end_date` ASC) USING BTREE,
  INDEX `status`(`status` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '预算表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of budgets
-- ----------------------------

-- ----------------------------
-- Table structure for categories
-- ----------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` int NULL DEFAULT 0 COMMENT '父级分类ID',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '分类名称',
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '分类编码',
  `level` int NULL DEFAULT 1 COMMENT '层级',
  `sort` int NULL DEFAULT 0 COMMENT '排序',
  `status` tinyint NULL DEFAULT 1 COMMENT '状态：0-禁用 1-启用',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_parent`(`parent_id` ASC) USING BTREE,
  INDEX `idx_code`(`code` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '产品分类表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of categories
-- ----------------------------
INSERT INTO `categories` VALUES (1, 0, '原材料', 'RAW', 1, 0, 1, NULL, '2025-03-25 15:06:56', '2025-03-28 13:23:16');
INSERT INTO `categories` VALUES (2, 0, '半成品', 'SEMI', 1, 0, 1, NULL, '2025-03-25 15:06:56', '2025-03-25 15:06:56');
INSERT INTO `categories` VALUES (3, 0, '成品', 'FINISHED', 1, 0, 1, NULL, '2025-03-25 15:06:56', '2025-03-25 15:06:56');
INSERT INTO `categories` VALUES (9, 0, 'HRF-M5', 'HRF-M5', 1, 0, 1, '', '2025-04-02 10:26:10', '2025-04-02 10:26:10');

-- ----------------------------
-- Table structure for cost_centers
-- ----------------------------
DROP TABLE IF EXISTS `cost_centers`;
CREATE TABLE `cost_centers`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `center_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '中心代码',
  `center_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '中心名称',
  `parent_id` int NULL DEFAULT NULL COMMENT '父中心ID',
  `department_id` int NULL DEFAULT NULL COMMENT '部门ID',
  `is_active` tinyint(1) NULL DEFAULT 1 COMMENT '是否活跃',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '描述',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `center_code`(`center_code` ASC) USING BTREE,
  INDEX `parent_id`(`parent_id` ASC) USING BTREE,
  INDEX `department_id`(`department_id` ASC) USING BTREE,
  INDEX `is_active`(`is_active` ASC) USING BTREE,
  CONSTRAINT `cost_centers_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `cost_centers` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '成本中心表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of cost_centers
-- ----------------------------

-- ----------------------------
-- Table structure for currencies
-- ----------------------------
DROP TABLE IF EXISTS `currencies`;
CREATE TABLE `currencies`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `currency_code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '货币代码',
  `currency_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '货币名称',
  `symbol` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '符号',
  `is_base_currency` tinyint(1) NULL DEFAULT 0 COMMENT '是否基础货币',
  `exchange_rate` decimal(15, 6) NULL DEFAULT 1.000000 COMMENT '汇率',
  `is_active` tinyint(1) NULL DEFAULT 1 COMMENT '是否活跃',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `currency_code`(`currency_code` ASC) USING BTREE,
  INDEX `is_base_currency`(`is_base_currency` ASC) USING BTREE,
  INDEX `is_active`(`is_active` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '币种表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of currencies
-- ----------------------------
INSERT INTO `currencies` VALUES (1, 'CNY', '人民币', '¥', 1, 1.000000, 1, '2025-04-14 14:44:53', '2025-04-14 14:44:53');
INSERT INTO `currencies` VALUES (2, 'USD', '美元', '$', 0, 6.950000, 1, '2025-04-14 14:44:53', '2025-04-14 14:44:53');
INSERT INTO `currencies` VALUES (3, 'EUR', '欧元', '€', 0, 7.550000, 1, '2025-04-14 14:44:53', '2025-04-14 14:44:53');
INSERT INTO `currencies` VALUES (4, 'JPY', '日元', '¥', 0, 0.063800, 1, '2025-04-14 14:44:53', '2025-04-14 14:44:53');
INSERT INTO `currencies` VALUES (5, 'HKD', '港元', 'HK$', 0, 0.890000, 1, '2025-04-14 14:44:53', '2025-04-14 14:44:53');

-- ----------------------------
-- Table structure for customers
-- ----------------------------
DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `contact_person` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `credit_limit` decimal(15, 2) NULL DEFAULT 0.00,
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `contact_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '联系电话',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of customers
-- ----------------------------
INSERT INTO `customers` VALUES (5, '韩国自动制御株式会社', '钱经理', NULL, '', '', 0.00, 'active', '2025-03-26 14:18:44', '2025-03-27 13:59:24', '13888888888', '');
INSERT INTO `customers` VALUES (6, '浙江凯昆机电有限公司', '赵经理', NULL, '', '', 0.00, 'active', '2025-03-26 14:20:41', '2025-03-27 09:07:42', '12345678910', '');
INSERT INTO `customers` VALUES (7, '温州金宏电器有限公司', '王经理', NULL, '', '', 0.00, 'active', '2025-03-26 14:36:16', '2025-03-27 09:07:17', '1388888888', '');

-- ----------------------------
-- Table structure for departments
-- ----------------------------
DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of departments
-- ----------------------------
INSERT INTO `departments` VALUES (1, '总部', '2025-04-14 20:07:54');
INSERT INTO `departments` VALUES (2, '技术部', '2025-04-14 20:10:47');
INSERT INTO `departments` VALUES (3, '财务部', '2025-04-15 09:21:44');

-- ----------------------------
-- Table structure for entries
-- ----------------------------
DROP TABLE IF EXISTS `entries`;
CREATE TABLE `entries`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `entry_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `entry_date` date NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `status` enum('draft','posted','reversed') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'draft',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `entry_number`(`entry_number` ASC) USING BTREE,
  UNIQUE INDEX `entry_number_2`(`entry_number` ASC) USING BTREE,
  UNIQUE INDEX `entry_number_3`(`entry_number` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of entries
-- ----------------------------

-- ----------------------------
-- Table structure for entry_items
-- ----------------------------
DROP TABLE IF EXISTS `entry_items`;
CREATE TABLE `entry_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `entry_id` int NOT NULL,
  `account_id` int NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `debit_amount` decimal(15, 2) NOT NULL DEFAULT 0.00,
  `credit_amount` decimal(15, 2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `entry_id`(`entry_id` ASC) USING BTREE,
  CONSTRAINT `entry_items_ibfk_1` FOREIGN KEY (`entry_id`) REFERENCES `entries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of entry_items
-- ----------------------------

-- ----------------------------
-- Table structure for fixed_assets
-- ----------------------------
DROP TABLE IF EXISTS `fixed_assets`;
CREATE TABLE `fixed_assets`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `asset_code` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '资产编码',
  `asset_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '资产名称',
  `asset_type` enum('机器设备','电子设备','办公家具','房屋建筑','车辆','其他') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '资产类型',
  `category_id` int NULL DEFAULT NULL COMMENT '资产类别ID',
  `acquisition_date` date NOT NULL COMMENT '取得日期',
  `acquisition_cost` decimal(15, 2) NOT NULL COMMENT '取得成本',
  `depreciation_method` enum('直线法','双倍余额递减法','年数总和法','工作量法','不计提') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '折旧方法',
  `useful_life` int NOT NULL COMMENT '使用年限(月)',
  `salvage_value` decimal(15, 2) NULL DEFAULT 0.00 COMMENT '残值',
  `current_value` decimal(15, 2) NOT NULL COMMENT '当前价值',
  `accumulated_depreciation` decimal(15, 2) NULL DEFAULT 0.00 COMMENT '累计折旧',
  `location_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '存放地点',
  `department_id` int NULL DEFAULT NULL COMMENT '部门ID',
  `custodian` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '保管人',
  `status` enum('在用','闲置','维修','报废','已处置') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '在用' COMMENT '状态',
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `asset_code`(`asset_code` ASC) USING BTREE,
  INDEX `asset_type`(`asset_type` ASC) USING BTREE,
  INDEX `acquisition_date`(`acquisition_date` ASC) USING BTREE,
  INDEX `status`(`status` ASC) USING BTREE,
  INDEX `idx_category_id`(`category_id` ASC) USING BTREE,
  CONSTRAINT `fk_asset_category` FOREIGN KEY (`category_id`) REFERENCES `asset_categories` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '固定资产表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of fixed_assets
-- ----------------------------
INSERT INTO `fixed_assets` VALUES (1, 'FA-2025-001', '笔记本电脑', '电子设备', 1, '2025-01-15', 8000.00, '直线法', 36, 800.00, 8000.00, 0.00, '办公室', 1, NULL, '在用', NULL, '2025-04-16 14:30:53', '2025-04-16 15:38:02');
INSERT INTO `fixed_assets` VALUES (2, 'FA-2025-002', '办公桌椅', '办公家具', 2, '2025-02-01', 3000.00, '直线法', 60, 300.00, 2865.00, 90.00, '办公室', 3, NULL, '闲置', NULL, '2025-04-16 14:30:53', '2025-04-16 16:16:04');
INSERT INTO `fixed_assets` VALUES (3, 'FA-2025-003', '服务器', '电子设备', 1, '2025-01-10', 25000.00, '直线法', 60, 2500.00, 25000.00, 0.00, '机房', 2, NULL, '维修', NULL, '2025-04-16 14:30:53', '2025-04-16 15:42:28');
INSERT INTO `fixed_assets` VALUES (4, 'FA-2025-004', '车辆', '电子设备', 1, '2025-04-16', 565421.00, '直线法', 60, 28271.05, 565421.00, 0.00, '停车场', 3, '王晓敏', '在用', NULL, '2025-04-16 15:03:57', '2025-04-16 15:37:44');
INSERT INTO `fixed_assets` VALUES (6, 'FA-2025-005', '投影仪', '电子设备', NULL, '2025-04-16', 36542.00, '直线法', 60, 1827.10, 33070.52, 2892.90, '会议室', 1, NULL, '在用', NULL, '2025-04-16 15:39:07', '2025-04-16 16:22:57');

-- ----------------------------
-- Table structure for gl_accounts
-- ----------------------------
DROP TABLE IF EXISTS `gl_accounts`;
CREATE TABLE `gl_accounts`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '科目编码',
  `account_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '科目名称',
  `account_type` enum('资产','负债','所有者权益','收入','成本','费用') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '科目类型',
  `parent_id` int NULL DEFAULT NULL COMMENT '父科目ID',
  `is_debit` tinyint(1) NULL DEFAULT 1 COMMENT '是否借方科目',
  `is_active` tinyint(1) NULL DEFAULT 1 COMMENT '是否活跃',
  `currency_code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'CNY' COMMENT '货币代码',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '描述',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `account_code`(`account_code` ASC) USING BTREE,
  INDEX `parent_id`(`parent_id` ASC) USING BTREE,
  CONSTRAINT `gl_accounts_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `gl_accounts` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 32 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '会计科目表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of gl_accounts
-- ----------------------------
INSERT INTO `gl_accounts` VALUES (1, '1001', '库存现金', '资产', NULL, 1, 1, 'CNY', '公司持有的现金', '2025-04-14 14:44:58', '2025-04-14 14:44:58');
INSERT INTO `gl_accounts` VALUES (2, '1002', '银行存款', '资产', NULL, 1, 1, 'CNY', '公司在银行的存款', '2025-04-14 14:44:58', '2025-04-14 14:44:58');
INSERT INTO `gl_accounts` VALUES (3, '1122', '应收账款', '资产', NULL, 1, 1, 'CNY', '企业因销售商品、产品、提供劳务等经营活动,应向购买单位收取的款项', '2025-04-14 14:44:58', '2025-04-14 14:44:58');
INSERT INTO `gl_accounts` VALUES (4, '1401', '材料采购', '资产', NULL, 1, 1, 'CNY', '企业采购材料的采购成本', '2025-04-14 14:44:58', '2025-04-14 14:44:58');
INSERT INTO `gl_accounts` VALUES (5, '1405', '库存商品', '资产', NULL, 1, 1, 'CNY', '企业库存的商品', '2025-04-14 14:44:58', '2025-04-14 14:44:58');
INSERT INTO `gl_accounts` VALUES (6, '1601', '固定资产', '资产', NULL, 1, 1, 'CNY', '企业持有的固定资产', '2025-04-14 14:44:58', '2025-04-14 14:44:58');
INSERT INTO `gl_accounts` VALUES (7, '1602', '累计折旧', '资产', NULL, 0, 1, 'CNY', '企业固定资产的累计折旧', '2025-04-14 14:44:58', '2025-04-14 14:44:58');
INSERT INTO `gl_accounts` VALUES (8, '2202', '应付账款', '负债', NULL, 0, 1, 'CNY', '企业因购买材料、商品和接受劳务供应等经营活动应支付的款项', '2025-04-14 14:44:58', '2025-04-14 14:44:58');
INSERT INTO `gl_accounts` VALUES (9, '3001', '实收资本', '所有者权益', NULL, 0, 1, 'CNY', '企业实际收到的投资者投入的资本', '2025-04-14 14:44:58', '2025-04-14 14:44:58');
INSERT INTO `gl_accounts` VALUES (10, '3103', '本年利润', '所有者权益', NULL, 0, 1, 'CNY', '企业当年的利润', '2025-04-14 14:44:58', '2025-04-14 14:44:58');
INSERT INTO `gl_accounts` VALUES (11, '4001', '主营业务收入', '收入', NULL, 0, 1, 'CNY', '企业销售商品、提供劳务等日常活动取得的收入', '2025-04-14 14:44:58', '2025-04-14 14:44:58');
INSERT INTO `gl_accounts` VALUES (12, '5001', '主营业务成本', '成本', NULL, 1, 1, 'CNY', '企业销售商品、提供劳务等日常活动发生的成本', '2025-04-14 14:44:58', '2025-04-14 14:44:58');
INSERT INTO `gl_accounts` VALUES (13, '6001', '管理费用', '费用', NULL, 1, 1, 'CNY', '企业行政管理部门为组织和管理生产经营活动而发生的各项费用', '2025-04-14 14:44:58', '2025-04-14 14:44:58');
INSERT INTO `gl_accounts` VALUES (14, '6301', '销售费用', '费用', NULL, 1, 1, 'CNY', '企业在销售商品和材料、提供劳务的过程中发生的各种费用', '2025-04-14 14:44:58', '2025-04-14 14:44:58');
INSERT INTO `gl_accounts` VALUES (15, '6601', '财务费用', '费用', NULL, 1, 1, 'CNY', '企业为筹集生产经营所需资金等而发生的筹资费用', '2025-04-14 14:44:58', '2025-04-14 16:39:07');
INSERT INTO `gl_accounts` VALUES (16, '1059', '测试科目', '资产', NULL, 1, 1, 'CNY', NULL, '2025-04-15 11:24:39', '2025-04-15 11:24:39');

-- ----------------------------
-- Table structure for gl_entries
-- ----------------------------
DROP TABLE IF EXISTS `gl_entries`;
CREATE TABLE `gl_entries`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `entry_number` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '分录编号',
  `entry_date` date NOT NULL COMMENT '记账日期',
  `posting_date` date NOT NULL COMMENT '过账日期',
  `document_type` enum('收据','发票','付款单','收款单','转账单','调整单') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '单据类型',
  `document_number` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '单据编号',
  `period_id` int NOT NULL COMMENT '会计期间ID',
  `is_posted` tinyint(1) NULL DEFAULT 0 COMMENT '是否已过账',
  `is_reversed` tinyint(1) NULL DEFAULT 0 COMMENT '是否已冲销',
  `reversal_entry_id` int NULL DEFAULT NULL COMMENT '冲销分录ID',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '描述',
  `created_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '创建人',
  `approved_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '审批人',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `entry_number`(`entry_number` ASC) USING BTREE,
  INDEX `entry_date`(`entry_date` ASC) USING BTREE,
  INDEX `posting_date`(`posting_date` ASC) USING BTREE,
  INDEX `document_number`(`document_number` ASC) USING BTREE,
  INDEX `period_id`(`period_id` ASC) USING BTREE,
  INDEX `reversal_entry_id`(`reversal_entry_id` ASC) USING BTREE,
  CONSTRAINT `gl_entries_ibfk_1` FOREIGN KEY (`reversal_entry_id`) REFERENCES `gl_entries` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '会计分录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of gl_entries
-- ----------------------------
INSERT INTO `gl_entries` VALUES (1, 'GL-TEST-001', '2024-03-20', '2024-03-20', '收据', 'TEST-001', 1, 0, 0, NULL, '测试分录 - 收到现金', 'system', NULL, '2025-04-15 11:20:44', '2025-04-15 11:20:44');
INSERT INTO `gl_entries` VALUES (2, '123123', '2025-04-16', '2025-04-16', '发票', '123213', 5, 1, 0, NULL, NULL, 'current_user', NULL, '2025-04-16 08:14:03', '2025-04-16 09:21:15');
INSERT INTO `gl_entries` VALUES (3, '123213', '2025-04-16', '2025-04-16', '发票', '123123', 5, 1, 1, 4, '123123', 'current_user', NULL, '2025-04-16 08:15:00', '2025-04-16 09:17:50');
INSERT INTO `gl_entries` VALUES (4, 'R-123213', '2025-04-16', '2025-04-16', '发票', '123123', 5, 0, 0, NULL, '冲销分录 123213: 冲销凭证：123213', 'admin', NULL, '2025-04-16 09:17:50', '2025-04-16 09:17:50');
INSERT INTO `gl_entries` VALUES (5, '234234', '2025-04-16', '2025-04-16', '收款单', '234234', 5, 1, 0, NULL, NULL, 'current_user', NULL, '2025-04-16 13:39:43', '2025-04-16 21:57:06');
INSERT INTO `gl_entries` VALUES (11, 'AP-PAY-1744814790148', '2025-04-16', '2025-04-16', '付款单', 'PAY-1744814790148', 1, 0, 0, NULL, '供应商 乐清市朗盛电子科技有限公司 付款', 'system', NULL, '2025-04-16 22:46:32', '2025-04-16 22:46:32');

-- ----------------------------
-- Table structure for gl_entry_items
-- ----------------------------
DROP TABLE IF EXISTS `gl_entry_items`;
CREATE TABLE `gl_entry_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `entry_id` int NOT NULL COMMENT '分录ID',
  `account_id` int NOT NULL COMMENT '科目ID',
  `debit_amount` decimal(15, 2) NULL DEFAULT 0.00 COMMENT '借方金额',
  `credit_amount` decimal(15, 2) NULL DEFAULT 0.00 COMMENT '贷方金额',
  `currency_code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'CNY' COMMENT '货币代码',
  `exchange_rate` decimal(15, 6) NULL DEFAULT 1.000000 COMMENT '汇率',
  `cost_center_id` int NULL DEFAULT NULL COMMENT '成本中心ID',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '描述',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `entry_id`(`entry_id` ASC) USING BTREE,
  INDEX `account_id`(`account_id` ASC) USING BTREE,
  CONSTRAINT `gl_entry_items_ibfk_1` FOREIGN KEY (`entry_id`) REFERENCES `gl_entries` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `gl_entry_items_ibfk_2` FOREIGN KEY (`account_id`) REFERENCES `gl_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '会计分录明细表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of gl_entry_items
-- ----------------------------
INSERT INTO `gl_entry_items` VALUES (1, 1, 1, 1000.00, 0.00, 'CNY', 1.000000, NULL, '收到现金', '2025-04-15 11:20:45');
INSERT INTO `gl_entry_items` VALUES (2, 1, 3, 0.00, 1000.00, 'CNY', 1.000000, NULL, '收到现金', '2025-04-15 11:20:45');
INSERT INTO `gl_entry_items` VALUES (3, 2, 1, 100.00, 0.00, 'CNY', 1.000000, NULL, NULL, '2025-04-16 08:14:03');
INSERT INTO `gl_entry_items` VALUES (4, 2, 1, 0.00, 100.00, 'CNY', 1.000000, NULL, NULL, '2025-04-16 08:14:03');
INSERT INTO `gl_entry_items` VALUES (5, 3, 5, 100.00, 0.00, 'CNY', 1.000000, NULL, NULL, '2025-04-16 08:15:00');
INSERT INTO `gl_entry_items` VALUES (6, 3, 1, 0.00, 100.00, 'CNY', 1.000000, NULL, NULL, '2025-04-16 08:15:00');
INSERT INTO `gl_entry_items` VALUES (7, 4, 5, 0.00, 100.00, 'CNY', 1.000000, NULL, '冲销明细: ', '2025-04-16 09:17:50');
INSERT INTO `gl_entry_items` VALUES (8, 4, 1, 100.00, 0.00, 'CNY', 1.000000, NULL, '冲销明细: ', '2025-04-16 09:17:50');
INSERT INTO `gl_entry_items` VALUES (9, 5, 1, 2000.00, 0.00, 'CNY', 1.000000, NULL, NULL, '2025-04-16 13:39:43');
INSERT INTO `gl_entry_items` VALUES (10, 5, 3, 0.00, 2000.00, 'CNY', 1.000000, NULL, NULL, '2025-04-16 13:39:43');
INSERT INTO `gl_entry_items` VALUES (11, 5, 1, 0.00, 10000.00, 'CNY', 1.000000, NULL, NULL, '2025-04-16 13:39:43');
INSERT INTO `gl_entry_items` VALUES (12, 5, 5, 10000.00, 0.00, 'CNY', 1.000000, NULL, NULL, '2025-04-16 13:39:43');
INSERT INTO `gl_entry_items` VALUES (13, 5, 7, 0.00, 10000.00, 'CNY', 1.000000, NULL, NULL, '2025-04-16 13:39:43');
INSERT INTO `gl_entry_items` VALUES (14, 5, 3, 10000.00, 0.00, 'CNY', 1.000000, NULL, NULL, '2025-04-16 13:39:44');
INSERT INTO `gl_entry_items` VALUES (20, 11, 8, 11300.00, 0.00, 'CNY', 1.000000, NULL, '应付账款减少 - 付款单号: PAY-1744814790148', '2025-04-16 22:46:33');
INSERT INTO `gl_entry_items` VALUES (21, 11, 2, 0.00, 11300.00, 'CNY', 1.000000, NULL, '付款 - 付款单号: PAY-1744814790148', '2025-04-16 22:46:33');

-- ----------------------------
-- Table structure for gl_periods
-- ----------------------------
DROP TABLE IF EXISTS `gl_periods`;
CREATE TABLE `gl_periods`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `period_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '期间名称',
  `start_date` date NOT NULL COMMENT '开始日期',
  `end_date` date NOT NULL COMMENT '结束日期',
  `is_closed` tinyint(1) NULL DEFAULT 0 COMMENT '是否已关闭',
  `is_adjusting` tinyint(1) NULL DEFAULT 0 COMMENT '是否调整期',
  `fiscal_year` int NOT NULL COMMENT '财政年度',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `period_name`(`period_name` ASC, `fiscal_year` ASC) USING BTREE,
  INDEX `start_date`(`start_date` ASC) USING BTREE,
  INDEX `end_date`(`end_date` ASC) USING BTREE,
  INDEX `fiscal_year`(`fiscal_year` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 26 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '会计期间表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of gl_periods
-- ----------------------------
INSERT INTO `gl_periods` VALUES (1, '2025年1月', '2025-01-01', '2025-01-30', 0, 0, 2025, '2025-04-14 14:44:53', '2025-04-14 14:44:53');
INSERT INTO `gl_periods` VALUES (2, '2025年2月', '2025-02-01', '2025-02-27', 0, 0, 2025, '2025-04-14 14:44:54', '2025-04-14 14:44:54');
INSERT INTO `gl_periods` VALUES (3, '2025年3月', '2025-03-01', '2025-03-30', 0, 0, 2025, '2025-04-14 14:44:54', '2025-04-14 14:44:54');
INSERT INTO `gl_periods` VALUES (4, '2025年4月', '2025-04-01', '2025-04-29', 0, 0, 2025, '2025-04-14 14:44:55', '2025-04-14 14:44:55');
INSERT INTO `gl_periods` VALUES (5, '2025年5月', '2025-05-01', '2025-05-30', 0, 0, 2025, '2025-04-14 14:44:55', '2025-04-14 14:44:55');
INSERT INTO `gl_periods` VALUES (6, '2025年6月', '2025-06-01', '2025-06-29', 0, 0, 2025, '2025-04-14 14:44:55', '2025-04-14 14:44:55');
INSERT INTO `gl_periods` VALUES (7, '2025年7月', '2025-07-01', '2025-07-30', 0, 0, 2025, '2025-04-14 14:44:56', '2025-04-14 14:44:56');
INSERT INTO `gl_periods` VALUES (8, '2025年8月', '2025-08-01', '2025-08-30', 0, 0, 2025, '2025-04-14 14:44:56', '2025-04-14 14:44:56');
INSERT INTO `gl_periods` VALUES (9, '2025年9月', '2025-09-01', '2025-09-29', 0, 0, 2025, '2025-04-14 14:44:57', '2025-04-14 14:44:57');
INSERT INTO `gl_periods` VALUES (10, '2025年10月', '2025-10-01', '2025-10-30', 0, 0, 2025, '2025-04-14 14:44:57', '2025-04-14 14:44:57');
INSERT INTO `gl_periods` VALUES (11, '2025年11月', '2025-11-01', '2025-11-29', 0, 0, 2025, '2025-04-14 14:44:57', '2025-04-14 14:44:57');
INSERT INTO `gl_periods` VALUES (12, '2025年12月', '2025-12-01', '2025-12-30', 0, 0, 2025, '2025-04-14 14:44:58', '2025-04-14 14:44:58');

-- ----------------------------
-- Table structure for inspection_items
-- ----------------------------
DROP TABLE IF EXISTS `inspection_items`;
CREATE TABLE `inspection_items`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `item_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '检验项目名称',
  `standard` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '检验标准',
  `type` enum('visual','dimension','function','performance','safety','other') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '检验类型',
  `is_critical` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否关键项',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `standard_id` bigint NULL DEFAULT NULL COMMENT '引用的标准ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 64 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '检验项目表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of inspection_items
-- ----------------------------
INSERT INTO `inspection_items` VALUES (1, '划痕', '123', 'visual', 0, '2025-04-17 18:32:43', '2025-04-17 18:32:43', NULL);
INSERT INTO `inspection_items` VALUES (2, '尺寸', '3243', 'visual', 0, '2025-04-17 18:32:43', '2025-04-17 18:32:43', NULL);
INSERT INTO `inspection_items` VALUES (3, '颜色', '234234', 'visual', 0, '2025-04-17 18:32:43', '2025-04-17 18:32:43', NULL);
INSERT INTO `inspection_items` VALUES (4, '外观', '尺寸', 'visual', 0, '2025-04-17 18:42:35', '2025-04-17 18:42:35', NULL);
INSERT INTO `inspection_items` VALUES (5, '外观', '尺寸', 'visual', 0, '2025-04-17 18:44:10', '2025-04-17 18:44:10', NULL);
INSERT INTO `inspection_items` VALUES (6, '外观', '尺寸', 'visual', 0, '2025-04-17 18:45:31', '2025-04-17 18:45:31', NULL);
INSERT INTO `inspection_items` VALUES (7, '测试', '电机', 'visual', 0, '2025-04-17 18:45:31', '2025-04-17 18:45:31', NULL);
INSERT INTO `inspection_items` VALUES (8, '1', '2', 'visual', 0, '2025-04-18 09:57:41', '2025-04-18 09:57:41', NULL);
INSERT INTO `inspection_items` VALUES (9, '1', '2', 'visual', 0, '2025-04-18 09:58:08', '2025-04-18 09:58:08', NULL);
INSERT INTO `inspection_items` VALUES (10, '1', '2', 'visual', 0, '2025-04-18 09:58:08', '2025-04-18 09:58:08', NULL);
INSERT INTO `inspection_items` VALUES (11, '1', '2', 'visual', 0, '2025-04-18 10:00:20', '2025-04-18 10:00:20', NULL);
INSERT INTO `inspection_items` VALUES (12, '1', '2', 'visual', 0, '2025-04-18 10:00:42', '2025-04-18 10:00:42', NULL);
INSERT INTO `inspection_items` VALUES (13, '外', '2', 'visual', 0, '2025-04-18 10:03:06', '2025-04-18 10:03:06', NULL);
INSERT INTO `inspection_items` VALUES (14, '1', '3', 'performance', 0, '2025-04-18 10:03:06', '2025-04-18 10:03:06', NULL);
INSERT INTO `inspection_items` VALUES (15, 'a', 'a', 'visual', 0, '2025-04-18 14:05:22', '2025-04-18 14:05:22', NULL);
INSERT INTO `inspection_items` VALUES (16, 'C', 'C', 'visual', 0, '2025-04-18 14:05:54', '2025-04-18 14:05:54', NULL);
INSERT INTO `inspection_items` VALUES (17, '外观', '外观', 'visual', 0, '2025-04-18 14:18:39', '2025-04-18 14:18:39', NULL);
INSERT INTO `inspection_items` VALUES (18, '外观', '测试', 'visual', 0, '2025-04-18 14:30:28', '2025-04-18 14:30:28', NULL);
INSERT INTO `inspection_items` VALUES (19, '外观', '测试', 'visual', 0, '2025-04-18 14:30:30', '2025-04-18 14:30:30', NULL);
INSERT INTO `inspection_items` VALUES (20, '测试', '二十', 'visual', 0, '2025-04-18 14:32:55', '2025-04-18 14:32:55', NULL);
INSERT INTO `inspection_items` VALUES (21, '外观检查', '检查产品表面是否有划痕、变形或颜色不均。', 'visual', 0, '2025-04-18 14:39:03', '2025-04-18 14:39:03', NULL);
INSERT INTO `inspection_items` VALUES (22, '功能测试', '验证产品所有功能（如按键、屏幕显示、声音输出）是否正常', 'function', 0, '2025-04-18 14:39:03', '2025-04-18 14:39:03', NULL);
INSERT INTO `inspection_items` VALUES (23, '安全性检测', '检查产品是否符合电气安全标准，如漏电或过热情况。', 'safety', 0, '2025-04-18 14:39:03', '2025-04-18 14:39:03', NULL);
INSERT INTO `inspection_items` VALUES (24, '尺寸精度检查', '使用游标卡尺、千分尺或三坐标测量仪，验证零部件的尺寸', 'visual', 0, '2025-04-18 16:03:33', '2025-04-18 16:03:33', NULL);
INSERT INTO `inspection_items` VALUES (25, '表面质量检测', '检查零部件表面是否有划痕、锈蚀、毛刺或裂纹，确保表面光洁度达到标准', 'function', 0, '2025-04-18 16:03:33', '2025-04-18 16:03:33', NULL);
INSERT INTO `inspection_items` VALUES (26, '123', '123', 'visual', 0, '2025-04-18 16:26:33', '2025-04-18 16:26:33', NULL);
INSERT INTO `inspection_items` VALUES (27, '123', '123', 'visual', 0, '2025-04-22 13:00:24', '2025-04-22 13:00:24', NULL);
INSERT INTO `inspection_items` VALUES (28, '尺寸精度检查', '使用游标卡尺、千分尺或三坐标测量仪，验证零部件的尺寸', 'visual', 0, '2025-04-28 16:45:06', '2025-04-28 16:45:06', NULL);
INSERT INTO `inspection_items` VALUES (29, '表面质量检测', '检查零部件表面是否有划痕、锈蚀、毛刺或裂纹，确保表面光洁度达到标准', 'function', 0, '2025-04-28 16:45:06', '2025-04-28 16:45:06', NULL);
INSERT INTO `inspection_items` VALUES (30, '尺寸精度检查', '使用游标卡尺、千分尺或三坐标测量仪，验证零部件的尺寸', 'visual', 0, '2025-04-28 16:45:12', '2025-04-28 16:45:12', NULL);
INSERT INTO `inspection_items` VALUES (31, '表面质量检测', '检查零部件表面是否有划痕、锈蚀、毛刺或裂纹，确保表面光洁度达到标准', 'function', 0, '2025-04-28 16:45:12', '2025-04-28 16:45:12', NULL);
INSERT INTO `inspection_items` VALUES (32, '123', '123', 'visual', 0, '2025-04-28 16:45:19', '2025-04-28 16:45:19', NULL);
INSERT INTO `inspection_items` VALUES (33, '外观检查', '检查产品表面是否有划痕、变形或颜色不均。', 'visual', 0, '2025-04-28 16:45:27', '2025-04-28 16:45:27', NULL);
INSERT INTO `inspection_items` VALUES (34, '功能测试', '验证产品所有功能（如按键、屏幕显示、声音输出）是否正常', 'function', 0, '2025-04-28 16:45:27', '2025-04-28 16:45:27', NULL);
INSERT INTO `inspection_items` VALUES (35, '安全性检测', '检查产品是否符合电气安全标准，如漏电或过热情况。', 'safety', 0, '2025-04-28 16:45:27', '2025-04-28 16:45:27', NULL);
INSERT INTO `inspection_items` VALUES (36, '外观检查', '检查产品表面是否有划痕、变形或颜色不均。', 'visual', 0, '2025-04-28 16:45:34', '2025-04-28 16:45:34', NULL);
INSERT INTO `inspection_items` VALUES (37, '功能测试', '验证产品所有功能（如按键、屏幕显示、声音输出）是否正常', 'function', 0, '2025-04-28 16:45:34', '2025-04-28 16:45:34', NULL);
INSERT INTO `inspection_items` VALUES (38, '安全性检测', '检查产品是否符合电气安全标准，如漏电或过热情况。', 'safety', 0, '2025-04-28 16:45:34', '2025-04-28 16:45:34', NULL);
INSERT INTO `inspection_items` VALUES (39, '检验项目列表', '以不同力度和频率踩踏脚踏开关，', 'visual', 1, '2025-04-28 16:55:15', '2025-04-28 16:55:15', NULL);
INSERT INTO `inspection_items` VALUES (40, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '2025-04-28 16:55:15', '2025-04-28 16:55:15', NULL);
INSERT INTO `inspection_items` VALUES (41, '防水性能测试', '将脚踏开关置于IPX4等级的喷水环境中', 'function', 1, '2025-04-28 16:55:15', '2025-04-28 16:55:15', NULL);
INSERT INTO `inspection_items` VALUES (42, '检验项目列表', '以不同力度和频率踩踏脚踏开关，', 'visual', 1, '2025-04-28 16:58:33', '2025-04-28 16:58:33', NULL);
INSERT INTO `inspection_items` VALUES (43, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '2025-04-28 16:58:33', '2025-04-28 16:58:33', NULL);
INSERT INTO `inspection_items` VALUES (44, '防水性能测试', '将脚踏开关置于IPX4等级的喷水环境中', 'function', 1, '2025-04-28 16:58:33', '2025-04-28 16:58:33', NULL);
INSERT INTO `inspection_items` VALUES (45, '检验项目列表', '以不同力度和频率踩踏脚踏开关，', 'visual', 1, '2025-04-29 15:53:10', '2025-04-29 15:53:10', NULL);
INSERT INTO `inspection_items` VALUES (46, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '2025-04-29 15:53:10', '2025-04-29 15:53:10', NULL);
INSERT INTO `inspection_items` VALUES (47, '防水性能测试', '将脚踏开关置于IPX4等级的喷水环境中', 'function', 1, '2025-04-29 15:53:10', '2025-04-29 15:53:10', NULL);
INSERT INTO `inspection_items` VALUES (48, '检验项目列表', '以不同力度和频率踩踏脚踏开关，', 'visual', 1, '2025-04-29 15:53:26', '2025-04-29 15:53:26', NULL);
INSERT INTO `inspection_items` VALUES (49, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '2025-04-29 15:53:26', '2025-04-29 15:53:26', NULL);
INSERT INTO `inspection_items` VALUES (50, '防水性能测试', '将脚踏开关置于IPX4等级的喷水环境中', 'function', 1, '2025-04-29 15:53:26', '2025-04-29 15:53:26', NULL);
INSERT INTO `inspection_items` VALUES (51, '检验项目列表', '以不同力度和频率踩踏脚踏开关，', 'visual', 1, '2025-04-29 15:53:33', '2025-04-29 15:53:33', NULL);
INSERT INTO `inspection_items` VALUES (52, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '2025-04-29 15:53:33', '2025-04-29 15:53:33', NULL);
INSERT INTO `inspection_items` VALUES (53, '防水性能测试', '将脚踏开关置于IPX4等级的喷水环境中', 'function', 1, '2025-04-29 15:53:33', '2025-04-29 15:53:33', NULL);
INSERT INTO `inspection_items` VALUES (54, '外观', '外观检查', 'visual', 0, '2025-04-29 15:59:59', '2025-04-29 15:59:59', NULL);
INSERT INTO `inspection_items` VALUES (55, '性能', '性能检查', 'function', 0, '2025-04-29 15:59:59', '2025-04-29 15:59:59', NULL);
INSERT INTO `inspection_items` VALUES (56, '包装', '包装检查', 'other', 0, '2025-04-29 15:59:59', '2025-04-29 15:59:59', NULL);
INSERT INTO `inspection_items` VALUES (57, '外观', '外观检查', 'visual', 0, '2025-04-29 16:27:57', '2025-04-29 16:27:57', NULL);
INSERT INTO `inspection_items` VALUES (58, '性能', '性能检查', 'function', 0, '2025-04-29 16:27:57', '2025-04-29 16:27:57', NULL);
INSERT INTO `inspection_items` VALUES (59, '包装', '包装检查', 'other', 0, '2025-04-29 16:27:57', '2025-04-29 16:27:57', NULL);
INSERT INTO `inspection_items` VALUES (60, '外观', '外观检查', 'visual', 0, '2025-04-29 16:28:05', '2025-04-29 16:28:05', NULL);
INSERT INTO `inspection_items` VALUES (61, '性能', '性能检查', 'function', 0, '2025-04-29 16:28:05', '2025-04-29 16:28:05', NULL);
INSERT INTO `inspection_items` VALUES (62, '包装', '包装检查', 'other', 0, '2025-04-29 16:28:05', '2025-04-29 16:28:05', NULL);
INSERT INTO `inspection_items` VALUES (63, '测试', '测试', 'visual', 0, '2025-04-29 16:29:02', '2025-04-29 16:29:02', NULL);

-- ----------------------------
-- Table structure for inspection_templates
-- ----------------------------
DROP TABLE IF EXISTS `inspection_templates`;
CREATE TABLE `inspection_templates`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `template_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '模板编号',
  `template_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '模板名称',
  `inspection_type` enum('incoming','process','final') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '检验类型：来料/过程/成品',
  `material_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '适用物料类型',
  `version` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '版本号',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '模板描述',
  `status` enum('active','inactive','draft') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'draft' COMMENT '状态：启用/停用/草稿',
  `created_by` bigint NOT NULL COMMENT '创建人ID',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_template_code`(`template_code` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 17 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '检验模板表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of inspection_templates
-- ----------------------------
INSERT INTO `inspection_templates` VALUES (12, 'IT1745830515926561', '脚踏开关', 'final', '97', 'A', '', 'active', 1, '2025-04-28 16:55:15', '2025-04-29 15:53:33');
INSERT INTO `inspection_templates` VALUES (13, 'IT1745913599907809', '105215037', 'final', '99', 'A', '', 'active', 1, '2025-04-29 15:59:59', '2025-04-29 16:28:05');
INSERT INTO `inspection_templates` VALUES (15, 'IT1746862012886101', '零部件', 'incoming', '101', 'A', '', 'active', 1, '2025-05-10 15:26:52', '2025-05-10 18:55:38');
INSERT INTO `inspection_templates` VALUES (16, 'IT1746874105617074', '蓝色踏板', 'incoming', '98', 'A', '', 'active', 1, '2025-05-10 18:48:25', '2025-05-10 18:57:16');

-- ----------------------------
-- Table structure for inventory
-- ----------------------------
DROP TABLE IF EXISTS `inventory`;
CREATE TABLE `inventory`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `quantity` decimal(10, 2) NOT NULL DEFAULT 0.00,
  `unit` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 98 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of inventory
-- ----------------------------
INSERT INTO `inventory` VALUES (4, 'Raw Material A', 100.00, 'kg', 'in-stock', '2025-03-31 12:51:17', '2025-03-31 12:51:17');
INSERT INTO `inventory` VALUES (5, 'Raw Material B', 50.00, 'liters', 'in-stock', '2025-03-31 12:51:17', '2025-03-31 12:51:17');
INSERT INTO `inventory` VALUES (6, 'Product X', 30.00, 'pieces', 'finished-goods', '2025-03-31 12:51:17', '2025-03-31 12:51:17');
INSERT INTO `inventory` VALUES (96, '脚踏开关', 0.00, '个', 'available', '2025-05-06 14:13:15', '2025-05-06 14:13:15');
INSERT INTO `inventory` VALUES (97, '脚踏开关', 0.00, '个', 'available', '2025-05-06 14:14:27', '2025-05-06 14:14:27');

-- ----------------------------
-- Table structure for inventory_inbound
-- ----------------------------
DROP TABLE IF EXISTS `inventory_inbound`;
CREATE TABLE `inventory_inbound`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `inbound_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '入库单号',
  `inbound_date` date NOT NULL COMMENT '入库日期',
  `location_id` int NOT NULL COMMENT '仓库ID',
  `status` enum('draft','confirmed','completed','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'draft' COMMENT '状态：draft-草稿，confirmed-已确认，completed-已完成，cancelled-已取消',
  `total_amount` decimal(10, 2) NULL DEFAULT 0.00 COMMENT '总数量',
  `total_amount_unit` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '总数量单位',
  `operator` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '操作人',
  `inspection_id` int NULL DEFAULT NULL COMMENT '质检单ID',
  `inspection_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '质检单号',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `created_by` int NULL DEFAULT NULL COMMENT '创建人ID',
  `updated_by` int NULL DEFAULT NULL COMMENT '更新人ID',
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否删除：0-否，1-是',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `inbound_no`(`inbound_no` ASC) USING BTREE,
  INDEX `idx_location_id`(`location_id` ASC) USING BTREE,
  INDEX `idx_inbound_date`(`inbound_date` ASC) USING BTREE,
  INDEX `idx_status`(`status` ASC) USING BTREE,
  CONSTRAINT `fk_inbound_location` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 98 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '入库单主表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of inventory_inbound
-- ----------------------------
INSERT INTO `inventory_inbound` VALUES (90, 'RK20250509001', '2025-05-09', 2, 'completed', 0.00, NULL, '王晓敏', NULL, NULL, '', '2025-05-09 09:36:04', '2025-05-09 09:36:19', NULL, NULL, 0);
INSERT INTO `inventory_inbound` VALUES (91, 'RK20250509002', '2025-05-09', 2, 'completed', 0.00, NULL, '王晓敏', NULL, NULL, '', '2025-05-09 10:14:38', '2025-05-09 10:19:07', NULL, NULL, 0);
INSERT INTO `inventory_inbound` VALUES (92, 'RK20250509003', '2025-05-09', 2, 'cancelled', 0.00, NULL, '王晓敏', NULL, NULL, '', '2025-05-09 10:16:11', '2025-05-10 08:47:56', NULL, NULL, 0);
INSERT INTO `inventory_inbound` VALUES (94, 'RK20250509004', '2025-05-09', 2, 'cancelled', 0.00, NULL, '王晓敏', NULL, NULL, '', '2025-05-09 10:17:16', '2025-05-10 08:47:54', NULL, NULL, 0);
INSERT INTO `inventory_inbound` VALUES (97, 'RK20250510001', '2025-05-10', 3, 'completed', 0.00, NULL, 'admin', 146, 'FQC20250510001', '从质检单 FQC20250510001 自动生成入库单', '2025-05-10 11:31:38', '2025-05-10 11:31:52', NULL, NULL, 0);

-- ----------------------------
-- Table structure for inventory_inbound_items
-- ----------------------------
DROP TABLE IF EXISTS `inventory_inbound_items`;
CREATE TABLE `inventory_inbound_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `inbound_id` int NOT NULL,
  `material_id` int NOT NULL,
  `material_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `material_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `specification` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `quantity` decimal(10, 2) NOT NULL,
  `unit` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `unit_id` int NOT NULL,
  `inspection_item_id` int NULL DEFAULT NULL,
  `location_id` int NOT NULL,
  `batch_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '批次号',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `inbound_id`(`inbound_id` ASC) USING BTREE,
  INDEX `material_id`(`material_id` ASC) USING BTREE,
  INDEX `unit_id`(`unit_id` ASC) USING BTREE,
  INDEX `location_id`(`location_id` ASC) USING BTREE,
  CONSTRAINT `inventory_inbound_items_ibfk_1` FOREIGN KEY (`inbound_id`) REFERENCES `inventory_inbound` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `inventory_inbound_items_ibfk_2` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `inventory_inbound_items_ibfk_3` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `inventory_inbound_items_ibfk_4` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 271 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of inventory_inbound_items
-- ----------------------------
INSERT INTO `inventory_inbound_items` VALUES (155, 90, 98, NULL, NULL, NULL, 1000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 09:36:06', '2025-05-09 09:36:06');
INSERT INTO `inventory_inbound_items` VALUES (156, 91, 101, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:40', '2025-05-09 10:14:40');
INSERT INTO `inventory_inbound_items` VALUES (157, 91, 98, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:41', '2025-05-09 10:14:41');
INSERT INTO `inventory_inbound_items` VALUES (158, 91, 95, NULL, NULL, NULL, 4000.00, NULL, 10, NULL, 2, NULL, NULL, '2025-05-09 10:14:41', '2025-05-09 10:14:41');
INSERT INTO `inventory_inbound_items` VALUES (159, 91, 94, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:42', '2025-05-09 10:14:42');
INSERT INTO `inventory_inbound_items` VALUES (160, 91, 93, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:43', '2025-05-09 10:14:43');
INSERT INTO `inventory_inbound_items` VALUES (161, 91, 92, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:43', '2025-05-09 10:14:43');
INSERT INTO `inventory_inbound_items` VALUES (162, 91, 91, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:44', '2025-05-09 10:14:44');
INSERT INTO `inventory_inbound_items` VALUES (163, 91, 90, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:45', '2025-05-09 10:14:45');
INSERT INTO `inventory_inbound_items` VALUES (164, 91, 89, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:46', '2025-05-09 10:14:46');
INSERT INTO `inventory_inbound_items` VALUES (165, 91, 88, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:46', '2025-05-09 10:14:46');
INSERT INTO `inventory_inbound_items` VALUES (166, 91, 87, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:47', '2025-05-09 10:14:47');
INSERT INTO `inventory_inbound_items` VALUES (167, 91, 86, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:48', '2025-05-09 10:14:48');
INSERT INTO `inventory_inbound_items` VALUES (168, 91, 85, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:48', '2025-05-09 10:14:48');
INSERT INTO `inventory_inbound_items` VALUES (169, 91, 84, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:49', '2025-05-09 10:14:49');
INSERT INTO `inventory_inbound_items` VALUES (170, 91, 83, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:50', '2025-05-09 10:14:50');
INSERT INTO `inventory_inbound_items` VALUES (171, 91, 82, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:51', '2025-05-09 10:14:51');
INSERT INTO `inventory_inbound_items` VALUES (172, 91, 81, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:51', '2025-05-09 10:14:51');
INSERT INTO `inventory_inbound_items` VALUES (173, 91, 80, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:52', '2025-05-09 10:14:52');
INSERT INTO `inventory_inbound_items` VALUES (174, 91, 79, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:53', '2025-05-09 10:14:53');
INSERT INTO `inventory_inbound_items` VALUES (175, 91, 78, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:53', '2025-05-09 10:14:53');
INSERT INTO `inventory_inbound_items` VALUES (176, 91, 77, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:54', '2025-05-09 10:14:54');
INSERT INTO `inventory_inbound_items` VALUES (177, 91, 76, NULL, NULL, NULL, 4000.00, NULL, 7, NULL, 2, NULL, NULL, '2025-05-09 10:14:55', '2025-05-09 10:14:55');
INSERT INTO `inventory_inbound_items` VALUES (178, 91, 75, NULL, NULL, NULL, 4000.00, NULL, 10, NULL, 2, NULL, NULL, '2025-05-09 10:14:55', '2025-05-09 10:14:55');
INSERT INTO `inventory_inbound_items` VALUES (179, 91, 74, NULL, NULL, NULL, 4000.00, NULL, 10, NULL, 2, NULL, NULL, '2025-05-09 10:14:56', '2025-05-09 10:14:56');
INSERT INTO `inventory_inbound_items` VALUES (180, 91, 73, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:57', '2025-05-09 10:14:57');
INSERT INTO `inventory_inbound_items` VALUES (181, 91, 72, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:58', '2025-05-09 10:14:58');
INSERT INTO `inventory_inbound_items` VALUES (182, 91, 71, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:58', '2025-05-09 10:14:58');
INSERT INTO `inventory_inbound_items` VALUES (183, 91, 70, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:14:59', '2025-05-09 10:14:59');
INSERT INTO `inventory_inbound_items` VALUES (184, 91, 69, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:15:00', '2025-05-09 10:15:00');
INSERT INTO `inventory_inbound_items` VALUES (185, 91, 68, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:15:01', '2025-05-09 10:15:01');
INSERT INTO `inventory_inbound_items` VALUES (186, 91, 67, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:15:01', '2025-05-09 10:15:01');
INSERT INTO `inventory_inbound_items` VALUES (187, 91, 66, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:15:02', '2025-05-09 10:15:02');
INSERT INTO `inventory_inbound_items` VALUES (188, 91, 65, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:15:03', '2025-05-09 10:15:03');
INSERT INTO `inventory_inbound_items` VALUES (189, 91, 64, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:15:03', '2025-05-09 10:15:03');
INSERT INTO `inventory_inbound_items` VALUES (190, 91, 63, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:15:04', '2025-05-09 10:15:04');
INSERT INTO `inventory_inbound_items` VALUES (191, 91, 62, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:15:05', '2025-05-09 10:15:05');
INSERT INTO `inventory_inbound_items` VALUES (192, 91, 61, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:15:06', '2025-05-09 10:15:06');
INSERT INTO `inventory_inbound_items` VALUES (193, 91, 60, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:15:06', '2025-05-09 10:15:06');
INSERT INTO `inventory_inbound_items` VALUES (194, 92, 101, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:11', '2025-05-09 10:16:11');
INSERT INTO `inventory_inbound_items` VALUES (195, 92, 98, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:12', '2025-05-09 10:16:12');
INSERT INTO `inventory_inbound_items` VALUES (196, 92, 95, NULL, NULL, NULL, 4000.00, NULL, 10, NULL, 2, NULL, NULL, '2025-05-09 10:16:13', '2025-05-09 10:16:13');
INSERT INTO `inventory_inbound_items` VALUES (197, 92, 94, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:14', '2025-05-09 10:16:14');
INSERT INTO `inventory_inbound_items` VALUES (198, 92, 93, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:14', '2025-05-09 10:16:14');
INSERT INTO `inventory_inbound_items` VALUES (199, 92, 92, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:15', '2025-05-09 10:16:15');
INSERT INTO `inventory_inbound_items` VALUES (200, 92, 91, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:16', '2025-05-09 10:16:16');
INSERT INTO `inventory_inbound_items` VALUES (201, 92, 90, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:17', '2025-05-09 10:16:17');
INSERT INTO `inventory_inbound_items` VALUES (202, 92, 89, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:17', '2025-05-09 10:16:17');
INSERT INTO `inventory_inbound_items` VALUES (203, 92, 88, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:18', '2025-05-09 10:16:18');
INSERT INTO `inventory_inbound_items` VALUES (204, 92, 87, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:19', '2025-05-09 10:16:19');
INSERT INTO `inventory_inbound_items` VALUES (205, 92, 86, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:19', '2025-05-09 10:16:19');
INSERT INTO `inventory_inbound_items` VALUES (206, 92, 85, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:20', '2025-05-09 10:16:20');
INSERT INTO `inventory_inbound_items` VALUES (207, 92, 84, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:21', '2025-05-09 10:16:21');
INSERT INTO `inventory_inbound_items` VALUES (208, 92, 83, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:22', '2025-05-09 10:16:22');
INSERT INTO `inventory_inbound_items` VALUES (209, 92, 82, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:22', '2025-05-09 10:16:22');
INSERT INTO `inventory_inbound_items` VALUES (210, 92, 81, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:24', '2025-05-09 10:16:24');
INSERT INTO `inventory_inbound_items` VALUES (211, 92, 80, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:25', '2025-05-09 10:16:25');
INSERT INTO `inventory_inbound_items` VALUES (212, 92, 79, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:26', '2025-05-09 10:16:26');
INSERT INTO `inventory_inbound_items` VALUES (213, 92, 78, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:27', '2025-05-09 10:16:27');
INSERT INTO `inventory_inbound_items` VALUES (214, 92, 77, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:28', '2025-05-09 10:16:28');
INSERT INTO `inventory_inbound_items` VALUES (215, 92, 76, NULL, NULL, NULL, 4000.00, NULL, 7, NULL, 2, NULL, NULL, '2025-05-09 10:16:30', '2025-05-09 10:16:30');
INSERT INTO `inventory_inbound_items` VALUES (216, 92, 75, NULL, NULL, NULL, 4000.00, NULL, 10, NULL, 2, NULL, NULL, '2025-05-09 10:16:31', '2025-05-09 10:16:31');
INSERT INTO `inventory_inbound_items` VALUES (217, 92, 74, NULL, NULL, NULL, 4000.00, NULL, 10, NULL, 2, NULL, NULL, '2025-05-09 10:16:32', '2025-05-09 10:16:32');
INSERT INTO `inventory_inbound_items` VALUES (218, 92, 73, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:33', '2025-05-09 10:16:33');
INSERT INTO `inventory_inbound_items` VALUES (219, 92, 72, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:35', '2025-05-09 10:16:35');
INSERT INTO `inventory_inbound_items` VALUES (220, 92, 71, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:36', '2025-05-09 10:16:36');
INSERT INTO `inventory_inbound_items` VALUES (221, 92, 70, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:37', '2025-05-09 10:16:37');
INSERT INTO `inventory_inbound_items` VALUES (222, 92, 69, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:39', '2025-05-09 10:16:39');
INSERT INTO `inventory_inbound_items` VALUES (223, 92, 68, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:39', '2025-05-09 10:16:39');
INSERT INTO `inventory_inbound_items` VALUES (224, 92, 67, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:40', '2025-05-09 10:16:40');
INSERT INTO `inventory_inbound_items` VALUES (225, 92, 66, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:41', '2025-05-09 10:16:41');
INSERT INTO `inventory_inbound_items` VALUES (226, 92, 65, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:42', '2025-05-09 10:16:42');
INSERT INTO `inventory_inbound_items` VALUES (227, 92, 64, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:43', '2025-05-09 10:16:43');
INSERT INTO `inventory_inbound_items` VALUES (228, 92, 63, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:44', '2025-05-09 10:16:44');
INSERT INTO `inventory_inbound_items` VALUES (229, 92, 62, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:45', '2025-05-09 10:16:45');
INSERT INTO `inventory_inbound_items` VALUES (230, 92, 61, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:46', '2025-05-09 10:16:46');
INSERT INTO `inventory_inbound_items` VALUES (231, 92, 60, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:16:47', '2025-05-09 10:16:47');
INSERT INTO `inventory_inbound_items` VALUES (232, 94, 101, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:18', '2025-05-09 10:17:18');
INSERT INTO `inventory_inbound_items` VALUES (233, 94, 98, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:18', '2025-05-09 10:17:18');
INSERT INTO `inventory_inbound_items` VALUES (234, 94, 95, NULL, NULL, NULL, 4000.00, NULL, 10, NULL, 2, NULL, NULL, '2025-05-09 10:17:19', '2025-05-09 10:17:19');
INSERT INTO `inventory_inbound_items` VALUES (235, 94, 94, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:20', '2025-05-09 10:17:20');
INSERT INTO `inventory_inbound_items` VALUES (236, 94, 93, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:20', '2025-05-09 10:17:20');
INSERT INTO `inventory_inbound_items` VALUES (237, 94, 92, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:21', '2025-05-09 10:17:21');
INSERT INTO `inventory_inbound_items` VALUES (238, 94, 91, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:22', '2025-05-09 10:17:22');
INSERT INTO `inventory_inbound_items` VALUES (239, 94, 90, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:23', '2025-05-09 10:17:23');
INSERT INTO `inventory_inbound_items` VALUES (240, 94, 89, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:23', '2025-05-09 10:17:23');
INSERT INTO `inventory_inbound_items` VALUES (241, 94, 88, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:24', '2025-05-09 10:17:24');
INSERT INTO `inventory_inbound_items` VALUES (242, 94, 87, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:25', '2025-05-09 10:17:25');
INSERT INTO `inventory_inbound_items` VALUES (243, 94, 86, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:25', '2025-05-09 10:17:25');
INSERT INTO `inventory_inbound_items` VALUES (244, 94, 85, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:26', '2025-05-09 10:17:26');
INSERT INTO `inventory_inbound_items` VALUES (245, 94, 84, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:27', '2025-05-09 10:17:27');
INSERT INTO `inventory_inbound_items` VALUES (246, 94, 83, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:28', '2025-05-09 10:17:28');
INSERT INTO `inventory_inbound_items` VALUES (247, 94, 82, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:28', '2025-05-09 10:17:28');
INSERT INTO `inventory_inbound_items` VALUES (248, 94, 81, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:29', '2025-05-09 10:17:29');
INSERT INTO `inventory_inbound_items` VALUES (249, 94, 80, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:30', '2025-05-09 10:17:30');
INSERT INTO `inventory_inbound_items` VALUES (250, 94, 79, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:30', '2025-05-09 10:17:30');
INSERT INTO `inventory_inbound_items` VALUES (251, 94, 78, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:31', '2025-05-09 10:17:31');
INSERT INTO `inventory_inbound_items` VALUES (252, 94, 77, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:32', '2025-05-09 10:17:32');
INSERT INTO `inventory_inbound_items` VALUES (253, 94, 76, NULL, NULL, NULL, 4000.00, NULL, 7, NULL, 2, NULL, NULL, '2025-05-09 10:17:33', '2025-05-09 10:17:33');
INSERT INTO `inventory_inbound_items` VALUES (254, 94, 75, NULL, NULL, NULL, 4000.00, NULL, 10, NULL, 2, NULL, NULL, '2025-05-09 10:17:33', '2025-05-09 10:17:33');
INSERT INTO `inventory_inbound_items` VALUES (255, 94, 74, NULL, NULL, NULL, 4000.00, NULL, 10, NULL, 2, NULL, NULL, '2025-05-09 10:17:34', '2025-05-09 10:17:34');
INSERT INTO `inventory_inbound_items` VALUES (256, 94, 73, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:35', '2025-05-09 10:17:35');
INSERT INTO `inventory_inbound_items` VALUES (257, 94, 72, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:35', '2025-05-09 10:17:35');
INSERT INTO `inventory_inbound_items` VALUES (258, 94, 71, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:36', '2025-05-09 10:17:36');
INSERT INTO `inventory_inbound_items` VALUES (259, 94, 70, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:37', '2025-05-09 10:17:37');
INSERT INTO `inventory_inbound_items` VALUES (260, 94, 69, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:38', '2025-05-09 10:17:38');
INSERT INTO `inventory_inbound_items` VALUES (261, 94, 68, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:38', '2025-05-09 10:17:38');
INSERT INTO `inventory_inbound_items` VALUES (262, 94, 67, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:39', '2025-05-09 10:17:39');
INSERT INTO `inventory_inbound_items` VALUES (263, 94, 66, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:40', '2025-05-09 10:17:40');
INSERT INTO `inventory_inbound_items` VALUES (264, 94, 65, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:40', '2025-05-09 10:17:40');
INSERT INTO `inventory_inbound_items` VALUES (265, 94, 64, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:41', '2025-05-09 10:17:41');
INSERT INTO `inventory_inbound_items` VALUES (266, 94, 63, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:42', '2025-05-09 10:17:42');
INSERT INTO `inventory_inbound_items` VALUES (267, 94, 62, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:43', '2025-05-09 10:17:43');
INSERT INTO `inventory_inbound_items` VALUES (268, 94, 61, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:43', '2025-05-09 10:17:43');
INSERT INTO `inventory_inbound_items` VALUES (269, 94, 60, NULL, NULL, NULL, 4000.00, NULL, 1, NULL, 2, NULL, NULL, '2025-05-09 10:17:44', '2025-05-09 10:17:44');
INSERT INTO `inventory_inbound_items` VALUES (270, 97, 99, NULL, NULL, NULL, 2.00, NULL, 1, NULL, 3, NULL, NULL, '2025-05-10 11:31:38', '2025-05-10 11:31:38');

-- ----------------------------
-- Table structure for inventory_locations
-- ----------------------------
DROP TABLE IF EXISTS `inventory_locations`;
CREATE TABLE `inventory_locations`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '仓库编码',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '仓库名称',
  `address` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '仓库地址',
  `manager` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '负责人',
  `contact` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '联系方式',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '状态: 0-禁用 1-启用',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `code`(`code` ASC) USING BTREE,
  INDEX `status`(`status` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of inventory_locations
-- ----------------------------

-- ----------------------------
-- Table structure for inventory_outbound
-- ----------------------------
DROP TABLE IF EXISTS `inventory_outbound`;
CREATE TABLE `inventory_outbound`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `outbound_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `outbound_date` date NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'draft',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `operator` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `reference_id` int NULL DEFAULT NULL,
  `reference_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_outbound_no`(`outbound_no` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 28 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '出库单主表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of inventory_outbound
-- ----------------------------
INSERT INTO `inventory_outbound` VALUES (18, 'OUT20250509001', '2025-05-09', 'completed', NULL, 'admin', '2025-05-09 10:24:31', '2025-05-09 10:24:36', NULL, NULL);
INSERT INTO `inventory_outbound` VALUES (19, 'OUT20250509002', '2025-05-09', 'confirmed', NULL, 'admin', '2025-05-09 11:27:30', '2025-05-09 11:29:31', NULL, NULL);
INSERT INTO `inventory_outbound` VALUES (20, 'OUT20250509003', '2025-05-09', 'cancelled', NULL, 'admin', '2025-05-09 11:28:00', '2025-05-09 12:54:44', NULL, NULL);
INSERT INTO `inventory_outbound` VALUES (26, 'OUT20250510001', '2025-05-10', 'completed', NULL, 'admin', '2025-05-10 09:03:37', '2025-05-10 09:03:56', NULL, NULL);
INSERT INTO `inventory_outbound` VALUES (27, 'OUT20250510002', '2025-05-10', 'completed', NULL, 'admin', '2025-05-10 11:30:08', '2025-05-10 11:30:36', 199, 'production_plan');

-- ----------------------------
-- Table structure for inventory_outbound_items
-- ----------------------------
DROP TABLE IF EXISTS `inventory_outbound_items`;
CREATE TABLE `inventory_outbound_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `outbound_id` int NOT NULL,
  `material_id` int NOT NULL,
  `quantity` decimal(10, 2) NOT NULL,
  `unit_id` int NOT NULL,
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_outbound_items_outbound`(`outbound_id` ASC) USING BTREE,
  INDEX `fk_outbound_items_material`(`material_id` ASC) USING BTREE,
  INDEX `fk_outbound_items_unit`(`unit_id` ASC) USING BTREE,
  CONSTRAINT `fk_outbound_items_material` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_outbound_items_outbound` FOREIGN KEY (`outbound_id`) REFERENCES `inventory_outbound` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_outbound_items_unit` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 191 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '出库单明细表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of inventory_outbound_items
-- ----------------------------
INSERT INTO `inventory_outbound_items` VALUES (96, 18, 77, 2000.00, 1, NULL, '2025-05-09 10:24:31', '2025-05-09 10:24:31');
INSERT INTO `inventory_outbound_items` VALUES (97, 18, 78, 2000.00, 1, NULL, '2025-05-09 10:24:31', '2025-05-09 10:24:31');
INSERT INTO `inventory_outbound_items` VALUES (98, 18, 79, 2000.00, 1, NULL, '2025-05-09 10:24:31', '2025-05-09 10:24:31');
INSERT INTO `inventory_outbound_items` VALUES (99, 18, 80, 2000.00, 1, NULL, '2025-05-09 10:24:31', '2025-05-09 10:24:31');
INSERT INTO `inventory_outbound_items` VALUES (100, 18, 81, 2000.00, 1, NULL, '2025-05-09 10:24:31', '2025-05-09 10:24:31');
INSERT INTO `inventory_outbound_items` VALUES (101, 18, 98, 2000.00, 1, NULL, '2025-05-09 10:24:31', '2025-05-09 10:24:31');
INSERT INTO `inventory_outbound_items` VALUES (102, 18, 83, 2000.00, 1, NULL, '2025-05-09 10:24:31', '2025-05-09 10:24:31');
INSERT INTO `inventory_outbound_items` VALUES (103, 18, 84, 2000.00, 1, NULL, '2025-05-09 10:24:31', '2025-05-09 10:24:31');
INSERT INTO `inventory_outbound_items` VALUES (104, 18, 85, 2000.00, 1, NULL, '2025-05-09 10:24:31', '2025-05-09 10:24:31');
INSERT INTO `inventory_outbound_items` VALUES (105, 18, 86, 2000.00, 1, NULL, '2025-05-09 10:24:31', '2025-05-09 10:24:31');
INSERT INTO `inventory_outbound_items` VALUES (106, 18, 87, 2000.00, 1, NULL, '2025-05-09 10:24:31', '2025-05-09 10:24:31');
INSERT INTO `inventory_outbound_items` VALUES (107, 18, 88, 2000.00, 1, NULL, '2025-05-09 10:24:31', '2025-05-09 10:24:31');
INSERT INTO `inventory_outbound_items` VALUES (108, 18, 89, 2000.00, 1, NULL, '2025-05-09 10:24:31', '2025-05-09 10:24:31');
INSERT INTO `inventory_outbound_items` VALUES (109, 18, 90, 2000.00, 1, NULL, '2025-05-09 10:24:31', '2025-05-09 10:24:31');
INSERT INTO `inventory_outbound_items` VALUES (110, 18, 91, 2000.00, 1, NULL, '2025-05-09 10:24:31', '2025-05-09 10:24:31');
INSERT INTO `inventory_outbound_items` VALUES (111, 18, 92, 2000.00, 1, NULL, '2025-05-09 10:24:31', '2025-05-09 10:24:31');
INSERT INTO `inventory_outbound_items` VALUES (112, 18, 93, 2000.00, 1, NULL, '2025-05-09 10:24:31', '2025-05-09 10:24:31');
INSERT INTO `inventory_outbound_items` VALUES (113, 18, 94, 2000.00, 1, NULL, '2025-05-09 10:24:31', '2025-05-09 10:24:31');
INSERT INTO `inventory_outbound_items` VALUES (114, 18, 95, 2000.00, 10, NULL, '2025-05-09 10:24:31', '2025-05-09 10:24:31');
INSERT INTO `inventory_outbound_items` VALUES (115, 19, 77, 3.00, 1, NULL, '2025-05-09 11:27:32', '2025-05-09 11:27:32');
INSERT INTO `inventory_outbound_items` VALUES (116, 19, 78, 3.00, 1, NULL, '2025-05-09 11:27:33', '2025-05-09 11:27:33');
INSERT INTO `inventory_outbound_items` VALUES (117, 19, 79, 3.00, 1, NULL, '2025-05-09 11:27:34', '2025-05-09 11:27:34');
INSERT INTO `inventory_outbound_items` VALUES (118, 19, 80, 3.00, 1, NULL, '2025-05-09 11:27:35', '2025-05-09 11:27:35');
INSERT INTO `inventory_outbound_items` VALUES (119, 19, 81, 3.00, 1, NULL, '2025-05-09 11:27:36', '2025-05-09 11:27:36');
INSERT INTO `inventory_outbound_items` VALUES (120, 19, 98, 3.00, 1, NULL, '2025-05-09 11:27:37', '2025-05-09 11:27:37');
INSERT INTO `inventory_outbound_items` VALUES (121, 19, 83, 3.00, 1, NULL, '2025-05-09 11:27:39', '2025-05-09 11:27:39');
INSERT INTO `inventory_outbound_items` VALUES (122, 19, 84, 3.00, 1, NULL, '2025-05-09 11:27:40', '2025-05-09 11:27:40');
INSERT INTO `inventory_outbound_items` VALUES (123, 19, 85, 3.00, 1, NULL, '2025-05-09 11:27:41', '2025-05-09 11:27:41');
INSERT INTO `inventory_outbound_items` VALUES (124, 19, 86, 3.00, 1, NULL, '2025-05-09 11:27:42', '2025-05-09 11:27:42');
INSERT INTO `inventory_outbound_items` VALUES (125, 19, 87, 3.00, 1, NULL, '2025-05-09 11:27:43', '2025-05-09 11:27:43');
INSERT INTO `inventory_outbound_items` VALUES (126, 19, 88, 3.00, 1, NULL, '2025-05-09 11:27:44', '2025-05-09 11:27:44');
INSERT INTO `inventory_outbound_items` VALUES (127, 19, 89, 3.00, 1, NULL, '2025-05-09 11:27:45', '2025-05-09 11:27:45');
INSERT INTO `inventory_outbound_items` VALUES (128, 19, 90, 3.00, 1, NULL, '2025-05-09 11:27:46', '2025-05-09 11:27:46');
INSERT INTO `inventory_outbound_items` VALUES (129, 19, 91, 3.00, 1, NULL, '2025-05-09 11:27:47', '2025-05-09 11:27:47');
INSERT INTO `inventory_outbound_items` VALUES (130, 19, 92, 3.00, 1, NULL, '2025-05-09 11:27:48', '2025-05-09 11:27:48');
INSERT INTO `inventory_outbound_items` VALUES (131, 19, 93, 3.00, 1, NULL, '2025-05-09 11:27:49', '2025-05-09 11:27:49');
INSERT INTO `inventory_outbound_items` VALUES (132, 19, 94, 3.00, 1, NULL, '2025-05-09 11:27:50', '2025-05-09 11:27:50');
INSERT INTO `inventory_outbound_items` VALUES (133, 19, 95, 3.00, 10, NULL, '2025-05-09 11:27:52', '2025-05-09 11:27:52');
INSERT INTO `inventory_outbound_items` VALUES (134, 20, 77, 3.00, 1, NULL, '2025-05-09 11:28:01', '2025-05-09 11:28:01');
INSERT INTO `inventory_outbound_items` VALUES (135, 20, 78, 3.00, 1, NULL, '2025-05-09 11:28:02', '2025-05-09 11:28:02');
INSERT INTO `inventory_outbound_items` VALUES (136, 20, 79, 3.00, 1, NULL, '2025-05-09 11:28:03', '2025-05-09 11:28:03');
INSERT INTO `inventory_outbound_items` VALUES (137, 20, 80, 3.00, 1, NULL, '2025-05-09 11:28:04', '2025-05-09 11:28:04');
INSERT INTO `inventory_outbound_items` VALUES (138, 20, 81, 3.00, 1, NULL, '2025-05-09 11:28:05', '2025-05-09 11:28:05');
INSERT INTO `inventory_outbound_items` VALUES (139, 20, 98, 3.00, 1, NULL, '2025-05-09 11:28:06', '2025-05-09 11:28:06');
INSERT INTO `inventory_outbound_items` VALUES (140, 20, 83, 3.00, 1, NULL, '2025-05-09 11:28:07', '2025-05-09 11:28:07');
INSERT INTO `inventory_outbound_items` VALUES (141, 20, 84, 3.00, 1, NULL, '2025-05-09 11:28:08', '2025-05-09 11:28:08');
INSERT INTO `inventory_outbound_items` VALUES (142, 20, 85, 3.00, 1, NULL, '2025-05-09 11:28:09', '2025-05-09 11:28:09');
INSERT INTO `inventory_outbound_items` VALUES (143, 20, 86, 3.00, 1, NULL, '2025-05-09 11:28:10', '2025-05-09 11:28:10');
INSERT INTO `inventory_outbound_items` VALUES (144, 20, 87, 3.00, 1, NULL, '2025-05-09 11:28:11', '2025-05-09 11:28:11');
INSERT INTO `inventory_outbound_items` VALUES (145, 20, 88, 3.00, 1, NULL, '2025-05-09 11:28:13', '2025-05-09 11:28:13');
INSERT INTO `inventory_outbound_items` VALUES (146, 20, 89, 3.00, 1, NULL, '2025-05-09 11:28:14', '2025-05-09 11:28:14');
INSERT INTO `inventory_outbound_items` VALUES (147, 20, 90, 3.00, 1, NULL, '2025-05-09 11:28:15', '2025-05-09 11:28:15');
INSERT INTO `inventory_outbound_items` VALUES (148, 20, 91, 3.00, 1, NULL, '2025-05-09 11:28:16', '2025-05-09 11:28:16');
INSERT INTO `inventory_outbound_items` VALUES (149, 20, 92, 3.00, 1, NULL, '2025-05-09 11:28:17', '2025-05-09 11:28:17');
INSERT INTO `inventory_outbound_items` VALUES (150, 20, 93, 3.00, 1, NULL, '2025-05-09 11:28:18', '2025-05-09 11:28:18');
INSERT INTO `inventory_outbound_items` VALUES (151, 20, 94, 3.00, 1, NULL, '2025-05-09 11:28:19', '2025-05-09 11:28:19');
INSERT INTO `inventory_outbound_items` VALUES (152, 20, 95, 3.00, 10, NULL, '2025-05-09 11:28:20', '2025-05-09 11:28:20');
INSERT INTO `inventory_outbound_items` VALUES (153, 26, 77, 2.00, 1, NULL, '2025-05-10 09:03:37', '2025-05-10 09:03:37');
INSERT INTO `inventory_outbound_items` VALUES (154, 26, 78, 2.00, 1, NULL, '2025-05-10 09:03:37', '2025-05-10 09:03:37');
INSERT INTO `inventory_outbound_items` VALUES (155, 26, 79, 2.00, 1, NULL, '2025-05-10 09:03:37', '2025-05-10 09:03:37');
INSERT INTO `inventory_outbound_items` VALUES (156, 26, 80, 2.00, 1, NULL, '2025-05-10 09:03:37', '2025-05-10 09:03:37');
INSERT INTO `inventory_outbound_items` VALUES (157, 26, 81, 2.00, 1, NULL, '2025-05-10 09:03:37', '2025-05-10 09:03:37');
INSERT INTO `inventory_outbound_items` VALUES (158, 26, 98, 2.00, 1, NULL, '2025-05-10 09:03:37', '2025-05-10 09:03:37');
INSERT INTO `inventory_outbound_items` VALUES (159, 26, 83, 2.00, 1, NULL, '2025-05-10 09:03:37', '2025-05-10 09:03:37');
INSERT INTO `inventory_outbound_items` VALUES (160, 26, 84, 2.00, 1, NULL, '2025-05-10 09:03:37', '2025-05-10 09:03:37');
INSERT INTO `inventory_outbound_items` VALUES (161, 26, 85, 2.00, 1, NULL, '2025-05-10 09:03:37', '2025-05-10 09:03:37');
INSERT INTO `inventory_outbound_items` VALUES (162, 26, 86, 2.00, 1, NULL, '2025-05-10 09:03:37', '2025-05-10 09:03:37');
INSERT INTO `inventory_outbound_items` VALUES (163, 26, 87, 2.00, 1, NULL, '2025-05-10 09:03:37', '2025-05-10 09:03:37');
INSERT INTO `inventory_outbound_items` VALUES (164, 26, 88, 2.00, 1, NULL, '2025-05-10 09:03:37', '2025-05-10 09:03:37');
INSERT INTO `inventory_outbound_items` VALUES (165, 26, 89, 2.00, 1, NULL, '2025-05-10 09:03:37', '2025-05-10 09:03:37');
INSERT INTO `inventory_outbound_items` VALUES (166, 26, 90, 2.00, 1, NULL, '2025-05-10 09:03:37', '2025-05-10 09:03:37');
INSERT INTO `inventory_outbound_items` VALUES (167, 26, 91, 2.00, 1, NULL, '2025-05-10 09:03:37', '2025-05-10 09:03:37');
INSERT INTO `inventory_outbound_items` VALUES (168, 26, 92, 2.00, 1, NULL, '2025-05-10 09:03:37', '2025-05-10 09:03:37');
INSERT INTO `inventory_outbound_items` VALUES (169, 26, 93, 2.00, 1, NULL, '2025-05-10 09:03:37', '2025-05-10 09:03:37');
INSERT INTO `inventory_outbound_items` VALUES (170, 26, 94, 2.00, 1, NULL, '2025-05-10 09:03:37', '2025-05-10 09:03:37');
INSERT INTO `inventory_outbound_items` VALUES (171, 26, 95, 2.00, 10, NULL, '2025-05-10 09:03:37', '2025-05-10 09:03:37');
INSERT INTO `inventory_outbound_items` VALUES (172, 27, 77, 2.00, 1, NULL, '2025-05-10 11:30:08', '2025-05-10 11:30:08');
INSERT INTO `inventory_outbound_items` VALUES (173, 27, 78, 2.00, 1, NULL, '2025-05-10 11:30:08', '2025-05-10 11:30:08');
INSERT INTO `inventory_outbound_items` VALUES (174, 27, 79, 2.00, 1, NULL, '2025-05-10 11:30:08', '2025-05-10 11:30:08');
INSERT INTO `inventory_outbound_items` VALUES (175, 27, 80, 2.00, 1, NULL, '2025-05-10 11:30:08', '2025-05-10 11:30:08');
INSERT INTO `inventory_outbound_items` VALUES (176, 27, 81, 2.00, 1, NULL, '2025-05-10 11:30:08', '2025-05-10 11:30:08');
INSERT INTO `inventory_outbound_items` VALUES (177, 27, 98, 2.00, 1, NULL, '2025-05-10 11:30:08', '2025-05-10 11:30:08');
INSERT INTO `inventory_outbound_items` VALUES (178, 27, 83, 2.00, 1, NULL, '2025-05-10 11:30:08', '2025-05-10 11:30:08');
INSERT INTO `inventory_outbound_items` VALUES (179, 27, 84, 2.00, 1, NULL, '2025-05-10 11:30:08', '2025-05-10 11:30:08');
INSERT INTO `inventory_outbound_items` VALUES (180, 27, 85, 2.00, 1, NULL, '2025-05-10 11:30:08', '2025-05-10 11:30:08');
INSERT INTO `inventory_outbound_items` VALUES (181, 27, 86, 2.00, 1, NULL, '2025-05-10 11:30:08', '2025-05-10 11:30:08');
INSERT INTO `inventory_outbound_items` VALUES (182, 27, 87, 2.00, 1, NULL, '2025-05-10 11:30:08', '2025-05-10 11:30:08');
INSERT INTO `inventory_outbound_items` VALUES (183, 27, 88, 2.00, 1, NULL, '2025-05-10 11:30:08', '2025-05-10 11:30:08');
INSERT INTO `inventory_outbound_items` VALUES (184, 27, 89, 2.00, 1, NULL, '2025-05-10 11:30:08', '2025-05-10 11:30:08');
INSERT INTO `inventory_outbound_items` VALUES (185, 27, 90, 2.00, 1, NULL, '2025-05-10 11:30:08', '2025-05-10 11:30:08');
INSERT INTO `inventory_outbound_items` VALUES (186, 27, 91, 2.00, 1, NULL, '2025-05-10 11:30:08', '2025-05-10 11:30:08');
INSERT INTO `inventory_outbound_items` VALUES (187, 27, 92, 2.00, 1, NULL, '2025-05-10 11:30:08', '2025-05-10 11:30:08');
INSERT INTO `inventory_outbound_items` VALUES (188, 27, 93, 2.00, 1, NULL, '2025-05-10 11:30:08', '2025-05-10 11:30:08');
INSERT INTO `inventory_outbound_items` VALUES (189, 27, 94, 2.00, 1, NULL, '2025-05-10 11:30:08', '2025-05-10 11:30:08');
INSERT INTO `inventory_outbound_items` VALUES (190, 27, 95, 2.00, 10, NULL, '2025-05-10 11:30:08', '2025-05-10 11:30:08');

-- ----------------------------
-- Table structure for inventory_stock
-- ----------------------------
DROP TABLE IF EXISTS `inventory_stock`;
CREATE TABLE `inventory_stock`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `material_id` int NOT NULL COMMENT '物料ID（关联物料表）',
  `location_id` int NOT NULL COMMENT '库位ID',
  `quantity` decimal(10, 2) NOT NULL DEFAULT 0.00 COMMENT '库存数量',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `idx_material_location`(`material_id` ASC, `location_id` ASC) USING BTREE,
  INDEX `fk_location`(`location_id` ASC) USING BTREE,
  CONSTRAINT `fk_location` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_material` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 187 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '库存主表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of inventory_stock
-- ----------------------------
INSERT INTO `inventory_stock` VALUES (148, 98, 2, 8894.00, '2025-05-09 09:36:25', '2025-05-10 20:55:12');
INSERT INTO `inventory_stock` VALUES (149, 101, 2, 6052.00, '2025-05-09 09:38:02', '2025-05-10 20:50:38');
INSERT INTO `inventory_stock` VALUES (150, 95, 2, 1996.00, '2025-05-09 10:19:20', '2025-05-10 11:30:38');
INSERT INTO `inventory_stock` VALUES (151, 94, 2, 1996.00, '2025-05-09 10:19:23', '2025-05-10 11:30:38');
INSERT INTO `inventory_stock` VALUES (152, 93, 2, 1996.00, '2025-05-09 10:19:26', '2025-05-10 11:30:38');
INSERT INTO `inventory_stock` VALUES (153, 92, 2, 1996.00, '2025-05-09 10:19:29', '2025-05-10 11:30:38');
INSERT INTO `inventory_stock` VALUES (154, 91, 2, 1996.00, '2025-05-09 10:19:32', '2025-05-10 11:30:38');
INSERT INTO `inventory_stock` VALUES (155, 90, 2, 1996.00, '2025-05-09 10:19:35', '2025-05-10 11:30:38');
INSERT INTO `inventory_stock` VALUES (156, 89, 2, 1996.00, '2025-05-09 10:19:38', '2025-05-10 11:30:38');
INSERT INTO `inventory_stock` VALUES (157, 88, 2, 1996.00, '2025-05-09 10:19:41', '2025-05-10 11:30:37');
INSERT INTO `inventory_stock` VALUES (158, 87, 2, 1996.00, '2025-05-09 10:19:44', '2025-05-10 11:30:37');
INSERT INTO `inventory_stock` VALUES (159, 86, 2, 1996.00, '2025-05-09 10:19:47', '2025-05-10 11:30:37');
INSERT INTO `inventory_stock` VALUES (160, 85, 2, 1996.00, '2025-05-09 10:19:50', '2025-05-10 11:30:37');
INSERT INTO `inventory_stock` VALUES (161, 84, 2, 1996.00, '2025-05-09 10:19:53', '2025-05-10 11:30:37');
INSERT INTO `inventory_stock` VALUES (162, 83, 2, 1996.00, '2025-05-09 10:19:56', '2025-05-10 11:30:37');
INSERT INTO `inventory_stock` VALUES (163, 82, 2, 4000.00, '2025-05-09 10:19:59', '2025-05-09 10:19:59');
INSERT INTO `inventory_stock` VALUES (164, 81, 2, 1996.00, '2025-05-09 10:20:02', '2025-05-10 11:30:37');
INSERT INTO `inventory_stock` VALUES (165, 80, 2, 1996.00, '2025-05-09 10:20:05', '2025-05-10 11:30:37');
INSERT INTO `inventory_stock` VALUES (166, 79, 2, 1996.00, '2025-05-09 10:20:08', '2025-05-10 11:30:36');
INSERT INTO `inventory_stock` VALUES (167, 78, 2, 1996.00, '2025-05-09 10:20:11', '2025-05-10 11:30:36');
INSERT INTO `inventory_stock` VALUES (168, 77, 2, 1996.00, '2025-05-09 10:20:14', '2025-05-10 11:30:36');
INSERT INTO `inventory_stock` VALUES (169, 76, 2, 4000.00, '2025-05-09 10:20:16', '2025-05-09 10:20:16');
INSERT INTO `inventory_stock` VALUES (170, 75, 2, 4000.00, '2025-05-09 10:20:19', '2025-05-09 10:20:19');
INSERT INTO `inventory_stock` VALUES (171, 74, 2, 4000.00, '2025-05-09 10:20:22', '2025-05-09 10:20:22');
INSERT INTO `inventory_stock` VALUES (172, 73, 2, 4000.00, '2025-05-09 10:20:25', '2025-05-09 10:20:25');
INSERT INTO `inventory_stock` VALUES (173, 72, 2, 4000.00, '2025-05-09 10:20:28', '2025-05-09 10:20:28');
INSERT INTO `inventory_stock` VALUES (174, 71, 2, 4000.00, '2025-05-09 10:20:31', '2025-05-09 10:20:31');
INSERT INTO `inventory_stock` VALUES (175, 70, 2, 4000.00, '2025-05-09 10:20:34', '2025-05-09 10:20:34');
INSERT INTO `inventory_stock` VALUES (176, 69, 2, 4000.00, '2025-05-09 10:20:37', '2025-05-09 10:20:37');
INSERT INTO `inventory_stock` VALUES (177, 68, 2, 4000.00, '2025-05-09 10:20:40', '2025-05-09 10:20:40');
INSERT INTO `inventory_stock` VALUES (178, 67, 2, 4000.00, '2025-05-09 10:20:44', '2025-05-09 10:20:44');
INSERT INTO `inventory_stock` VALUES (179, 66, 2, 4000.00, '2025-05-09 10:20:46', '2025-05-09 10:20:46');
INSERT INTO `inventory_stock` VALUES (180, 65, 2, 4000.00, '2025-05-09 10:20:49', '2025-05-09 10:20:49');
INSERT INTO `inventory_stock` VALUES (181, 64, 2, 4000.00, '2025-05-09 10:20:52', '2025-05-09 10:20:52');
INSERT INTO `inventory_stock` VALUES (182, 63, 2, 4000.00, '2025-05-09 10:20:55', '2025-05-09 10:20:55');
INSERT INTO `inventory_stock` VALUES (183, 62, 2, 4000.00, '2025-05-09 10:20:58', '2025-05-09 10:20:58');
INSERT INTO `inventory_stock` VALUES (184, 61, 2, 4000.00, '2025-05-09 10:21:01', '2025-05-09 10:21:01');
INSERT INTO `inventory_stock` VALUES (185, 60, 2, 4000.00, '2025-05-09 10:21:04', '2025-05-09 10:21:04');
INSERT INTO `inventory_stock` VALUES (186, 99, 3, 2.00, '2025-05-10 11:31:52', '2025-05-10 11:31:52');

-- ----------------------------
-- Table structure for inventory_stock_records
-- ----------------------------
DROP TABLE IF EXISTS `inventory_stock_records`;
CREATE TABLE `inventory_stock_records`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `material_id` int NOT NULL COMMENT '物料ID',
  `warehouse_id` int NOT NULL COMMENT '仓库ID',
  `batch_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '批次号',
  `quantity` decimal(10, 2) NOT NULL COMMENT '数量',
  `type` enum('in','out','adjust','transfer') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '类型',
  `source_id` int NULL DEFAULT NULL COMMENT '来源单据ID',
  `source_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '来源单据类型',
  `operator` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '操作员',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `material_id`(`material_id` ASC) USING BTREE,
  INDEX `warehouse_id`(`warehouse_id` ASC) USING BTREE,
  INDEX `type`(`type` ASC) USING BTREE,
  INDEX `source_id`(`source_id` ASC, `source_type` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 46 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of inventory_stock_records
-- ----------------------------

-- ----------------------------
-- Table structure for inventory_transactions
-- ----------------------------
DROP TABLE IF EXISTS `inventory_transactions`;
CREATE TABLE `inventory_transactions`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `material_id` int NOT NULL COMMENT '物料ID',
  `location_id` int NOT NULL COMMENT '库位ID',
  `transaction_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '交易类型：in-入库,out-出库',
  `quantity` decimal(10, 2) NOT NULL COMMENT '数量',
  `unit_id` int NOT NULL COMMENT '单位ID',
  `batch_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '批次号',
  `reference_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '关联单据号',
  `reference_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '关联单据类型：采购入库、生产入库、销售出库等',
  `operator` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '操作员',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `before_quantity` decimal(10, 2) NULL DEFAULT NULL,
  `after_quantity` decimal(10, 2) NULL DEFAULT NULL,
  `transaction_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_transactions_material`(`material_id` ASC) USING BTREE,
  INDEX `fk_transactions_location`(`location_id` ASC) USING BTREE,
  INDEX `fk_transactions_unit`(`unit_id` ASC) USING BTREE,
  CONSTRAINT `fk_transactions_location` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_transactions_material` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_transactions_unit` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 910 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '库存流水表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of inventory_transactions
-- ----------------------------
INSERT INTO `inventory_transactions` VALUES (799, 98, 2, 'inbound', 1000.00, 1, NULL, 'RK20250509001', 'inbound', '王晓敏', ' (inbound: RK20250509001)', -50.00, 950.00, NULL, '2025-05-09 09:36:24');
INSERT INTO `inventory_transactions` VALUES (801, 98, 2, 'outsourced_outbound', -50.00, 1, NULL, 'WW250509001', 'outsourced_processing_material', 'system', '外委加工发料 WW250509001', 950.00, 900.00, NULL, '2025-05-09 09:37:42');
INSERT INTO `inventory_transactions` VALUES (802, 101, 2, 'outsourced_inbound', 50.00, 1, NULL, 'WWRK250509001', 'outsourced_processing_receipt', '王晓敏', '外委加工入库 WWRK250509001', 0.00, 50.00, NULL, '2025-05-09 09:38:03');
INSERT INTO `inventory_transactions` VALUES (803, 101, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 50.00, 4050.00, NULL, '2025-05-09 10:19:13');
INSERT INTO `inventory_transactions` VALUES (804, 98, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 900.00, 4900.00, NULL, '2025-05-09 10:19:16');
INSERT INTO `inventory_transactions` VALUES (805, 95, 2, 'inbound', 4000.00, 10, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:19:19');
INSERT INTO `inventory_transactions` VALUES (806, 94, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:19:23');
INSERT INTO `inventory_transactions` VALUES (807, 93, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:19:26');
INSERT INTO `inventory_transactions` VALUES (808, 92, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:19:29');
INSERT INTO `inventory_transactions` VALUES (809, 91, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:19:32');
INSERT INTO `inventory_transactions` VALUES (810, 90, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:19:35');
INSERT INTO `inventory_transactions` VALUES (811, 89, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:19:37');
INSERT INTO `inventory_transactions` VALUES (812, 88, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:19:40');
INSERT INTO `inventory_transactions` VALUES (813, 87, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:19:43');
INSERT INTO `inventory_transactions` VALUES (814, 86, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:19:46');
INSERT INTO `inventory_transactions` VALUES (815, 85, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:19:49');
INSERT INTO `inventory_transactions` VALUES (816, 84, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:19:52');
INSERT INTO `inventory_transactions` VALUES (817, 83, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:19:55');
INSERT INTO `inventory_transactions` VALUES (818, 82, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:19:58');
INSERT INTO `inventory_transactions` VALUES (819, 81, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:01');
INSERT INTO `inventory_transactions` VALUES (820, 80, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:04');
INSERT INTO `inventory_transactions` VALUES (821, 79, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:07');
INSERT INTO `inventory_transactions` VALUES (822, 78, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:10');
INSERT INTO `inventory_transactions` VALUES (823, 77, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:13');
INSERT INTO `inventory_transactions` VALUES (824, 76, 2, 'inbound', 4000.00, 7, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:16');
INSERT INTO `inventory_transactions` VALUES (825, 75, 2, 'inbound', 4000.00, 10, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:19');
INSERT INTO `inventory_transactions` VALUES (826, 74, 2, 'inbound', 4000.00, 10, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:22');
INSERT INTO `inventory_transactions` VALUES (827, 73, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:25');
INSERT INTO `inventory_transactions` VALUES (828, 72, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:28');
INSERT INTO `inventory_transactions` VALUES (829, 71, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:31');
INSERT INTO `inventory_transactions` VALUES (830, 70, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:34');
INSERT INTO `inventory_transactions` VALUES (831, 69, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:37');
INSERT INTO `inventory_transactions` VALUES (832, 68, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:40');
INSERT INTO `inventory_transactions` VALUES (833, 67, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:43');
INSERT INTO `inventory_transactions` VALUES (834, 66, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:46');
INSERT INTO `inventory_transactions` VALUES (835, 65, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:49');
INSERT INTO `inventory_transactions` VALUES (836, 64, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:52');
INSERT INTO `inventory_transactions` VALUES (837, 63, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:55');
INSERT INTO `inventory_transactions` VALUES (838, 62, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:20:58');
INSERT INTO `inventory_transactions` VALUES (839, 61, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:21:01');
INSERT INTO `inventory_transactions` VALUES (840, 60, 2, 'inbound', 4000.00, 1, NULL, 'RK20250509002', 'inbound', '王晓敏', ' (inbound: RK20250509002)', 0.00, 4000.00, NULL, '2025-05-09 10:21:04');
INSERT INTO `inventory_transactions` VALUES (841, 77, 2, 'outbound', 2000.00, 1, NULL, 'OUT20250509001', 'outbound', 'admin', ' (outbound: OUT20250509001)', 4000.00, 2000.00, NULL, '2025-05-09 10:24:36');
INSERT INTO `inventory_transactions` VALUES (842, 78, 2, 'outbound', 2000.00, 1, NULL, 'OUT20250509001', 'outbound', 'admin', ' (outbound: OUT20250509001)', 4000.00, 2000.00, NULL, '2025-05-09 10:24:36');
INSERT INTO `inventory_transactions` VALUES (843, 79, 2, 'outbound', 2000.00, 1, NULL, 'OUT20250509001', 'outbound', 'admin', ' (outbound: OUT20250509001)', 4000.00, 2000.00, NULL, '2025-05-09 10:24:36');
INSERT INTO `inventory_transactions` VALUES (844, 80, 2, 'outbound', 2000.00, 1, NULL, 'OUT20250509001', 'outbound', 'admin', ' (outbound: OUT20250509001)', 4000.00, 2000.00, NULL, '2025-05-09 10:24:37');
INSERT INTO `inventory_transactions` VALUES (845, 81, 2, 'outbound', 2000.00, 1, NULL, 'OUT20250509001', 'outbound', 'admin', ' (outbound: OUT20250509001)', 4000.00, 2000.00, NULL, '2025-05-09 10:24:37');
INSERT INTO `inventory_transactions` VALUES (846, 98, 2, 'outbound', 2000.00, 1, NULL, 'OUT20250509001', 'outbound', 'admin', ' (outbound: OUT20250509001)', 4900.00, 2900.00, NULL, '2025-05-09 10:24:37');
INSERT INTO `inventory_transactions` VALUES (847, 83, 2, 'outbound', 2000.00, 1, NULL, 'OUT20250509001', 'outbound', 'admin', ' (outbound: OUT20250509001)', 4000.00, 2000.00, NULL, '2025-05-09 10:24:37');
INSERT INTO `inventory_transactions` VALUES (848, 84, 2, 'outbound', 2000.00, 1, NULL, 'OUT20250509001', 'outbound', 'admin', ' (outbound: OUT20250509001)', 4000.00, 2000.00, NULL, '2025-05-09 10:24:37');
INSERT INTO `inventory_transactions` VALUES (849, 85, 2, 'outbound', 2000.00, 1, NULL, 'OUT20250509001', 'outbound', 'admin', ' (outbound: OUT20250509001)', 4000.00, 2000.00, NULL, '2025-05-09 10:24:37');
INSERT INTO `inventory_transactions` VALUES (850, 86, 2, 'outbound', 2000.00, 1, NULL, 'OUT20250509001', 'outbound', 'admin', ' (outbound: OUT20250509001)', 4000.00, 2000.00, NULL, '2025-05-09 10:24:37');
INSERT INTO `inventory_transactions` VALUES (851, 87, 2, 'outbound', 2000.00, 1, NULL, 'OUT20250509001', 'outbound', 'admin', ' (outbound: OUT20250509001)', 4000.00, 2000.00, NULL, '2025-05-09 10:24:37');
INSERT INTO `inventory_transactions` VALUES (852, 88, 2, 'outbound', 2000.00, 1, NULL, 'OUT20250509001', 'outbound', 'admin', ' (outbound: OUT20250509001)', 4000.00, 2000.00, NULL, '2025-05-09 10:24:37');
INSERT INTO `inventory_transactions` VALUES (853, 89, 2, 'outbound', 2000.00, 1, NULL, 'OUT20250509001', 'outbound', 'admin', ' (outbound: OUT20250509001)', 4000.00, 2000.00, NULL, '2025-05-09 10:24:37');
INSERT INTO `inventory_transactions` VALUES (854, 90, 2, 'outbound', 2000.00, 1, NULL, 'OUT20250509001', 'outbound', 'admin', ' (outbound: OUT20250509001)', 4000.00, 2000.00, NULL, '2025-05-09 10:24:37');
INSERT INTO `inventory_transactions` VALUES (855, 91, 2, 'outbound', 2000.00, 1, NULL, 'OUT20250509001', 'outbound', 'admin', ' (outbound: OUT20250509001)', 4000.00, 2000.00, NULL, '2025-05-09 10:24:38');
INSERT INTO `inventory_transactions` VALUES (856, 92, 2, 'outbound', 2000.00, 1, NULL, 'OUT20250509001', 'outbound', 'admin', ' (outbound: OUT20250509001)', 4000.00, 2000.00, NULL, '2025-05-09 10:24:38');
INSERT INTO `inventory_transactions` VALUES (857, 93, 2, 'outbound', 2000.00, 1, NULL, 'OUT20250509001', 'outbound', 'admin', ' (outbound: OUT20250509001)', 4000.00, 2000.00, NULL, '2025-05-09 10:24:38');
INSERT INTO `inventory_transactions` VALUES (858, 94, 2, 'outbound', 2000.00, 1, NULL, 'OUT20250509001', 'outbound', 'admin', ' (outbound: OUT20250509001)', 4000.00, 2000.00, NULL, '2025-05-09 10:24:38');
INSERT INTO `inventory_transactions` VALUES (859, 95, 2, 'outbound', 2000.00, 10, NULL, 'OUT20250509001', 'outbound', 'admin', ' (outbound: OUT20250509001)', 4000.00, 2000.00, NULL, '2025-05-09 10:24:38');
INSERT INTO `inventory_transactions` VALUES (860, 77, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510001', 'outbound', 'admin', ' (outbound: OUT20250510001)', 2000.00, 1998.00, NULL, '2025-05-10 09:03:56');
INSERT INTO `inventory_transactions` VALUES (861, 78, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510001', 'outbound', 'admin', ' (outbound: OUT20250510001)', 2000.00, 1998.00, NULL, '2025-05-10 09:03:56');
INSERT INTO `inventory_transactions` VALUES (862, 79, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510001', 'outbound', 'admin', ' (outbound: OUT20250510001)', 2000.00, 1998.00, NULL, '2025-05-10 09:03:56');
INSERT INTO `inventory_transactions` VALUES (863, 80, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510001', 'outbound', 'admin', ' (outbound: OUT20250510001)', 2000.00, 1998.00, NULL, '2025-05-10 09:03:56');
INSERT INTO `inventory_transactions` VALUES (864, 81, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510001', 'outbound', 'admin', ' (outbound: OUT20250510001)', 2000.00, 1998.00, NULL, '2025-05-10 09:03:57');
INSERT INTO `inventory_transactions` VALUES (865, 98, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510001', 'outbound', 'admin', ' (outbound: OUT20250510001)', 2900.00, 2898.00, NULL, '2025-05-10 09:03:57');
INSERT INTO `inventory_transactions` VALUES (866, 83, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510001', 'outbound', 'admin', ' (outbound: OUT20250510001)', 2000.00, 1998.00, NULL, '2025-05-10 09:03:57');
INSERT INTO `inventory_transactions` VALUES (867, 84, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510001', 'outbound', 'admin', ' (outbound: OUT20250510001)', 2000.00, 1998.00, NULL, '2025-05-10 09:03:57');
INSERT INTO `inventory_transactions` VALUES (868, 85, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510001', 'outbound', 'admin', ' (outbound: OUT20250510001)', 2000.00, 1998.00, NULL, '2025-05-10 09:03:57');
INSERT INTO `inventory_transactions` VALUES (869, 86, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510001', 'outbound', 'admin', ' (outbound: OUT20250510001)', 2000.00, 1998.00, NULL, '2025-05-10 09:03:57');
INSERT INTO `inventory_transactions` VALUES (870, 87, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510001', 'outbound', 'admin', ' (outbound: OUT20250510001)', 2000.00, 1998.00, NULL, '2025-05-10 09:03:57');
INSERT INTO `inventory_transactions` VALUES (871, 88, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510001', 'outbound', 'admin', ' (outbound: OUT20250510001)', 2000.00, 1998.00, NULL, '2025-05-10 09:03:57');
INSERT INTO `inventory_transactions` VALUES (872, 89, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510001', 'outbound', 'admin', ' (outbound: OUT20250510001)', 2000.00, 1998.00, NULL, '2025-05-10 09:03:57');
INSERT INTO `inventory_transactions` VALUES (873, 90, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510001', 'outbound', 'admin', ' (outbound: OUT20250510001)', 2000.00, 1998.00, NULL, '2025-05-10 09:03:58');
INSERT INTO `inventory_transactions` VALUES (874, 91, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510001', 'outbound', 'admin', ' (outbound: OUT20250510001)', 2000.00, 1998.00, NULL, '2025-05-10 09:03:58');
INSERT INTO `inventory_transactions` VALUES (875, 92, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510001', 'outbound', 'admin', ' (outbound: OUT20250510001)', 2000.00, 1998.00, NULL, '2025-05-10 09:03:58');
INSERT INTO `inventory_transactions` VALUES (876, 93, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510001', 'outbound', 'admin', ' (outbound: OUT20250510001)', 2000.00, 1998.00, NULL, '2025-05-10 09:03:58');
INSERT INTO `inventory_transactions` VALUES (877, 94, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510001', 'outbound', 'admin', ' (outbound: OUT20250510001)', 2000.00, 1998.00, NULL, '2025-05-10 09:03:58');
INSERT INTO `inventory_transactions` VALUES (878, 95, 2, 'outbound', 2.00, 10, NULL, 'OUT20250510001', 'outbound', 'admin', ' (outbound: OUT20250510001)', 2000.00, 1998.00, NULL, '2025-05-10 09:03:58');
INSERT INTO `inventory_transactions` VALUES (879, 77, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510002', 'outbound', 'admin', ' (outbound: OUT20250510002)', 1998.00, 1996.00, NULL, '2025-05-10 11:30:36');
INSERT INTO `inventory_transactions` VALUES (880, 78, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510002', 'outbound', 'admin', ' (outbound: OUT20250510002)', 1998.00, 1996.00, NULL, '2025-05-10 11:30:36');
INSERT INTO `inventory_transactions` VALUES (881, 79, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510002', 'outbound', 'admin', ' (outbound: OUT20250510002)', 1998.00, 1996.00, NULL, '2025-05-10 11:30:36');
INSERT INTO `inventory_transactions` VALUES (882, 80, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510002', 'outbound', 'admin', ' (outbound: OUT20250510002)', 1998.00, 1996.00, NULL, '2025-05-10 11:30:37');
INSERT INTO `inventory_transactions` VALUES (883, 81, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510002', 'outbound', 'admin', ' (outbound: OUT20250510002)', 1998.00, 1996.00, NULL, '2025-05-10 11:30:37');
INSERT INTO `inventory_transactions` VALUES (884, 98, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510002', 'outbound', 'admin', ' (outbound: OUT20250510002)', 2898.00, 2896.00, NULL, '2025-05-10 11:30:37');
INSERT INTO `inventory_transactions` VALUES (885, 83, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510002', 'outbound', 'admin', ' (outbound: OUT20250510002)', 1998.00, 1996.00, NULL, '2025-05-10 11:30:37');
INSERT INTO `inventory_transactions` VALUES (886, 84, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510002', 'outbound', 'admin', ' (outbound: OUT20250510002)', 1998.00, 1996.00, NULL, '2025-05-10 11:30:37');
INSERT INTO `inventory_transactions` VALUES (887, 85, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510002', 'outbound', 'admin', ' (outbound: OUT20250510002)', 1998.00, 1996.00, NULL, '2025-05-10 11:30:37');
INSERT INTO `inventory_transactions` VALUES (888, 86, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510002', 'outbound', 'admin', ' (outbound: OUT20250510002)', 1998.00, 1996.00, NULL, '2025-05-10 11:30:37');
INSERT INTO `inventory_transactions` VALUES (889, 87, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510002', 'outbound', 'admin', ' (outbound: OUT20250510002)', 1998.00, 1996.00, NULL, '2025-05-10 11:30:37');
INSERT INTO `inventory_transactions` VALUES (890, 88, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510002', 'outbound', 'admin', ' (outbound: OUT20250510002)', 1998.00, 1996.00, NULL, '2025-05-10 11:30:38');
INSERT INTO `inventory_transactions` VALUES (891, 89, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510002', 'outbound', 'admin', ' (outbound: OUT20250510002)', 1998.00, 1996.00, NULL, '2025-05-10 11:30:38');
INSERT INTO `inventory_transactions` VALUES (892, 90, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510002', 'outbound', 'admin', ' (outbound: OUT20250510002)', 1998.00, 1996.00, NULL, '2025-05-10 11:30:38');
INSERT INTO `inventory_transactions` VALUES (893, 91, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510002', 'outbound', 'admin', ' (outbound: OUT20250510002)', 1998.00, 1996.00, NULL, '2025-05-10 11:30:38');
INSERT INTO `inventory_transactions` VALUES (894, 92, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510002', 'outbound', 'admin', ' (outbound: OUT20250510002)', 1998.00, 1996.00, NULL, '2025-05-10 11:30:38');
INSERT INTO `inventory_transactions` VALUES (895, 93, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510002', 'outbound', 'admin', ' (outbound: OUT20250510002)', 1998.00, 1996.00, NULL, '2025-05-10 11:30:38');
INSERT INTO `inventory_transactions` VALUES (896, 94, 2, 'outbound', 2.00, 1, NULL, 'OUT20250510002', 'outbound', 'admin', ' (outbound: OUT20250510002)', 1998.00, 1996.00, NULL, '2025-05-10 11:30:38');
INSERT INTO `inventory_transactions` VALUES (897, 95, 2, 'outbound', 2.00, 10, NULL, 'OUT20250510002', 'outbound', 'admin', ' (outbound: OUT20250510002)', 1998.00, 1996.00, NULL, '2025-05-10 11:30:38');
INSERT INTO `inventory_transactions` VALUES (898, 99, 3, 'inbound', 2.00, 1, NULL, 'RK20250510001', 'inbound', 'admin', ' (inbound: RK20250510001)', 0.00, 2.00, NULL, '2025-05-10 11:31:52');
INSERT INTO `inventory_transactions` VALUES (899, 98, 2, 'in', 2000.00, 1, NULL, 'GR202505100003', 'purchase_receipt', 'system', '采购入库', 2896.00, 4896.00, NULL, '2025-05-10 20:09:54');
INSERT INTO `inventory_transactions` VALUES (900, 98, 2, 'in', 2000.00, 1, NULL, 'GR202505100003', 'purchase_receipt', 'system', '采购入库', 4896.00, 6896.00, NULL, '2025-05-10 20:13:43');
INSERT INTO `inventory_transactions` VALUES (901, 98, 2, 'purchase_inbound', 2000.00, 1, NULL, 'GR202505100003', 'purchase_receipt', 'system', '采购入库', 6896.00, 8896.00, NULL, '2025-05-10 20:27:44');
INSERT INTO `inventory_transactions` VALUES (902, 101, 2, 'purchase_inbound', 2000.00, 1, NULL, 'GR202505100007', 'purchase_receipt', 'system', '采购入库', 4050.00, 6050.00, NULL, '2025-05-10 20:34:27');
INSERT INTO `inventory_transactions` VALUES (903, 98, 2, 'outsourced_outbound', -1.00, 1, NULL, 'WW250510001', 'outsourced_processing_material', 'system', '外委加工发料 WW250510001', 8896.00, 8895.00, NULL, '2025-05-10 20:41:06');
INSERT INTO `inventory_transactions` VALUES (904, 101, 2, 'outsourced_inbound', 1.00, 1, NULL, 'WWRK250510001', 'outsourced_processing_receipt', '王晓敏', '外委加工入库 WWRK250510001', 6050.00, 6051.00, NULL, '2025-05-10 20:41:43');
INSERT INTO `inventory_transactions` VALUES (905, 98, 2, 'outsourced_outbound', -1.00, 1, NULL, 'WW250510002', 'outsourced_processing_material', 'system', '外委加工发料 WW250510002', 8895.00, 8894.00, NULL, '2025-05-10 20:43:07');
INSERT INTO `inventory_transactions` VALUES (906, 101, 2, 'outsourced_outbound', -1.00, 1, NULL, 'WW250510003', 'outsourced_processing_material', 'system', '外委加工发料 WW250510003', 6051.00, 6050.00, NULL, '2025-05-10 20:47:49');
INSERT INTO `inventory_transactions` VALUES (907, 98, 2, 'outsourced_inbound', 1.00, 1, NULL, 'WWRK250510003', 'outsourced_processing_receipt', '王晓敏', '外委加工入库 WWRK250510003', 8894.00, 8895.00, NULL, '2025-05-10 20:48:29');
INSERT INTO `inventory_transactions` VALUES (908, 101, 2, 'outsourced_inbound', 2.00, 1, NULL, 'WWRK250510002', 'outsourced_processing_receipt', '王晓敏', '外委加工入库 WWRK250510002', 6050.00, 6052.00, NULL, '2025-05-10 20:50:38');
INSERT INTO `inventory_transactions` VALUES (909, 98, 2, 'outsourced_outbound', -1.00, 1, NULL, 'WW250510004', 'outsourced_processing_material', 'system', '外委加工发料 WW250510004', 8895.00, 8894.00, NULL, '2025-05-10 20:55:12');

-- ----------------------------
-- Table structure for locations
-- ----------------------------
DROP TABLE IF EXISTS `locations`;
CREATE TABLE `locations`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '库位编码',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '库位名称',
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'warehouse',
  `area` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `warehouse_id` int NULL DEFAULT NULL,
  `warehouse_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `status` tinyint(1) NULL DEFAULT 1 COMMENT '状态：1-启用，0-禁用',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '备注',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_code`(`code` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '库位表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of locations
-- ----------------------------
INSERT INTO `locations` VALUES (1, 'RM-STORE', '一号仓库', 'warehouse', NULL, NULL, 1, '', 1, NULL, '2025-03-28 09:33:31', '2025-03-31 13:18:30');
INSERT INTO `locations` VALUES (2, 'SP-STORE', '零部件仓库', 'warehouse', NULL, NULL, 2, '', 1, NULL, '2025-03-28 09:33:31', '2025-04-02 10:26:43');
INSERT INTO `locations` VALUES (3, 'FG-STORE', '成品仓库', 'warehouse', NULL, NULL, 3, '', 1, NULL, '2025-03-28 09:33:31', '2025-04-02 10:26:34');

-- ----------------------------
-- Table structure for materials
-- ----------------------------
DROP TABLE IF EXISTS `materials`;
CREATE TABLE `materials`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '物料编码',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '物料名称',
  `category_id` int NOT NULL COMMENT '物料分类ID',
  `unit_id` int NOT NULL COMMENT '计量单位ID',
  `location_id` int NULL DEFAULT NULL COMMENT '默认库位ID',
  `location_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '默认库位名称',
  `specs` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '规格型号',
  `price` decimal(10, 2) NULL DEFAULT NULL COMMENT '参考价格',
  `min_stock` int NULL DEFAULT NULL COMMENT '最小库存',
  `max_stock` int NULL DEFAULT NULL COMMENT '最大库存',
  `status` tinyint NULL DEFAULT 1 COMMENT '状态：0-禁用 1-启用',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_code`(`code` ASC) USING BTREE,
  INDEX `idx_category`(`category_id` ASC) USING BTREE,
  INDEX `fk_materials_location`(`location_id` ASC) USING BTREE,
  CONSTRAINT `fk_materials_location` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 102 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '物料表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of materials
-- ----------------------------
INSERT INTO `materials` VALUES (60, '3001007208', '灰色底座', 1, 1, 2, NULL, 'HRF-M1C-F 出线口6x8.8', 6.00, 500, 1000, 1, NULL, '2025-04-28 11:01:57', '2025-04-28 11:01:57');
INSERT INTO `materials` VALUES (61, '3001011173', '灰色上盖', 1, 1, 2, NULL, 'HRF-M1', 1.00, 500, 1000, 1, NULL, '2025-04-28 11:01:57', '2025-04-28 11:01:57');
INSERT INTO `materials` VALUES (62, '3004007001', '橡皮脚钉', 1, 1, 2, NULL, 'HRF-M1/MD4', 4.00, 500, 1000, 1, NULL, '2025-04-28 11:01:57', '2025-04-28 11:01:57');
INSERT INTO `materials` VALUES (63, '3005002029', '轴', 1, 1, 2, NULL, 'HRF-M1', 3.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (64, '3006001001', '灰色电缆线', 1, 1, 2, NULL, 'HRF-M1 浸锡3.5mm 环保', 1.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (65, '3009001123', '弹簧', 1, 1, 2, NULL, 'HRF-M1 盐雾48小时镀镍', 8.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (66, '3011001001', '盘头自攻螺钉', 1, 1, 2, NULL, 'HRF-M1 ST3x8', 5.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (67, '3011001230', '螺钉带弹垫平垫', 1, 1, 2, NULL, 'HRF-M1 M3x16', 3.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (68, '3011002013', '螺母', 1, 1, 2, NULL, 'HRF-MD2 M3 兰白锌', 1.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (69, '3012001007', '微动开关', 1, 1, 2, NULL, 'V15F-01C G350-500 镀金', 4.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (70, '4001003010', '外箱', 1, 1, 2, NULL, 'HRF-M1 390x380x255', 4.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (71, '4002002077', '内盒', 1, 1, 2, NULL, 'HRF-M1 120x72x58', 8.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (72, '4003003015', '警示标签 闪电', 1, 1, 2, NULL, 'HRF-M1 A4  (15x13)黄底黑字', 2.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (73, '4003003019', '警示标签 感叹', 1, 1, 2, NULL, 'HRF-M1 B4  (15x13)黄底黑字', 4.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (74, '4005001006', '塑料袋', 1, 10, 2, NULL, 'KEG1 170x120mm', 4.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (75, '4005001013', '小外箱塑料袋', 1, 10, 2, NULL, 'KCB02 750x800mm', 6.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (76, '4006001001', '干燥剂', 1, 7, 2, NULL, '35mmx40mm 通用', 2.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (77, '200301028', '开关盒', 1, 1, 2, NULL, 'HRF-M5', 2.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (78, '3001007153', '蓝色底座', 1, 1, 2, NULL, 'HRF-M5', 8.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (79, '3001009027', '蓝色右侧板', 1, 1, 2, NULL, 'HRF-M5', 7.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (80, '3001009028', '蓝色左侧板', 1, 1, 2, NULL, 'HRF-M5', 6.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (81, '3001011155', '透明盖', 1, 1, 2, NULL, 'HRF-M5', 2.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (82, '3001023003', '黄色踏板', 1, 1, 2, NULL, 'HRF-M5', 6.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (83, '3002013023', '底板', 1, 1, 2, NULL, 'HRF-M5', 5.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (84, '3002018010', '标示条', 1, 1, 2, NULL, 'HRF-M5', 5.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (85, '3004002029', '防水橡胶垫片', 1, 1, 2, NULL, 'HRF-M5', 6.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (86, '3004007004', '白色脚钉', 1, 1, 2, NULL, 'HRF-M5', 6.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (87, '3006001016', '整卷电缆线', 1, 1, 2, NULL, 'HRF-M5 RW2x0.52 红白', 6.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (88, '3009001085', '弹簧', 1, 1, 2, NULL, 'HRF-M5', 9.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (89, '3011001132', '沉头自攻螺钉', 1, 1, 2, NULL, 'HRF-M5 ST3x8 头部直径6.1', 4.00, 500, 1000, 1, NULL, '2025-04-28 11:01:58', '2025-04-28 11:01:58');
INSERT INTO `materials` VALUES (90, '3011001283', '十字盘头带垫一体自攻螺丝', 1, 1, 2, NULL, 'ST3×6*7 平尾   304', 3.00, 500, 1000, 1, NULL, '2025-04-28 11:01:59', '2025-04-28 11:01:59');
INSERT INTO `materials` VALUES (91, '4001002001', '包装外箱（中文）', 1, 1, 2, NULL, 'KCB02 370x340x250mm', 1.00, 500, 1000, 1, NULL, '2025-04-28 11:01:59', '2025-04-28 11:01:59');
INSERT INTO `materials` VALUES (92, '4002002169', '飞机盒', 1, 1, 2, NULL, 'HRF-M5', 2.00, 500, 1000, 1, NULL, '2025-04-28 11:01:59', '2025-04-28 11:01:59');
INSERT INTO `materials` VALUES (93, '4003003014', '警示标签 闪电', 1, 1, 2, NULL, 'HRF-MD2 A3  (23x20)黄底黑字', 6.00, 500, 1000, 1, NULL, '2025-04-28 11:01:59', '2025-04-28 11:01:59');
INSERT INTO `materials` VALUES (94, '4003003018', '警示标签 感叹', 1, 1, 2, NULL, 'HRF-MD2 B3  (23x20)黄底黑字', 1.00, 500, 1000, 1, NULL, '2025-04-28 11:01:59', '2025-04-28 11:01:59');
INSERT INTO `materials` VALUES (95, '4005001012', '塑料袋', 1, 10, 2, NULL, 'HRF-HD3N 400x250mm', 2.00, 500, 1000, 1, NULL, '2025-04-28 11:01:59', '2025-04-28 11:01:59');
INSERT INTO `materials` VALUES (96, '105215012', '脚踏开关', 3, 1, 3, '成品仓库', 'HRF-M5Y', 60.00, 10, 100, 1, '', '2025-04-28 11:04:07', '2025-04-28 11:04:07');
INSERT INTO `materials` VALUES (97, '105201006', '脚踏开关', 3, 1, 3, '成品仓库', 'HRF-M1Y', 30.00, 10, 100, 1, '', '2025-04-28 11:04:45', '2025-04-28 11:05:20');
INSERT INTO `materials` VALUES (98, '3001023002', '蓝色踏板', 1, 1, 2, '零部件仓库', 'HRF-M5B', 2.00, 100, 1000, 1, '', '2025-04-28 11:23:20', '2025-04-28 11:23:20');
INSERT INTO `materials` VALUES (99, '105215037', '脚踏开关', 3, 1, 3, '成品仓库', 'HRF-M5B', 60.00, 10, 100, 1, '', '2025-04-28 11:23:55', '2025-04-28 15:55:15');
INSERT INTO `materials` VALUES (101, '300102300201', '黑色踏板', 1, 1, 2, '零部件仓库', 'HRF-M5K', 6.00, 100, 1000, 1, '', '2025-05-08 13:15:50', '2025-05-08 13:16:02');

-- ----------------------------
-- Table structure for menus
-- ----------------------------
DROP TABLE IF EXISTS `menus`;
CREATE TABLE `menus`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` int NULL DEFAULT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `path` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `component` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `redirect` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `icon` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `permission` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `type` tinyint NOT NULL DEFAULT 0 COMMENT '0-目录 1-菜单 2-按钮',
  `visible` tinyint NOT NULL DEFAULT 1,
  `status` tinyint NOT NULL DEFAULT 1,
  `sort_order` int NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `parent_id`(`parent_id` ASC) USING BTREE,
  INDEX `status`(`status` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 719 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of menus
-- ----------------------------
INSERT INTO `menus` VALUES (1, 0, '仪表盘', '/', 'Dashboard', NULL, 'icon-dashboard', 'dashboard', 1, 1, 1, 1, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (2, 0, '生产管理', '/production', '', NULL, 'icon-data-line', 'production', 0, 1, 1, 2, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (3, 0, '基础数据', '/baseData', '', NULL, 'icon-base', 'baseData', 0, 1, 1, 3, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (4, 0, '库存管理', '/inventory', '', NULL, 'icon-inventory', 'inventory', 0, 1, 1, 4, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (5, 0, '采购管理', '/purchase', '', NULL, 'icon-shopping-bag', 'purchase', 0, 1, 1, 5, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (6, 0, '销售管理', '/sales', '', NULL, 'icon-sales', 'sales', 0, 1, 1, 6, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (7, 0, '财务管理', '/finance', '', NULL, 'icon-money', 'finance', 0, 1, 1, 7, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (8, 0, '质量管理', '/quality', '', NULL, 'icon-quality', 'quality', 0, 1, 1, 8, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (9, 0, '系统管理', '/system', '', NULL, 'icon-setting', 'system', 0, 1, 1, 9, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (21, 2, '生产计划', '/production/plan', 'production/ProductionPlan', NULL, 'icon-calendar', 'production:plan', 1, 1, 1, 1, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (22, 2, '生产任务', '/production/task', 'production/ProductionTask', NULL, 'icon-tickets', 'production:task', 1, 1, 1, 2, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (23, 2, '生产过程', '/production/process', 'production/ProductionProcess', NULL, 'icon-set-up', 'production:process', 1, 1, 1, 3, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (24, 2, '生产报工', '/production/report', 'production/ProductionReport', NULL, 'icon-data-analysis', 'production:report', 1, 1, 1, 4, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (31, 3, '物料管理', '/baseData/materials', 'baseData/Materials', NULL, 'icon-material', 'baseData:materials', 1, 1, 1, 1, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (32, 3, 'BOM管理', '/baseData/boms', 'baseData/Boms', NULL, 'icon-bom', 'baseData:boms', 1, 1, 1, 2, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (33, 3, '客户管理', '/baseData/customers', 'baseData/Customers', NULL, 'icon-customer', 'baseData:customers', 1, 1, 1, 3, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (34, 3, '供应商管理', '/baseData/suppliers', 'baseData/Suppliers', NULL, 'icon-supplier', 'baseData:suppliers', 1, 1, 1, 4, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (35, 3, '分类管理', '/baseData/categories', 'baseData/Categories', NULL, 'icon-category', 'baseData:categories', 1, 1, 1, 5, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (36, 3, '单位管理', '/baseData/units', 'baseData/Units', NULL, 'icon-unit', 'baseData:units', 1, 1, 1, 6, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (37, 3, '库位管理', '/baseData/locations', 'baseData/Locations', NULL, 'icon-location', 'baseData:locations', 1, 1, 1, 7, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (41, 4, '库存查询', '/inventory/stock', 'inventory/InventoryStock', NULL, 'icon-stock', 'inventory:stock', 1, 1, 1, 1, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (42, 4, '入库管理', '/inventory/inbound', 'inventory/InventoryInbound', NULL, 'icon-plus', 'inventory:inbound', 1, 1, 1, 2, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (43, 4, '出库管理', '/inventory/outbound', 'inventory/InventoryOutbound', NULL, 'icon-minus', 'inventory:outbound', 1, 1, 1, 3, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (44, 4, '库存调拨', '/inventory/transfer', 'inventory/InventoryTransfer', NULL, 'icon-right', 'inventory:transfer', 1, 1, 1, 4, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (45, 4, '库存盘点', '/inventory/check', 'inventory/InventoryCheck', NULL, 'icon-check', 'inventory:check', 1, 1, 1, 5, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (51, 5, '采购申请', '/purchase/requisitions', 'purchase/PurchaseRequisitions', NULL, 'icon-document', 'purchase:requisitions', 1, 1, 1, 1, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (52, 5, '采购订单', '/purchase/orders', 'purchase/PurchaseOrders', NULL, 'icon-wallet', 'purchase:orders', 1, 1, 1, 2, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (53, 5, '采购入库', '/purchase/receipts', 'purchase/PurchaseReceipts', NULL, 'icon-goods', 'purchase:receipts', 1, 1, 1, 3, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (54, 5, '采购退货', '/purchase/returns', 'purchase/PurchaseReturns', NULL, 'icon-return', 'purchase:returns', 1, 1, 1, 4, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (61, 6, '销售订单', '/sales/orders', 'sales/SalesOrders', NULL, 'icon-order', 'sales:orders', 1, 1, 1, 1, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (62, 6, '销售出库', '/sales/outbound', 'sales/SalesOutbound', NULL, 'icon-outbound', 'sales:outbound', 1, 1, 1, 2, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (63, 6, '销售退货', '/sales/returns', 'sales/SalesReturns', NULL, 'icon-return', 'sales:returns', 1, 1, 1, 3, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (64, 6, '销售换货', '/sales/exchanges', 'sales/SalesExchanges', NULL, 'icon-exchange', 'sales:exchanges', 1, 1, 1, 4, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (65, 6, '报价单统计', '/sales/quotations', 'sales/SalesQuotations', NULL, 'icon-quotation', 'sales:quotations', 1, 1, 1, 5, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (71, 7, '会计科目', '/finance/gl/accounts', 'finance/gl/Accounts', NULL, 'icon-account', 'finance:gl:accounts', 1, 1, 1, 1, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (72, 7, '会计凭证', '/finance/gl/entries', 'finance/gl/Entries', NULL, 'icon-document', 'finance:gl:entries', 1, 1, 1, 2, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (73, 7, '会计期间', '/finance/gl/periods', 'finance/gl/Periods', NULL, 'icon-calendar', 'finance:gl:periods', 1, 1, 1, 3, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (74, 7, '应收账款', '/finance/ar/invoices', 'finance/ar/Invoices', NULL, 'icon-tickets', 'finance:ar:invoices', 1, 1, 1, 4, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (75, 7, '收款管理', '/finance/ar/receipts', 'finance/ar/Receipts', NULL, 'icon-money', 'finance:ar:receipts', 1, 1, 1, 5, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (76, 7, '账龄分析', '/finance/ar/aging', 'finance/ar/Aging', NULL, 'icon-data-analysis', 'finance:ar:aging', 1, 1, 1, 6, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (77, 7, '应付账款', '/finance/ap/invoices', 'finance/ap/Invoices', NULL, 'icon-document', 'finance:ap:invoices', 1, 1, 1, 7, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (78, 7, '付款管理', '/finance/ap/payments', 'finance/ap/Payments', NULL, 'icon-money', 'finance:ap:payments', 1, 1, 1, 8, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (79, 7, '账龄分析', '/finance/ap/aging', 'finance/ap/Aging', NULL, 'icon-data-analysis', 'finance:ap:aging', 1, 1, 1, 9, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (81, 8, '来料检验', '/quality/incoming', 'quality/IncomingInspection', NULL, 'icon-document', 'quality:incoming', 1, 1, 1, 1, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (82, 8, '过程检验', '/quality/process', 'quality/ProcessInspection', NULL, 'icon-outbound', 'quality:process', 1, 1, 1, 2, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (83, 8, '成品检验', '/quality/final', 'quality/FinalInspection', NULL, 'icon-return', 'quality:final', 1, 1, 1, 3, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (84, 8, '检验模板', '/quality/templates', 'quality/InspectionTemplates', NULL, 'icon-document', 'quality:templates', 1, 1, 1, 4, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (85, 8, '追溯管理', '/quality/traceability', 'quality/TraceabilityManagement', NULL, 'icon-connection', 'quality:traceability', 1, 1, 1, 5, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (91, 9, '用户管理', '/system/users', 'system/Users', NULL, 'icon-user', 'system:users', 1, 1, 1, 1, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (92, 9, '部门管理', '/system/departments', 'system/Departments', NULL, 'icon-office-building', 'system:departments', 1, 1, 1, 2, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (93, 9, '权限设置', '/system/permissions', 'system/Permissions', NULL, 'icon-lock', 'system:permissions', 1, 1, 1, 3, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (710, 7, '固定资产', '/finance/assets/list', 'finance/assets/AssetsList', NULL, 'icon-goods', 'finance:assets:list', 1, 1, 1, 10, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (711, 7, '资产类别', '/finance/assets/categories', 'finance/assets/AssetCategoryList', NULL, 'icon-folder', 'finance:assets:categories', 1, 1, 1, 11, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (712, 7, '折旧管理', '/finance/assets/depreciation', 'finance/assets/Depreciation', NULL, 'icon-calendar', 'finance:assets:depreciation', 1, 1, 1, 12, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (713, 7, '银行账户', '/finance/cash/accounts', 'finance/cash/BankAccounts', NULL, 'icon-wallet', 'finance:cash:accounts', 1, 1, 1, 13, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (714, 7, '交易记录', '/finance/cash/transactions', 'finance/cash/Transactions', NULL, 'icon-right', 'finance:cash:transactions', 1, 1, 1, 14, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (715, 7, '银行对账', '/finance/cash/reconciliation', 'finance/cash/Reconciliation', NULL, 'icon-check', 'finance:cash:reconciliation', 1, 1, 1, 15, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (716, 7, '资产负债表', '/finance/reports/balance-sheet', 'finance/reports/BalanceSheet', NULL, 'icon-document', 'finance:reports:balance-sheet', 1, 1, 1, 16, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (717, 7, '利润表', '/finance/reports/income-statement', 'finance/reports/IncomeStatement', NULL, 'icon-data-analysis', 'finance:reports:income-statement', 1, 1, 1, 17, '2025-04-19 10:03:32', '2025-04-19 10:03:32');
INSERT INTO `menus` VALUES (718, 7, '现金流量表', '/finance/reports/cash-flow', 'finance/reports/CashFlow', NULL, 'icon-wallet', 'finance:reports:cash-flow', 1, 1, 1, 18, '2025-04-19 10:03:32', '2025-04-19 10:03:32');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `customer` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `product` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `quantity` int NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of orders
-- ----------------------------

-- ----------------------------
-- Table structure for outsourced_processing_materials
-- ----------------------------
DROP TABLE IF EXISTS `outsourced_processing_materials`;
CREATE TABLE `outsourced_processing_materials`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `processing_id` int NOT NULL,
  `material_id` int NULL DEFAULT NULL,
  `material_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `material_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `specification` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `unit` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `unit_id` int NULL DEFAULT NULL,
  `quantity` decimal(10, 2) NOT NULL,
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `processing_id`(`processing_id` ASC) USING BTREE,
  INDEX `material_id`(`material_id` ASC) USING BTREE,
  INDEX `unit_id`(`unit_id` ASC) USING BTREE,
  CONSTRAINT `outsourced_processing_materials_ibfk_1` FOREIGN KEY (`processing_id`) REFERENCES `outsourced_processings` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `outsourced_processing_materials_ibfk_2` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `outsourced_processing_materials_ibfk_3` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 20 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of outsourced_processing_materials
-- ----------------------------
INSERT INTO `outsourced_processing_materials` VALUES (6, 9, 98, '3001023002', '蓝色踏板', '', '个', 1, 100.00, '', '2025-05-08 14:19:25', '2025-05-08 14:19:25');
INSERT INTO `outsourced_processing_materials` VALUES (7, 10, 98, '3001023002', '蓝色踏板', '', '个', 1, 6.00, '', '2025-05-08 14:35:30', '2025-05-08 14:35:30');
INSERT INTO `outsourced_processing_materials` VALUES (8, 11, 94, '4003003018', '警示标签 感叹', '', '个', 1, 100.00, '', '2025-05-08 14:45:59', '2025-05-08 14:45:59');
INSERT INTO `outsourced_processing_materials` VALUES (9, 12, 98, '3001023002', '蓝色踏板', '', '个', 1, 100.00, '', '2025-05-08 15:12:13', '2025-05-08 15:12:13');
INSERT INTO `outsourced_processing_materials` VALUES (10, 13, 101, '300102300201', '黑色踏板', '', '个', 1, 200.00, '', '2025-05-08 15:19:08', '2025-05-08 15:19:08');
INSERT INTO `outsourced_processing_materials` VALUES (11, 14, 101, '300102300201', '黑色踏板', '', '个', 1, 20.00, '', '2025-05-08 15:20:58', '2025-05-08 15:20:58');
INSERT INTO `outsourced_processing_materials` VALUES (12, 15, 101, '300102300201', '黑色踏板', '', '个', 1, 20.00, '', '2025-05-08 15:22:37', '2025-05-08 15:22:37');
INSERT INTO `outsourced_processing_materials` VALUES (13, 16, 101, '300102300201', '黑色踏板', '', '个', 1, 100.00, '', '2025-05-08 15:25:04', '2025-05-08 15:25:04');
INSERT INTO `outsourced_processing_materials` VALUES (14, 17, 98, '3001023002', '蓝色踏板', '', '个', 1, 100.00, '', '2025-05-08 15:47:19', '2025-05-08 15:47:19');
INSERT INTO `outsourced_processing_materials` VALUES (15, 18, 98, '3001023002', '蓝色踏板', '', '个', 1, 50.00, '', '2025-05-09 09:37:26', '2025-05-09 09:37:26');
INSERT INTO `outsourced_processing_materials` VALUES (16, 19, 98, '3001023002', '蓝色踏板', '', '个', 1, 1.00, '', '2025-05-10 20:41:02', '2025-05-10 20:41:02');
INSERT INTO `outsourced_processing_materials` VALUES (17, 20, 98, '3001023002', '蓝色踏板', '', '个', 1, 1.00, '', '2025-05-10 20:43:04', '2025-05-10 20:43:04');
INSERT INTO `outsourced_processing_materials` VALUES (18, 21, 101, '300102300201', '黑色踏板', '', '个', 1, 1.00, '', '2025-05-10 20:44:16', '2025-05-10 20:44:16');
INSERT INTO `outsourced_processing_materials` VALUES (19, 22, 98, '3001023002', '蓝色踏板', '', '个', 1, 1.00, '', '2025-05-10 20:54:21', '2025-05-10 20:54:21');

-- ----------------------------
-- Table structure for outsourced_processing_products
-- ----------------------------
DROP TABLE IF EXISTS `outsourced_processing_products`;
CREATE TABLE `outsourced_processing_products`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `processing_id` int NOT NULL,
  `product_id` int NULL DEFAULT NULL,
  `product_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `product_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `specification` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `unit` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `unit_id` int NULL DEFAULT NULL,
  `quantity` decimal(10, 2) NOT NULL,
  `unit_price` decimal(10, 2) NOT NULL,
  `total_price` decimal(12, 2) NOT NULL,
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `processing_id`(`processing_id` ASC) USING BTREE,
  INDEX `product_id`(`product_id` ASC) USING BTREE,
  INDEX `unit_id`(`unit_id` ASC) USING BTREE,
  CONSTRAINT `outsourced_processing_products_ibfk_1` FOREIGN KEY (`processing_id`) REFERENCES `outsourced_processings` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `outsourced_processing_products_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `materials` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `outsourced_processing_products_ibfk_3` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 20 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of outsourced_processing_products
-- ----------------------------
INSERT INTO `outsourced_processing_products` VALUES (6, 9, 101, '300102300201', '黑色踏板', '', '个', 1, 100.00, 10.00, 1000.00, '', '2025-05-08 14:19:25', '2025-05-08 14:19:25');
INSERT INTO `outsourced_processing_products` VALUES (7, 10, 101, '300102300201', '黑色踏板', '', '个', 1, 6.00, 6.00, 36.00, '', '2025-05-08 14:35:30', '2025-05-08 14:35:30');
INSERT INTO `outsourced_processing_products` VALUES (8, 11, 93, '4003003014', '警示标签 闪电', '', '个', 1, 100.00, 1.00, 100.00, '', '2025-05-08 14:45:59', '2025-05-08 14:45:59');
INSERT INTO `outsourced_processing_products` VALUES (9, 12, 101, '300102300201', '黑色踏板', '', '个', 1, 100.00, 5.00, 500.00, '', '2025-05-08 15:12:13', '2025-05-08 15:12:13');
INSERT INTO `outsourced_processing_products` VALUES (10, 13, 98, '3001023002', '蓝色踏板', '', '个', 1, 100.00, 0.00, 0.00, '', '2025-05-08 15:19:08', '2025-05-08 15:19:08');
INSERT INTO `outsourced_processing_products` VALUES (11, 14, 98, '3001023002', '蓝色踏板', '', '个', 1, 20.00, 5.00, 100.00, '', '2025-05-08 15:20:58', '2025-05-08 15:20:58');
INSERT INTO `outsourced_processing_products` VALUES (12, 15, 98, '3001023002', '蓝色踏板', '', '个', 1, 20.00, 0.00, 0.00, '', '2025-05-08 15:22:37', '2025-05-08 15:22:37');
INSERT INTO `outsourced_processing_products` VALUES (13, 16, 98, '3001023002', '蓝色踏板', '', '个', 1, 100.00, 0.00, 0.00, '', '2025-05-08 15:25:04', '2025-05-08 15:25:04');
INSERT INTO `outsourced_processing_products` VALUES (14, 17, 101, '300102300201', '黑色踏板', '', '个', 1, 100.00, 5.00, 500.00, '', '2025-05-08 15:47:19', '2025-05-08 15:47:19');
INSERT INTO `outsourced_processing_products` VALUES (15, 18, 101, '300102300201', '黑色踏板', '', '个', 1, 50.00, 10.00, 500.00, '', '2025-05-09 09:37:27', '2025-05-09 09:37:27');
INSERT INTO `outsourced_processing_products` VALUES (16, 19, 101, '300102300201', '黑色踏板', '', '个', 1, 1.00, 2.00, 2.00, '', '2025-05-10 20:41:02', '2025-05-10 20:41:02');
INSERT INTO `outsourced_processing_products` VALUES (17, 20, 101, '300102300201', '黑色踏板', '', '个', 1, 2.00, 0.00, 0.00, '', '2025-05-10 20:43:04', '2025-05-10 20:43:04');
INSERT INTO `outsourced_processing_products` VALUES (18, 21, 98, '3001023002', '蓝色踏板', '', '个', 1, 1.00, 0.00, 0.00, '', '2025-05-10 20:44:16', '2025-05-10 20:44:16');
INSERT INTO `outsourced_processing_products` VALUES (19, 22, 101, '300102300201', '黑色踏板', '', '个', 1, 1.00, 0.00, 0.00, '', '2025-05-10 20:54:21', '2025-05-10 20:54:21');

-- ----------------------------
-- Table structure for outsourced_processing_receipt_items
-- ----------------------------
DROP TABLE IF EXISTS `outsourced_processing_receipt_items`;
CREATE TABLE `outsourced_processing_receipt_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `receipt_id` int NOT NULL,
  `product_id` int NULL DEFAULT NULL,
  `product_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `product_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `specification` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `unit` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `unit_id` int NULL DEFAULT NULL,
  `expected_quantity` decimal(10, 2) NOT NULL,
  `actual_quantity` decimal(10, 2) NOT NULL,
  `unit_price` decimal(10, 2) NOT NULL,
  `total_price` decimal(12, 2) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `receipt_id`(`receipt_id` ASC) USING BTREE,
  INDEX `product_id`(`product_id` ASC) USING BTREE,
  INDEX `unit_id`(`unit_id` ASC) USING BTREE,
  CONSTRAINT `outsourced_processing_receipt_items_ibfk_1` FOREIGN KEY (`receipt_id`) REFERENCES `outsourced_processing_receipts` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `outsourced_processing_receipt_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `materials` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `outsourced_processing_receipt_items_ibfk_3` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 20 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of outsourced_processing_receipt_items
-- ----------------------------
INSERT INTO `outsourced_processing_receipt_items` VALUES (7, 12, 101, '300102300201', '黑色踏板', '', '个', 1, 100.00, 100.00, 10.00, 1000.00, '2025-05-08 14:34:13', '2025-05-08 14:34:13');
INSERT INTO `outsourced_processing_receipt_items` VALUES (8, 13, 101, '300102300201', '黑色踏板', '', '个', 1, 6.00, 6.00, 6.00, 36.00, '2025-05-08 14:36:09', '2025-05-08 14:36:09');
INSERT INTO `outsourced_processing_receipt_items` VALUES (9, 14, 93, '4003003014', '警示标签 闪电', '', '个', 1, 100.00, 100.00, 1.00, 100.00, '2025-05-08 14:47:22', '2025-05-08 14:47:22');
INSERT INTO `outsourced_processing_receipt_items` VALUES (10, 15, 101, '300102300201', '黑色踏板', '', '个', 1, 100.00, 100.00, 5.00, 500.00, '2025-05-08 15:16:34', '2025-05-08 15:16:34');
INSERT INTO `outsourced_processing_receipt_items` VALUES (11, 16, 98, '3001023002', '蓝色踏板', '', '个', 1, 100.00, 100.00, 0.00, 0.00, '2025-05-08 15:19:20', '2025-05-08 15:19:20');
INSERT INTO `outsourced_processing_receipt_items` VALUES (12, 17, 98, '3001023002', '蓝色踏板', '', '个', 1, 20.00, 20.00, 5.00, 100.00, '2025-05-08 15:21:08', '2025-05-08 15:21:08');
INSERT INTO `outsourced_processing_receipt_items` VALUES (13, 18, 98, '3001023002', '蓝色踏板', '', '个', 1, 20.00, 20.00, 0.00, 0.00, '2025-05-08 15:22:46', '2025-05-08 15:22:46');
INSERT INTO `outsourced_processing_receipt_items` VALUES (14, 19, 98, '3001023002', '蓝色踏板', '', '个', 1, 100.00, 100.00, 0.00, 0.00, '2025-05-08 15:25:12', '2025-05-08 15:25:12');
INSERT INTO `outsourced_processing_receipt_items` VALUES (15, 20, 101, '300102300201', '黑色踏板', '', '个', 1, 50.00, 50.00, 10.00, 500.00, '2025-05-09 09:37:52', '2025-05-09 09:37:52');
INSERT INTO `outsourced_processing_receipt_items` VALUES (16, 21, 101, '300102300201', '黑色踏板', '', '个', 1, 1.00, 1.00, 2.00, 2.00, '2025-05-10 20:41:24', '2025-05-10 20:41:24');
INSERT INTO `outsourced_processing_receipt_items` VALUES (17, 22, 101, '300102300201', '黑色踏板', '', '个', 1, 2.00, 2.00, 0.00, 0.00, '2025-05-10 20:43:23', '2025-05-10 20:43:23');
INSERT INTO `outsourced_processing_receipt_items` VALUES (18, 23, 98, '3001023002', '蓝色踏板', '', '个', 1, 1.00, 1.00, 0.00, 0.00, '2025-05-10 20:48:18', '2025-05-10 20:48:18');
INSERT INTO `outsourced_processing_receipt_items` VALUES (19, 24, 101, '300102300201', '黑色踏板', '', '个', 1, 100.00, 100.00, 5.00, 500.00, '2025-05-10 20:53:39', '2025-05-10 20:53:39');

-- ----------------------------
-- Table structure for outsourced_processing_receipts
-- ----------------------------
DROP TABLE IF EXISTS `outsourced_processing_receipts`;
CREATE TABLE `outsourced_processing_receipts`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `receipt_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `processing_id` int NULL DEFAULT NULL,
  `processing_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `supplier_id` int NULL DEFAULT NULL,
  `supplier_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `warehouse_id` int NULL DEFAULT NULL,
  `warehouse_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `receipt_date` date NOT NULL,
  `operator` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `receipt_no`(`receipt_no` ASC) USING BTREE,
  INDEX `processing_id`(`processing_id` ASC) USING BTREE,
  INDEX `supplier_id`(`supplier_id` ASC) USING BTREE,
  INDEX `outsourced_processing_receipts_location_fk`(`warehouse_id` ASC) USING BTREE,
  CONSTRAINT `outsourced_processing_receipts_ibfk_1` FOREIGN KEY (`processing_id`) REFERENCES `outsourced_processings` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `outsourced_processing_receipts_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `outsourced_processing_receipts_location_fk` FOREIGN KEY (`warehouse_id`) REFERENCES `locations` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 25 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of outsourced_processing_receipts
-- ----------------------------
INSERT INTO `outsourced_processing_receipts` VALUES (12, 'WWRK250508001', 9, 'WW250508001', 13, '乐清市朗盛电子科技有限公司', 2, '零部件仓库', '2025-05-08', '123', '', 'confirmed', '2025-05-08 14:34:13', '2025-05-08 14:34:19');
INSERT INTO `outsourced_processing_receipts` VALUES (13, 'WWRK250508002', 10, 'WW250508002', 12, '常州市瑞发电子有限公司', 2, '零部件仓库', '2025-05-08', '123', '', 'confirmed', '2025-05-08 14:36:09', '2025-05-08 14:36:13');
INSERT INTO `outsourced_processing_receipts` VALUES (14, 'WWRK250508003', 11, 'WW250508003', 13, '乐清市朗盛电子科技有限公司', 2, '零部件仓库', '2025-05-08', '王晓敏', '', 'confirmed', '2025-05-08 14:47:22', '2025-05-08 14:47:26');
INSERT INTO `outsourced_processing_receipts` VALUES (15, 'WWRK250508004', 12, 'WW250508004', 13, '乐清市朗盛电子科技有限公司', 2, '零部件仓库', '2025-05-08', '王晓敏', '', 'confirmed', '2025-05-08 15:16:34', '2025-05-08 15:16:38');
INSERT INTO `outsourced_processing_receipts` VALUES (16, 'WWRK250508005', 13, 'WW250508005', 13, '乐清市朗盛电子科技有限公司', 2, '零部件仓库', '2025-05-08', '王晓敏', '', 'confirmed', '2025-05-08 15:19:20', '2025-05-08 15:19:26');
INSERT INTO `outsourced_processing_receipts` VALUES (17, 'WWRK250508006', 14, 'WW250508006', 12, '常州市瑞发电子有限公司', 3, '成品仓库', '2025-05-08', '王晓敏', '', 'confirmed', '2025-05-08 15:21:08', '2025-05-08 15:21:11');
INSERT INTO `outsourced_processing_receipts` VALUES (18, 'WWRK250508007', 15, 'WW250508007', 11, '乐清市通达有线电厂', 2, '零部件仓库', '2025-05-08', '123', '', 'confirmed', '2025-05-08 15:22:46', '2025-05-08 15:22:50');
INSERT INTO `outsourced_processing_receipts` VALUES (19, 'WWRK250508008', 16, 'WW250508008', 13, '乐清市朗盛电子科技有限公司', 2, '零部件仓库', '2025-05-08', '123', '', 'confirmed', '2025-05-08 15:25:12', '2025-05-08 15:25:15');
INSERT INTO `outsourced_processing_receipts` VALUES (20, 'WWRK250509001', 18, 'WW250509001', 11, '乐清市通达有线电厂', 2, '零部件仓库', '2025-05-09', '王晓敏', '', 'confirmed', '2025-05-09 09:37:51', '2025-05-09 09:38:00');
INSERT INTO `outsourced_processing_receipts` VALUES (21, 'WWRK250510001', 19, 'WW250510001', 13, '乐清市朗盛电子科技有限公司', 2, '零部件仓库', '2025-05-10', '王晓敏', '', 'confirmed', '2025-05-10 20:41:24', '2025-05-10 20:41:43');
INSERT INTO `outsourced_processing_receipts` VALUES (22, 'WWRK250510002', 20, 'WW250510002', 13, '乐清市朗盛电子科技有限公司', 2, '零部件仓库', '2025-05-10', '王晓敏', '', 'confirmed', '2025-05-10 20:43:23', '2025-05-10 20:50:38');
INSERT INTO `outsourced_processing_receipts` VALUES (23, 'WWRK250510003', 21, 'WW250510003', 13, '乐清市朗盛电子科技有限公司', 2, '零部件仓库', '2025-05-10', '王晓敏', '', 'confirmed', '2025-05-10 20:48:18', '2025-05-10 20:48:29');
INSERT INTO `outsourced_processing_receipts` VALUES (24, 'WWRK250510004', 17, 'WW250508009', 12, '常州市瑞发电子有限公司', 2, '零部件仓库', '2025-05-10', '王晓敏', '', 'pending', '2025-05-10 20:53:39', '2025-05-10 20:53:39');

-- ----------------------------
-- Table structure for outsourced_processings
-- ----------------------------
DROP TABLE IF EXISTS `outsourced_processings`;
CREATE TABLE `outsourced_processings`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `processing_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `processing_date` date NOT NULL,
  `supplier_id` int NULL DEFAULT NULL,
  `supplier_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `expected_delivery_date` date NULL DEFAULT NULL,
  `contact_person` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `contact_phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `total_amount` decimal(12, 2) NULL DEFAULT 0.00,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `processing_no`(`processing_no` ASC) USING BTREE,
  INDEX `supplier_id`(`supplier_id` ASC) USING BTREE,
  CONSTRAINT `outsourced_processings_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 23 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of outsourced_processings
-- ----------------------------
INSERT INTO `outsourced_processings` VALUES (9, 'WW250508001', '2025-05-08', 13, '乐清市朗盛电子科技有限公司', '2025-05-08', '', '', 1000.00, '', 'completed', '2025-05-08 14:19:25', '2025-05-08 14:34:20');
INSERT INTO `outsourced_processings` VALUES (10, 'WW250508002', '2025-05-08', 12, '常州市瑞发电子有限公司', '2025-05-08', '', '', 36.00, '', 'completed', '2025-05-08 14:35:30', '2025-05-08 14:36:13');
INSERT INTO `outsourced_processings` VALUES (11, 'WW250508003', '2025-05-08', 13, '乐清市朗盛电子科技有限公司', '2025-05-08', '', '', 100.00, '', 'completed', '2025-05-08 14:45:59', '2025-05-08 14:47:27');
INSERT INTO `outsourced_processings` VALUES (12, 'WW250508004', '2025-05-08', 13, '乐清市朗盛电子科技有限公司', '2025-05-08', '', '', 500.00, '', 'completed', '2025-05-08 15:12:13', '2025-05-08 15:16:39');
INSERT INTO `outsourced_processings` VALUES (13, 'WW250508005', '2025-05-08', 13, '乐清市朗盛电子科技有限公司', '2025-05-08', '', '', 0.00, '', 'completed', '2025-05-08 15:19:08', '2025-05-08 15:19:26');
INSERT INTO `outsourced_processings` VALUES (14, 'WW250508006', '2025-05-08', 12, '常州市瑞发电子有限公司', '2025-05-08', '', '', 100.00, '', 'completed', '2025-05-08 15:20:58', '2025-05-08 15:21:11');
INSERT INTO `outsourced_processings` VALUES (15, 'WW250508007', '2025-05-08', 11, '乐清市通达有线电厂', '2025-05-08', '', '', 0.00, '', 'completed', '2025-05-08 15:22:37', '2025-05-08 15:22:50');
INSERT INTO `outsourced_processings` VALUES (16, 'WW250508008', '2025-05-08', 13, '乐清市朗盛电子科技有限公司', '2025-05-08', '', '', 0.00, '', 'completed', '2025-05-08 15:25:04', '2025-05-08 15:25:16');
INSERT INTO `outsourced_processings` VALUES (17, 'WW250508009', '2025-05-08', 12, '常州市瑞发电子有限公司', '2025-05-08', '', '', 500.00, '', 'completed', '2025-05-08 15:47:19', '2025-05-10 20:53:39');
INSERT INTO `outsourced_processings` VALUES (18, 'WW250509001', '2025-05-09', 11, '乐清市通达有线电厂', '2025-05-10', '', '', 500.00, '', 'completed', '2025-05-09 09:37:26', '2025-05-09 09:38:04');
INSERT INTO `outsourced_processings` VALUES (19, 'WW250510001', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '', '', 2.00, '', 'completed', '2025-05-10 20:41:02', '2025-05-10 20:41:43');
INSERT INTO `outsourced_processings` VALUES (20, 'WW250510002', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '', '', 0.00, '', 'completed', '2025-05-10 20:43:04', '2025-05-10 20:50:38');
INSERT INTO `outsourced_processings` VALUES (21, 'WW250510003', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '', '', 0.00, '', 'completed', '2025-05-10 20:44:16', '2025-05-10 20:48:29');
INSERT INTO `outsourced_processings` VALUES (22, 'WW250510004', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '王晓敏', '1800000', 0.00, '', 'confirmed', '2025-05-10 20:54:21', '2025-05-10 20:55:12');

-- ----------------------------
-- Table structure for process_template_details
-- ----------------------------
DROP TABLE IF EXISTS `process_template_details`;
CREATE TABLE `process_template_details`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `template_id` int NOT NULL COMMENT '模板ID',
  `order_num` int NOT NULL COMMENT '工序顺序',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '工序名称',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '工序描述',
  `standard_hours` decimal(10, 2) NOT NULL DEFAULT 0.00 COMMENT '标准工时(小时)',
  `department` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '执行部门',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_template_id`(`template_id` ASC) USING BTREE,
  INDEX `idx_order`(`order_num` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 17 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '工序模板明细表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of process_template_details
-- ----------------------------
INSERT INTO `process_template_details` VALUES (13, 3, 1, '绕线', '', 1.00, '', '', '2025-04-26 11:04:26', '2025-04-26 11:04:26');
INSERT INTO `process_template_details` VALUES (14, 3, 2, '裁线', '', 1.00, '', '', '2025-04-26 11:04:26', '2025-04-26 11:04:26');
INSERT INTO `process_template_details` VALUES (15, 3, 3, '焊锡', '', 1.00, '', '', '2025-04-26 11:04:26', '2025-04-26 11:04:26');
INSERT INTO `process_template_details` VALUES (16, 3, 4, '装配', '', 1.00, '', '', '2025-04-26 11:04:26', '2025-04-26 11:04:26');

-- ----------------------------
-- Table structure for process_templates
-- ----------------------------
DROP TABLE IF EXISTS `process_templates`;
CREATE TABLE `process_templates`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '模板编号',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '模板名称',
  `product_id` int NULL DEFAULT NULL COMMENT '关联产品ID',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '模板描述',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '状态：0-禁用, 1-启用',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `idx_template_code`(`code` ASC) USING BTREE,
  INDEX `idx_product_id`(`product_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '工序模板表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of process_templates
-- ----------------------------
INSERT INTO `process_templates` VALUES (3, 'PT003', '脚踏开关-105215281', 56, '', 1, '2025-04-26 11:04:26', '2025-04-26 11:04:26');

-- ----------------------------
-- Table structure for processes
-- ----------------------------
DROP TABLE IF EXISTS `processes`;
CREATE TABLE `processes`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '工序编码',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '工序名称',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '工序描述',
  `standard_time` int NULL DEFAULT NULL COMMENT '标准工时(分钟)',
  `is_active` tinyint(1) NOT NULL DEFAULT 1 COMMENT '是否启用',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `idx_process_code`(`code` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '工序表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of processes
-- ----------------------------
INSERT INTO `processes` VALUES (1, 'P001', '材料准备', '准备生产所需的原材料', 30, 1, '2025-04-15 10:49:26', '2025-04-15 10:49:26');
INSERT INTO `processes` VALUES (2, 'P002', '零件加工', '加工生产所需的零件', 120, 1, '2025-04-15 10:49:26', '2025-04-15 10:49:26');
INSERT INTO `processes` VALUES (3, 'P003', '组装', '将零件组装成成品', 90, 1, '2025-04-15 10:49:26', '2025-04-15 10:49:26');
INSERT INTO `processes` VALUES (4, 'P004', '测试', '对成品进行测试', 60, 1, '2025-04-15 10:49:26', '2025-04-15 10:49:26');
INSERT INTO `processes` VALUES (5, 'P005', '包装', '对成品进行包装', 30, 1, '2025-04-15 10:49:26', '2025-04-15 10:49:26');

-- ----------------------------
-- Table structure for production
-- ----------------------------
DROP TABLE IF EXISTS `production`;
CREATE TABLE `production`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `product` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `planned_quantity` int NOT NULL,
  `actual_quantity` int NULL DEFAULT 0,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'planned',
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of production
-- ----------------------------

-- ----------------------------
-- Table structure for production_exceptions
-- ----------------------------
DROP TABLE IF EXISTS `production_exceptions`;
CREATE TABLE `production_exceptions`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `process_id` int NOT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `solution` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `process_id`(`process_id` ASC) USING BTREE,
  CONSTRAINT `production_exceptions_ibfk_1` FOREIGN KEY (`process_id`) REFERENCES `production_processes` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of production_exceptions
-- ----------------------------

-- ----------------------------
-- Table structure for production_orders
-- ----------------------------
DROP TABLE IF EXISTS `production_orders`;
CREATE TABLE `production_orders`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '工单号',
  `product_id` int NOT NULL COMMENT '产品ID',
  `planned_quantity` int NOT NULL COMMENT '计划数量',
  `actual_quantity` int NULL DEFAULT 0 COMMENT '实际数量',
  `start_date` date NULL DEFAULT NULL COMMENT '计划开始日期',
  `end_date` date NULL DEFAULT NULL COMMENT '计划结束日期',
  `actual_start_date` date NULL DEFAULT NULL COMMENT '实际开始日期',
  `actual_end_date` date NULL DEFAULT NULL COMMENT '实际结束日期',
  `status` enum('pending','in_progress','completed','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'pending' COMMENT '状态',
  `priority` enum('low','medium','high') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'medium' COMMENT '优先级',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `idx_order_no`(`order_no` ASC) USING BTREE,
  INDEX `idx_product_id`(`product_id` ASC) USING BTREE,
  INDEX `idx_status`(`status` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '生产工单表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of production_orders
-- ----------------------------
INSERT INTO `production_orders` VALUES (1, 'PD20250413001', 1, 200, 0, '2025-04-13', '2025-04-15', NULL, NULL, 'in_progress', 'medium', NULL, '2025-04-15 10:52:00', '2025-04-15 10:52:00');
INSERT INTO `production_orders` VALUES (2, 'PD20250412002', 2, 300, 0, '2025-04-12', '2025-04-14', NULL, NULL, 'completed', 'medium', NULL, '2025-04-15 10:52:00', '2025-04-15 10:52:00');
INSERT INTO `production_orders` VALUES (3, 'PD20250411001', 3, 150, 0, '2025-04-11', '2025-04-13', NULL, NULL, 'completed', 'medium', NULL, '2025-04-15 10:52:00', '2025-04-15 10:52:00');
INSERT INTO `production_orders` VALUES (4, 'PD20250410003', 4, 500, 0, '2025-04-10', '2025-04-12', NULL, NULL, 'completed', 'medium', NULL, '2025-04-15 10:52:00', '2025-04-15 10:52:00');

-- ----------------------------
-- Table structure for production_plan_materials
-- ----------------------------
DROP TABLE IF EXISTS `production_plan_materials`;
CREATE TABLE `production_plan_materials`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `plan_id` int NOT NULL COMMENT '生产计划ID',
  `material_id` int NOT NULL COMMENT '物料ID',
  `required_quantity` decimal(10, 2) NOT NULL COMMENT '需求数量',
  `stock_quantity` decimal(10, 2) NOT NULL COMMENT '当前库存数量',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_plan`(`plan_id` ASC) USING BTREE,
  INDEX `idx_material`(`material_id` ASC) USING BTREE,
  CONSTRAINT `fk_plan_materials_material` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_plan_materials_plan` FOREIGN KEY (`plan_id`) REFERENCES `production_plans` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 830 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '生产计划物料需求表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of production_plan_materials
-- ----------------------------
INSERT INTO `production_plan_materials` VALUES (359, 175, 77, 100.00, 0.00, '2025-04-28 14:32:12', '2025-04-28 14:32:12');
INSERT INTO `production_plan_materials` VALUES (360, 175, 78, 100.00, 0.00, '2025-04-28 14:32:12', '2025-04-28 14:32:12');
INSERT INTO `production_plan_materials` VALUES (361, 175, 79, 100.00, 0.00, '2025-04-28 14:32:12', '2025-04-28 14:32:12');
INSERT INTO `production_plan_materials` VALUES (362, 175, 80, 100.00, 0.00, '2025-04-28 14:32:12', '2025-04-28 14:32:12');
INSERT INTO `production_plan_materials` VALUES (363, 175, 81, 100.00, 0.00, '2025-04-28 14:32:12', '2025-04-28 14:32:12');
INSERT INTO `production_plan_materials` VALUES (364, 175, 98, 100.00, 0.00, '2025-04-28 14:32:12', '2025-04-28 14:32:12');
INSERT INTO `production_plan_materials` VALUES (365, 175, 83, 100.00, 0.00, '2025-04-28 14:32:12', '2025-04-28 14:32:12');
INSERT INTO `production_plan_materials` VALUES (366, 175, 84, 100.00, 0.00, '2025-04-28 14:32:12', '2025-04-28 14:32:12');
INSERT INTO `production_plan_materials` VALUES (367, 175, 85, 100.00, 0.00, '2025-04-28 14:32:12', '2025-04-28 14:32:12');
INSERT INTO `production_plan_materials` VALUES (368, 175, 86, 100.00, 0.00, '2025-04-28 14:32:12', '2025-04-28 14:32:12');
INSERT INTO `production_plan_materials` VALUES (369, 175, 87, 100.00, 0.00, '2025-04-28 14:32:12', '2025-04-28 14:32:12');
INSERT INTO `production_plan_materials` VALUES (370, 175, 88, 100.00, 0.00, '2025-04-28 14:32:12', '2025-04-28 14:32:12');
INSERT INTO `production_plan_materials` VALUES (371, 175, 89, 100.00, 0.00, '2025-04-28 14:32:12', '2025-04-28 14:32:12');
INSERT INTO `production_plan_materials` VALUES (372, 175, 90, 100.00, 0.00, '2025-04-28 14:32:12', '2025-04-28 14:32:12');
INSERT INTO `production_plan_materials` VALUES (373, 175, 91, 100.00, 0.00, '2025-04-28 14:32:12', '2025-04-28 14:32:12');
INSERT INTO `production_plan_materials` VALUES (374, 175, 92, 100.00, 0.00, '2025-04-28 14:32:12', '2025-04-28 14:32:12');
INSERT INTO `production_plan_materials` VALUES (375, 175, 93, 100.00, 0.00, '2025-04-28 14:32:12', '2025-04-28 14:32:12');
INSERT INTO `production_plan_materials` VALUES (376, 175, 94, 100.00, 0.00, '2025-04-28 14:32:12', '2025-04-28 14:32:12');
INSERT INTO `production_plan_materials` VALUES (377, 175, 95, 100.00, 0.00, '2025-04-28 14:32:12', '2025-04-28 14:32:12');
INSERT INTO `production_plan_materials` VALUES (378, 176, 77, 1000.00, 0.00, '2025-04-28 14:49:30', '2025-04-28 14:49:30');
INSERT INTO `production_plan_materials` VALUES (379, 176, 78, 1000.00, 0.00, '2025-04-28 14:49:30', '2025-04-28 14:49:30');
INSERT INTO `production_plan_materials` VALUES (380, 176, 79, 1000.00, 0.00, '2025-04-28 14:49:30', '2025-04-28 14:49:30');
INSERT INTO `production_plan_materials` VALUES (381, 176, 80, 1000.00, 0.00, '2025-04-28 14:49:30', '2025-04-28 14:49:30');
INSERT INTO `production_plan_materials` VALUES (382, 176, 81, 1000.00, 0.00, '2025-04-28 14:49:30', '2025-04-28 14:49:30');
INSERT INTO `production_plan_materials` VALUES (383, 176, 82, 1000.00, 0.00, '2025-04-28 14:49:30', '2025-04-28 14:49:30');
INSERT INTO `production_plan_materials` VALUES (384, 176, 83, 1000.00, 0.00, '2025-04-28 14:49:30', '2025-04-28 14:49:30');
INSERT INTO `production_plan_materials` VALUES (385, 176, 84, 1000.00, 0.00, '2025-04-28 14:49:30', '2025-04-28 14:49:30');
INSERT INTO `production_plan_materials` VALUES (386, 176, 85, 1000.00, 0.00, '2025-04-28 14:49:30', '2025-04-28 14:49:30');
INSERT INTO `production_plan_materials` VALUES (387, 176, 86, 1000.00, 0.00, '2025-04-28 14:49:30', '2025-04-28 14:49:30');
INSERT INTO `production_plan_materials` VALUES (388, 176, 87, 1000.00, 0.00, '2025-04-28 14:49:30', '2025-04-28 14:49:30');
INSERT INTO `production_plan_materials` VALUES (389, 176, 88, 1000.00, 0.00, '2025-04-28 14:49:30', '2025-04-28 14:49:30');
INSERT INTO `production_plan_materials` VALUES (390, 176, 89, 1000.00, 0.00, '2025-04-28 14:49:30', '2025-04-28 14:49:30');
INSERT INTO `production_plan_materials` VALUES (391, 176, 90, 1000.00, 0.00, '2025-04-28 14:49:30', '2025-04-28 14:49:30');
INSERT INTO `production_plan_materials` VALUES (392, 176, 91, 1000.00, 0.00, '2025-04-28 14:49:30', '2025-04-28 14:49:30');
INSERT INTO `production_plan_materials` VALUES (393, 176, 92, 1000.00, 0.00, '2025-04-28 14:49:30', '2025-04-28 14:49:30');
INSERT INTO `production_plan_materials` VALUES (394, 176, 93, 1000.00, 0.00, '2025-04-28 14:49:30', '2025-04-28 14:49:30');
INSERT INTO `production_plan_materials` VALUES (395, 176, 94, 1000.00, 0.00, '2025-04-28 14:49:30', '2025-04-28 14:49:30');
INSERT INTO `production_plan_materials` VALUES (396, 176, 95, 1000.00, 0.00, '2025-04-28 14:49:31', '2025-04-28 14:49:31');
INSERT INTO `production_plan_materials` VALUES (397, 177, 77, 1.00, 900.00, '2025-04-28 16:08:34', '2025-04-28 16:08:34');
INSERT INTO `production_plan_materials` VALUES (398, 177, 78, 1.00, 900.00, '2025-04-28 16:08:34', '2025-04-28 16:08:34');
INSERT INTO `production_plan_materials` VALUES (399, 177, 79, 1.00, 900.00, '2025-04-28 16:08:34', '2025-04-28 16:08:34');
INSERT INTO `production_plan_materials` VALUES (400, 177, 80, 1.00, 900.00, '2025-04-28 16:08:34', '2025-04-28 16:08:34');
INSERT INTO `production_plan_materials` VALUES (401, 177, 81, 1.00, 900.00, '2025-04-28 16:08:34', '2025-04-28 16:08:34');
INSERT INTO `production_plan_materials` VALUES (402, 177, 98, 1.00, 1901.00, '2025-04-28 16:08:34', '2025-04-28 16:08:34');
INSERT INTO `production_plan_materials` VALUES (403, 177, 83, 1.00, 900.00, '2025-04-28 16:08:34', '2025-04-28 16:08:34');
INSERT INTO `production_plan_materials` VALUES (404, 177, 84, 1.00, 900.00, '2025-04-28 16:08:34', '2025-04-28 16:08:34');
INSERT INTO `production_plan_materials` VALUES (405, 177, 85, 1.00, 899.99, '2025-04-28 16:08:34', '2025-04-28 16:08:34');
INSERT INTO `production_plan_materials` VALUES (406, 177, 86, 1.00, 900.00, '2025-04-28 16:08:34', '2025-04-28 16:08:34');
INSERT INTO `production_plan_materials` VALUES (407, 177, 87, 1.00, 900.00, '2025-04-28 16:08:34', '2025-04-28 16:08:34');
INSERT INTO `production_plan_materials` VALUES (408, 177, 88, 1.00, 900.00, '2025-04-28 16:08:34', '2025-04-28 16:08:34');
INSERT INTO `production_plan_materials` VALUES (409, 177, 89, 1.00, 900.00, '2025-04-28 16:08:34', '2025-04-28 16:08:34');
INSERT INTO `production_plan_materials` VALUES (410, 177, 90, 1.00, 900.00, '2025-04-28 16:08:34', '2025-04-28 16:08:34');
INSERT INTO `production_plan_materials` VALUES (411, 177, 91, 1.00, 900.00, '2025-04-28 16:08:34', '2025-04-28 16:08:34');
INSERT INTO `production_plan_materials` VALUES (412, 177, 92, 1.00, 901.00, '2025-04-28 16:08:34', '2025-04-28 16:08:34');
INSERT INTO `production_plan_materials` VALUES (413, 177, 93, 1.00, 900.00, '2025-04-28 16:08:34', '2025-04-28 16:08:34');
INSERT INTO `production_plan_materials` VALUES (414, 177, 94, 1.00, 900.00, '2025-04-28 16:08:34', '2025-04-28 16:08:34');
INSERT INTO `production_plan_materials` VALUES (415, 177, 95, 1.00, 900.00, '2025-04-28 16:08:34', '2025-04-28 16:08:34');
INSERT INTO `production_plan_materials` VALUES (435, 179, 60, 1.00, 2000.00, '2025-04-28 16:42:23', '2025-04-28 16:42:23');
INSERT INTO `production_plan_materials` VALUES (436, 179, 61, 1.00, 2000.00, '2025-04-28 16:42:24', '2025-04-28 16:42:24');
INSERT INTO `production_plan_materials` VALUES (437, 179, 62, 1.00, 2000.00, '2025-04-28 16:42:24', '2025-04-28 16:42:24');
INSERT INTO `production_plan_materials` VALUES (438, 179, 63, 1.00, 2000.00, '2025-04-28 16:42:25', '2025-04-28 16:42:25');
INSERT INTO `production_plan_materials` VALUES (439, 179, 64, 1.00, 2000.00, '2025-04-28 16:42:25', '2025-04-28 16:42:25');
INSERT INTO `production_plan_materials` VALUES (440, 179, 65, 1.00, 2000.00, '2025-04-28 16:42:26', '2025-04-28 16:42:26');
INSERT INTO `production_plan_materials` VALUES (441, 179, 66, 1.00, 2000.00, '2025-04-28 16:42:26', '2025-04-28 16:42:26');
INSERT INTO `production_plan_materials` VALUES (442, 179, 67, 1.00, 2000.00, '2025-04-28 16:42:27', '2025-04-28 16:42:27');
INSERT INTO `production_plan_materials` VALUES (443, 179, 68, 1.00, 2000.00, '2025-04-28 16:42:27', '2025-04-28 16:42:27');
INSERT INTO `production_plan_materials` VALUES (444, 179, 69, 1.00, 2000.00, '2025-04-28 16:42:28', '2025-04-28 16:42:28');
INSERT INTO `production_plan_materials` VALUES (445, 179, 70, 0.04, 2000.00, '2025-04-28 16:42:28', '2025-04-28 16:42:28');
INSERT INTO `production_plan_materials` VALUES (446, 179, 71, 0.10, 2000.00, '2025-04-28 16:42:29', '2025-04-28 16:42:29');
INSERT INTO `production_plan_materials` VALUES (447, 179, 72, 1.00, 2000.00, '2025-04-28 16:42:29', '2025-04-28 16:42:29');
INSERT INTO `production_plan_materials` VALUES (448, 179, 73, 1.00, 2000.00, '2025-04-28 16:42:30', '2025-04-28 16:42:30');
INSERT INTO `production_plan_materials` VALUES (449, 179, 74, 1.00, 2000.00, '2025-04-28 16:42:30', '2025-04-28 16:42:30');
INSERT INTO `production_plan_materials` VALUES (450, 179, 75, 1.00, 2000.00, '2025-04-28 16:42:31', '2025-04-28 16:42:31');
INSERT INTO `production_plan_materials` VALUES (451, 179, 76, 1.00, 2000.00, '2025-04-28 16:42:31', '2025-04-28 16:42:31');
INSERT INTO `production_plan_materials` VALUES (452, 181, 77, 1.00, 899.00, '2025-04-28 16:56:55', '2025-04-28 16:56:55');
INSERT INTO `production_plan_materials` VALUES (453, 181, 78, 1.00, 899.00, '2025-04-28 16:56:55', '2025-04-28 16:56:55');
INSERT INTO `production_plan_materials` VALUES (454, 181, 79, 1.00, 899.00, '2025-04-28 16:56:55', '2025-04-28 16:56:55');
INSERT INTO `production_plan_materials` VALUES (455, 181, 80, 1.00, 899.00, '2025-04-28 16:56:55', '2025-04-28 16:56:55');
INSERT INTO `production_plan_materials` VALUES (456, 181, 81, 1.00, 899.00, '2025-04-28 16:56:55', '2025-04-28 16:56:55');
INSERT INTO `production_plan_materials` VALUES (457, 181, 82, 1.00, 1000.00, '2025-04-28 16:56:55', '2025-04-28 16:56:55');
INSERT INTO `production_plan_materials` VALUES (458, 181, 83, 1.00, 899.00, '2025-04-28 16:56:55', '2025-04-28 16:56:55');
INSERT INTO `production_plan_materials` VALUES (459, 181, 84, 1.00, 899.00, '2025-04-28 16:56:55', '2025-04-28 16:56:55');
INSERT INTO `production_plan_materials` VALUES (460, 181, 85, 1.00, 898.99, '2025-04-28 16:56:55', '2025-04-28 16:56:55');
INSERT INTO `production_plan_materials` VALUES (461, 181, 86, 1.00, 899.00, '2025-04-28 16:56:55', '2025-04-28 16:56:55');
INSERT INTO `production_plan_materials` VALUES (462, 181, 87, 1.00, 899.00, '2025-04-28 16:56:55', '2025-04-28 16:56:55');
INSERT INTO `production_plan_materials` VALUES (463, 181, 88, 1.00, 899.00, '2025-04-28 16:56:55', '2025-04-28 16:56:55');
INSERT INTO `production_plan_materials` VALUES (464, 181, 89, 1.00, 899.00, '2025-04-28 16:56:55', '2025-04-28 16:56:55');
INSERT INTO `production_plan_materials` VALUES (465, 181, 90, 1.00, 899.00, '2025-04-28 16:56:55', '2025-04-28 16:56:55');
INSERT INTO `production_plan_materials` VALUES (466, 181, 91, 1.00, 899.00, '2025-04-28 16:56:55', '2025-04-28 16:56:55');
INSERT INTO `production_plan_materials` VALUES (467, 181, 92, 1.00, 900.00, '2025-04-28 16:56:55', '2025-04-28 16:56:55');
INSERT INTO `production_plan_materials` VALUES (468, 181, 93, 1.00, 899.00, '2025-04-28 16:56:55', '2025-04-28 16:56:55');
INSERT INTO `production_plan_materials` VALUES (469, 181, 94, 1.00, 899.00, '2025-04-28 16:56:55', '2025-04-28 16:56:55');
INSERT INTO `production_plan_materials` VALUES (470, 181, 95, 1.00, 899.00, '2025-04-28 16:56:55', '2025-04-28 16:56:55');
INSERT INTO `production_plan_materials` VALUES (471, 182, 77, 1.00, 898.00, '2025-04-28 16:58:55', '2025-04-28 16:58:55');
INSERT INTO `production_plan_materials` VALUES (472, 182, 78, 1.00, 898.00, '2025-04-28 16:58:56', '2025-04-28 16:58:56');
INSERT INTO `production_plan_materials` VALUES (473, 182, 79, 1.00, 898.00, '2025-04-28 16:58:56', '2025-04-28 16:58:56');
INSERT INTO `production_plan_materials` VALUES (474, 182, 80, 1.00, 898.00, '2025-04-28 16:58:56', '2025-04-28 16:58:56');
INSERT INTO `production_plan_materials` VALUES (475, 182, 81, 1.00, 898.00, '2025-04-28 16:58:56', '2025-04-28 16:58:56');
INSERT INTO `production_plan_materials` VALUES (476, 182, 82, 1.00, 999.00, '2025-04-28 16:58:56', '2025-04-28 16:58:56');
INSERT INTO `production_plan_materials` VALUES (477, 182, 83, 1.00, 898.00, '2025-04-28 16:58:56', '2025-04-28 16:58:56');
INSERT INTO `production_plan_materials` VALUES (478, 182, 84, 1.00, 898.00, '2025-04-28 16:58:56', '2025-04-28 16:58:56');
INSERT INTO `production_plan_materials` VALUES (479, 182, 85, 1.00, 897.99, '2025-04-28 16:58:56', '2025-04-28 16:58:56');
INSERT INTO `production_plan_materials` VALUES (480, 182, 86, 1.00, 898.00, '2025-04-28 16:58:56', '2025-04-28 16:58:56');
INSERT INTO `production_plan_materials` VALUES (481, 182, 87, 1.00, 898.00, '2025-04-28 16:58:56', '2025-04-28 16:58:56');
INSERT INTO `production_plan_materials` VALUES (482, 182, 88, 1.00, 898.00, '2025-04-28 16:58:56', '2025-04-28 16:58:56');
INSERT INTO `production_plan_materials` VALUES (483, 182, 89, 1.00, 898.00, '2025-04-28 16:58:56', '2025-04-28 16:58:56');
INSERT INTO `production_plan_materials` VALUES (484, 182, 90, 1.00, 898.00, '2025-04-28 16:58:56', '2025-04-28 16:58:56');
INSERT INTO `production_plan_materials` VALUES (485, 182, 91, 1.00, 898.00, '2025-04-28 16:58:56', '2025-04-28 16:58:56');
INSERT INTO `production_plan_materials` VALUES (486, 182, 92, 1.00, 899.00, '2025-04-28 16:58:56', '2025-04-28 16:58:56');
INSERT INTO `production_plan_materials` VALUES (487, 182, 93, 1.00, 898.00, '2025-04-28 16:58:56', '2025-04-28 16:58:56');
INSERT INTO `production_plan_materials` VALUES (488, 182, 94, 1.00, 898.00, '2025-04-28 16:58:56', '2025-04-28 16:58:56');
INSERT INTO `production_plan_materials` VALUES (489, 182, 95, 1.00, 898.00, '2025-04-28 16:58:56', '2025-04-28 16:58:56');
INSERT INTO `production_plan_materials` VALUES (490, 183, 77, 10.00, 897.00, '2025-04-30 13:54:10', '2025-04-30 13:54:10');
INSERT INTO `production_plan_materials` VALUES (491, 183, 78, 10.00, 897.00, '2025-04-30 13:54:10', '2025-04-30 13:54:10');
INSERT INTO `production_plan_materials` VALUES (492, 183, 79, 10.00, 897.00, '2025-04-30 13:54:10', '2025-04-30 13:54:10');
INSERT INTO `production_plan_materials` VALUES (493, 183, 80, 10.00, 897.00, '2025-04-30 13:54:10', '2025-04-30 13:54:10');
INSERT INTO `production_plan_materials` VALUES (494, 183, 81, 10.00, 897.00, '2025-04-30 13:54:10', '2025-04-30 13:54:10');
INSERT INTO `production_plan_materials` VALUES (495, 183, 98, 10.00, 1900.00, '2025-04-30 13:54:10', '2025-04-30 13:54:10');
INSERT INTO `production_plan_materials` VALUES (496, 183, 83, 10.00, 897.00, '2025-04-30 13:54:10', '2025-04-30 13:54:10');
INSERT INTO `production_plan_materials` VALUES (497, 183, 84, 10.00, 897.00, '2025-04-30 13:54:10', '2025-04-30 13:54:10');
INSERT INTO `production_plan_materials` VALUES (498, 183, 85, 10.00, 896.99, '2025-04-30 13:54:10', '2025-04-30 13:54:10');
INSERT INTO `production_plan_materials` VALUES (499, 183, 86, 10.00, 897.00, '2025-04-30 13:54:10', '2025-04-30 13:54:10');
INSERT INTO `production_plan_materials` VALUES (500, 183, 87, 10.00, 897.00, '2025-04-30 13:54:10', '2025-04-30 13:54:10');
INSERT INTO `production_plan_materials` VALUES (501, 183, 88, 10.00, 897.00, '2025-04-30 13:54:10', '2025-04-30 13:54:10');
INSERT INTO `production_plan_materials` VALUES (502, 183, 89, 10.00, 897.00, '2025-04-30 13:54:10', '2025-04-30 13:54:10');
INSERT INTO `production_plan_materials` VALUES (503, 183, 90, 10.00, 897.00, '2025-04-30 13:54:10', '2025-04-30 13:54:10');
INSERT INTO `production_plan_materials` VALUES (504, 183, 91, 10.00, 897.00, '2025-04-30 13:54:10', '2025-04-30 13:54:10');
INSERT INTO `production_plan_materials` VALUES (505, 183, 92, 10.00, 898.00, '2025-04-30 13:54:10', '2025-04-30 13:54:10');
INSERT INTO `production_plan_materials` VALUES (506, 183, 93, 10.00, 897.00, '2025-04-30 13:54:10', '2025-04-30 13:54:10');
INSERT INTO `production_plan_materials` VALUES (507, 183, 94, 10.00, 897.00, '2025-04-30 13:54:10', '2025-04-30 13:54:10');
INSERT INTO `production_plan_materials` VALUES (508, 183, 95, 10.00, 897.00, '2025-04-30 13:54:10', '2025-04-30 13:54:10');
INSERT INTO `production_plan_materials` VALUES (509, 184, 77, 4.00, 887.00, '2025-04-30 15:45:52', '2025-04-30 15:45:52');
INSERT INTO `production_plan_materials` VALUES (510, 184, 78, 4.00, 887.00, '2025-04-30 15:45:52', '2025-04-30 15:45:52');
INSERT INTO `production_plan_materials` VALUES (511, 184, 79, 4.00, 887.00, '2025-04-30 15:45:52', '2025-04-30 15:45:52');
INSERT INTO `production_plan_materials` VALUES (512, 184, 80, 4.00, 887.00, '2025-04-30 15:45:52', '2025-04-30 15:45:52');
INSERT INTO `production_plan_materials` VALUES (513, 184, 81, 4.00, 887.00, '2025-04-30 15:45:53', '2025-04-30 15:45:53');
INSERT INTO `production_plan_materials` VALUES (514, 184, 98, 4.00, 1890.00, '2025-04-30 15:45:53', '2025-04-30 15:45:53');
INSERT INTO `production_plan_materials` VALUES (515, 184, 83, 4.00, 887.00, '2025-04-30 15:45:53', '2025-04-30 15:45:53');
INSERT INTO `production_plan_materials` VALUES (516, 184, 84, 4.00, 887.00, '2025-04-30 15:45:53', '2025-04-30 15:45:53');
INSERT INTO `production_plan_materials` VALUES (517, 184, 85, 4.00, 886.99, '2025-04-30 15:45:53', '2025-04-30 15:45:53');
INSERT INTO `production_plan_materials` VALUES (518, 184, 86, 4.00, 887.00, '2025-04-30 15:45:53', '2025-04-30 15:45:53');
INSERT INTO `production_plan_materials` VALUES (519, 184, 87, 4.00, 887.00, '2025-04-30 15:45:53', '2025-04-30 15:45:53');
INSERT INTO `production_plan_materials` VALUES (520, 184, 88, 4.00, 887.00, '2025-04-30 15:45:53', '2025-04-30 15:45:53');
INSERT INTO `production_plan_materials` VALUES (521, 184, 89, 4.00, 887.00, '2025-04-30 15:45:53', '2025-04-30 15:45:53');
INSERT INTO `production_plan_materials` VALUES (522, 184, 90, 4.00, 887.00, '2025-04-30 15:45:53', '2025-04-30 15:45:53');
INSERT INTO `production_plan_materials` VALUES (523, 184, 91, 4.00, 887.00, '2025-04-30 15:45:53', '2025-04-30 15:45:53');
INSERT INTO `production_plan_materials` VALUES (524, 184, 92, 4.00, 888.00, '2025-04-30 15:45:53', '2025-04-30 15:45:53');
INSERT INTO `production_plan_materials` VALUES (525, 184, 93, 4.00, 887.00, '2025-04-30 15:45:53', '2025-04-30 15:45:53');
INSERT INTO `production_plan_materials` VALUES (526, 184, 94, 4.00, 887.00, '2025-04-30 15:45:53', '2025-04-30 15:45:53');
INSERT INTO `production_plan_materials` VALUES (527, 184, 95, 4.00, 887.00, '2025-04-30 15:45:53', '2025-04-30 15:45:53');
INSERT INTO `production_plan_materials` VALUES (528, 185, 77, 57.00, 883.00, '2025-04-30 15:53:52', '2025-04-30 15:53:52');
INSERT INTO `production_plan_materials` VALUES (529, 185, 78, 57.00, 883.00, '2025-04-30 15:53:52', '2025-04-30 15:53:52');
INSERT INTO `production_plan_materials` VALUES (530, 185, 79, 57.00, 883.00, '2025-04-30 15:53:52', '2025-04-30 15:53:52');
INSERT INTO `production_plan_materials` VALUES (531, 185, 80, 57.00, 883.00, '2025-04-30 15:53:52', '2025-04-30 15:53:52');
INSERT INTO `production_plan_materials` VALUES (532, 185, 81, 57.00, 883.00, '2025-04-30 15:53:52', '2025-04-30 15:53:52');
INSERT INTO `production_plan_materials` VALUES (533, 185, 82, 57.00, 998.00, '2025-04-30 15:53:52', '2025-04-30 15:53:52');
INSERT INTO `production_plan_materials` VALUES (534, 185, 83, 57.00, 883.00, '2025-04-30 15:53:52', '2025-04-30 15:53:52');
INSERT INTO `production_plan_materials` VALUES (535, 185, 84, 57.00, 883.00, '2025-04-30 15:53:52', '2025-04-30 15:53:52');
INSERT INTO `production_plan_materials` VALUES (536, 185, 85, 57.00, 882.99, '2025-04-30 15:53:52', '2025-04-30 15:53:52');
INSERT INTO `production_plan_materials` VALUES (537, 185, 86, 57.00, 883.00, '2025-04-30 15:53:52', '2025-04-30 15:53:52');
INSERT INTO `production_plan_materials` VALUES (538, 185, 87, 57.00, 883.00, '2025-04-30 15:53:52', '2025-04-30 15:53:52');
INSERT INTO `production_plan_materials` VALUES (539, 185, 88, 57.00, 883.00, '2025-04-30 15:53:52', '2025-04-30 15:53:52');
INSERT INTO `production_plan_materials` VALUES (540, 185, 89, 57.00, 883.00, '2025-04-30 15:53:52', '2025-04-30 15:53:52');
INSERT INTO `production_plan_materials` VALUES (541, 185, 90, 57.00, 883.00, '2025-04-30 15:53:53', '2025-04-30 15:53:53');
INSERT INTO `production_plan_materials` VALUES (542, 185, 91, 57.00, 883.00, '2025-04-30 15:53:53', '2025-04-30 15:53:53');
INSERT INTO `production_plan_materials` VALUES (543, 185, 92, 57.00, 884.00, '2025-04-30 15:53:53', '2025-04-30 15:53:53');
INSERT INTO `production_plan_materials` VALUES (544, 185, 93, 57.00, 883.00, '2025-04-30 15:53:53', '2025-04-30 15:53:53');
INSERT INTO `production_plan_materials` VALUES (545, 185, 94, 57.00, 883.00, '2025-04-30 15:53:53', '2025-04-30 15:53:53');
INSERT INTO `production_plan_materials` VALUES (546, 185, 95, 57.00, 883.00, '2025-04-30 15:53:53', '2025-04-30 15:53:53');
INSERT INTO `production_plan_materials` VALUES (547, 186, 77, 2.00, 826.00, '2025-04-30 15:59:54', '2025-04-30 15:59:54');
INSERT INTO `production_plan_materials` VALUES (548, 186, 78, 2.00, 826.00, '2025-04-30 15:59:54', '2025-04-30 15:59:54');
INSERT INTO `production_plan_materials` VALUES (549, 186, 79, 2.00, 826.00, '2025-04-30 15:59:54', '2025-04-30 15:59:54');
INSERT INTO `production_plan_materials` VALUES (550, 186, 80, 2.00, 826.00, '2025-04-30 15:59:54', '2025-04-30 15:59:54');
INSERT INTO `production_plan_materials` VALUES (551, 186, 81, 2.00, 826.00, '2025-04-30 15:59:54', '2025-04-30 15:59:54');
INSERT INTO `production_plan_materials` VALUES (552, 186, 98, 2.00, 1886.00, '2025-04-30 15:59:54', '2025-04-30 15:59:54');
INSERT INTO `production_plan_materials` VALUES (553, 186, 83, 2.00, 826.00, '2025-04-30 15:59:54', '2025-04-30 15:59:54');
INSERT INTO `production_plan_materials` VALUES (554, 186, 84, 2.00, 826.00, '2025-04-30 15:59:54', '2025-04-30 15:59:54');
INSERT INTO `production_plan_materials` VALUES (555, 186, 85, 2.00, 825.99, '2025-04-30 15:59:54', '2025-04-30 15:59:54');
INSERT INTO `production_plan_materials` VALUES (556, 186, 86, 2.00, 826.00, '2025-04-30 15:59:54', '2025-04-30 15:59:54');
INSERT INTO `production_plan_materials` VALUES (557, 186, 87, 2.00, 826.00, '2025-04-30 15:59:54', '2025-04-30 15:59:54');
INSERT INTO `production_plan_materials` VALUES (558, 186, 88, 2.00, 826.00, '2025-04-30 15:59:54', '2025-04-30 15:59:54');
INSERT INTO `production_plan_materials` VALUES (559, 186, 89, 2.00, 826.00, '2025-04-30 15:59:54', '2025-04-30 15:59:54');
INSERT INTO `production_plan_materials` VALUES (560, 186, 90, 2.00, 826.00, '2025-04-30 15:59:54', '2025-04-30 15:59:54');
INSERT INTO `production_plan_materials` VALUES (561, 186, 91, 2.00, 826.00, '2025-04-30 15:59:54', '2025-04-30 15:59:54');
INSERT INTO `production_plan_materials` VALUES (562, 186, 92, 2.00, 827.00, '2025-04-30 15:59:54', '2025-04-30 15:59:54');
INSERT INTO `production_plan_materials` VALUES (563, 186, 93, 2.00, 826.00, '2025-04-30 15:59:54', '2025-04-30 15:59:54');
INSERT INTO `production_plan_materials` VALUES (564, 186, 94, 2.00, 826.00, '2025-04-30 15:59:54', '2025-04-30 15:59:54');
INSERT INTO `production_plan_materials` VALUES (565, 186, 95, 2.00, 826.00, '2025-04-30 15:59:54', '2025-04-30 15:59:54');
INSERT INTO `production_plan_materials` VALUES (566, 187, 77, 8.00, 824.00, '2025-04-30 16:10:09', '2025-04-30 16:10:09');
INSERT INTO `production_plan_materials` VALUES (567, 187, 78, 8.00, 824.00, '2025-04-30 16:10:09', '2025-04-30 16:10:09');
INSERT INTO `production_plan_materials` VALUES (568, 187, 79, 8.00, 824.00, '2025-04-30 16:10:09', '2025-04-30 16:10:09');
INSERT INTO `production_plan_materials` VALUES (569, 187, 80, 8.00, 824.00, '2025-04-30 16:10:09', '2025-04-30 16:10:09');
INSERT INTO `production_plan_materials` VALUES (570, 187, 81, 8.00, 824.00, '2025-04-30 16:10:09', '2025-04-30 16:10:09');
INSERT INTO `production_plan_materials` VALUES (571, 187, 98, 8.00, 1884.00, '2025-04-30 16:10:09', '2025-04-30 16:10:09');
INSERT INTO `production_plan_materials` VALUES (572, 187, 83, 8.00, 824.00, '2025-04-30 16:10:09', '2025-04-30 16:10:09');
INSERT INTO `production_plan_materials` VALUES (573, 187, 84, 8.00, 824.00, '2025-04-30 16:10:09', '2025-04-30 16:10:09');
INSERT INTO `production_plan_materials` VALUES (574, 187, 85, 8.00, 823.99, '2025-04-30 16:10:09', '2025-04-30 16:10:09');
INSERT INTO `production_plan_materials` VALUES (575, 187, 86, 8.00, 824.00, '2025-04-30 16:10:09', '2025-04-30 16:10:09');
INSERT INTO `production_plan_materials` VALUES (576, 187, 87, 8.00, 824.00, '2025-04-30 16:10:09', '2025-04-30 16:10:09');
INSERT INTO `production_plan_materials` VALUES (577, 187, 88, 8.00, 824.00, '2025-04-30 16:10:09', '2025-04-30 16:10:09');
INSERT INTO `production_plan_materials` VALUES (578, 187, 89, 8.00, 824.00, '2025-04-30 16:10:09', '2025-04-30 16:10:09');
INSERT INTO `production_plan_materials` VALUES (579, 187, 90, 8.00, 824.00, '2025-04-30 16:10:09', '2025-04-30 16:10:09');
INSERT INTO `production_plan_materials` VALUES (580, 187, 91, 8.00, 824.00, '2025-04-30 16:10:09', '2025-04-30 16:10:09');
INSERT INTO `production_plan_materials` VALUES (581, 187, 92, 8.00, 825.00, '2025-04-30 16:10:09', '2025-04-30 16:10:09');
INSERT INTO `production_plan_materials` VALUES (582, 187, 93, 8.00, 824.00, '2025-04-30 16:10:09', '2025-04-30 16:10:09');
INSERT INTO `production_plan_materials` VALUES (583, 187, 94, 8.00, 824.00, '2025-04-30 16:10:09', '2025-04-30 16:10:09');
INSERT INTO `production_plan_materials` VALUES (584, 187, 95, 8.00, 824.00, '2025-04-30 16:10:09', '2025-04-30 16:10:09');
INSERT INTO `production_plan_materials` VALUES (585, 188, 77, 3.00, 816.00, '2025-04-30 16:24:42', '2025-04-30 16:24:42');
INSERT INTO `production_plan_materials` VALUES (586, 188, 78, 3.00, 816.00, '2025-04-30 16:24:42', '2025-04-30 16:24:42');
INSERT INTO `production_plan_materials` VALUES (587, 188, 79, 3.00, 816.00, '2025-04-30 16:24:42', '2025-04-30 16:24:42');
INSERT INTO `production_plan_materials` VALUES (588, 188, 80, 3.00, 816.00, '2025-04-30 16:24:42', '2025-04-30 16:24:42');
INSERT INTO `production_plan_materials` VALUES (589, 188, 81, 3.00, 816.00, '2025-04-30 16:24:42', '2025-04-30 16:24:42');
INSERT INTO `production_plan_materials` VALUES (590, 188, 82, 3.00, 941.00, '2025-04-30 16:24:42', '2025-04-30 16:24:42');
INSERT INTO `production_plan_materials` VALUES (591, 188, 83, 3.00, 816.00, '2025-04-30 16:24:42', '2025-04-30 16:24:42');
INSERT INTO `production_plan_materials` VALUES (592, 188, 84, 3.00, 816.00, '2025-04-30 16:24:43', '2025-04-30 16:24:43');
INSERT INTO `production_plan_materials` VALUES (593, 188, 85, 3.00, 815.99, '2025-04-30 16:24:43', '2025-04-30 16:24:43');
INSERT INTO `production_plan_materials` VALUES (594, 188, 86, 3.00, 816.00, '2025-04-30 16:24:43', '2025-04-30 16:24:43');
INSERT INTO `production_plan_materials` VALUES (595, 188, 87, 3.00, 816.00, '2025-04-30 16:24:43', '2025-04-30 16:24:43');
INSERT INTO `production_plan_materials` VALUES (596, 188, 88, 3.00, 816.00, '2025-04-30 16:24:43', '2025-04-30 16:24:43');
INSERT INTO `production_plan_materials` VALUES (597, 188, 89, 3.00, 816.00, '2025-04-30 16:24:43', '2025-04-30 16:24:43');
INSERT INTO `production_plan_materials` VALUES (598, 188, 90, 3.00, 816.00, '2025-04-30 16:24:43', '2025-04-30 16:24:43');
INSERT INTO `production_plan_materials` VALUES (599, 188, 91, 3.00, 816.00, '2025-04-30 16:24:43', '2025-04-30 16:24:43');
INSERT INTO `production_plan_materials` VALUES (600, 188, 92, 3.00, 817.00, '2025-04-30 16:24:43', '2025-04-30 16:24:43');
INSERT INTO `production_plan_materials` VALUES (601, 188, 93, 3.00, 816.00, '2025-04-30 16:24:43', '2025-04-30 16:24:43');
INSERT INTO `production_plan_materials` VALUES (602, 188, 94, 3.00, 816.00, '2025-04-30 16:24:43', '2025-04-30 16:24:43');
INSERT INTO `production_plan_materials` VALUES (603, 188, 95, 3.00, 816.00, '2025-04-30 16:24:43', '2025-04-30 16:24:43');
INSERT INTO `production_plan_materials` VALUES (604, 189, 77, 6.00, 813.00, '2025-04-30 16:49:20', '2025-04-30 16:49:20');
INSERT INTO `production_plan_materials` VALUES (605, 189, 78, 6.00, 813.00, '2025-04-30 16:49:20', '2025-04-30 16:49:20');
INSERT INTO `production_plan_materials` VALUES (606, 189, 79, 6.00, 813.00, '2025-04-30 16:49:20', '2025-04-30 16:49:20');
INSERT INTO `production_plan_materials` VALUES (607, 189, 80, 6.00, 813.00, '2025-04-30 16:49:20', '2025-04-30 16:49:20');
INSERT INTO `production_plan_materials` VALUES (608, 189, 81, 6.00, 813.00, '2025-04-30 16:49:20', '2025-04-30 16:49:20');
INSERT INTO `production_plan_materials` VALUES (609, 189, 82, 6.00, 938.00, '2025-04-30 16:49:20', '2025-04-30 16:49:20');
INSERT INTO `production_plan_materials` VALUES (610, 189, 83, 6.00, 813.00, '2025-04-30 16:49:20', '2025-04-30 16:49:20');
INSERT INTO `production_plan_materials` VALUES (611, 189, 84, 6.00, 813.00, '2025-04-30 16:49:20', '2025-04-30 16:49:20');
INSERT INTO `production_plan_materials` VALUES (612, 189, 85, 6.00, 812.99, '2025-04-30 16:49:20', '2025-04-30 16:49:20');
INSERT INTO `production_plan_materials` VALUES (613, 189, 86, 6.00, 813.00, '2025-04-30 16:49:20', '2025-04-30 16:49:20');
INSERT INTO `production_plan_materials` VALUES (614, 189, 87, 6.00, 813.00, '2025-04-30 16:49:20', '2025-04-30 16:49:20');
INSERT INTO `production_plan_materials` VALUES (615, 189, 88, 6.00, 813.00, '2025-04-30 16:49:20', '2025-04-30 16:49:20');
INSERT INTO `production_plan_materials` VALUES (616, 189, 89, 6.00, 813.00, '2025-04-30 16:49:21', '2025-04-30 16:49:21');
INSERT INTO `production_plan_materials` VALUES (617, 189, 90, 6.00, 813.00, '2025-04-30 16:49:21', '2025-04-30 16:49:21');
INSERT INTO `production_plan_materials` VALUES (618, 189, 91, 6.00, 813.00, '2025-04-30 16:49:21', '2025-04-30 16:49:21');
INSERT INTO `production_plan_materials` VALUES (619, 189, 92, 6.00, 814.00, '2025-04-30 16:49:21', '2025-04-30 16:49:21');
INSERT INTO `production_plan_materials` VALUES (620, 189, 93, 6.00, 813.00, '2025-04-30 16:49:21', '2025-04-30 16:49:21');
INSERT INTO `production_plan_materials` VALUES (621, 189, 94, 6.00, 813.00, '2025-04-30 16:49:21', '2025-04-30 16:49:21');
INSERT INTO `production_plan_materials` VALUES (622, 189, 95, 6.00, 813.00, '2025-04-30 16:49:21', '2025-04-30 16:49:21');
INSERT INTO `production_plan_materials` VALUES (623, 190, 77, 1.00, 807.00, '2025-05-05 13:58:27', '2025-05-05 13:58:27');
INSERT INTO `production_plan_materials` VALUES (624, 190, 78, 1.00, 807.00, '2025-05-05 13:58:27', '2025-05-05 13:58:27');
INSERT INTO `production_plan_materials` VALUES (625, 190, 79, 1.00, 807.00, '2025-05-05 13:58:27', '2025-05-05 13:58:27');
INSERT INTO `production_plan_materials` VALUES (626, 190, 80, 1.00, 807.00, '2025-05-05 13:58:27', '2025-05-05 13:58:27');
INSERT INTO `production_plan_materials` VALUES (627, 190, 81, 1.00, 807.00, '2025-05-05 13:58:27', '2025-05-05 13:58:27');
INSERT INTO `production_plan_materials` VALUES (628, 190, 98, 1.00, 1876.00, '2025-05-05 13:58:27', '2025-05-05 13:58:27');
INSERT INTO `production_plan_materials` VALUES (629, 190, 83, 1.00, 807.00, '2025-05-05 13:58:27', '2025-05-05 13:58:27');
INSERT INTO `production_plan_materials` VALUES (630, 190, 84, 1.00, 807.00, '2025-05-05 13:58:27', '2025-05-05 13:58:27');
INSERT INTO `production_plan_materials` VALUES (631, 190, 85, 1.00, 806.99, '2025-05-05 13:58:27', '2025-05-05 13:58:27');
INSERT INTO `production_plan_materials` VALUES (632, 190, 86, 1.00, 807.00, '2025-05-05 13:58:28', '2025-05-05 13:58:28');
INSERT INTO `production_plan_materials` VALUES (633, 190, 87, 1.00, 807.00, '2025-05-05 13:58:28', '2025-05-05 13:58:28');
INSERT INTO `production_plan_materials` VALUES (634, 190, 88, 1.00, 807.00, '2025-05-05 13:58:28', '2025-05-05 13:58:28');
INSERT INTO `production_plan_materials` VALUES (635, 190, 89, 1.00, 807.00, '2025-05-05 13:58:28', '2025-05-05 13:58:28');
INSERT INTO `production_plan_materials` VALUES (636, 190, 90, 1.00, 807.00, '2025-05-05 13:58:28', '2025-05-05 13:58:28');
INSERT INTO `production_plan_materials` VALUES (637, 190, 91, 1.00, 807.00, '2025-05-05 13:58:28', '2025-05-05 13:58:28');
INSERT INTO `production_plan_materials` VALUES (638, 190, 92, 1.00, 808.00, '2025-05-05 13:58:28', '2025-05-05 13:58:28');
INSERT INTO `production_plan_materials` VALUES (639, 190, 93, 1.00, 807.00, '2025-05-05 13:58:28', '2025-05-05 13:58:28');
INSERT INTO `production_plan_materials` VALUES (640, 190, 94, 1.00, 807.00, '2025-05-05 13:58:28', '2025-05-05 13:58:28');
INSERT INTO `production_plan_materials` VALUES (641, 190, 95, 1.00, 807.00, '2025-05-05 13:58:28', '2025-05-05 13:58:28');
INSERT INTO `production_plan_materials` VALUES (642, 191, 77, 1.00, 806.00, '2025-05-05 14:04:31', '2025-05-05 14:04:31');
INSERT INTO `production_plan_materials` VALUES (643, 191, 78, 1.00, 806.00, '2025-05-05 14:04:31', '2025-05-05 14:04:31');
INSERT INTO `production_plan_materials` VALUES (644, 191, 79, 1.00, 806.00, '2025-05-05 14:04:31', '2025-05-05 14:04:31');
INSERT INTO `production_plan_materials` VALUES (645, 191, 80, 1.00, 806.00, '2025-05-05 14:04:31', '2025-05-05 14:04:31');
INSERT INTO `production_plan_materials` VALUES (646, 191, 81, 1.00, 806.00, '2025-05-05 14:04:31', '2025-05-05 14:04:31');
INSERT INTO `production_plan_materials` VALUES (647, 191, 98, 1.00, 1875.00, '2025-05-05 14:04:31', '2025-05-05 14:04:31');
INSERT INTO `production_plan_materials` VALUES (648, 191, 83, 1.00, 806.00, '2025-05-05 14:04:31', '2025-05-05 14:04:31');
INSERT INTO `production_plan_materials` VALUES (649, 191, 84, 1.00, 806.00, '2025-05-05 14:04:31', '2025-05-05 14:04:31');
INSERT INTO `production_plan_materials` VALUES (650, 191, 85, 1.00, 805.99, '2025-05-05 14:04:32', '2025-05-05 14:04:32');
INSERT INTO `production_plan_materials` VALUES (651, 191, 86, 1.00, 806.00, '2025-05-05 14:04:32', '2025-05-05 14:04:32');
INSERT INTO `production_plan_materials` VALUES (652, 191, 87, 1.00, 806.00, '2025-05-05 14:04:32', '2025-05-05 14:04:32');
INSERT INTO `production_plan_materials` VALUES (653, 191, 88, 1.00, 806.00, '2025-05-05 14:04:32', '2025-05-05 14:04:32');
INSERT INTO `production_plan_materials` VALUES (654, 191, 89, 1.00, 806.00, '2025-05-05 14:04:32', '2025-05-05 14:04:32');
INSERT INTO `production_plan_materials` VALUES (655, 191, 90, 1.00, 806.00, '2025-05-05 14:04:32', '2025-05-05 14:04:32');
INSERT INTO `production_plan_materials` VALUES (656, 191, 91, 1.00, 806.00, '2025-05-05 14:04:32', '2025-05-05 14:04:32');
INSERT INTO `production_plan_materials` VALUES (657, 191, 92, 1.00, 807.00, '2025-05-05 14:04:32', '2025-05-05 14:04:32');
INSERT INTO `production_plan_materials` VALUES (658, 191, 93, 1.00, 806.00, '2025-05-05 14:04:32', '2025-05-05 14:04:32');
INSERT INTO `production_plan_materials` VALUES (659, 191, 94, 1.00, 806.00, '2025-05-05 14:04:32', '2025-05-05 14:04:32');
INSERT INTO `production_plan_materials` VALUES (660, 191, 95, 1.00, 806.00, '2025-05-05 14:04:32', '2025-05-05 14:04:32');
INSERT INTO `production_plan_materials` VALUES (661, 192, 77, 1.00, 805.00, '2025-05-05 14:29:16', '2025-05-05 14:29:16');
INSERT INTO `production_plan_materials` VALUES (662, 192, 78, 1.00, 805.00, '2025-05-05 14:29:16', '2025-05-05 14:29:16');
INSERT INTO `production_plan_materials` VALUES (663, 192, 79, 1.00, 805.00, '2025-05-05 14:29:16', '2025-05-05 14:29:16');
INSERT INTO `production_plan_materials` VALUES (664, 192, 80, 1.00, 805.00, '2025-05-05 14:29:16', '2025-05-05 14:29:16');
INSERT INTO `production_plan_materials` VALUES (665, 192, 81, 1.00, 805.00, '2025-05-05 14:29:16', '2025-05-05 14:29:16');
INSERT INTO `production_plan_materials` VALUES (666, 192, 98, 1.00, 1874.00, '2025-05-05 14:29:16', '2025-05-05 14:29:16');
INSERT INTO `production_plan_materials` VALUES (667, 192, 83, 1.00, 805.00, '2025-05-05 14:29:16', '2025-05-05 14:29:16');
INSERT INTO `production_plan_materials` VALUES (668, 192, 84, 1.00, 805.00, '2025-05-05 14:29:16', '2025-05-05 14:29:16');
INSERT INTO `production_plan_materials` VALUES (669, 192, 85, 1.00, 804.99, '2025-05-05 14:29:16', '2025-05-05 14:29:16');
INSERT INTO `production_plan_materials` VALUES (670, 192, 86, 1.00, 805.00, '2025-05-05 14:29:16', '2025-05-05 14:29:16');
INSERT INTO `production_plan_materials` VALUES (671, 192, 87, 1.00, 805.00, '2025-05-05 14:29:16', '2025-05-05 14:29:16');
INSERT INTO `production_plan_materials` VALUES (672, 192, 88, 1.00, 805.00, '2025-05-05 14:29:16', '2025-05-05 14:29:16');
INSERT INTO `production_plan_materials` VALUES (673, 192, 89, 1.00, 805.00, '2025-05-05 14:29:16', '2025-05-05 14:29:16');
INSERT INTO `production_plan_materials` VALUES (674, 192, 90, 1.00, 805.00, '2025-05-05 14:29:16', '2025-05-05 14:29:16');
INSERT INTO `production_plan_materials` VALUES (675, 192, 91, 1.00, 805.00, '2025-05-05 14:29:16', '2025-05-05 14:29:16');
INSERT INTO `production_plan_materials` VALUES (676, 192, 92, 1.00, 806.00, '2025-05-05 14:29:16', '2025-05-05 14:29:16');
INSERT INTO `production_plan_materials` VALUES (677, 192, 93, 1.00, 805.00, '2025-05-05 14:29:16', '2025-05-05 14:29:16');
INSERT INTO `production_plan_materials` VALUES (678, 192, 94, 1.00, 805.00, '2025-05-05 14:29:16', '2025-05-05 14:29:16');
INSERT INTO `production_plan_materials` VALUES (679, 192, 95, 1.00, 805.00, '2025-05-05 14:29:16', '2025-05-05 14:29:16');
INSERT INTO `production_plan_materials` VALUES (680, 193, 60, 1.00, 1999.00, '2025-05-05 14:34:12', '2025-05-05 14:34:12');
INSERT INTO `production_plan_materials` VALUES (681, 193, 61, 1.00, 1999.00, '2025-05-05 14:34:12', '2025-05-05 14:34:12');
INSERT INTO `production_plan_materials` VALUES (682, 193, 62, 1.00, 1999.00, '2025-05-05 14:34:12', '2025-05-05 14:34:12');
INSERT INTO `production_plan_materials` VALUES (683, 193, 63, 1.00, 1999.00, '2025-05-05 14:34:12', '2025-05-05 14:34:12');
INSERT INTO `production_plan_materials` VALUES (684, 193, 64, 1.00, 1999.00, '2025-05-05 14:34:12', '2025-05-05 14:34:12');
INSERT INTO `production_plan_materials` VALUES (685, 193, 65, 1.00, 1999.00, '2025-05-05 14:34:12', '2025-05-05 14:34:12');
INSERT INTO `production_plan_materials` VALUES (686, 193, 66, 1.00, 1999.00, '2025-05-05 14:34:12', '2025-05-05 14:34:12');
INSERT INTO `production_plan_materials` VALUES (687, 193, 67, 1.00, 1999.00, '2025-05-05 14:34:12', '2025-05-05 14:34:12');
INSERT INTO `production_plan_materials` VALUES (688, 193, 68, 1.00, 1999.00, '2025-05-05 14:34:12', '2025-05-05 14:34:12');
INSERT INTO `production_plan_materials` VALUES (689, 193, 69, 1.00, 1999.00, '2025-05-05 14:34:12', '2025-05-05 14:34:12');
INSERT INTO `production_plan_materials` VALUES (690, 193, 70, 0.04, 1999.96, '2025-05-05 14:34:12', '2025-05-05 14:34:12');
INSERT INTO `production_plan_materials` VALUES (691, 193, 71, 0.10, 1999.90, '2025-05-05 14:34:12', '2025-05-05 14:34:12');
INSERT INTO `production_plan_materials` VALUES (692, 193, 72, 1.00, 1999.00, '2025-05-05 14:34:12', '2025-05-05 14:34:12');
INSERT INTO `production_plan_materials` VALUES (693, 193, 73, 1.00, 1999.00, '2025-05-05 14:34:12', '2025-05-05 14:34:12');
INSERT INTO `production_plan_materials` VALUES (694, 193, 74, 1.00, 1999.00, '2025-05-05 14:34:12', '2025-05-05 14:34:12');
INSERT INTO `production_plan_materials` VALUES (695, 193, 75, 1.00, 1999.00, '2025-05-05 14:34:12', '2025-05-05 14:34:12');
INSERT INTO `production_plan_materials` VALUES (696, 193, 76, 1.00, 1999.00, '2025-05-05 14:34:12', '2025-05-05 14:34:12');
INSERT INTO `production_plan_materials` VALUES (697, 194, 77, 3.00, 804.00, '2025-05-05 15:09:03', '2025-05-05 15:09:03');
INSERT INTO `production_plan_materials` VALUES (698, 194, 78, 3.00, 804.00, '2025-05-05 15:09:03', '2025-05-05 15:09:03');
INSERT INTO `production_plan_materials` VALUES (699, 194, 79, 3.00, 804.00, '2025-05-05 15:09:03', '2025-05-05 15:09:03');
INSERT INTO `production_plan_materials` VALUES (700, 194, 80, 3.00, 804.00, '2025-05-05 15:09:03', '2025-05-05 15:09:03');
INSERT INTO `production_plan_materials` VALUES (701, 194, 81, 3.00, 804.00, '2025-05-05 15:09:03', '2025-05-05 15:09:03');
INSERT INTO `production_plan_materials` VALUES (702, 194, 82, 3.00, 932.00, '2025-05-05 15:09:03', '2025-05-05 15:09:03');
INSERT INTO `production_plan_materials` VALUES (703, 194, 83, 3.00, 804.00, '2025-05-05 15:09:03', '2025-05-05 15:09:03');
INSERT INTO `production_plan_materials` VALUES (704, 194, 84, 3.00, 804.00, '2025-05-05 15:09:03', '2025-05-05 15:09:03');
INSERT INTO `production_plan_materials` VALUES (705, 194, 85, 3.00, 803.99, '2025-05-05 15:09:03', '2025-05-05 15:09:03');
INSERT INTO `production_plan_materials` VALUES (706, 194, 86, 3.00, 804.00, '2025-05-05 15:09:03', '2025-05-05 15:09:03');
INSERT INTO `production_plan_materials` VALUES (707, 194, 87, 3.00, 804.00, '2025-05-05 15:09:03', '2025-05-05 15:09:03');
INSERT INTO `production_plan_materials` VALUES (708, 194, 88, 3.00, 804.00, '2025-05-05 15:09:03', '2025-05-05 15:09:03');
INSERT INTO `production_plan_materials` VALUES (709, 194, 89, 3.00, 804.00, '2025-05-05 15:09:03', '2025-05-05 15:09:03');
INSERT INTO `production_plan_materials` VALUES (710, 194, 90, 3.00, 804.00, '2025-05-05 15:09:03', '2025-05-05 15:09:03');
INSERT INTO `production_plan_materials` VALUES (711, 194, 91, 3.00, 804.00, '2025-05-05 15:09:03', '2025-05-05 15:09:03');
INSERT INTO `production_plan_materials` VALUES (712, 194, 92, 3.00, 805.00, '2025-05-05 15:09:03', '2025-05-05 15:09:03');
INSERT INTO `production_plan_materials` VALUES (713, 194, 93, 3.00, 804.00, '2025-05-05 15:09:03', '2025-05-05 15:09:03');
INSERT INTO `production_plan_materials` VALUES (714, 194, 94, 3.00, 804.00, '2025-05-05 15:09:03', '2025-05-05 15:09:03');
INSERT INTO `production_plan_materials` VALUES (715, 194, 95, 3.00, 804.00, '2025-05-05 15:09:03', '2025-05-05 15:09:03');
INSERT INTO `production_plan_materials` VALUES (792, 199, 77, 2.00, 2000.00, '2025-05-10 09:00:42', '2025-05-10 09:00:42');
INSERT INTO `production_plan_materials` VALUES (793, 199, 78, 2.00, 2000.00, '2025-05-10 09:00:42', '2025-05-10 09:00:42');
INSERT INTO `production_plan_materials` VALUES (794, 199, 79, 2.00, 2000.00, '2025-05-10 09:00:42', '2025-05-10 09:00:42');
INSERT INTO `production_plan_materials` VALUES (795, 199, 80, 2.00, 2000.00, '2025-05-10 09:00:42', '2025-05-10 09:00:42');
INSERT INTO `production_plan_materials` VALUES (796, 199, 81, 2.00, 2000.00, '2025-05-10 09:00:42', '2025-05-10 09:00:42');
INSERT INTO `production_plan_materials` VALUES (797, 199, 98, 2.00, 2900.00, '2025-05-10 09:00:42', '2025-05-10 09:00:42');
INSERT INTO `production_plan_materials` VALUES (798, 199, 83, 2.00, 2000.00, '2025-05-10 09:00:42', '2025-05-10 09:00:42');
INSERT INTO `production_plan_materials` VALUES (799, 199, 84, 2.00, 2000.00, '2025-05-10 09:00:42', '2025-05-10 09:00:42');
INSERT INTO `production_plan_materials` VALUES (800, 199, 85, 2.00, 2000.00, '2025-05-10 09:00:42', '2025-05-10 09:00:42');
INSERT INTO `production_plan_materials` VALUES (801, 199, 86, 2.00, 2000.00, '2025-05-10 09:00:42', '2025-05-10 09:00:42');
INSERT INTO `production_plan_materials` VALUES (802, 199, 87, 2.00, 2000.00, '2025-05-10 09:00:42', '2025-05-10 09:00:42');
INSERT INTO `production_plan_materials` VALUES (803, 199, 88, 2.00, 2000.00, '2025-05-10 09:00:42', '2025-05-10 09:00:42');
INSERT INTO `production_plan_materials` VALUES (804, 199, 89, 2.00, 2000.00, '2025-05-10 09:00:42', '2025-05-10 09:00:42');
INSERT INTO `production_plan_materials` VALUES (805, 199, 90, 2.00, 2000.00, '2025-05-10 09:00:42', '2025-05-10 09:00:42');
INSERT INTO `production_plan_materials` VALUES (806, 199, 91, 2.00, 2000.00, '2025-05-10 09:00:42', '2025-05-10 09:00:42');
INSERT INTO `production_plan_materials` VALUES (807, 199, 92, 2.00, 2000.00, '2025-05-10 09:00:42', '2025-05-10 09:00:42');
INSERT INTO `production_plan_materials` VALUES (808, 199, 93, 2.00, 2000.00, '2025-05-10 09:00:42', '2025-05-10 09:00:42');
INSERT INTO `production_plan_materials` VALUES (809, 199, 94, 2.00, 2000.00, '2025-05-10 09:00:42', '2025-05-10 09:00:42');
INSERT INTO `production_plan_materials` VALUES (810, 199, 95, 2.00, 2000.00, '2025-05-10 09:00:42', '2025-05-10 09:00:42');
INSERT INTO `production_plan_materials` VALUES (811, 200, 77, 2.00, 1996.00, '2025-05-10 12:58:08', '2025-05-10 12:58:08');
INSERT INTO `production_plan_materials` VALUES (812, 200, 78, 2.00, 1996.00, '2025-05-10 12:58:08', '2025-05-10 12:58:08');
INSERT INTO `production_plan_materials` VALUES (813, 200, 79, 2.00, 1996.00, '2025-05-10 12:58:08', '2025-05-10 12:58:08');
INSERT INTO `production_plan_materials` VALUES (814, 200, 80, 2.00, 1996.00, '2025-05-10 12:58:08', '2025-05-10 12:58:08');
INSERT INTO `production_plan_materials` VALUES (815, 200, 81, 2.00, 1996.00, '2025-05-10 12:58:08', '2025-05-10 12:58:08');
INSERT INTO `production_plan_materials` VALUES (816, 200, 98, 2.00, 2896.00, '2025-05-10 12:58:08', '2025-05-10 12:58:08');
INSERT INTO `production_plan_materials` VALUES (817, 200, 83, 2.00, 1996.00, '2025-05-10 12:58:08', '2025-05-10 12:58:08');
INSERT INTO `production_plan_materials` VALUES (818, 200, 84, 2.00, 1996.00, '2025-05-10 12:58:09', '2025-05-10 12:58:09');
INSERT INTO `production_plan_materials` VALUES (819, 200, 85, 2.00, 1996.00, '2025-05-10 12:58:09', '2025-05-10 12:58:09');
INSERT INTO `production_plan_materials` VALUES (820, 200, 86, 2.00, 1996.00, '2025-05-10 12:58:09', '2025-05-10 12:58:09');
INSERT INTO `production_plan_materials` VALUES (821, 200, 87, 2.00, 1996.00, '2025-05-10 12:58:09', '2025-05-10 12:58:09');
INSERT INTO `production_plan_materials` VALUES (822, 200, 88, 2.00, 1996.00, '2025-05-10 12:58:09', '2025-05-10 12:58:09');
INSERT INTO `production_plan_materials` VALUES (823, 200, 89, 2.00, 1996.00, '2025-05-10 12:58:09', '2025-05-10 12:58:09');
INSERT INTO `production_plan_materials` VALUES (824, 200, 90, 2.00, 1996.00, '2025-05-10 12:58:09', '2025-05-10 12:58:09');
INSERT INTO `production_plan_materials` VALUES (825, 200, 91, 2.00, 1996.00, '2025-05-10 12:58:09', '2025-05-10 12:58:09');
INSERT INTO `production_plan_materials` VALUES (826, 200, 92, 2.00, 1996.00, '2025-05-10 12:58:09', '2025-05-10 12:58:09');
INSERT INTO `production_plan_materials` VALUES (827, 200, 93, 2.00, 1996.00, '2025-05-10 12:58:09', '2025-05-10 12:58:09');
INSERT INTO `production_plan_materials` VALUES (828, 200, 94, 2.00, 1996.00, '2025-05-10 12:58:09', '2025-05-10 12:58:09');
INSERT INTO `production_plan_materials` VALUES (829, 200, 95, 2.00, 1996.00, '2025-05-10 12:58:09', '2025-05-10 12:58:09');

-- ----------------------------
-- Table structure for production_plans
-- ----------------------------
DROP TABLE IF EXISTS `production_plans`;
CREATE TABLE `production_plans`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '计划编号',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '计划名称',
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `product_id` int NOT NULL COMMENT '产品ID',
  `quantity` decimal(10, 2) NOT NULL COMMENT '计划数量',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'draft' COMMENT '状态：draft-草稿，confirmed-已确认，preparing-备料中，material_issued-已发料，completed-已完成，inspection-检验中，warehousing-入库中，cancelled-已取消',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '备注',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `plan_date` date NULL DEFAULT NULL COMMENT '计划日期',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_code`(`code` ASC) USING BTREE,
  INDEX `idx_product`(`product_id` ASC) USING BTREE,
  CONSTRAINT `fk_plan_product` FOREIGN KEY (`product_id`) REFERENCES `materials` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `check_dates` CHECK (`end_date` >= `start_date`)
) ENGINE = InnoDB AUTO_INCREMENT = 201 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '生产计划表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of production_plans
-- ----------------------------
INSERT INTO `production_plans` VALUES (175, 'SC250428001', '订单物料生产计划-脚踏开关', '2025-04-28', '2025-05-05', 99, 100.00, 'completed', NULL, '2025-04-28 14:32:12', '2025-04-29 16:36:01', NULL);
INSERT INTO `production_plans` VALUES (176, 'SC250428002', '订单物料生产计划-脚踏开关', '2025-04-28', '2025-05-05', 96, 1000.00, 'completed', NULL, '2025-04-28 14:49:30', '2025-04-29 15:54:19', NULL);
INSERT INTO `production_plans` VALUES (177, 'SC250428003', '订单物料生产计划-脚踏开关', '2025-04-28', '2025-05-05', 99, 1.00, 'completed', NULL, '2025-04-28 16:08:33', '2025-04-29 15:54:49', NULL);
INSERT INTO `production_plans` VALUES (179, 'SC250428005', '测试检验', '2025-04-28', '2025-05-26', 97, 1.00, 'completed', NULL, '2025-04-28 16:42:22', '2025-04-29 15:51:37', NULL);
INSERT INTO `production_plans` VALUES (181, 'SC250428006', '测试检验', '2025-04-28', '2025-05-26', 96, 1.00, 'completed', NULL, '2025-04-28 16:56:55', '2025-04-29 15:48:11', NULL);
INSERT INTO `production_plans` VALUES (182, 'SC250428007', '测试检验', '2025-04-28', '2025-05-26', 96, 1.00, 'completed', NULL, '2025-04-28 16:58:55', '2025-04-29 12:54:04', NULL);
INSERT INTO `production_plans` VALUES (183, 'SC250430001', '订单物料生产计划-脚踏开关', '2025-04-30', '2025-05-07', 99, 10.00, 'completed', NULL, '2025-04-30 13:54:10', '2025-04-30 13:55:34', NULL);
INSERT INTO `production_plans` VALUES (184, 'SC250430002', '测试', '2025-04-30', '2025-05-28', 99, 4.00, 'completed', NULL, '2025-04-30 15:45:52', '2025-04-30 15:46:27', NULL);
INSERT INTO `production_plans` VALUES (185, 'SC250430003', '订单物料生产计划-脚踏开关', '2025-04-30', '2025-05-07', 96, 57.00, 'completed', NULL, '2025-04-30 15:53:52', '2025-04-30 15:54:40', NULL);
INSERT INTO `production_plans` VALUES (186, 'SC250430004', '测试', '2025-04-30', '2025-05-28', 99, 2.00, 'completed', NULL, '2025-04-30 15:59:54', '2025-04-30 16:01:14', NULL);
INSERT INTO `production_plans` VALUES (187, 'SC250430005', '测试', '2025-04-30', '2025-05-28', 99, 8.00, 'inspection', NULL, '2025-04-30 16:10:09', '2025-04-30 16:10:46', NULL);
INSERT INTO `production_plans` VALUES (188, 'SC250430006', '测试', '2025-04-30', '2025-05-28', 96, 3.00, 'inspection', NULL, '2025-04-30 16:24:42', '2025-04-30 16:25:18', NULL);
INSERT INTO `production_plans` VALUES (189, 'SC250430007', '测试检验', '2025-04-30', '2025-05-28', 96, 6.00, 'inspection', NULL, '2025-04-30 16:49:20', '2025-04-30 17:01:13', NULL);
INSERT INTO `production_plans` VALUES (190, 'SC250505001', '测试状态', '2025-05-05', '2025-06-02', 99, 1.00, 'inspection', NULL, '2025-05-05 13:58:27', '2025-05-05 13:59:26', NULL);
INSERT INTO `production_plans` VALUES (191, 'SC250505002', '测试', '2025-05-05', '2025-06-02', 99, 1.00, 'inspection', NULL, '2025-05-05 14:04:31', '2025-05-05 14:05:08', NULL);
INSERT INTO `production_plans` VALUES (192, 'SC250505003', '测试状态', '2025-05-05', '2025-06-02', 99, 1.00, 'inspection', NULL, '2025-05-05 14:29:16', '2025-05-05 14:30:00', NULL);
INSERT INTO `production_plans` VALUES (193, 'SC250505004', '测试状态', '2025-05-05', '2025-06-02', 97, 1.00, 'completed', NULL, '2025-05-05 14:34:12', '2025-05-05 14:35:42', NULL);
INSERT INTO `production_plans` VALUES (194, 'SC250505005', '订单物料生产计划-脚踏开关', '2025-05-05', '2025-05-12', 96, 3.00, 'completed', NULL, '2025-05-05 15:09:03', '2025-05-05 15:10:34', NULL);
INSERT INTO `production_plans` VALUES (199, 'SC250510001', '测试出库状态', '2025-05-10', '2025-06-07', 99, 2.00, 'completed', NULL, '2025-05-10 09:00:42', '2025-05-10 11:31:52', NULL);
INSERT INTO `production_plans` VALUES (200, 'SC250510002', '测试', '2025-05-10', '2025-06-07', 99, 2.00, 'draft', NULL, '2025-05-10 12:58:08', '2025-05-10 12:58:08', NULL);

-- ----------------------------
-- Table structure for production_processes
-- ----------------------------
DROP TABLE IF EXISTS `production_processes`;
CREATE TABLE `production_processes`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `task_id` int NOT NULL,
  `process_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `sequence` int NOT NULL DEFAULT 0,
  `quantity` decimal(10, 2) NOT NULL DEFAULT 0.00 COMMENT '计划数量',
  `planned_start_time` datetime NULL DEFAULT NULL,
  `planned_end_time` datetime NULL DEFAULT NULL,
  `actual_start_time` datetime NULL DEFAULT NULL,
  `actual_end_time` datetime NULL DEFAULT NULL,
  `progress` int NOT NULL DEFAULT 0,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'pending',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '工序描述',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sequence_number` int GENERATED ALWAYS AS (`sequence`) STORED COMMENT '工序顺序(别名)' NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `task_id`(`task_id` ASC) USING BTREE,
  CONSTRAINT `production_processes_ibfk_1` FOREIGN KEY (`task_id`) REFERENCES `production_tasks` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 58 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of production_processes
-- ----------------------------

-- ----------------------------
-- Table structure for production_reports
-- ----------------------------
DROP TABLE IF EXISTS `production_reports`;
CREATE TABLE `production_reports`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `report_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '报工单号',
  `task_id` bigint NOT NULL COMMENT '关联任务ID',
  `operator_id` bigint NOT NULL COMMENT '操作人员ID',
  `operator_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '操作人员姓名',
  `report_quantity` int NOT NULL COMMENT '报工数量',
  `qualified_quantity` int NOT NULL COMMENT '合格数量',
  `defective_quantity` int NULL DEFAULT 0 COMMENT '不良品数量',
  `report_time` datetime NOT NULL COMMENT '报工时间',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_report_no`(`report_no` ASC) USING BTREE,
  INDEX `idx_task_id`(`task_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '生产报工表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of production_reports
-- ----------------------------

-- ----------------------------
-- Table structure for production_task_progress
-- ----------------------------
DROP TABLE IF EXISTS `production_task_progress`;
CREATE TABLE `production_task_progress`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `task_id` int NOT NULL COMMENT '生产任务ID',
  `progress_date` date NOT NULL COMMENT '进度记录日期',
  `completed_quantity` int NOT NULL DEFAULT 0 COMMENT '完成数量',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '进度备注',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `task_id`(`task_id` ASC) USING BTREE,
  CONSTRAINT `production_task_progress_ibfk_1` FOREIGN KEY (`task_id`) REFERENCES `production_tasks` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '生产任务进度记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of production_task_progress
-- ----------------------------

-- ----------------------------
-- Table structure for production_tasks
-- ----------------------------
DROP TABLE IF EXISTS `production_tasks`;
CREATE TABLE `production_tasks`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '任务编号',
  `plan_id` int NOT NULL COMMENT '关联的生产计划ID',
  `product_id` int NOT NULL COMMENT '产品ID',
  `quantity` decimal(10, 2) NOT NULL COMMENT '计划数量',
  `start_date` date NOT NULL COMMENT '开始日期',
  `expected_end_date` date NOT NULL COMMENT '预计完成日期',
  `actual_end_date` date NULL DEFAULT NULL COMMENT '实际完成日期',
  `manager` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '负责人',
  `status` enum('pending','inProgress','completed','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'pending' COMMENT '状态：待开始、进行中、已完成、已取消',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_code`(`code` ASC) USING BTREE,
  INDEX `plan_id`(`plan_id` ASC) USING BTREE,
  CONSTRAINT `production_tasks_ibfk_1` FOREIGN KEY (`plan_id`) REFERENCES `production_plans` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 102 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '生产任务表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of production_tasks
-- ----------------------------
INSERT INTO `production_tasks` VALUES (83, 'SCT250429001', 182, 96, 1.00, '2025-04-29', '2025-04-29', '2025-04-30', '王晓敏', 'completed', '', '2025-04-29 12:53:58', '2025-04-30 15:18:16');
INSERT INTO `production_tasks` VALUES (84, 'SCT250429002', 181, 96, 1.00, '2025-04-29', '2025-04-29', '2025-04-30', '1', 'completed', '', '2025-04-29 15:48:04', '2025-04-30 15:18:14');
INSERT INTO `production_tasks` VALUES (85, 'SCT250429003', 179, 97, 1.00, '2025-04-29', '2025-04-29', '2025-04-30', '1', 'completed', '', '2025-04-29 15:49:47', '2025-04-30 15:18:13');
INSERT INTO `production_tasks` VALUES (86, 'SCT250429004', 176, 96, 1000.00, '2025-04-29', '2025-04-29', '2025-04-30', '1', 'completed', '', '2025-04-29 15:54:08', '2025-04-30 15:18:11');
INSERT INTO `production_tasks` VALUES (87, 'SCT250429005', 177, 99, 1.00, '2025-04-29', '2025-04-29', '2025-04-30', '1', 'completed', '', '2025-04-29 15:54:45', '2025-04-30 11:28:17');
INSERT INTO `production_tasks` VALUES (88, 'SCT250429006', 175, 99, 100.00, '2025-04-29', '2025-04-29', '2025-04-30', '1', 'completed', '', '2025-04-29 16:35:58', '2025-04-30 11:26:53');
INSERT INTO `production_tasks` VALUES (89, 'SCT250430001', 183, 99, 10.00, '2025-04-30', '2025-05-01', '2025-04-30', 'xlx', 'completed', '', '2025-04-30 13:55:20', '2025-04-30 13:55:34');
INSERT INTO `production_tasks` VALUES (90, 'SCT250430002', 184, 99, 4.00, '2025-04-30', '2025-04-30', '2025-04-30', '123', 'completed', '', '2025-04-30 15:46:23', '2025-04-30 15:46:27');
INSERT INTO `production_tasks` VALUES (91, 'SCT250430003', 185, 96, 57.00, '2025-04-30', '2025-05-01', '2025-04-30', '123', 'completed', '', '2025-04-30 15:54:36', '2025-04-30 15:54:40');
INSERT INTO `production_tasks` VALUES (92, 'SCT250430004', 186, 99, 2.00, '2025-04-30', '2025-04-30', '2025-04-30', '123', 'completed', '', '2025-04-30 16:00:51', '2025-04-30 16:01:14');
INSERT INTO `production_tasks` VALUES (93, 'SCT250430005', 187, 99, 8.00, '2025-04-30', '2025-04-30', '2025-04-30', '123', 'completed', '', '2025-04-30 16:10:42', '2025-04-30 16:10:46');
INSERT INTO `production_tasks` VALUES (94, 'SCT250430006', 188, 96, 3.00, '2025-04-30', '2025-05-01', '2025-04-30', '123', 'completed', '', '2025-04-30 16:25:15', '2025-04-30 16:25:18');
INSERT INTO `production_tasks` VALUES (95, 'SCT250430007', 189, 96, 6.00, '2025-04-30', '2025-04-30', '2025-04-30', '1', 'completed', '', '2025-04-30 17:01:09', '2025-04-30 17:01:13');
INSERT INTO `production_tasks` VALUES (96, 'SCT250505001', 190, 99, 1.00, '2025-05-05', '2025-05-05', '2025-05-05', '王晓敏', 'completed', '', '2025-05-05 13:59:19', '2025-05-05 13:59:26');
INSERT INTO `production_tasks` VALUES (97, 'SCT250505002', 191, 99, 1.00, '2025-05-05', '2025-05-05', '2025-05-05', '测试', 'completed', '', '2025-05-05 14:05:04', '2025-05-05 14:05:08');
INSERT INTO `production_tasks` VALUES (98, 'SCT250505003', 192, 99, 1.00, '2025-05-05', '2025-05-05', '2025-05-05', '测试', 'completed', '', '2025-05-05 14:29:51', '2025-05-05 14:30:00');
INSERT INTO `production_tasks` VALUES (99, 'SCT250505004', 193, 97, 1.00, '2025-05-05', '2025-05-05', '2025-05-05', '测试', 'completed', '', '2025-05-05 14:34:48', '2025-05-05 14:34:52');
INSERT INTO `production_tasks` VALUES (100, 'SCT250505005', 194, 96, 3.00, '2025-05-05', '2025-05-06', '2025-05-05', '王晓敏', 'completed', '', '2025-05-05 15:10:05', '2025-05-05 15:10:08');
INSERT INTO `production_tasks` VALUES (101, 'SCT250510001', 199, 99, 2.00, '2025-05-10', '2025-05-10', '2025-05-10', '王晓敏', 'completed', '', '2025-05-10 11:31:08', '2025-05-10 11:31:11');

-- ----------------------------
-- Table structure for products
-- ----------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '产品编码',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '产品名称',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '产品描述',
  `unit` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '单位',
  `category_id` int NULL DEFAULT NULL COMMENT '产品类别ID',
  `is_active` tinyint(1) NOT NULL DEFAULT 1 COMMENT '是否启用',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `idx_product_code`(`code` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '产品表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of products
-- ----------------------------
INSERT INTO `products` VALUES (1, 'PRD001', '智能照明控制器', '用于智能家居的照明控制系统', '个', NULL, 1, '2025-04-15 10:52:00', '2025-04-15 10:52:00');
INSERT INTO `products` VALUES (2, 'PRD002', '电路板组件', '用于电子设备的核心电路板', '个', NULL, 1, '2025-04-15 10:52:00', '2025-04-15 10:52:00');
INSERT INTO `products` VALUES (3, 'PRD003', '智能家居网关', '智能家居系统的控制中心', '个', NULL, 1, '2025-04-15 10:52:00', '2025-04-15 10:52:00');
INSERT INTO `products` VALUES (4, 'PRD004', '无线传感器', '用于环境监测的无线传感器', '个', NULL, 1, '2025-04-15 10:52:00', '2025-04-15 10:52:00');

-- ----------------------------
-- Table structure for purchase_order_items
-- ----------------------------
DROP TABLE IF EXISTS `purchase_order_items`;
CREATE TABLE `purchase_order_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `material_id` int NULL DEFAULT NULL,
  `material_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `material_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `specification` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `unit` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `unit_id` int NULL DEFAULT NULL,
  `price` decimal(10, 2) NOT NULL,
  `quantity` decimal(10, 2) NOT NULL,
  `total` decimal(12, 2) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `order_id`(`order_id` ASC) USING BTREE,
  INDEX `material_id`(`material_id` ASC) USING BTREE,
  INDEX `unit_id`(`unit_id` ASC) USING BTREE,
  CONSTRAINT `purchase_order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `purchase_order_items_ibfk_2` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `purchase_order_items_ibfk_3` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 112 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of purchase_order_items
-- ----------------------------
INSERT INTO `purchase_order_items` VALUES (55, 31, 92, '4002002169', '飞机盒', '', '个', 1, 0.00, 100.00, 0.00, '2025-04-30 09:04:25', '2025-04-30 09:04:25');
INSERT INTO `purchase_order_items` VALUES (56, 32, 77, '200301028', '开关盒', '', '个', 1, 0.00, 100.00, 0.00, '2025-04-30 12:59:01', '2025-04-30 12:59:01');
INSERT INTO `purchase_order_items` VALUES (57, 32, 76, '4006001001', '干燥剂', '', '个', 7, 0.00, 100.00, 0.00, '2025-04-30 12:59:01', '2025-04-30 12:59:01');
INSERT INTO `purchase_order_items` VALUES (77, 43, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 0.00, 200.00, 0.00, '2025-05-10 14:50:57', '2025-05-10 14:50:57');
INSERT INTO `purchase_order_items` VALUES (78, 43, 91, '4001002001', '包装外箱（中文）', 'KCB02 370x340x250mm', '个', 1, 0.00, 200.00, 0.00, '2025-05-10 14:50:57', '2025-05-10 14:50:57');
INSERT INTO `purchase_order_items` VALUES (79, 44, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 0.00, 200.00, 0.00, '2025-05-10 14:53:43', '2025-05-10 14:53:43');
INSERT INTO `purchase_order_items` VALUES (80, 44, 91, '4001002001', '包装外箱（中文）', 'KCB02 370x340x250mm', '个', 1, 0.00, 200.00, 0.00, '2025-05-10 14:53:43', '2025-05-10 14:53:43');
INSERT INTO `purchase_order_items` VALUES (87, 48, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 0.00, 200.00, 0.00, '2025-05-10 15:06:59', '2025-05-10 15:06:59');
INSERT INTO `purchase_order_items` VALUES (88, 48, 91, '4001002001', '包装外箱（中文）', 'KCB02 370x340x250mm', '个', 1, 0.00, 200.00, 0.00, '2025-05-10 15:06:59', '2025-05-10 15:06:59');
INSERT INTO `purchase_order_items` VALUES (89, 49, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 0.00, 200.00, 0.00, '2025-05-10 15:07:56', '2025-05-10 15:07:56');
INSERT INTO `purchase_order_items` VALUES (90, 49, 91, '4001002001', '包装外箱（中文）', 'KCB02 370x340x250mm', '个', 1, 0.00, 200.00, 0.00, '2025-05-10 15:07:56', '2025-05-10 15:07:56');
INSERT INTO `purchase_order_items` VALUES (91, 50, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 0.00, 200.00, 0.00, '2025-05-10 15:14:18', '2025-05-10 15:14:18');
INSERT INTO `purchase_order_items` VALUES (92, 50, 91, '4001002001', '包装外箱（中文）', 'KCB02 370x340x250mm', '个', 1, 0.00, 200.00, 0.00, '2025-05-10 15:14:18', '2025-05-10 15:14:18');
INSERT INTO `purchase_order_items` VALUES (93, 51, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 20.00, 2000.00, 40000.00, '2025-05-10 15:28:42', '2025-05-10 15:28:42');
INSERT INTO `purchase_order_items` VALUES (94, 52, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 0.00, 2000.00, 0.00, '2025-05-10 16:09:55', '2025-05-10 16:09:55');
INSERT INTO `purchase_order_items` VALUES (95, 53, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 0.00, 2000.00, 0.00, '2025-05-10 16:11:07', '2025-05-10 16:11:07');
INSERT INTO `purchase_order_items` VALUES (96, 54, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 0.00, 2000.00, 0.00, '2025-05-10 16:44:03', '2025-05-10 16:44:03');
INSERT INTO `purchase_order_items` VALUES (97, 55, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 0.00, 2000.00, 0.00, '2025-05-10 16:45:29', '2025-05-10 16:45:29');
INSERT INTO `purchase_order_items` VALUES (98, 56, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 0.00, 2000.00, 0.00, '2025-05-10 16:46:18', '2025-05-10 16:46:18');
INSERT INTO `purchase_order_items` VALUES (99, 57, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 0.00, 2000.00, 0.00, '2025-05-10 16:49:24', '2025-05-10 16:49:24');
INSERT INTO `purchase_order_items` VALUES (100, 58, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 0.00, 2000.00, 0.00, '2025-05-10 16:58:24', '2025-05-10 16:58:24');
INSERT INTO `purchase_order_items` VALUES (101, 59, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 0.00, 2000.00, 0.00, '2025-05-10 17:02:05', '2025-05-10 17:02:05');
INSERT INTO `purchase_order_items` VALUES (102, 60, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 0.00, 2000.00, 0.00, '2025-05-10 17:10:27', '2025-05-10 17:10:27');
INSERT INTO `purchase_order_items` VALUES (103, 61, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 0.00, 2000.00, 0.00, '2025-05-10 17:17:53', '2025-05-10 17:17:53');
INSERT INTO `purchase_order_items` VALUES (104, 62, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 0.00, 2000.00, 0.00, '2025-05-10 17:20:56', '2025-05-10 17:20:56');
INSERT INTO `purchase_order_items` VALUES (105, 63, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 0.00, 2000.00, 0.00, '2025-05-10 18:39:53', '2025-05-10 18:39:53');
INSERT INTO `purchase_order_items` VALUES (106, 64, 98, '3001023002', '蓝色踏板', 'HRF-M5B', '个', 1, 0.00, 2000.00, 0.00, '2025-05-10 19:02:07', '2025-05-10 19:02:07');
INSERT INTO `purchase_order_items` VALUES (107, 65, 98, '3001023002', '蓝色踏板', 'HRF-M5B', '个', 1, 0.00, 2000.00, 0.00, '2025-05-10 19:09:31', '2025-05-10 19:09:31');
INSERT INTO `purchase_order_items` VALUES (108, 66, 98, '3001023002', '蓝色踏板', 'HRF-M5B', '个', 1, 0.00, 2000.00, 0.00, '2025-05-10 19:55:05', '2025-05-10 19:55:05');
INSERT INTO `purchase_order_items` VALUES (109, 67, 98, '3001023002', '蓝色踏板', 'HRF-M5B', '个', 1, 0.00, 2000.00, 0.00, '2025-05-10 20:00:11', '2025-05-10 20:00:11');
INSERT INTO `purchase_order_items` VALUES (110, 68, 98, '3001023002', '蓝色踏板', 'HRF-M5B', '个', 1, 0.00, 2000.00, 0.00, '2025-05-10 20:00:33', '2025-05-10 20:00:33');
INSERT INTO `purchase_order_items` VALUES (111, 69, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 0.00, 2000.00, 0.00, '2025-05-10 20:33:21', '2025-05-10 20:33:21');

-- ----------------------------
-- Table structure for purchase_orders
-- ----------------------------
DROP TABLE IF EXISTS `purchase_orders`;
CREATE TABLE `purchase_orders`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `order_date` date NOT NULL,
  `supplier_id` int NULL DEFAULT NULL,
  `supplier_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `expected_delivery_date` date NULL DEFAULT NULL,
  `contact_person` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `contact_phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `total_amount` decimal(12, 2) NULL DEFAULT 0.00,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `requisition_id` int NULL DEFAULT NULL,
  `requisition_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `order_no`(`order_no` ASC) USING BTREE,
  INDEX `supplier_id`(`supplier_id` ASC) USING BTREE,
  INDEX `fk_order_requisition`(`requisition_id` ASC) USING BTREE,
  CONSTRAINT `fk_order_requisition` FOREIGN KEY (`requisition_id`) REFERENCES `purchase_requisitions` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `purchase_orders_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 70 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of purchase_orders
-- ----------------------------
INSERT INTO `purchase_orders` VALUES (31, 'PO202504300001', '2025-04-30', 13, '乐清市朗盛电子科技有限公司', '2025-04-30', '老六', '13888888888', 0.00, NULL, 'completed', '2025-04-30 09:04:25', '2025-04-30 09:32:55', NULL, NULL);
INSERT INTO `purchase_orders` VALUES (32, 'PO202504300002', '2025-04-30', 13, '乐清市朗盛电子科技有限公司', '2025-04-30', '老六', '13888888888', 0.00, NULL, 'completed', '2025-04-30 12:59:01', '2025-04-30 12:59:09', NULL, NULL);
INSERT INTO `purchase_orders` VALUES (43, 'PO202505100002', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'cancelled', '2025-05-10 14:50:57', '2025-05-10 14:56:52', 20, 'PR202505100003');
INSERT INTO `purchase_orders` VALUES (44, 'PO202505100003', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'cancelled', '2025-05-10 14:53:43', '2025-05-10 14:56:56', 20, 'PR202505100003');
INSERT INTO `purchase_orders` VALUES (48, 'PO202505100004', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'completed', '2025-05-10 15:06:59', '2025-05-10 16:45:17', 20, 'PR202505100003');
INSERT INTO `purchase_orders` VALUES (49, 'PO202505100005', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'completed', '2025-05-10 15:07:56', '2025-05-10 15:25:49', 20, 'PR202505100003');
INSERT INTO `purchase_orders` VALUES (50, 'PO202505100006', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'completed', '2025-05-10 15:14:18', '2025-05-10 15:25:34', 20, 'PR202505100003');
INSERT INTO `purchase_orders` VALUES (51, 'PO202505100007', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 40000.00, NULL, 'completed', '2025-05-10 15:28:42', '2025-05-10 15:28:51', 21, 'PR202505100004');
INSERT INTO `purchase_orders` VALUES (52, 'PO202505100008', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'completed', '2025-05-10 16:09:55', '2025-05-10 16:10:05', 21, 'PR202505100004');
INSERT INTO `purchase_orders` VALUES (53, 'PO202505100009', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'completed', '2025-05-10 16:11:07', '2025-05-10 16:11:16', 21, 'PR202505100004');
INSERT INTO `purchase_orders` VALUES (54, 'PO202505100010', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'completed', '2025-05-10 16:44:03', '2025-05-10 16:44:18', 21, 'PR202505100004');
INSERT INTO `purchase_orders` VALUES (55, 'PO202505100011', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'completed', '2025-05-10 16:45:29', '2025-05-10 16:45:46', 21, 'PR202505100004');
INSERT INTO `purchase_orders` VALUES (56, 'PO202505100012', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'completed', '2025-05-10 16:46:18', '2025-05-10 16:46:32', 21, 'PR202505100004');
INSERT INTO `purchase_orders` VALUES (57, 'PO202505100013', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'completed', '2025-05-10 16:49:24', '2025-05-10 16:49:35', 21, 'PR202505100004');
INSERT INTO `purchase_orders` VALUES (58, 'PO202505100014', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'completed', '2025-05-10 16:58:24', '2025-05-10 16:58:32', 21, 'PR202505100004');
INSERT INTO `purchase_orders` VALUES (59, 'PO202505100015', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'completed', '2025-05-10 17:02:05', '2025-05-10 17:02:19', 21, 'PR202505100004');
INSERT INTO `purchase_orders` VALUES (60, 'PO202505100016', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'completed', '2025-05-10 17:10:27', '2025-05-10 17:10:38', 21, 'PR202505100004');
INSERT INTO `purchase_orders` VALUES (61, 'PO202505100017', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'completed', '2025-05-10 17:17:53', '2025-05-10 17:19:24', 21, 'PR202505100004');
INSERT INTO `purchase_orders` VALUES (62, 'PO202505100018', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'completed', '2025-05-10 17:20:56', '2025-05-10 17:21:02', 21, 'PR202505100004');
INSERT INTO `purchase_orders` VALUES (63, 'PO202505100019', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-17', '老六', '13888888888', 0.00, NULL, 'completed', '2025-05-10 18:39:53', '2025-05-10 18:40:08', 21, 'PR202505100004');
INSERT INTO `purchase_orders` VALUES (64, 'PO202505100020', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'completed', '2025-05-10 19:02:07', '2025-05-10 19:02:23', 22, 'PR202505100005');
INSERT INTO `purchase_orders` VALUES (65, 'PO202505100021', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'completed', '2025-05-10 19:09:31', '2025-05-10 19:09:49', 22, 'PR202505100005');
INSERT INTO `purchase_orders` VALUES (66, 'PO202505100022', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'completed', '2025-05-10 19:55:05', '2025-05-10 19:55:22', 22, 'PR202505100005');
INSERT INTO `purchase_orders` VALUES (67, 'PO202505100023', '2025-05-10', 11, '乐清市通达有线电厂', '2025-05-10', '李四', '13888888888', 0.00, NULL, 'completed', '2025-05-10 20:00:11', '2025-05-10 20:00:59', 22, 'PR202505100005');
INSERT INTO `purchase_orders` VALUES (68, 'PO202505100024', '2025-05-10', 11, '乐清市通达有线电厂', '2025-05-10', '李四', '13888888888', 0.00, NULL, 'completed', '2025-05-10 20:00:33', '2025-05-10 20:00:55', 22, 'PR202505100005');
INSERT INTO `purchase_orders` VALUES (69, 'PO202505100025', '2025-05-10', 13, '乐清市朗盛电子科技有限公司', '2025-05-10', '老六', '13888888888', 0.00, NULL, 'completed', '2025-05-10 20:33:21', '2025-05-10 20:33:37', 21, 'PR202505100004');

-- ----------------------------
-- Table structure for purchase_receipt_items
-- ----------------------------
DROP TABLE IF EXISTS `purchase_receipt_items`;
CREATE TABLE `purchase_receipt_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `receipt_id` int NOT NULL COMMENT '入库单ID',
  `order_item_id` int NULL DEFAULT NULL COMMENT '订单项ID',
  `material_id` int NOT NULL COMMENT '物料ID',
  `material_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '物料编码',
  `material_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '物料名称',
  `specification` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '规格',
  `unit` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '单位',
  `unit_id` int NULL DEFAULT NULL COMMENT '单位ID',
  `ordered_quantity` decimal(10, 2) NULL DEFAULT 0.00,
  `quantity` decimal(10, 2) NULL DEFAULT 0.00,
  `received_quantity` decimal(10, 2) NOT NULL COMMENT '实收数量',
  `qualified_quantity` decimal(10, 2) NULL DEFAULT 0.00 COMMENT '合格数量',
  `price` decimal(10, 2) NULL DEFAULT 0.00 COMMENT '单价',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `from_inspection` tinyint(1) NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `receipt_id`(`receipt_id` ASC) USING BTREE,
  INDEX `material_id`(`material_id` ASC) USING BTREE,
  CONSTRAINT `purchase_receipt_items_ibfk_1` FOREIGN KEY (`receipt_id`) REFERENCES `purchase_receipts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of purchase_receipt_items
-- ----------------------------
INSERT INTO `purchase_receipt_items` VALUES (17, 36, NULL, 98, '', '', '', NULL, NULL, 0.00, 2000.00, 2000.00, 2000.00, 0.00, '自动创建的来料检验单 - 供应商: 乐清市朗盛电子科技有限公司', 0, '2025-05-10 19:24:05', '2025-05-10 19:24:05');
INSERT INTO `purchase_receipt_items` VALUES (18, 37, NULL, 98, '', '', '', NULL, 1, 2000.00, 2000.00, 2000.00, 2000.00, 0.00, '自动入库：自动创建的来料检验单 - 供应商: 乐清市通达有线电厂', 0, '2025-05-10 20:03:55', '2025-05-10 20:03:55');
INSERT INTO `purchase_receipt_items` VALUES (19, 38, NULL, 98, '', '', '', NULL, 1, 2000.00, 2000.00, 2000.00, 2000.00, 0.00, '自动入库：自动创建的来料检验单 - 供应商: 乐清市通达有线电厂', 0, '2025-05-10 20:07:53', '2025-05-10 20:07:53');
INSERT INTO `purchase_receipt_items` VALUES (20, 39, NULL, 98, '', '', '', NULL, NULL, 0.00, 2000.00, 2000.00, 2000.00, 0.00, '自动创建的来料检验单 - 供应商: 乐清市通达有线电厂', 0, '2025-05-10 20:27:32', '2025-05-10 20:27:32');
INSERT INTO `purchase_receipt_items` VALUES (21, 40, NULL, 101, '', '', '', NULL, 1, 2000.00, 2000.00, 2000.00, 2000.00, 0.00, '自动入库：自动创建的来料检验单 - 供应商: 乐清市朗盛电子科技有限公司', 0, '2025-05-10 20:34:08', '2025-05-10 20:34:08');

-- ----------------------------
-- Table structure for purchase_receipts
-- ----------------------------
DROP TABLE IF EXISTS `purchase_receipts`;
CREATE TABLE `purchase_receipts`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `receipt_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '入库单号',
  `order_id` int NULL DEFAULT NULL COMMENT '关联订单ID',
  `order_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '关联订单号',
  `supplier_id` int NOT NULL COMMENT '供应商ID',
  `supplier_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '供应商名称',
  `warehouse_id` int NOT NULL COMMENT '仓库ID',
  `warehouse_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '仓库名称',
  `receipt_date` date NOT NULL COMMENT '入库日期',
  `operator` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '操作员',
  `inspection_id` int NULL DEFAULT NULL COMMENT '关联检验单ID',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `from_inspection` tinyint(1) NULL DEFAULT 0,
  `status` enum('draft','confirmed','completed','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'draft',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `receipt_no`(`receipt_no` ASC) USING BTREE,
  INDEX `order_id`(`order_id` ASC) USING BTREE,
  INDEX `supplier_id`(`supplier_id` ASC) USING BTREE,
  INDEX `warehouse_id`(`warehouse_id` ASC) USING BTREE,
  INDEX `status`(`status` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 41 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of purchase_receipts
-- ----------------------------
INSERT INTO `purchase_receipts` VALUES (31, 'GR202504300001', 31, '', 13, '', 13, '', '2025-04-30', 'admin', 125, '由质检单INCOMING20250430001自动生成，仅包含检验合格的物料： | [2025-04-30T01:33:31.305Z] 状态变更为 confirmed: 用户直接确认入库 | [2025-04-30T01:33:35.534Z] 状态变更为 completed', 1, 'completed', '2025-04-30 09:33:22', '2025-04-30 09:33:35');
INSERT INTO `purchase_receipts` VALUES (32, 'GR202504300002', 32, '', 13, '', 13, '', '2025-04-30', 'admin', 128, '由质检单INCOMING20250430002自动生成，仅包含检验合格的物料： | [2025-04-30T05:01:26.976Z] 状态变更为 confirmed: 用户直接确认入库 | [2025-04-30T05:01:31.230Z] 状态变更为 completed', 1, 'completed', '2025-04-30 13:01:16', '2025-04-30 13:01:31');
INSERT INTO `purchase_receipts` VALUES (33, 'GR202505050001', 32, '', 13, '', 13, '', '2025-05-05', 'admin', 128, '由质检单INCOMING20250430002自动生成，仅包含检验合格的物料： | [2025-05-05T06:04:05.929Z] 状态变更为 confirmed: 用户直接确认入库 | [2025-05-05T06:04:10.405Z] 状态变更为 completed', 1, 'completed', '2025-05-05 14:03:48', '2025-05-05 14:04:04');
INSERT INTO `purchase_receipts` VALUES (34, 'GR202505100001', 32, '', 13, '', 1, '', '2025-05-10', 'admin', 147, '由质检单INCOMING20250510001自动生成，仅包含检验合格的物料：', 1, 'draft', '2025-05-10 15:10:31', '2025-05-10 15:10:31');
INSERT INTO `purchase_receipts` VALUES (35, 'GR202505100002', 51, '', 13, '', 1, '', '2025-05-10', 'admin', 148, '由质检单INCOMING20250510002自动生成，仅包含检验合格的物料：', 1, 'draft', '2025-05-10 15:29:07', '2025-05-10 15:29:07');
INSERT INTO `purchase_receipts` VALUES (36, 'GR202505100003', 65, '', 13, '', 2, '', '2025-05-10', 'admin', 163, ' | [2025-05-10T11:24:36.297Z] 状态变更为 confirmed: 用户直接确认入库 | [2025-05-10T12:14:00.243Z] 状态变更为 completed', 0, 'completed', '2025-05-10 19:24:05', '2025-05-10 20:13:42');
INSERT INTO `purchase_receipts` VALUES (37, 'GR202505100004', 67, '', 11, '', 1, '', '2025-05-10', 'admin', 166, ' | [2025-05-10T12:07:11.148Z] 状态变更为 confirmed | [2025-05-10T12:07:21.059Z] 状态变更为 cancelled', 0, 'cancelled', '2025-05-10 20:03:55', '2025-05-10 20:07:03');
INSERT INTO `purchase_receipts` VALUES (38, 'GR202505100005', 68, '', 11, '', 2, '', '2025-05-10', 'admin', 165, ' | [2025-05-10T12:08:23.361Z] 状态变更为 confirmed: 用户直接确认入库 | [2025-05-10T12:10:11.812Z] 状态变更为 completed', 0, 'completed', '2025-05-10 20:07:53', '2025-05-10 20:09:54');
INSERT INTO `purchase_receipts` VALUES (39, 'GR202505100006', 67, '', 11, '', 2, '', '2025-05-10', 'admin', 166, ' | [2025-05-10T12:27:53.275Z] 状态变更为 confirmed: 用户直接确认入库 | [2025-05-10T12:28:01.238Z] 状态变更为 completed', 0, 'completed', '2025-05-10 20:27:31', '2025-05-10 20:27:43');
INSERT INTO `purchase_receipts` VALUES (40, 'GR202505100007', 69, '', 13, '', 2, '', '2025-05-10', 'admin', 167, ' | [2025-05-10T12:34:37.416Z] 状态变更为 confirmed: 用户直接确认入库 | [2025-05-10T12:34:44.884Z] 状态变更为 completed', 0, 'completed', '2025-05-10 20:34:08', '2025-05-10 20:34:27');

-- ----------------------------
-- Table structure for purchase_requisition_items
-- ----------------------------
DROP TABLE IF EXISTS `purchase_requisition_items`;
CREATE TABLE `purchase_requisition_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `requisition_id` int NOT NULL,
  `material_id` int NULL DEFAULT NULL,
  `material_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `material_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `specification` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `unit` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `unit_id` int NULL DEFAULT NULL,
  `quantity` decimal(10, 2) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `requisition_id`(`requisition_id` ASC) USING BTREE,
  INDEX `material_id`(`material_id` ASC) USING BTREE,
  INDEX `unit_id`(`unit_id` ASC) USING BTREE,
  CONSTRAINT `purchase_requisition_items_ibfk_1` FOREIGN KEY (`requisition_id`) REFERENCES `purchase_requisitions` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `purchase_requisition_items_ibfk_2` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `purchase_requisition_items_ibfk_3` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 34 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of purchase_requisition_items
-- ----------------------------
INSERT INTO `purchase_requisition_items` VALUES (23, 15, 92, '4002002169', '飞机盒', '', '个', 1, 100.00, '2025-04-30 09:04:01', '2025-04-30 09:04:01');
INSERT INTO `purchase_requisition_items` VALUES (24, 16, 77, '200301028', '开关盒', '', '个', 1, 100.00, '2025-04-30 12:58:11', '2025-04-30 12:58:11');
INSERT INTO `purchase_requisition_items` VALUES (25, 16, 76, '4006001001', '干燥剂', '', '个', 7, 100.00, '2025-04-30 12:58:12', '2025-04-30 12:58:12');
INSERT INTO `purchase_requisition_items` VALUES (26, 17, 77, '200301028', '开关盒', '', '个', 1, 100.00, '2025-04-30 12:58:17', '2025-04-30 12:58:17');
INSERT INTO `purchase_requisition_items` VALUES (27, 17, 76, '4006001001', '干燥剂', '', '个', 7, 100.00, '2025-04-30 12:58:17', '2025-04-30 12:58:17');
INSERT INTO `purchase_requisition_items` VALUES (28, 18, 92, '4002002169', '飞机盒', '', '个', 1, 200.00, '2025-05-10 13:02:55', '2025-05-10 13:02:55');
INSERT INTO `purchase_requisition_items` VALUES (29, 19, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 1.00, '2025-05-10 13:12:25', '2025-05-10 13:12:25');
INSERT INTO `purchase_requisition_items` VALUES (30, 20, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 200.00, '2025-05-10 14:50:35', '2025-05-10 14:50:35');
INSERT INTO `purchase_requisition_items` VALUES (31, 20, 91, '4001002001', '包装外箱（中文）', 'KCB02 370x340x250mm', '个', 1, 200.00, '2025-05-10 14:50:35', '2025-05-10 14:50:35');
INSERT INTO `purchase_requisition_items` VALUES (32, 21, 101, '300102300201', '黑色踏板', 'HRF-M5K', '个', 1, 2000.00, '2025-05-10 15:28:21', '2025-05-10 15:28:21');
INSERT INTO `purchase_requisition_items` VALUES (33, 22, 98, '3001023002', '蓝色踏板', 'HRF-M5B', '个', 1, 2000.00, '2025-05-10 19:01:37', '2025-05-10 19:01:37');

-- ----------------------------
-- Table structure for purchase_requisitions
-- ----------------------------
DROP TABLE IF EXISTS `purchase_requisitions`;
CREATE TABLE `purchase_requisitions`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `requisition_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `request_date` date NOT NULL,
  `requester` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'draft',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `requisition_number`(`requisition_number` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 23 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of purchase_requisitions
-- ----------------------------
INSERT INTO `purchase_requisitions` VALUES (15, 'PR202504300001', '2025-04-30', 'admin', '', 'approved', '2025-04-30 09:04:01', '2025-04-30 09:04:09');
INSERT INTO `purchase_requisitions` VALUES (16, 'PR202504300002', '2025-04-30', 'admin', '', 'approved', '2025-04-30 12:58:10', '2025-04-30 12:58:35');
INSERT INTO `purchase_requisitions` VALUES (17, 'PR202504300003', '2025-04-30', 'admin', '', 'approved', '2025-04-30 12:58:16', '2025-04-30 12:58:31');
INSERT INTO `purchase_requisitions` VALUES (18, 'PR202505100001', '2025-05-10', 'admin', '', 'draft', '2025-05-10 13:02:55', '2025-05-10 13:02:55');
INSERT INTO `purchase_requisitions` VALUES (19, 'PR202505100002', '2025-05-10', 'admin', '', 'submitted', '2025-05-10 13:12:25', '2025-05-10 15:40:48');
INSERT INTO `purchase_requisitions` VALUES (20, 'PR202505100003', '2025-05-10', 'admin', '', 'approved', '2025-05-10 14:50:35', '2025-05-10 14:50:47');
INSERT INTO `purchase_requisitions` VALUES (21, 'PR202505100004', '2025-05-10', 'admin', '', 'approved', '2025-05-10 15:28:21', '2025-05-10 15:28:26');
INSERT INTO `purchase_requisitions` VALUES (22, 'PR202505100005', '2025-05-10', 'admin', '', 'approved', '2025-05-10 19:01:37', '2025-05-10 19:01:46');

-- ----------------------------
-- Table structure for quality_inspection_items
-- ----------------------------
DROP TABLE IF EXISTS `quality_inspection_items`;
CREATE TABLE `quality_inspection_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `inspection_id` int NOT NULL COMMENT '检验单ID',
  `item_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '检验项目名称',
  `standard` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '检验标准',
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `is_critical` tinyint(1) NULL DEFAULT 0 COMMENT '是否关键项',
  `actual_value` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '实际值',
  `method` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '检验方法',
  `result` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '检验结果',
  `is_qualified` tinyint(1) NULL DEFAULT NULL COMMENT '是否合格',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_inspection_id`(`inspection_id` ASC) USING BTREE,
  CONSTRAINT `fk_inspection_items_inspection` FOREIGN KEY (`inspection_id`) REFERENCES `quality_inspections` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 683 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '质量检验项表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of quality_inspection_items
-- ----------------------------
INSERT INTO `quality_inspection_items` VALUES (524, 129, '外观', '外观检查', 'visual', 0, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:16:50', '2025-04-30 15:16:50');
INSERT INTO `quality_inspection_items` VALUES (525, 129, '性能', '性能检查', 'function', 0, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:16:50', '2025-04-30 15:16:50');
INSERT INTO `quality_inspection_items` VALUES (526, 129, '包装', '包装检查', 'other', 0, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:16:50', '2025-04-30 15:16:50');
INSERT INTO `quality_inspection_items` VALUES (527, 126, '外观', '外观检查', 'visual', 0, '12', NULL, 'passed', NULL, NULL, '2025-04-30 15:17:17', '2025-04-30 15:17:17');
INSERT INTO `quality_inspection_items` VALUES (528, 126, '性能', '性能检查', 'function', 0, '12', NULL, 'passed', NULL, NULL, '2025-04-30 15:17:17', '2025-04-30 15:17:17');
INSERT INTO `quality_inspection_items` VALUES (529, 126, '包装', '包装检查', 'other', 0, '23', NULL, 'passed', NULL, NULL, '2025-04-30 15:17:17', '2025-04-30 15:17:17');
INSERT INTO `quality_inspection_items` VALUES (530, 127, '外观', '外观检查', 'visual', 0, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:17:46', '2025-04-30 15:17:46');
INSERT INTO `quality_inspection_items` VALUES (531, 127, '性能', '性能检查', 'function', 0, '31', NULL, 'passed', NULL, NULL, '2025-04-30 15:17:46', '2025-04-30 15:17:46');
INSERT INTO `quality_inspection_items` VALUES (532, 127, '包装', '包装检查', 'other', 0, '213', NULL, 'passed', NULL, NULL, '2025-04-30 15:17:46', '2025-04-30 15:17:46');
INSERT INTO `quality_inspection_items` VALUES (548, 133, '外观检查', '无明显缺陷、划痕、变形', 'visual', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:21:53', '2025-04-30 15:21:53');
INSERT INTO `quality_inspection_items` VALUES (549, 133, '尺寸检查', '符合图纸要求', 'dimension', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:21:53', '2025-04-30 15:21:53');
INSERT INTO `quality_inspection_items` VALUES (550, 133, '功能测试', '功能正常', 'function', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:21:53', '2025-04-30 15:21:53');
INSERT INTO `quality_inspection_items` VALUES (557, 131, '外观检查', '无明显缺陷、划痕、变形', 'visual', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:24:21', '2025-04-30 15:24:21');
INSERT INTO `quality_inspection_items` VALUES (558, 131, '尺寸检查', '符合图纸要求', 'dimension', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:24:21', '2025-04-30 15:24:21');
INSERT INTO `quality_inspection_items` VALUES (559, 131, '功能测试', '功能正常', 'function', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:24:21', '2025-04-30 15:24:21');
INSERT INTO `quality_inspection_items` VALUES (560, 134, '外观检查', '无明显缺陷、划痕、变形', 'visual', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:28:38', '2025-04-30 15:28:38');
INSERT INTO `quality_inspection_items` VALUES (561, 134, '尺寸检查', '符合图纸要求', 'dimension', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:28:38', '2025-04-30 15:28:38');
INSERT INTO `quality_inspection_items` VALUES (562, 134, '功能测试', '功能正常', 'function', 1, '1', NULL, 'passed', NULL, NULL, '2025-04-30 15:28:38', '2025-04-30 15:28:38');
INSERT INTO `quality_inspection_items` VALUES (563, 130, '外观', '外观检查', 'visual', 0, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:32:52', '2025-04-30 15:32:52');
INSERT INTO `quality_inspection_items` VALUES (564, 130, '性能', '性能检查', 'function', 0, '321', NULL, 'passed', NULL, NULL, '2025-04-30 15:32:52', '2025-04-30 15:32:52');
INSERT INTO `quality_inspection_items` VALUES (565, 130, '包装', '包装检查', 'other', 0, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:32:53', '2025-04-30 15:32:53');
INSERT INTO `quality_inspection_items` VALUES (566, 132, '检验项目列表', '以不同力度和频率踩踏脚踏开关，', 'visual', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:40:50', '2025-04-30 15:40:50');
INSERT INTO `quality_inspection_items` VALUES (567, 132, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:40:50', '2025-04-30 15:40:50');
INSERT INTO `quality_inspection_items` VALUES (568, 132, '防水性能测试', '将脚踏开关置于IPX4等级的喷水环境中', 'function', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:40:50', '2025-04-30 15:40:50');
INSERT INTO `quality_inspection_items` VALUES (572, 135, '外观', '外观检查', 'visual', 0, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:46:45', '2025-04-30 15:46:45');
INSERT INTO `quality_inspection_items` VALUES (573, 135, '性能', '性能检查', 'function', 0, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:46:45', '2025-04-30 15:46:45');
INSERT INTO `quality_inspection_items` VALUES (574, 135, '包装', '包装检查', 'other', 0, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:46:45', '2025-04-30 15:46:45');
INSERT INTO `quality_inspection_items` VALUES (578, 136, '外观检查', '无明显缺陷、划痕、变形', 'visual', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:54:58', '2025-04-30 15:54:58');
INSERT INTO `quality_inspection_items` VALUES (579, 136, '尺寸检查', '符合图纸要求', 'dimension', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:54:58', '2025-04-30 15:54:58');
INSERT INTO `quality_inspection_items` VALUES (580, 136, '功能测试', '功能正常', 'function', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 15:54:58', '2025-04-30 15:54:58');
INSERT INTO `quality_inspection_items` VALUES (581, 137, '外观', '外观检查', 'visual', 0, NULL, NULL, NULL, NULL, NULL, '2025-04-30 16:01:14', '2025-04-30 16:01:14');
INSERT INTO `quality_inspection_items` VALUES (582, 137, '性能', '性能检查', 'function', 0, NULL, NULL, NULL, NULL, NULL, '2025-04-30 16:01:14', '2025-04-30 16:01:14');
INSERT INTO `quality_inspection_items` VALUES (583, 137, '包装', '包装检查', 'other', 0, NULL, NULL, NULL, NULL, NULL, '2025-04-30 16:01:14', '2025-04-30 16:01:14');
INSERT INTO `quality_inspection_items` VALUES (587, 138, '外观', '外观检查', 'visual', 0, '123', NULL, 'passed', NULL, NULL, '2025-04-30 16:11:34', '2025-04-30 16:11:34');
INSERT INTO `quality_inspection_items` VALUES (588, 138, '性能', '性能检查', 'function', 0, '123', NULL, 'passed', NULL, NULL, '2025-04-30 16:11:34', '2025-04-30 16:11:34');
INSERT INTO `quality_inspection_items` VALUES (589, 138, '包装', '包装检查', 'other', 0, '123', NULL, 'passed', NULL, NULL, '2025-04-30 16:11:34', '2025-04-30 16:11:34');
INSERT INTO `quality_inspection_items` VALUES (593, 139, '外观检查', '无明显缺陷、划痕、变形', 'visual', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 16:25:34', '2025-04-30 16:25:34');
INSERT INTO `quality_inspection_items` VALUES (594, 139, '尺寸检查', '符合图纸要求', 'dimension', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 16:25:34', '2025-04-30 16:25:34');
INSERT INTO `quality_inspection_items` VALUES (595, 139, '功能测试', '功能正常', 'function', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 16:25:34', '2025-04-30 16:25:34');
INSERT INTO `quality_inspection_items` VALUES (599, 140, '外观检查', '无明显缺陷、划痕、变形', 'visual', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 17:01:26', '2025-04-30 17:01:26');
INSERT INTO `quality_inspection_items` VALUES (600, 140, '尺寸检查', '符合图纸要求', 'dimension', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 17:01:26', '2025-04-30 17:01:26');
INSERT INTO `quality_inspection_items` VALUES (601, 140, '功能测试', '功能正常', 'function', 1, '123', NULL, 'passed', NULL, NULL, '2025-04-30 17:01:26', '2025-04-30 17:01:26');
INSERT INTO `quality_inspection_items` VALUES (605, 141, '外观', '外观检查', 'visual', 0, '123', NULL, 'passed', NULL, NULL, '2025-05-05 13:59:45', '2025-05-05 13:59:45');
INSERT INTO `quality_inspection_items` VALUES (606, 141, '性能', '性能检查', 'function', 0, '123', NULL, 'passed', NULL, NULL, '2025-05-05 13:59:45', '2025-05-05 13:59:45');
INSERT INTO `quality_inspection_items` VALUES (607, 141, '包装', '包装检查', 'other', 0, '123', NULL, 'passed', NULL, NULL, '2025-05-05 13:59:45', '2025-05-05 13:59:45');
INSERT INTO `quality_inspection_items` VALUES (614, 142, '外观', '外观检查', 'visual', 0, '123', NULL, 'passed', NULL, NULL, '2025-05-05 14:05:31', '2025-05-05 14:05:31');
INSERT INTO `quality_inspection_items` VALUES (615, 142, '性能', '性能检查', 'function', 0, '123', NULL, 'passed', NULL, NULL, '2025-05-05 14:05:31', '2025-05-05 14:05:31');
INSERT INTO `quality_inspection_items` VALUES (616, 142, '包装', '包装检查', 'other', 0, '123', NULL, 'passed', NULL, NULL, '2025-05-05 14:05:31', '2025-05-05 14:05:31');
INSERT INTO `quality_inspection_items` VALUES (620, 143, '外观', '外观检查', 'visual', 0, '123', NULL, 'passed', NULL, NULL, '2025-05-05 14:30:21', '2025-05-05 14:30:21');
INSERT INTO `quality_inspection_items` VALUES (621, 143, '性能', '性能检查', 'function', 0, '321', NULL, 'passed', NULL, NULL, '2025-05-05 14:30:21', '2025-05-05 14:30:21');
INSERT INTO `quality_inspection_items` VALUES (622, 143, '包装', '包装检查', 'other', 0, '123', NULL, 'passed', NULL, NULL, '2025-05-05 14:30:21', '2025-05-05 14:30:21');
INSERT INTO `quality_inspection_items` VALUES (626, 144, '检验项目列表', '以不同力度和频率踩踏脚踏开关，', 'visual', 1, '123', NULL, 'passed', NULL, NULL, '2025-05-05 14:35:22', '2025-05-05 14:35:22');
INSERT INTO `quality_inspection_items` VALUES (627, 144, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '321', NULL, 'passed', NULL, NULL, '2025-05-05 14:35:22', '2025-05-05 14:35:22');
INSERT INTO `quality_inspection_items` VALUES (628, 144, '防水性能测试', '将脚踏开关置于IPX4等级的喷水环境中', 'function', 1, '123', NULL, 'passed', NULL, NULL, '2025-05-05 14:35:22', '2025-05-05 14:35:22');
INSERT INTO `quality_inspection_items` VALUES (632, 145, '外观检查', '无明显缺陷、划痕、变形', 'visual', 1, '123', NULL, 'passed', NULL, NULL, '2025-05-05 15:10:27', '2025-05-05 15:10:27');
INSERT INTO `quality_inspection_items` VALUES (633, 145, '尺寸检查', '符合图纸要求', 'dimension', 1, '123', NULL, 'passed', NULL, NULL, '2025-05-05 15:10:27', '2025-05-05 15:10:27');
INSERT INTO `quality_inspection_items` VALUES (634, 145, '功能测试', '功能正常', 'function', 1, '13', NULL, 'passed', NULL, NULL, '2025-05-05 15:10:27', '2025-05-05 15:10:27');
INSERT INTO `quality_inspection_items` VALUES (638, 146, '外观', '外观检查', 'visual', 0, '123', NULL, 'passed', NULL, NULL, '2025-05-10 11:31:38', '2025-05-10 11:31:38');
INSERT INTO `quality_inspection_items` VALUES (639, 146, '性能', '性能检查', 'function', 0, '321', NULL, 'passed', NULL, NULL, '2025-05-10 11:31:38', '2025-05-10 11:31:38');
INSERT INTO `quality_inspection_items` VALUES (640, 146, '包装', '包装检查', 'other', 0, '123', NULL, 'passed', NULL, NULL, '2025-05-10 11:31:38', '2025-05-10 11:31:38');
INSERT INTO `quality_inspection_items` VALUES (653, 163, '检验项目列表', '以不同力度和频率踩踏脚踏开关，', 'visual', 1, '123', NULL, 'passed', NULL, NULL, '2025-05-10 19:15:54', '2025-05-10 19:15:54');
INSERT INTO `quality_inspection_items` VALUES (654, 163, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '123', NULL, 'passed', NULL, NULL, '2025-05-10 19:15:54', '2025-05-10 19:15:54');
INSERT INTO `quality_inspection_items` VALUES (655, 163, '防水性能测试', '将脚踏开关置于IPX4等级的喷水环境中', 'function', 1, '123', NULL, 'passed', NULL, NULL, '2025-05-10 19:15:54', '2025-05-10 19:15:54');
INSERT INTO `quality_inspection_items` VALUES (656, 162, '检验项目列表', '以不同力度和频率踩踏脚踏开关，', 'visual', 1, '123123', NULL, 'passed', NULL, NULL, '2025-05-10 19:18:12', '2025-05-10 19:18:12');
INSERT INTO `quality_inspection_items` VALUES (657, 162, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '123', NULL, 'passed', NULL, NULL, '2025-05-10 19:18:12', '2025-05-10 19:18:12');
INSERT INTO `quality_inspection_items` VALUES (658, 162, '防水性能测试', '将脚踏开关置于IPX4等级的喷水环境中', 'function', 1, '123', NULL, 'passed', NULL, NULL, '2025-05-10 19:18:12', '2025-05-10 19:18:12');
INSERT INTO `quality_inspection_items` VALUES (659, 161, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '123', NULL, 'passed', NULL, NULL, '2025-05-10 19:21:38', '2025-05-10 19:21:38');
INSERT INTO `quality_inspection_items` VALUES (660, 161, '检验项目列表', '以不同力度和频率踩踏脚踏开关，', 'visual', 1, '123', NULL, 'passed', NULL, NULL, '2025-05-10 19:21:38', '2025-05-10 19:21:38');
INSERT INTO `quality_inspection_items` VALUES (661, 161, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '123', NULL, 'passed', NULL, NULL, '2025-05-10 19:21:38', '2025-05-10 19:21:38');
INSERT INTO `quality_inspection_items` VALUES (662, 160, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '1', NULL, 'passed', NULL, NULL, '2025-05-10 19:24:55', '2025-05-10 19:24:55');
INSERT INTO `quality_inspection_items` VALUES (663, 160, '检验项目列表', '以不同力度和频率踩踏脚踏开关，', 'visual', 1, '1', NULL, 'passed', NULL, NULL, '2025-05-10 19:24:55', '2025-05-10 19:24:55');
INSERT INTO `quality_inspection_items` VALUES (664, 160, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '1', NULL, 'passed', NULL, NULL, '2025-05-10 19:24:55', '2025-05-10 19:24:55');
INSERT INTO `quality_inspection_items` VALUES (668, 159, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '123123', NULL, 'passed', NULL, NULL, '2025-05-10 19:45:32', '2025-05-10 19:45:32');
INSERT INTO `quality_inspection_items` VALUES (669, 159, '检验项目列表', '以不同力度和频率踩踏脚踏开关，', 'visual', 1, '123', NULL, 'passed', NULL, NULL, '2025-05-10 19:45:32', '2025-05-10 19:45:32');
INSERT INTO `quality_inspection_items` VALUES (670, 159, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '123', NULL, 'passed', NULL, NULL, '2025-05-10 19:45:32', '2025-05-10 19:45:32');
INSERT INTO `quality_inspection_items` VALUES (671, 164, '检验项目列表', '以不同力度和频率踩踏脚踏开关，', 'visual', 1, '123123', NULL, 'passed', NULL, NULL, '2025-05-10 19:56:14', '2025-05-10 19:56:14');
INSERT INTO `quality_inspection_items` VALUES (672, 164, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '1', NULL, 'passed', NULL, NULL, '2025-05-10 19:56:14', '2025-05-10 19:56:14');
INSERT INTO `quality_inspection_items` VALUES (673, 164, '防水性能测试', '将脚踏开关置于IPX4等级的喷水环境中', 'function', 1, '1', NULL, 'passed', NULL, NULL, '2025-05-10 19:56:14', '2025-05-10 19:56:14');
INSERT INTO `quality_inspection_items` VALUES (674, 166, '检验项目列表', '以不同力度和频率踩踏脚踏开关，', 'visual', 1, '1', NULL, 'passed', NULL, NULL, '2025-05-10 20:03:53', '2025-05-10 20:03:53');
INSERT INTO `quality_inspection_items` VALUES (675, 166, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '1', NULL, 'passed', NULL, NULL, '2025-05-10 20:03:53', '2025-05-10 20:03:53');
INSERT INTO `quality_inspection_items` VALUES (676, 166, '防水性能测试', '将脚踏开关置于IPX4等级的喷水环境中', 'function', 1, '1', NULL, 'passed', NULL, NULL, '2025-05-10 20:03:53', '2025-05-10 20:03:53');
INSERT INTO `quality_inspection_items` VALUES (677, 165, '检验项目列表', '以不同力度和频率踩踏脚踏开关，', 'visual', 1, '12', NULL, 'passed', NULL, NULL, '2025-05-10 20:07:51', '2025-05-10 20:07:51');
INSERT INTO `quality_inspection_items` VALUES (678, 165, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '2', NULL, 'passed', NULL, NULL, '2025-05-10 20:07:51', '2025-05-10 20:07:51');
INSERT INTO `quality_inspection_items` VALUES (679, 165, '防水性能测试', '将脚踏开关置于IPX4等级的喷水环境中', 'function', 1, '3', NULL, 'passed', NULL, NULL, '2025-05-10 20:07:51', '2025-05-10 20:07:51');
INSERT INTO `quality_inspection_items` VALUES (680, 167, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '123', NULL, 'passed', NULL, NULL, '2025-05-10 20:34:06', '2025-05-10 20:34:06');
INSERT INTO `quality_inspection_items` VALUES (681, 167, '检验项目列表', '以不同力度和频率踩踏脚踏开关，', 'visual', 1, '321', NULL, 'passed', NULL, NULL, '2025-05-10 20:34:06', '2025-05-10 20:34:06');
INSERT INTO `quality_inspection_items` VALUES (682, 167, '耐久性测试', '在模拟实际使用条件下，', 'dimension', 1, '1', NULL, 'passed', NULL, NULL, '2025-05-10 20:34:06', '2025-05-10 20:34:06');

-- ----------------------------
-- Table structure for quality_inspections
-- ----------------------------
DROP TABLE IF EXISTS `quality_inspections`;
CREATE TABLE `quality_inspections`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `inspection_no` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '检验单号',
  `inspection_type` enum('incoming','process','final') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '检验类型: 来料检验/过程检验/成品检验',
  `reference_id` int NULL DEFAULT NULL COMMENT '关联单号ID(采购单ID/工单ID)',
  `reference_no` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '关联单号',
  `material_id` int NULL DEFAULT NULL COMMENT '物料ID(来料检验)',
  `product_id` int NULL DEFAULT NULL COMMENT '产品ID(过程检验和成品检验)',
  `product_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '产品名称',
  `product_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '产品型号',
  `process_id` int NULL DEFAULT NULL COMMENT '工序ID(过程检验)',
  `batch_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '批次号',
  `quantity` decimal(10, 2) NOT NULL COMMENT '检验数量',
  `unit` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '单位',
  `status` enum('pending','passed','failed','partial','rework','conditional') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'pending' COMMENT '检验状态',
  `planned_date` date NOT NULL COMMENT '计划检验日期',
  `actual_date` date NULL DEFAULT NULL COMMENT '实际检验日期',
  `inspector_id` int NULL DEFAULT NULL COMMENT '检验员ID',
  `inspector_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '检验员姓名',
  `standard_type` enum('factory','customer','industry','national') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '标准类型',
  `standard_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '标准编号',
  `template_id` int NULL DEFAULT NULL COMMENT '检验模板ID',
  `note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `idx_inspection_no`(`inspection_no` ASC) USING BTREE,
  INDEX `idx_reference_id`(`reference_id` ASC) USING BTREE,
  INDEX `idx_material_id`(`material_id` ASC) USING BTREE,
  INDEX `idx_product_id`(`product_id` ASC) USING BTREE,
  INDEX `idx_process_id`(`process_id` ASC) USING BTREE,
  INDEX `idx_status`(`status` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 168 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '质量检验主表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of quality_inspections
-- ----------------------------
INSERT INTO `quality_inspections` VALUES (126, 'FQC20250430001', 'final', 88, 'SCT250429006', NULL, 99, '脚踏开关', 'HRF-M5B', NULL, '批次20250430', 100.00, '个', 'pending', '2025-04-30', '2025-04-30', NULL, '123', NULL, NULL, NULL, '任务SCT250429006完成后自动生成的成品检验单', '2025-04-30 11:26:53', '2025-04-30 15:24:02');
INSERT INTO `quality_inspections` VALUES (127, 'FQC20250430002', 'final', 87, 'SCT250429005', NULL, 99, '脚踏开关', 'HRF-M5B', NULL, '批次20250430', 1.00, '个', 'pending', '2025-04-30', '2025-04-30', NULL, '123', NULL, NULL, NULL, '任务SCT250429005完成后自动生成的成品检验单 (复检)', '2025-04-30 11:28:17', '2025-04-30 15:24:04');
INSERT INTO `quality_inspections` VALUES (129, 'FINAL20250430001', 'final', 88, 'SCT250429006', NULL, 88, '脚踏开关', 'HRF-M5B', NULL, '123', 1000.00, '个', 'pending', '2025-04-30', '2025-04-30', NULL, '123', 'factory', 'SCT250429006-FQC', NULL, '', '2025-04-30 13:11:08', '2025-04-30 15:24:06');
INSERT INTO `quality_inspections` VALUES (130, 'FQC20250430003', 'final', 89, 'SCT250430001', NULL, 99, '脚踏开关', 'HRF-M5B', NULL, '批次20250430', 10.00, '个', 'passed', '2025-04-30', '2025-04-30', NULL, '123', NULL, NULL, NULL, '任务SCT250430001完成后自动生成的成品检验单', '2025-04-30 13:55:34', '2025-04-30 15:32:52');
INSERT INTO `quality_inspections` VALUES (131, 'FQC20250430004', 'final', 86, 'SCT250429004', NULL, 96, '脚踏开关', 'HRF-M5Y', NULL, '批次20250430', 1000.00, '个', 'passed', '2025-04-30', '2025-04-30', NULL, '123', NULL, NULL, NULL, '任务SCT250429004完成后自动生成的成品检验单', '2025-04-30 15:18:11', '2025-04-30 15:24:21');
INSERT INTO `quality_inspections` VALUES (132, 'FQC20250430005', 'final', 85, 'SCT250429003', NULL, 97, '脚踏开关', 'HRF-M1Y', NULL, '批次20250430', 1.00, '个', 'passed', '2025-04-30', '2025-04-30', NULL, '123', NULL, NULL, NULL, '任务SCT250429003完成后自动生成的成品检验单', '2025-04-30 15:18:13', '2025-04-30 15:40:50');
INSERT INTO `quality_inspections` VALUES (133, 'FQC20250430006', 'final', 84, 'SCT250429002', NULL, 96, '脚踏开关', 'HRF-M5Y', NULL, '批次20250430', 1.00, '个', 'pending', '2025-04-30', '2025-04-30', NULL, '123', NULL, NULL, NULL, '任务SCT250429002完成后自动生成的成品检验单', '2025-04-30 15:18:14', '2025-04-30 15:24:11');
INSERT INTO `quality_inspections` VALUES (134, 'FQC20250430007', 'final', 83, 'SCT250429001', NULL, 96, '脚踏开关', 'HRF-M5Y', NULL, '批次20250430', 1.00, '个', 'passed', '2025-04-30', '2025-04-30', NULL, '123', NULL, NULL, NULL, '任务SCT250429001完成后自动生成的成品检验单', '2025-04-30 15:18:16', '2025-04-30 15:28:38');
INSERT INTO `quality_inspections` VALUES (135, 'FQC20250430008', 'final', 90, 'SCT250430002', NULL, 99, '脚踏开关', 'HRF-M5B', NULL, '批次20250430', 4.00, '个', 'passed', '2025-04-30', '2025-04-30', NULL, '123', NULL, NULL, NULL, '任务SCT250430002完成后自动生成的成品检验单', '2025-04-30 15:46:27', '2025-04-30 15:46:45');
INSERT INTO `quality_inspections` VALUES (136, 'FQC20250430009', 'final', 91, 'SCT250430003', NULL, 96, '脚踏开关', 'HRF-M5Y', NULL, '批次20250430', 57.00, '个', 'passed', '2025-04-30', '2025-04-30', NULL, '123', NULL, NULL, NULL, '任务SCT250430003完成后自动生成的成品检验单', '2025-04-30 15:54:40', '2025-04-30 15:54:57');
INSERT INTO `quality_inspections` VALUES (137, 'FQC20250430010', 'final', 92, 'SCT250430004', NULL, 99, '脚踏开关', 'HRF-M5B', NULL, '批次20250430', 2.00, '个', 'pending', '2025-04-30', NULL, NULL, NULL, NULL, NULL, NULL, '任务SCT250430004完成后自动生成的成品检验单', '2025-04-30 16:01:14', '2025-04-30 16:01:14');
INSERT INTO `quality_inspections` VALUES (138, 'FQC20250430011', 'final', 93, 'SCT250430005', NULL, 99, '脚踏开关', 'HRF-M5B', NULL, '批次20250430', 8.00, '个', 'passed', '2025-04-30', '2025-04-30', NULL, '123', NULL, NULL, NULL, '任务SCT250430005完成后自动生成的成品检验单', '2025-04-30 16:10:46', '2025-04-30 16:11:34');
INSERT INTO `quality_inspections` VALUES (139, 'FQC20250430012', 'final', 94, 'SCT250430006', NULL, 96, '脚踏开关', 'HRF-M5Y', NULL, '批次20250430', 3.00, '个', 'passed', '2025-04-30', '2025-04-30', NULL, '123', NULL, NULL, NULL, '任务SCT250430006完成后自动生成的成品检验单', '2025-04-30 16:25:18', '2025-04-30 16:25:34');
INSERT INTO `quality_inspections` VALUES (140, 'FQC20250430013', 'final', 95, 'SCT250430007', NULL, 96, '脚踏开关', 'HRF-M5Y', NULL, '批次20250430', 6.00, '个', 'passed', '2025-04-30', '2025-04-30', NULL, '123', NULL, NULL, NULL, '任务SCT250430007完成后自动生成的成品检验单', '2025-04-30 17:01:13', '2025-04-30 17:01:26');
INSERT INTO `quality_inspections` VALUES (141, 'FQC20250505001', 'final', 96, 'SCT250505001', NULL, 99, '脚踏开关', 'HRF-M5B', NULL, '批次20250505', 1.00, '个', 'passed', '2025-05-05', '2025-05-05', NULL, '测试', NULL, NULL, NULL, '任务SCT250505001完成后自动生成的成品检验单', '2025-05-05 13:59:26', '2025-05-05 13:59:45');
INSERT INTO `quality_inspections` VALUES (142, 'FQC20250505002', 'final', 97, 'SCT250505002', NULL, 99, '脚踏开关', 'HRF-M5B', NULL, '批次20250505', 1.00, '个', 'passed', '2025-05-05', '2025-05-05', NULL, '测试', NULL, NULL, NULL, '任务SCT250505002完成后自动生成的成品检验单', '2025-05-05 14:05:08', '2025-05-05 14:05:31');
INSERT INTO `quality_inspections` VALUES (143, 'FQC20250505003', 'final', 98, 'SCT250505003', NULL, 99, '脚踏开关', 'HRF-M5B', NULL, '批次20250505', 1.00, '个', 'passed', '2025-05-05', '2025-05-05', NULL, '测试', NULL, NULL, NULL, '任务SCT250505003完成后自动生成的成品检验单', '2025-05-05 14:30:00', '2025-05-05 14:30:21');
INSERT INTO `quality_inspections` VALUES (144, 'FQC20250505004', 'final', 99, 'SCT250505004', NULL, 97, '脚踏开关', 'HRF-M1Y', NULL, '批次20250505', 1.00, '个', 'passed', '2025-05-05', '2025-05-05', NULL, '测试', NULL, NULL, NULL, '任务SCT250505004完成后自动生成的成品检验单', '2025-05-05 14:34:52', '2025-05-05 14:35:22');
INSERT INTO `quality_inspections` VALUES (145, 'FQC20250505005', 'final', 100, 'SCT250505005', NULL, 96, '脚踏开关', 'HRF-M5Y', NULL, '批次20250505', 3.00, '个', 'passed', '2025-05-05', '2025-05-05', NULL, '123', NULL, NULL, NULL, '任务SCT250505005完成后自动生成的成品检验单', '2025-05-05 15:10:08', '2025-05-05 15:10:27');
INSERT INTO `quality_inspections` VALUES (146, 'FQC20250510001', 'final', 101, 'SCT250510001', NULL, 99, '脚踏开关', 'HRF-M5B', NULL, '批次20250510', 2.00, '个', 'passed', '2025-05-10', '2025-05-10', NULL, '王晓敏', NULL, NULL, NULL, '任务SCT250510001完成后自动生成的成品检验单', '2025-05-10 11:31:11', '2025-05-10 11:31:38');
INSERT INTO `quality_inspections` VALUES (159, 'WL250510001', 'incoming', 61, 'PO202505100017', 101, 101, '黑色踏板', 'HRF-M5K', NULL, '默认批次号', 2000.00, '个', 'passed', '2025-05-10', '2025-05-10', NULL, '王晓敏', NULL, NULL, NULL, '自动创建的来料检验单 - 供应商: 乐清市朗盛电子科技有限公司', '2025-05-10 17:19:24', '2025-05-10 19:45:05');
INSERT INTO `quality_inspections` VALUES (160, 'WL250510002', 'incoming', 62, 'PO202505100018', 101, 101, '黑色踏板', 'HRF-M5K', NULL, '默认批次号', 2000.00, '个', 'passed', '2025-05-10', '2025-05-10', NULL, '王晓敏', NULL, NULL, NULL, '自动创建的来料检验单 - 供应商: 乐清市朗盛电子科技有限公司', '2025-05-10 17:21:02', '2025-05-10 19:24:54');
INSERT INTO `quality_inspections` VALUES (161, 'WL250510003', 'incoming', 63, 'PO202505100019', 101, 101, '黑色踏板', 'HRF-M5K', NULL, '默认批次号', 2000.00, '个', 'passed', '2025-05-10', '2025-05-10', NULL, '王晓敏', NULL, NULL, NULL, '自动创建的来料检验单 - 供应商: 乐清市朗盛电子科技有限公司', '2025-05-10 18:40:09', '2025-05-10 19:21:38');
INSERT INTO `quality_inspections` VALUES (162, 'WL250510004', 'incoming', 64, 'PO202505100020', 98, 98, '蓝色踏板', 'HRF-M5B', NULL, '默认批次号', 2000.00, '个', 'passed', '2025-05-10', '2025-05-10', NULL, '王晓敏', NULL, NULL, NULL, '自动创建的来料检验单 - 供应商: 乐清市朗盛电子科技有限公司', '2025-05-10 19:02:23', '2025-05-10 19:18:12');
INSERT INTO `quality_inspections` VALUES (163, 'WL250510005', 'incoming', 65, 'PO202505100021', 98, 98, '蓝色踏板', 'HRF-M5B', NULL, '默认批次号', 2000.00, '个', 'passed', '2025-05-10', '2025-05-10', NULL, '王晓敏', NULL, NULL, NULL, '自动创建的来料检验单 - 供应商: 乐清市朗盛电子科技有限公司', '2025-05-10 19:09:49', '2025-05-10 19:15:54');
INSERT INTO `quality_inspections` VALUES (164, 'WL250510006', 'incoming', 66, 'PO202505100022', 98, 98, '蓝色踏板', 'HRF-M5B', NULL, '默认批次号', 2000.00, '个', 'passed', '2025-05-10', '2025-05-10', NULL, '王晓敏', NULL, NULL, NULL, '自动创建的来料检验单 - 供应商: 乐清市朗盛电子科技有限公司', '2025-05-10 19:55:23', '2025-05-10 19:56:14');
INSERT INTO `quality_inspections` VALUES (165, 'WL250510007', 'incoming', 68, 'PO202505100024', 98, 98, '蓝色踏板', 'HRF-M5B', NULL, '默认批次号', 2000.00, '个', 'passed', '2025-05-10', '2025-05-10', NULL, '王晓敏', NULL, NULL, NULL, '自动创建的来料检验单 - 供应商: 乐清市通达有线电厂', '2025-05-10 20:00:55', '2025-05-10 20:07:51');
INSERT INTO `quality_inspections` VALUES (166, 'WL250510008', 'incoming', 67, 'PO202505100023', 98, 98, '蓝色踏板', 'HRF-M5B', NULL, '默认批次号', 2000.00, '个', 'passed', '2025-05-10', '2025-05-10', NULL, '王晓敏', NULL, NULL, NULL, '自动创建的来料检验单 - 供应商: 乐清市通达有线电厂', '2025-05-10 20:00:59', '2025-05-10 20:03:53');
INSERT INTO `quality_inspections` VALUES (167, 'WL250510009', 'incoming', 69, 'PO202505100025', 101, 101, '黑色踏板', 'HRF-M5K', NULL, '默认批次号', 2000.00, '个', 'passed', '2025-05-10', '2025-05-10', NULL, '王晓敏', NULL, NULL, NULL, '自动创建的来料检验单 - 供应商: 乐清市朗盛电子科技有限公司', '2025-05-10 20:33:38', '2025-05-10 20:34:06');

-- ----------------------------
-- Table structure for quality_standard_items
-- ----------------------------
DROP TABLE IF EXISTS `quality_standard_items`;
CREATE TABLE `quality_standard_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `standard_id` int NOT NULL COMMENT '标准ID',
  `item_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '检验项目名称',
  `item_standard` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '项目标准',
  `method` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '检验方法',
  `is_required` tinyint(1) NOT NULL DEFAULT 1 COMMENT '是否必检项',
  `sequence` int NOT NULL COMMENT '序号',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `standard_id`(`standard_id` ASC) USING BTREE,
  CONSTRAINT `quality_standard_items_ibfk_1` FOREIGN KEY (`standard_id`) REFERENCES `quality_standards` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '质量检验标准项表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of quality_standard_items
-- ----------------------------

-- ----------------------------
-- Table structure for quality_standards
-- ----------------------------
DROP TABLE IF EXISTS `quality_standards`;
CREATE TABLE `quality_standards`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `standard_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '标准编号',
  `standard_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '标准名称',
  `standard_type` enum('factory','customer','industry','national') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '标准类型',
  `target_type` enum('material','product','process') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '适用对象类型',
  `target_id` int NOT NULL COMMENT '适用对象ID',
  `version` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '版本号',
  `is_active` tinyint(1) NOT NULL DEFAULT 1 COMMENT '是否激活',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '描述',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `idx_standard_no`(`standard_no` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '质量检验标准表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of quality_standards
-- ----------------------------

-- ----------------------------
-- Table structure for reconciliation_items
-- ----------------------------
DROP TABLE IF EXISTS `reconciliation_items`;
CREATE TABLE `reconciliation_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `reconciliation_id` int NOT NULL,
  `transaction_id` int NOT NULL,
  `notes` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `reconciliation_id`(`reconciliation_id` ASC) USING BTREE,
  INDEX `transaction_id`(`transaction_id` ASC) USING BTREE,
  CONSTRAINT `reconciliation_items_ibfk_1` FOREIGN KEY (`reconciliation_id`) REFERENCES `reconciliations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reconciliation_items_ibfk_2` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of reconciliation_items
-- ----------------------------

-- ----------------------------
-- Table structure for reconciliations
-- ----------------------------
DROP TABLE IF EXISTS `reconciliations`;
CREATE TABLE `reconciliations`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_id` int NOT NULL,
  `reconciliation_date` date NOT NULL,
  `bank_statement_balance` decimal(15, 2) NOT NULL,
  `book_balance` decimal(15, 2) NOT NULL,
  `difference` decimal(15, 2) NOT NULL DEFAULT 0.00,
  `status` enum('draft','completed') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'draft',
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `attachment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '对账单附件文件路径',
  `created_by` int NOT NULL,
  `updated_by` int NULL DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `account_id`(`account_id` ASC) USING BTREE,
  CONSTRAINT `reconciliations_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `bank_accounts` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of reconciliations
-- ----------------------------

-- ----------------------------
-- Table structure for role_menus
-- ----------------------------
DROP TABLE IF EXISTS `role_menus`;
CREATE TABLE `role_menus`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `role_id` int NOT NULL,
  `menu_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `unique_role_menu`(`role_id` ASC, `menu_id` ASC) USING BTREE,
  INDEX `role_id`(`role_id` ASC) USING BTREE,
  INDEX `menu_id`(`menu_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 26 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of role_menus
-- ----------------------------
INSERT INTO `role_menus` VALUES (10, 5, 5, '2025-04-19 18:26:48');
INSERT INTO `role_menus` VALUES (11, 1, 1, '2025-04-19 18:27:06');
INSERT INTO `role_menus` VALUES (12, 1, 2, '2025-04-19 18:27:06');
INSERT INTO `role_menus` VALUES (13, 1, 3, '2025-04-19 18:27:06');
INSERT INTO `role_menus` VALUES (14, 1, 4, '2025-04-19 18:27:06');
INSERT INTO `role_menus` VALUES (15, 1, 5, '2025-04-19 18:27:06');
INSERT INTO `role_menus` VALUES (16, 1, 6, '2025-04-19 18:27:06');
INSERT INTO `role_menus` VALUES (17, 1, 7, '2025-04-19 18:27:06');
INSERT INTO `role_menus` VALUES (18, 1, 8, '2025-04-19 18:27:06');
INSERT INTO `role_menus` VALUES (19, 1, 9, '2025-04-19 18:27:06');
INSERT INTO `role_menus` VALUES (23, 6, 6, '2025-04-20 12:59:57');
INSERT INTO `role_menus` VALUES (24, 6, 7, '2025-04-20 12:59:57');
INSERT INTO `role_menus` VALUES (25, 6, 8, '2025-04-20 12:59:57');

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `description` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `status`(`status` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of roles
-- ----------------------------
INSERT INTO `roles` VALUES (1, '管理员', 'admin', '系统管理员，拥有所有权限', 1, '2025-04-14 19:26:03', '2025-04-14 19:26:03');
INSERT INTO `roles` VALUES (2, '普通用户', 'user', '普通用户，拥有基本权限', 1, '2025-04-14 19:26:03', '2025-04-14 19:26:03');
INSERT INTO `roles` VALUES (5, '采购部门', 'purchase', '负责公司所需原材料、设备、服务等物资的采购，', 1, '2025-04-19 09:38:21', '2025-04-19 10:09:21');
INSERT INTO `roles` VALUES (6, '测试', 'test', '', 1, '2025-04-19 17:07:37', '2025-04-19 17:07:37');

-- ----------------------------
-- Table structure for sales_exchange_items
-- ----------------------------
DROP TABLE IF EXISTS `sales_exchange_items`;
CREATE TABLE `sales_exchange_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `exchange_id` int NOT NULL,
  `old_product_id` int NOT NULL,
  `new_product_id` int NOT NULL,
  `quantity` int NOT NULL,
  `reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `exchange_id`(`exchange_id` ASC) USING BTREE,
  INDEX `old_product_id`(`old_product_id` ASC) USING BTREE,
  INDEX `new_product_id`(`new_product_id` ASC) USING BTREE,
  CONSTRAINT `sales_exchange_items_ibfk_1` FOREIGN KEY (`exchange_id`) REFERENCES `sales_exchanges` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `sales_exchange_items_ibfk_2` FOREIGN KEY (`old_product_id`) REFERENCES `inventory` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `sales_exchange_items_ibfk_3` FOREIGN KEY (`new_product_id`) REFERENCES `inventory` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sales_exchange_items
-- ----------------------------

-- ----------------------------
-- Table structure for sales_exchanges
-- ----------------------------
DROP TABLE IF EXISTS `sales_exchanges`;
CREATE TABLE `sales_exchanges`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `exchange_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `order_id` int NOT NULL,
  `exchange_date` date NOT NULL,
  `exchange_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `status` enum('draft','pending','approved','completed','rejected') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'draft',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `exchange_no`(`exchange_no` ASC) USING BTREE,
  INDEX `order_id`(`order_id` ASC) USING BTREE,
  INDEX `created_by`(`created_by` ASC) USING BTREE,
  CONSTRAINT `sales_exchanges_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `sales_orders` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `sales_exchanges_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sales_exchanges
-- ----------------------------

-- ----------------------------
-- Table structure for sales_order_items
-- ----------------------------
DROP TABLE IF EXISTS `sales_order_items`;
CREATE TABLE `sales_order_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `material_id` int NOT NULL,
  `quantity` int NOT NULL,
  `unit_price` decimal(10, 2) NOT NULL,
  `amount` decimal(10, 2) NOT NULL,
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `order_id`(`order_id` ASC) USING BTREE,
  INDEX `material_id`(`material_id` ASC) USING BTREE,
  CONSTRAINT `sales_order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `sales_orders` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `sales_order_items_ibfk_2` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 132 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sales_order_items
-- ----------------------------
INSERT INTO `sales_order_items` VALUES (103, 94, 97, 100, 30.00, 3000.00, NULL);
INSERT INTO `sales_order_items` VALUES (104, 95, 96, 100, 60.00, 6000.00, NULL);
INSERT INTO `sales_order_items` VALUES (105, 96, 99, 1000, 60.00, 60000.00, NULL);
INSERT INTO `sales_order_items` VALUES (106, 97, 99, 100, 60.00, 6000.00, NULL);
INSERT INTO `sales_order_items` VALUES (107, 98, 96, 1000, 60.00, 60000.00, NULL);
INSERT INTO `sales_order_items` VALUES (108, 99, 99, 1, 60.00, 60.00, NULL);
INSERT INTO `sales_order_items` VALUES (109, 100, 99, 10, 60.00, 600.00, NULL);
INSERT INTO `sales_order_items` VALUES (110, 101, 96, 58, 60.00, 3480.00, NULL);
INSERT INTO `sales_order_items` VALUES (111, 102, 99, 1, 60.00, 60.00, NULL);
INSERT INTO `sales_order_items` VALUES (112, 103, 96, 20, 60.00, 1200.00, NULL);
INSERT INTO `sales_order_items` VALUES (113, 104, 96, 70, 60.00, 4200.00, NULL);
INSERT INTO `sales_order_items` VALUES (114, 105, 99, 2, 60.00, 120.00, NULL);
INSERT INTO `sales_order_items` VALUES (115, 105, 97, 1, 30.00, 30.00, NULL);
INSERT INTO `sales_order_items` VALUES (116, 105, 96, 4, 60.00, 240.00, NULL);
INSERT INTO `sales_order_items` VALUES (117, 106, 99, 1, 60.00, 60.00, NULL);
INSERT INTO `sales_order_items` VALUES (118, 107, 99, 25, 60.00, 1500.00, NULL);
INSERT INTO `sales_order_items` VALUES (119, 107, 97, 20, 30.00, 600.00, NULL);
INSERT INTO `sales_order_items` VALUES (120, 107, 96, 10, 60.00, 600.00, NULL);
INSERT INTO `sales_order_items` VALUES (121, 108, 99, 2, 60.00, 120.00, NULL);
INSERT INTO `sales_order_items` VALUES (122, 109, 99, 20, 60.00, 1200.00, NULL);
INSERT INTO `sales_order_items` VALUES (123, 109, 97, 10, 30.00, 300.00, NULL);
INSERT INTO `sales_order_items` VALUES (124, 109, 96, 7, 60.00, 420.00, NULL);
INSERT INTO `sales_order_items` VALUES (125, 110, 98, 20, 2.00, 40.00, NULL);
INSERT INTO `sales_order_items` VALUES (126, 111, 99, 1, 60.00, 60.00, NULL);
INSERT INTO `sales_order_items` VALUES (127, 111, 97, 1, 30.00, 30.00, NULL);
INSERT INTO `sales_order_items` VALUES (128, 111, 96, 1, 60.00, 60.00, NULL);
INSERT INTO `sales_order_items` VALUES (129, 112, 99, 135, 60.00, 8100.00, NULL);
INSERT INTO `sales_order_items` VALUES (130, 113, 99, 2000, 60.00, 120000.00, NULL);
INSERT INTO `sales_order_items` VALUES (131, 114, 99, 2000, 60.00, 120000.00, NULL);

-- ----------------------------
-- Table structure for sales_orders
-- ----------------------------
DROP TABLE IF EXISTS `sales_orders`;
CREATE TABLE `sales_orders`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `customer_id` int NOT NULL,
  `quotation_id` int NULL DEFAULT NULL,
  `total_amount` decimal(15, 2) NOT NULL,
  `payment_terms` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `delivery_date` date NULL DEFAULT NULL,
  `status` enum('draft','pending','confirmed','processing','in_production','ready_to_ship','shipped','delivered','completed','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'draft',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `order_no`(`order_no` ASC) USING BTREE,
  INDEX `customer_id`(`customer_id` ASC) USING BTREE,
  INDEX `quotation_id`(`quotation_id` ASC) USING BTREE,
  INDEX `created_by`(`created_by` ASC) USING BTREE,
  CONSTRAINT `sales_orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `sales_orders_ibfk_2` FOREIGN KEY (`quotation_id`) REFERENCES `sales_quotations` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `sales_orders_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 115 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sales_orders
-- ----------------------------
INSERT INTO `sales_orders` VALUES (94, 'DD250428001', 5, NULL, 3000.00, '', '2025-04-27', 'shipped', '', 1, '2025-04-28 13:11:26', '2025-05-06 15:06:41');
INSERT INTO `sales_orders` VALUES (95, 'DD250428002', 6, NULL, 6000.00, '', '2025-04-27', 'shipped', '', 1, '2025-04-28 13:37:17', '2025-05-06 15:08:40');
INSERT INTO `sales_orders` VALUES (96, 'DD250428003', 7, NULL, 60000.00, '', '2025-04-27', 'cancelled', '', 1, '2025-04-28 13:38:32', '2025-04-28 14:31:55');
INSERT INTO `sales_orders` VALUES (97, 'DD250428004', 6, NULL, 6000.00, '', '2025-04-27', 'shipped', '', 1, '2025-04-28 14:32:13', '2025-05-06 16:21:09');
INSERT INTO `sales_orders` VALUES (98, 'DD250428005', 5, NULL, 60000.00, '', '2025-04-27', 'shipped', '', 1, '2025-04-28 14:49:31', '2025-05-06 15:14:31');
INSERT INTO `sales_orders` VALUES (99, 'DD250428006', 7, NULL, 60.00, '', '2025-04-27', 'ready_to_ship', '', 1, '2025-04-28 16:08:34', '2025-05-05 15:10:34');
INSERT INTO `sales_orders` VALUES (100, 'DD250430001', 7, NULL, 600.00, '', '2025-04-30', 'ready_to_ship', '', 1, '2025-04-30 13:54:10', '2025-05-05 15:10:34');
INSERT INTO `sales_orders` VALUES (101, 'DD250430002', 7, NULL, 3480.00, '', '2025-04-29', 'cancelled', '', 1, '2025-04-30 15:53:53', '2025-05-05 15:01:10');
INSERT INTO `sales_orders` VALUES (102, 'DD250505001', 6, NULL, 60.00, '', '2025-05-04', 'ready_to_ship', '', 1, '2025-05-05 15:01:29', '2025-05-05 15:01:29');
INSERT INTO `sales_orders` VALUES (103, 'DD250505002', 5, NULL, 1200.00, '', '2025-05-05', 'shipped', '', 1, '2025-05-05 15:08:43', '2025-05-06 15:09:53');
INSERT INTO `sales_orders` VALUES (104, 'DD250505003', 5, NULL, 4200.00, '', '2025-05-05', 'shipped', '', 1, '2025-05-05 15:09:04', '2025-05-06 16:02:46');
INSERT INTO `sales_orders` VALUES (105, 'DD250506001', 7, NULL, 390.00, '', '2025-05-05', 'shipped', '', 1, '2025-05-06 14:38:17', '2025-05-06 14:42:14');
INSERT INTO `sales_orders` VALUES (106, 'DD250506002', 7, NULL, 60.00, '', '2025-05-06', 'shipped', '', 1, '2025-05-06 14:51:33', '2025-05-06 14:59:42');
INSERT INTO `sales_orders` VALUES (107, 'DD250506003', 5, NULL, 2700.00, '', '2025-05-06', 'shipped', '', 1, '2025-05-06 16:24:22', '2025-05-08 14:00:37');
INSERT INTO `sales_orders` VALUES (108, 'DD250506004', 7, NULL, 120.00, '', '2025-05-06', 'shipped', '', 1, '2025-05-06 16:25:53', '2025-05-08 14:06:49');
INSERT INTO `sales_orders` VALUES (109, 'DD250506005', 7, NULL, 1920.00, '', '2025-05-06', 'shipped', '', 1, '2025-05-06 16:26:25', '2025-05-06 16:26:38');
INSERT INTO `sales_orders` VALUES (110, 'DD250507001', 7, NULL, 40.00, '', '2025-05-07', 'shipped', '', 1, '2025-05-07 14:05:53', '2025-05-07 15:06:35');
INSERT INTO `sales_orders` VALUES (111, 'DD250508001', 5, NULL, 150.00, '', '2025-05-23', 'shipped', '', 1, '2025-05-08 08:48:19', '2025-05-08 08:49:04');
INSERT INTO `sales_orders` VALUES (112, 'DD250508002', 5, NULL, 8100.00, '', '2025-05-08', 'shipped', '', 1, '2025-05-08 14:53:36', '2025-05-08 14:53:52');
INSERT INTO `sales_orders` VALUES (113, 'DD250509001', 5, NULL, 120000.00, '', '2025-05-22', 'ready_to_ship', '', 1, '2025-05-09 10:03:53', '2025-05-10 12:43:29');
INSERT INTO `sales_orders` VALUES (114, 'DD250509002', 5, NULL, 120000.00, '', '2025-05-22', 'ready_to_ship', '', 1, '2025-05-09 10:04:28', '2025-05-10 12:43:21');

-- ----------------------------
-- Table structure for sales_outbound
-- ----------------------------
DROP TABLE IF EXISTS `sales_outbound`;
CREATE TABLE `sales_outbound`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `outbound_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `order_id` int NOT NULL,
  `delivery_date` date NOT NULL,
  `status` enum('draft','processing','completed','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'draft',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `outbound_no`(`outbound_no` ASC) USING BTREE,
  INDEX `order_id`(`order_id` ASC) USING BTREE,
  INDEX `created_by`(`created_by` ASC) USING BTREE,
  CONSTRAINT `sales_outbound_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `sales_orders` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `sales_outbound_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 73 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sales_outbound
-- ----------------------------
INSERT INTO `sales_outbound` VALUES (50, 'SO250506001', 94, '2025-05-04', 'completed', '', 1, '2025-05-06 15:52:24', '2025-05-06 15:52:29');
INSERT INTO `sales_outbound` VALUES (51, 'SO250506002', 94, '2025-05-05', 'processing', '', 1, '2025-05-06 16:02:22', '2025-05-06 16:02:24');
INSERT INTO `sales_outbound` VALUES (52, 'SO250506003', 104, '2025-05-04', 'completed', '', 1, '2025-05-06 16:02:41', '2025-05-06 16:02:46');
INSERT INTO `sales_outbound` VALUES (53, 'SO250506004', 98, '2025-05-04', 'completed', '', 1, '2025-05-06 16:06:51', '2025-05-06 16:17:23');
INSERT INTO `sales_outbound` VALUES (54, 'SO250506005', 104, '2025-05-04', 'completed', '', 1, '2025-05-06 16:19:20', '2025-05-06 16:19:25');
INSERT INTO `sales_outbound` VALUES (55, 'SO250506006', 97, '2025-05-04', 'completed', '', 1, '2025-05-06 16:21:04', '2025-05-06 16:21:09');
INSERT INTO `sales_outbound` VALUES (56, 'SO250506007', 109, '2025-05-04', 'completed', '', 1, '2025-05-06 16:26:33', '2025-05-06 16:26:37');
INSERT INTO `sales_outbound` VALUES (57, 'SO250507001', 94, '2025-05-05', 'completed', '', 1, '2025-05-07 13:45:17', '2025-05-07 13:45:22');
INSERT INTO `sales_outbound` VALUES (58, 'SO250507002', 110, '2025-05-05', 'completed', '', 1, '2025-05-07 14:06:04', '2025-05-07 15:06:46');
INSERT INTO `sales_outbound` VALUES (59, 'SO250507003', 94, '2025-05-05', 'cancelled', '', 1, '2025-05-07 14:42:34', '2025-05-07 16:50:25');
INSERT INTO `sales_outbound` VALUES (60, 'SO250507004', 110, '2025-05-05', 'completed', '', 1, '2025-05-07 14:42:52', '2025-05-07 15:06:35');
INSERT INTO `sales_outbound` VALUES (61, 'SO250507005', 110, '2025-05-05', 'completed', '', 1, '2025-05-07 15:21:35', '2025-05-07 15:21:40');
INSERT INTO `sales_outbound` VALUES (62, 'SO250507006', 110, '2025-05-05', 'completed', '', 1, '2025-05-07 15:51:48', '2025-05-07 15:55:06');
INSERT INTO `sales_outbound` VALUES (63, 'SO250507007', 110, '2025-05-05', 'completed', '', 1, '2025-05-07 15:55:39', '2025-05-07 15:55:51');
INSERT INTO `sales_outbound` VALUES (64, 'SO250507008', 110, '2025-05-05', 'completed', '', 1, '2025-05-07 16:02:49', '2025-05-07 16:02:53');
INSERT INTO `sales_outbound` VALUES (65, 'SO250507009', 110, '2025-05-05', 'completed', '', 1, '2025-05-07 16:46:50', '2025-05-07 16:46:55');
INSERT INTO `sales_outbound` VALUES (67, 'SO250507010', 110, '2025-05-05', 'completed', '', 1, '2025-05-07 16:56:13', '2025-05-08 08:28:18');
INSERT INTO `sales_outbound` VALUES (68, 'SO250508001', 111, '2025-05-06', 'completed', '', 1, '2025-05-08 08:48:55', '2025-05-08 08:49:04');
INSERT INTO `sales_outbound` VALUES (69, 'SO250508002', 107, '2025-05-06', 'completed', '', 1, '2025-05-08 08:49:27', '2025-05-08 14:00:37');
INSERT INTO `sales_outbound` VALUES (70, 'SO250508003', 108, '2025-05-06', 'completed', '', 1, '2025-05-08 14:06:43', '2025-05-08 14:06:49');
INSERT INTO `sales_outbound` VALUES (71, 'SO250508004', 112, '2025-05-06', 'completed', '', 1, '2025-05-08 14:53:46', '2025-05-08 14:53:52');
INSERT INTO `sales_outbound` VALUES (72, 'SO250510001', 113, '2025-05-09', 'processing', '', 1, '2025-05-10 21:35:35', '2025-05-10 21:35:40');

-- ----------------------------
-- Table structure for sales_outbound_items
-- ----------------------------
DROP TABLE IF EXISTS `sales_outbound_items`;
CREATE TABLE `sales_outbound_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `outbound_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `outbound_id`(`outbound_id` ASC) USING BTREE,
  INDEX `product_id`(`product_id` ASC) USING BTREE,
  CONSTRAINT `sales_outbound_items_ibfk_1` FOREIGN KEY (`outbound_id`) REFERENCES `sales_outbound` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `sales_outbound_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `inventory` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 73 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sales_outbound_items
-- ----------------------------
INSERT INTO `sales_outbound_items` VALUES (44, 50, 97, 100);
INSERT INTO `sales_outbound_items` VALUES (45, 51, 97, 3);
INSERT INTO `sales_outbound_items` VALUES (46, 52, 96, 1);
INSERT INTO `sales_outbound_items` VALUES (47, 53, 96, 3);
INSERT INTO `sales_outbound_items` VALUES (48, 54, 96, 5);
INSERT INTO `sales_outbound_items` VALUES (49, 55, 99, 100);
INSERT INTO `sales_outbound_items` VALUES (50, 56, 99, 20);
INSERT INTO `sales_outbound_items` VALUES (51, 56, 97, 10);
INSERT INTO `sales_outbound_items` VALUES (52, 56, 96, 7);
INSERT INTO `sales_outbound_items` VALUES (53, 57, 97, 50);
INSERT INTO `sales_outbound_items` VALUES (54, 58, 98, 20);
INSERT INTO `sales_outbound_items` VALUES (55, 59, 97, 100);
INSERT INTO `sales_outbound_items` VALUES (56, 60, 98, 2);
INSERT INTO `sales_outbound_items` VALUES (57, 61, 98, 20);
INSERT INTO `sales_outbound_items` VALUES (58, 62, 98, 20);
INSERT INTO `sales_outbound_items` VALUES (59, 63, 98, 17);
INSERT INTO `sales_outbound_items` VALUES (60, 64, 98, 20);
INSERT INTO `sales_outbound_items` VALUES (61, 65, 98, 23);
INSERT INTO `sales_outbound_items` VALUES (63, 67, 98, 20);
INSERT INTO `sales_outbound_items` VALUES (64, 68, 99, 1);
INSERT INTO `sales_outbound_items` VALUES (65, 68, 97, 1);
INSERT INTO `sales_outbound_items` VALUES (66, 68, 96, 1);
INSERT INTO `sales_outbound_items` VALUES (67, 69, 99, 25);
INSERT INTO `sales_outbound_items` VALUES (68, 69, 97, 20);
INSERT INTO `sales_outbound_items` VALUES (69, 69, 96, 10);
INSERT INTO `sales_outbound_items` VALUES (70, 70, 99, 2);
INSERT INTO `sales_outbound_items` VALUES (71, 71, 99, 135);
INSERT INTO `sales_outbound_items` VALUES (72, 72, 99, 2000);

-- ----------------------------
-- Table structure for sales_quotation_items
-- ----------------------------
DROP TABLE IF EXISTS `sales_quotation_items`;
CREATE TABLE `sales_quotation_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `quotation_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL,
  `unit_price` decimal(15, 2) NOT NULL,
  `discount_percent` decimal(5, 2) NULL DEFAULT 0.00,
  `tax_percent` decimal(5, 2) NULL DEFAULT 0.00,
  `total_price` decimal(15, 2) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `quotation_id`(`quotation_id` ASC) USING BTREE,
  INDEX `product_id`(`product_id` ASC) USING BTREE,
  CONSTRAINT `sales_quotation_items_ibfk_1` FOREIGN KEY (`quotation_id`) REFERENCES `sales_quotations` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `sales_quotation_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `inventory` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sales_quotation_items
-- ----------------------------

-- ----------------------------
-- Table structure for sales_quotations
-- ----------------------------
DROP TABLE IF EXISTS `sales_quotations`;
CREATE TABLE `sales_quotations`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `quotation_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `customer_id` int NOT NULL,
  `total_amount` decimal(15, 2) NOT NULL,
  `validity_date` date NOT NULL,
  `status` enum('draft','sent','accepted','rejected','expired') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'draft',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `quotation_no`(`quotation_no` ASC) USING BTREE,
  INDEX `customer_id`(`customer_id` ASC) USING BTREE,
  INDEX `created_by`(`created_by` ASC) USING BTREE,
  CONSTRAINT `sales_quotations_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sales_quotations
-- ----------------------------

-- ----------------------------
-- Table structure for sales_return_items
-- ----------------------------
DROP TABLE IF EXISTS `sales_return_items`;
CREATE TABLE `sales_return_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `return_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL,
  `reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `return_id`(`return_id` ASC) USING BTREE,
  INDEX `product_id`(`product_id` ASC) USING BTREE,
  CONSTRAINT `sales_return_items_ibfk_1` FOREIGN KEY (`return_id`) REFERENCES `sales_returns` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `sales_return_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `inventory` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sales_return_items
-- ----------------------------

-- ----------------------------
-- Table structure for sales_returns
-- ----------------------------
DROP TABLE IF EXISTS `sales_returns`;
CREATE TABLE `sales_returns`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `return_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `order_id` int NOT NULL,
  `return_date` date NOT NULL,
  `return_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `status` enum('draft','pending','approved','completed','rejected') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'draft',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `return_no`(`return_no` ASC) USING BTREE,
  INDEX `order_id`(`order_id` ASC) USING BTREE,
  INDEX `created_by`(`created_by` ASC) USING BTREE,
  CONSTRAINT `sales_returns_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `sales_orders` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `sales_returns_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sales_returns
-- ----------------------------

-- ----------------------------
-- Table structure for stock_movements
-- ----------------------------
DROP TABLE IF EXISTS `stock_movements`;
CREATE TABLE `stock_movements`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `material_id` int NOT NULL,
  `movement_type` enum('inbound','outbound','transfer','adjustment') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `quantity` decimal(10, 2) NOT NULL,
  `reference_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `reference_id` int NOT NULL,
  `remarks` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `material_id`(`material_id` ASC) USING BTREE,
  INDEX `created_by`(`created_by` ASC) USING BTREE,
  CONSTRAINT `stock_movements_ibfk_1` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `stock_movements_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of stock_movements
-- ----------------------------

-- ----------------------------
-- Table structure for suppliers
-- ----------------------------
DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE `suppliers`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '供应商编码',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '供应商名称',
  `contact_person` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '联系人',
  `contact_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '联系电话',
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '电子邮箱',
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '地址',
  `status` tinyint NULL DEFAULT 1 COMMENT '状态：0-禁用 1-启用',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_code`(`code` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '供应商表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of suppliers
-- ----------------------------
INSERT INTO `suppliers` VALUES (10, '1', '广德县兰柯电子科技有限公司', '张三', '13888888888', '', '', 1, '', '2025-03-26 09:19:52', '2025-03-26 09:19:52');
INSERT INTO `suppliers` VALUES (11, '2', '乐清市通达有线电厂', '李四', '13888888888', '', '', 1, '', '2025-03-26 09:20:12', '2025-03-26 09:20:12');
INSERT INTO `suppliers` VALUES (12, '4', '常州市瑞发电子有限公司', '王五', '13888888888', '', '', 1, '', '2025-03-26 09:20:29', '2025-03-26 10:00:44');
INSERT INTO `suppliers` VALUES (13, '3', '乐清市朗盛电子科技有限公司', '老六', '13888888888', '', '', 1, '', '2025-03-26 10:01:27', '2025-04-01 13:50:54');

-- ----------------------------
-- Table structure for tax_types
-- ----------------------------
DROP TABLE IF EXISTS `tax_types`;
CREATE TABLE `tax_types`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `tax_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '税种代码',
  `tax_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '税种名称',
  `tax_rate` decimal(5, 2) NOT NULL COMMENT '税率(%)',
  `tax_category` enum('增值税','消费税','企业所得税','个人所得税','其他') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '税种类别',
  `account_id` int NULL DEFAULT NULL COMMENT '会计科目ID',
  `is_active` tinyint(1) NULL DEFAULT 1 COMMENT '是否活跃',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '描述',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `tax_code`(`tax_code` ASC) USING BTREE,
  INDEX `tax_category`(`tax_category` ASC) USING BTREE,
  INDEX `is_active`(`is_active` ASC) USING BTREE,
  INDEX `account_id`(`account_id` ASC) USING BTREE,
  CONSTRAINT `tax_types_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `gl_accounts` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '税种表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tax_types
-- ----------------------------

-- ----------------------------
-- Table structure for template_item_mappings
-- ----------------------------
DROP TABLE IF EXISTS `template_item_mappings`;
CREATE TABLE `template_item_mappings`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `template_id` bigint NOT NULL COMMENT '模板ID',
  `item_id` bigint NOT NULL COMMENT '项目ID',
  `sort_order` int NOT NULL DEFAULT 0 COMMENT '排序顺序',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_template_item`(`template_id` ASC, `item_id` ASC) USING BTREE,
  INDEX `item_id`(`item_id` ASC) USING BTREE,
  CONSTRAINT `template_item_mappings_ibfk_1` FOREIGN KEY (`template_id`) REFERENCES `inspection_templates` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `template_item_mappings_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `inspection_items` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 70 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '模板-项目关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of template_item_mappings
-- ----------------------------
INSERT INTO `template_item_mappings` VALUES (51, 12, 51, 0, '2025-04-29 15:53:33');
INSERT INTO `template_item_mappings` VALUES (52, 12, 52, 1, '2025-04-29 15:53:33');
INSERT INTO `template_item_mappings` VALUES (53, 12, 53, 2, '2025-04-29 15:53:33');
INSERT INTO `template_item_mappings` VALUES (60, 13, 60, 0, '2025-04-29 16:28:05');
INSERT INTO `template_item_mappings` VALUES (61, 13, 61, 1, '2025-04-29 16:28:05');
INSERT INTO `template_item_mappings` VALUES (62, 13, 62, 2, '2025-04-29 16:28:05');
INSERT INTO `template_item_mappings` VALUES (64, 15, 40, 0, '2025-05-10 15:26:52');
INSERT INTO `template_item_mappings` VALUES (65, 15, 52, 1, '2025-05-10 15:26:52');
INSERT INTO `template_item_mappings` VALUES (66, 15, 51, 2, '2025-05-10 15:26:52');
INSERT INTO `template_item_mappings` VALUES (67, 16, 53, 0, '2025-05-10 18:48:25');
INSERT INTO `template_item_mappings` VALUES (68, 16, 45, 1, '2025-05-10 18:48:25');
INSERT INTO `template_item_mappings` VALUES (69, 16, 46, 2, '2025-05-10 18:48:25');

-- ----------------------------
-- Table structure for todos
-- ----------------------------
DROP TABLE IF EXISTS `todos`;
CREATE TABLE `todos`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `deadline` datetime NULL DEFAULT NULL,
  `priority` int NOT NULL DEFAULT 2,
  `completed` tinyint(1) NOT NULL DEFAULT 0,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tags` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `todos_user_id_index`(`userId` ASC) USING BTREE,
  CONSTRAINT `todos_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 35 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of todos
-- ----------------------------
INSERT INTO `todos` VALUES (2, 1, '参加团队会议', '讨论新功能开发计划', '2025-04-19 22:05:42', 2, 1, '2025-04-19 22:05:42', '2025-04-21 02:38:18', NULL);
INSERT INTO `todos` VALUES (3, 1, '整理工作文档', '整理并归档本月工作文档', '2025-04-26 22:05:42', 1, 0, '2025-04-19 22:05:42', '2025-04-19 22:05:42', NULL);
INSERT INTO `todos` VALUES (4, 1, '回复客户邮件', '回复客户关于产品升级的邮件', '2025-04-18 22:05:42', 3, 1, '2025-04-19 22:05:42', '2025-04-19 22:05:42', NULL);
INSERT INTO `todos` VALUES (5, 1, '修复系统bug', '修复用户反馈的登录问题', '2025-04-19 22:05:42', 2, 0, '2025-04-19 22:05:42', '2025-04-19 22:05:42', NULL);
INSERT INTO `todos` VALUES (6, 1, '准备周会演示', '准备下周一产品进度演示文稿', '2025-04-20 22:37:16', 3, 0, '2025-04-19 22:37:15', '2025-04-19 22:37:15', NULL);
INSERT INTO `todos` VALUES (7, 1, '优化网站性能', '检查并优化网站加载速度，特别是首页', '2025-04-26 22:37:16', 2, 0, '2025-04-19 22:37:15', '2025-04-19 22:37:15', NULL);
INSERT INTO `todos` VALUES (8, 1, '处理客户反馈', '回复客户邮件并解决反馈的问题', '2025-04-19 22:37:16', 3, 0, '2025-04-19 22:37:15', '2025-04-19 22:37:15', NULL);
INSERT INTO `todos` VALUES (9, 1, '更新项目文档', '更新API文档和用户手册', '2025-04-21 22:37:16', 1, 0, '2025-04-19 22:37:15', '2025-04-19 22:37:15', NULL);
INSERT INTO `todos` VALUES (10, 1, '团队建设活动', '组织团队周五下午的建设活动', '2025-04-20 22:37:16', 2, 0, '2025-04-19 22:37:15', '2025-04-19 22:37:15', NULL);
INSERT INTO `todos` VALUES (11, 1, '学习新技术', '学习Vue3和TypeScript新特性', '2025-04-26 22:37:16', 1, 0, '2025-04-19 22:37:15', '2025-04-19 22:37:15', NULL);
INSERT INTO `todos` VALUES (12, 1, '完成代码审查', '审查同事提交的代码并给出反馈', '2025-04-18 22:37:16', 2, 1, '2025-04-19 22:37:15', '2025-04-19 22:37:15', NULL);
INSERT INTO `todos` VALUES (13, 1, '修复登录问题', '修复用户反馈的登录失败问题', '2025-04-17 22:37:16', 3, 1, '2025-04-19 22:37:15', '2025-04-19 22:37:15', NULL);
INSERT INTO `todos` VALUES (14, 1, '更新第三方库', '将项目依赖更新到最新版本', '2025-04-12 22:37:16', 1, 1, '2025-04-19 22:37:15', '2025-04-19 22:37:15', NULL);
INSERT INTO `todos` VALUES (15, 1, '部署测试环境', '将最新代码部署到测试服务器', '2025-04-19 22:37:16', 2, 0, '2025-04-19 22:37:15', '2025-04-19 22:37:15', NULL);
INSERT INTO `todos` VALUES (16, 1, '准备周会演示', '准备下周一产品进度演示文稿', '2025-04-20 22:37:33', 3, 0, '2025-04-19 22:37:32', '2025-04-19 22:37:32', NULL);
INSERT INTO `todos` VALUES (17, 1, '优化网站性能', '检查并优化网站加载速度，特别是首页', '2025-04-26 22:37:33', 2, 0, '2025-04-19 22:37:32', '2025-04-19 22:37:32', NULL);
INSERT INTO `todos` VALUES (18, 1, '处理客户反馈', '回复客户邮件并解决反馈的问题', '2025-04-19 22:37:33', 3, 0, '2025-04-19 22:37:32', '2025-04-19 22:37:32', NULL);
INSERT INTO `todos` VALUES (19, 1, '更新项目文档', '更新API文档和用户手册', '2025-04-21 22:37:33', 1, 0, '2025-04-19 22:37:32', '2025-04-19 22:37:32', NULL);
INSERT INTO `todos` VALUES (20, 1, '团队建设活动', '组织团队周五下午的建设活动', '2025-04-20 22:37:33', 2, 0, '2025-04-19 22:37:32', '2025-04-19 22:37:32', NULL);
INSERT INTO `todos` VALUES (21, 1, '学习新技术', '学习Vue3和TypeScript新特性', '2025-04-26 22:37:33', 1, 0, '2025-04-19 22:37:32', '2025-04-19 22:37:32', NULL);
INSERT INTO `todos` VALUES (22, 1, '完成代码审查', '审查同事提交的代码并给出反馈', '2025-04-18 22:37:33', 2, 1, '2025-04-19 22:37:32', '2025-04-19 22:37:32', NULL);
INSERT INTO `todos` VALUES (23, 1, '修复登录问题', '修复用户反馈的登录失败问题', '2025-04-17 22:37:33', 3, 1, '2025-04-19 22:37:32', '2025-04-19 22:37:32', NULL);
INSERT INTO `todos` VALUES (24, 1, '更新第三方库', '将项目依赖更新到最新版本', '2025-04-12 22:37:33', 1, 1, '2025-04-19 22:37:32', '2025-04-19 22:37:32', NULL);
INSERT INTO `todos` VALUES (25, 1, '部署测试环境', '将最新代码部署到测试服务器', '2025-04-19 22:37:33', 2, 0, '2025-04-19 22:37:32', '2025-04-19 22:37:32', NULL);
INSERT INTO `todos` VALUES (26, 2, '设计新产品原型', '为下一代产品设计交互原型', '2025-04-20 22:38:13', 3, 0, '2025-04-19 22:38:13', '2025-04-19 22:38:13', NULL);
INSERT INTO `todos` VALUES (27, 2, '开发营销活动', '策划并实施Q2产品营销活动', '2025-04-26 22:38:13', 2, 0, '2025-04-19 22:38:13', '2025-04-19 22:38:13', NULL);
INSERT INTO `todos` VALUES (28, 2, '完成用户调研', '收集并分析用户使用产品的数据反馈', '2025-04-19 22:38:13', 3, 0, '2025-04-19 22:38:13', '2025-04-19 22:38:13', NULL);
INSERT INTO `todos` VALUES (29, 2, '撰写使用手册', '完成产品新功能使用说明文档', '2025-04-21 22:38:13', 1, 0, '2025-04-19 22:38:13', '2025-04-19 22:38:13', NULL);
INSERT INTO `todos` VALUES (30, 2, '升级开发环境', '更新开发工具和环境以支持新功能', '2025-04-18 22:38:13', 2, 1, '2025-04-19 22:38:13', '2025-04-19 22:38:13', NULL);
INSERT INTO `todos` VALUES (31, 2, '代码性能优化', '优化核心功能代码以提高响应速度', '2025-04-26 22:38:13', 1, 0, '2025-04-19 22:38:13', '2025-04-19 22:38:13', NULL);
INSERT INTO `todos` VALUES (32, 2, '设计系统图标', '设计新版本所需的UI图标集', '2025-04-17 22:38:13', 2, 1, '2025-04-19 22:38:13', '2025-04-19 22:38:13', NULL);
INSERT INTO `todos` VALUES (33, 2, '修复数据同步问题', '解决用户数据同步延迟的问题', '2025-04-18 22:38:13', 3, 1, '2025-04-19 22:38:13', '2025-04-19 22:38:13', NULL);
INSERT INTO `todos` VALUES (34, 1, '星期五请假陪豆豆', '', '2025-04-21 11:34:11', 2, 0, '2025-04-20 11:34:38', '2025-04-20 11:34:38', NULL);

-- ----------------------------
-- Table structure for traceability
-- ----------------------------
DROP TABLE IF EXISTS `traceability`;
CREATE TABLE `traceability`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `product_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `batch_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `production_date` date NOT NULL,
  `supplier_id` int NULL DEFAULT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'in_production',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `id`(`id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of traceability
-- ----------------------------
INSERT INTO `traceability` VALUES (1, 'PRD-001', '高端工业电机', 'BTC2023-001', '2023-01-15', 1, 'completed', '批次生产正常', '2025-04-14 13:58:32', '2025-04-14 13:58:32');
INSERT INTO `traceability` VALUES (2, 'PRD-002', '精密轴承', 'BTC2023-002', '2023-01-20', 2, 'in_production', '生产中', '2025-04-14 13:58:32', '2025-04-14 13:58:32');
INSERT INTO `traceability` VALUES (3, 'PRD-003', '液压系统', 'BTC2023-003', '2023-02-05', 3, 'shipped', '已出货', '2025-04-14 13:58:32', '2025-04-14 13:58:32');
INSERT INTO `traceability` VALUES (4, 'PRD-004', '自动控制阀', 'BTC2023-004', '2023-02-10', 1, 'sold', '已售出', '2025-04-14 13:58:32', '2025-04-14 13:58:32');
INSERT INTO `traceability` VALUES (5, 'PRD-005', '工业传感器', 'BTC2023-005', '2023-03-01', 2, 'in_production', '生产过程中', '2025-04-14 13:58:32', '2025-04-14 13:58:32');

-- ----------------------------
-- Table structure for traceability_material
-- ----------------------------
DROP TABLE IF EXISTS `traceability_material`;
CREATE TABLE `traceability_material`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `traceability_id` int NULL DEFAULT NULL,
  `material_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `batch_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `quantity` decimal(10, 2) NOT NULL,
  `supplier_id` int NULL DEFAULT NULL,
  `usage_time` timestamp NULL DEFAULT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `id`(`id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of traceability_material
-- ----------------------------
INSERT INTO `traceability_material` VALUES (1, 1, 'MAT-001', 'MB-2022-001', 5.00, 1, '2023-01-15 08:30:00', '钢材', '2025-04-14 13:58:32', '2025-04-14 13:58:32');
INSERT INTO `traceability_material` VALUES (2, 1, 'MAT-002', 'MB-2022-002', 10.00, 2, '2023-01-15 08:45:00', '铜材', '2025-04-14 13:58:32', '2025-04-14 13:58:32');
INSERT INTO `traceability_material` VALUES (3, 1, 'MAT-003', 'MB-2022-003', 2.00, 3, '2023-01-15 09:00:00', '电子元件', '2025-04-14 13:58:32', '2025-04-14 13:58:32');
INSERT INTO `traceability_material` VALUES (4, 2, 'MAT-001', 'MB-2022-004', 3.00, 1, '2023-01-20 08:30:00', '钢材', '2025-04-14 13:58:32', '2025-04-14 13:58:32');
INSERT INTO `traceability_material` VALUES (5, 2, 'MAT-004', 'MB-2022-005', 8.00, 2, '2023-01-20 08:45:00', '不锈钢', '2025-04-14 13:58:32', '2025-04-14 13:58:32');

-- ----------------------------
-- Table structure for traceability_process
-- ----------------------------
DROP TABLE IF EXISTS `traceability_process`;
CREATE TABLE `traceability_process`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `traceability_id` int NULL DEFAULT NULL,
  `process_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `operator` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `duration` int NULL DEFAULT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'pending',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `id`(`id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of traceability_process
-- ----------------------------
INSERT INTO `traceability_process` VALUES (1, 1, '材料准备', '张工', '2023-01-15 08:00:00', '2023-01-15 09:30:00', 90, 'completed', '材料质量良好', '2025-04-14 13:58:32', '2025-04-14 13:58:32');
INSERT INTO `traceability_process` VALUES (2, 1, '零件加工', '李工', '2023-01-15 10:00:00', '2023-01-15 14:00:00', 240, 'completed', '按标准完成', '2025-04-14 13:58:32', '2025-04-14 13:58:32');
INSERT INTO `traceability_process` VALUES (3, 1, '组装', '王工', '2023-01-16 08:00:00', '2023-01-16 12:00:00', 240, 'completed', '组装顺利', '2025-04-14 13:58:32', '2025-04-14 13:58:32');
INSERT INTO `traceability_process` VALUES (4, 1, '测试', '赵工', '2023-01-16 13:00:00', '2023-01-16 15:00:00', 120, 'completed', '测试通过', '2025-04-14 13:58:32', '2025-04-14 13:58:32');
INSERT INTO `traceability_process` VALUES (5, 2, '材料准备', '张工', '2023-01-20 08:00:00', '2023-01-20 09:30:00', 90, 'completed', '材料质量良好', '2025-04-14 13:58:32', '2025-04-14 13:58:32');
INSERT INTO `traceability_process` VALUES (6, 2, '零件加工', '李工', '2023-01-20 10:00:00', '2023-01-20 14:00:00', 240, 'completed', '按标准完成', '2025-04-14 13:58:32', '2025-04-14 13:58:32');
INSERT INTO `traceability_process` VALUES (7, 2, '组装', '王工', '2023-01-21 08:00:00', NULL, NULL, 'in_progress', '组装中', '2025-04-14 13:58:32', '2025-04-14 13:58:32');

-- ----------------------------
-- Table structure for traceability_quality
-- ----------------------------
DROP TABLE IF EXISTS `traceability_quality`;
CREATE TABLE `traceability_quality`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `traceability_id` int NULL DEFAULT NULL,
  `check_point` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `inspector` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `check_time` timestamp NULL DEFAULT NULL,
  `result` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `id`(`id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of traceability_quality
-- ----------------------------
INSERT INTO `traceability_quality` VALUES (1, 1, '原材料检验', '陈工', '2023-01-15 07:45:00', 'pass', '材料符合标准', '2025-04-14 13:58:32', '2025-04-14 13:58:32');
INSERT INTO `traceability_quality` VALUES (2, 1, '半成品检验', '陈工', '2023-01-15 14:30:00', 'pass', '加工质量良好', '2025-04-14 13:58:32', '2025-04-14 13:58:32');
INSERT INTO `traceability_quality` VALUES (3, 1, '成品检验', '周工', '2023-01-16 15:30:00', 'pass', '成品符合标准', '2025-04-14 13:58:32', '2025-04-14 13:58:32');
INSERT INTO `traceability_quality` VALUES (4, 2, '原材料检验', '陈工', '2023-01-20 07:45:00', 'pass', '材料符合标准', '2025-04-14 13:58:32', '2025-04-14 13:58:32');
INSERT INTO `traceability_quality` VALUES (5, 2, '半成品检验', '陈工', '2023-01-20 14:30:00', 'pass', '加工质量良好', '2025-04-14 13:58:32', '2025-04-14 13:58:32');

-- ----------------------------
-- Table structure for transactions
-- ----------------------------
DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `transaction_date` date NOT NULL,
  `amount` decimal(15, 2) NOT NULL,
  `transaction_type` enum('income','expense','transfer') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `account_id` int NOT NULL,
  `target_account_id` int NULL DEFAULT NULL COMMENT '只在转账类型交易中使用',
  `category_id` int NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `reference_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `attachment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '附件文件路径',
  `reconciled` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int NOT NULL,
  `updated_by` int NULL DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `account_id`(`account_id` ASC) USING BTREE,
  INDEX `target_account_id`(`target_account_id` ASC) USING BTREE,
  INDEX `category_id`(`category_id` ASC) USING BTREE,
  CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `bank_accounts` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`target_account_id`) REFERENCES `bank_accounts` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `transactions_ibfk_3` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of transactions
-- ----------------------------

-- ----------------------------
-- Table structure for units
-- ----------------------------
DROP TABLE IF EXISTS `units`;
CREATE TABLE `units`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '单位名称',
  `code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '单位编码',
  `status` tinyint NULL DEFAULT 1 COMMENT '状态：0-禁用 1-启用',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_code`(`code` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '产品单位表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of units
-- ----------------------------
INSERT INTO `units` VALUES (1, '个', 'PC', 1, NULL, '2025-03-25 15:06:56', '2025-03-25 15:06:56');
INSERT INTO `units` VALUES (2, '件', 'PCS', 1, NULL, '2025-03-25 15:06:56', '2025-03-25 15:06:56');
INSERT INTO `units` VALUES (3, '箱', 'BOX', 1, NULL, '2025-03-25 15:06:56', '2025-03-25 15:06:56');
INSERT INTO `units` VALUES (4, '千克', 'KG', 1, NULL, '2025-03-25 15:06:56', '2025-03-25 15:06:56');
INSERT INTO `units` VALUES (5, '米', 'M', 1, NULL, '2025-03-25 15:06:56', '2025-03-25 15:06:56');
INSERT INTO `units` VALUES (6, '升', 'L', 1, NULL, '2025-03-25 15:06:56', '2025-03-25 15:06:56');
INSERT INTO `units` VALUES (7, '个', 'g', 1, '', '2025-03-25 16:47:08', '2025-03-25 16:47:08');
INSERT INTO `units` VALUES (10, '条', 'BAR', 1, '', '2025-04-28 10:46:08', '2025-04-28 10:46:42');
INSERT INTO `units` VALUES (11, '包', 'PAK', 1, '', '2025-04-28 10:46:29', '2025-04-28 10:46:29');

-- ----------------------------
-- Table structure for user_roles
-- ----------------------------
DROP TABLE IF EXISTS `user_roles`;
CREATE TABLE `user_roles`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `role_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `unique_user_role`(`user_id` ASC, `role_id` ASC) USING BTREE,
  INDEX `user_id`(`user_id` ASC) USING BTREE,
  INDEX `role_id`(`role_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user_roles
-- ----------------------------
INSERT INTO `user_roles` VALUES (2, 4, 1, '2025-04-15 09:21:11');
INSERT INTO `user_roles` VALUES (3, 3, 5, '2025-04-19 18:24:38');
INSERT INTO `user_roles` VALUES (4, 6, 5, '2025-04-19 18:26:17');
INSERT INTO `user_roles` VALUES (5, 1, 1, '2025-04-19 19:37:55');
INSERT INTO `user_roles` VALUES (6, 7, 1, '2025-04-23 11:13:33');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `role` enum('admin','manager','user') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'user',
  `department_id` int NULL DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `avatar` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `real_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `department` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `position` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `last_login_at` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username` ASC) USING BTREE,
  UNIQUE INDEX `username_2`(`username` ASC) USING BTREE,
  INDEX `department_id`(`department_id` ASC) USING BTREE,
  INDEX `status`(`status` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'admin', '$2a$10$/3rR.47sP31ZzWrVfMkH3utG6B030Mk3RHHl3qbYwAfqLrd549S.G', '510076394@qq.com', '18368743511', 'admin', 1, 1, '2018-01-01 11:00:39', '2025-05-11 15:28:35', 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wgARCAKyArIDASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAAAQACAwQFBgcI/8QAGgEAAwEBAQEAAAAAAAAAAAAAAAECAwQFBv/aAAwDAQACEAMQAAABhSXZ5rXJS4LNawNEJqtNDa5+v1CfnXcHodAOfEvoRzpH0K5+QN1Ybidk4SDdPPxh0jaN+YCSTSSBJFgRQZFW5U2mXB38ToNq+cPJQVXLR581a2+3N2c3SfKiFrxAhNEEizPSvNei5ujp4+IwIv1Gz5Jos9KXl0BXpVXku6JjyN7mkXqGsx3y1KzV597F7N72zlpOoW+ONutMTkY17EqIti5mjxNaj0VvA3sqwtd3LWaOXQwGLfoVSSjECXo/OztdZmsncpd3z9HG5PogjTzu3Vv1Ssdc/k9TkZunYznlJQW1pN6Qjm39bQeOGdp7nloeivLTPihnrk6WaGbmdDlq2D15bBxp9o1zjOHfr1YqWnTgkZr5lQg9gYy1d5voRO0strW6c++pBABYVRRVzUx+4y0hrQb03wcT1rVcPskU97MiD0etqZGFX6dqoVy1WzXw6Geied+itSAjXnEFmuylJnQutdmZmt9IcuZmHZ0MJ7XGGmWApS76toy5dBdvz0ya4be84L0Hl7M65St47cS5jtZ7blJ6fL66twzKq0sgSbJK1x2FGae+KFs1Ny6zBMPnJIpaXVy0b/M+Hgs5fVlOyJawkEBTU05hIJwaBCQR52ljO9OBjDp0NvG2NOEUrsKXM363UZ6c32/K9Jj1bPPWdJT5u1kvTy6NbZ5ubtxN0U++xOggw0ir3KJfMQWa+Gw9D4bpGWMjKHRVu1kp32lHn+gnmrZ+q1vOvxht9K7SZezNKJE9K7UJenJvzuX0CPfzuE09rmrzsekeY9vjrqtypcteVqTQ3W/PZo8npVtCtBUX7HOyXG/RZHGvV2qd18oY8uWRWKg8CaKS53dXG1ed8Rn2qfTlHNCdIkFdBYNdBOWsCUvYAUUQrGRJiGu7DXU9fpLcbTXFXk091zw1Tos/SMLpOc6LDvT4teV5k6zU6+HquO6zUk5fvKWrjq+GSKNRSuZ5XP09DOw3uvztGtq6sQ9QmPIR7eHbUaboIZyvA59IX8RVlvLOruNW3z0ri4mpvmRYdWEXO9Fzzm9qZereKSKVQKzl19XmTw8XrUL1GTTOzHC401H422p6A0bxzJIiVG9QHlx2atzt850mbmZy6IaTiLaSMqTQAVH2OMa6jguAz7naygqSanAGP02sxboowVpUJIbVYI6rrvJkj1j1H5X15r6e5vlmJQ19Kh0ZdJpwyoqZU7svVXT8rqwatG9QXPhUNCjz719PJ6CtY4bY6EGWWMputUjPex5GVztuVsobqepX0wuOztjXkqGhp1m1BMz3Nfj0VsbZyWrejkbFZJIqKViA59W5YpycXr1pJFXYwPQQzFEbGpl6JwXEgZHP0M4qtm6efUafEdrxzm82VtTGyctV3T8CjW8/DKTmgMLmuAh2iwzBtp7WOpJ7EFajqul4zNCnBCiE1eopHo/Y+EalT7+OX6moxFNBn7A0c3ahX6duhPLj521i8+9bt+J9BdYTLUfSNTJW8yJ9eufRZJYeFKvJKOOhq49w/bpXdOXI0a0lRKinGS4HLpr5GtlUrGrk6zxSKSp596jHRuWqaw7L76F3L03qOUqHRdaMG7NW6czly5q+motfOdbL2ceo0eP7TiqzknnGkQ2BRT5vjfQtjPTyWT2Tzpq5veWtD2655v7By9FCHpVltz8m6Ec9T6xM4Op6OqXkOV7kdI+dK/0hkaZfOjPZOQ1y4pWq1wgU0fT/AC4i+lcXz315aZW5g683Pm268unz/Q8/zb1vUfLfUUYtPp4enPn27TXXLVuwc88Fu1m1nWp6lOpl5/Rfed+Cenpz2MbZlHVWsstuWKVxFh73OtXNjC3ayIBJpZ1/Gz36KxRsZ77Fjn2quom4+Ga9Ct+Y9dL6Zubel5E9l7uJ5cinQvUmr/HY9rTHcGO6om6rE7vh7hyR8KqH1S7s5WqQJM3cRpX1BN5T6t5vohIZ2UgARSEVwGkd5z3h2f1c3tUniK0j6Q57xv1XPXmuR+iZJfzGPX/Iunmb1vJK49uu+Y+h3d7R5rp8tKmB0OFyb0PSfOfRENfWsb88xSE0OA2ggFWsBmWtLPqasOxnUomaBBySV8S+Y9HIzmul5hqXo+b6Oss7SBU5ebo5sbblnPnz2shRkvfG5mXfp24vt2tnz35W6y0r3po5CcmlepUcjPBd15FXl6LHfp8bk/MMtoa6l6uWOUbyrAXtWLj0eWCWPfluekeUKL+kdTxT2zg7mlMz0fH4zynTzdXwoPXyh6dUsT2gGytR6n6j8s+4c3X2vhXuuPlp83KWLv4D6X5m9v3LoeZ6Gda+B0PP8nRU7vhtVadE3n9vfGW9XJncZSYF9Z4C+s1gaefCmT4uq160HW3BlraSOScj1+bFy3Tc6KzuYm1WTkHOcanbpZb7N6lfz1a14aYXkM0TCL9LMKy3sNosLzcvfedFYvuPk88u1NDTDO0dDF5+nyuN8nVyhDfVT+rB3n+qtOa3m/E+G+l/n/u4Mljzvz9B9B8X2fn944/seOl+FFTel5zHOhCSXovTcOvz7mvcKeO3hD9HO7PPZagia+mL/kfrnnej43519FfPHZysSW2F33X596yb9Eour8XbN0XPWYvZkxDc7jMFBvxYxFrty2hqrKQ9V+TGLfODGzpFzQT6Jc+hZk90Rdd0oSq1NV1TkrVTWLZ0DNU4tEzecdFyM4aKHUNkJta4DDJUERlQ0QUi2Ws12Fq9DU/Oud75H0Z+Yeny6mOtXWrZ0G6qV1JZOqg8s3+0Vprks6UUqF4Zyv01kdWPgffdw2dWizc598u3rvJ4Lxj6g8P7OPkonjq43e7eCdLlr7/4D7JxvN2eSojv85WK5D2WTi+18302lLLZIIRIIEFCaiBooCQKGmkAkUNqcgkWczTDUOVGPZOMwN1YKa3ThAN5YLh7gwHBurmZGdEOcQuiHOpHQrngPohz8lLcGEkugGXpt+gAjCq0V/DoflamzSwtK2JeFldkqUE/E9shJLOgUGFBAUkhFvMaLqVy8jXSLjoA7jntmeX8vt9f8t9DhoasfpavpI5Fw+j4JB2/Jej5FIpXEnrnkHXZ7do2mo0sshTLDYXCIIEgk0XItxiR4qxsOZSbdkaoLRQOBHVzFNQOLEhxYBuIQJzUNwSEkAD0xDeABPAA3JpEQCDtDK3uTq6tIeb250Z1blJKKQIBFEKvPdVy9rp0lm0kgQRAUn4dzF1LwBQMUo5EHG6+3zGufR4NvVjTnG6dVbV00t5Plftfj/ZwYsGnS6uJtmWgL1xuVq7JFrmIgggUBp24kSPjmQAExzXJgBQJFA9hootlPE1r3DjLkEbpADBKgiUjgoiC9DY+cURNsIIBZDK7pmIUVrq+bo4b0eY8HWkllaQLEV49cdlw/AN7eTtep8hTX1DF4b7vx9VLSSx1SQAtdXDC6ViuXrhecuPXF51201oJLO0Qg4/sIMzSdqhfgzvnC11bO8z9M4fbDlK1qL0/JqUxtZ1odd297m6fOJ+l5PQsmKTs4yHAAyViC9PBrim2koGhyApqZJm62XDsTxTtNRQMTkgJyBpRbanIWHr0LsuUotNLk20pqbOht7XmdoBHPskEmUADkC15/wCMdZyno8BcfpjXL5sq/XfysGf7J436Ljt6+kvO70gQBQDL8NOF6PCWvbriy1VA/d+x+Zfo7h7baQ59kx6AtJHyyliep53oqmkeUZ17G9TyLXu3NdF53o38+LEx6eidynTj5i3qYPo+ZbTl18jWvah5KTeCmBOAV54bABOTH5ernS5bFW2Aa9AwlA0kACUAKTM61UtyTOZODE57dTo8buPN7CAeXcIQlSsiYaTGBDtOyr7jwzlPcPE+/wA5vqflrdsfXPJkAh9j88+gebpmSXF1oFAMHe5PSPB3xSel53qHpnB+lC8C5DqOYKb7t4Z75z79QEzh7HJIaIQYVPSzXqXMdR4rctdD2+d2Yfk8Po5fQR228jTEiHct1GHtg4o+r5KilYEpTkJJzGEpFK7WsgkUEmbq5U065UuAA9tIJIAnIGlEEkAz7lLRmhNFO02jpRYbdnMl5naGmJU2MRLdzWpaPURB1K49zY4vsJrx+fMz6aHRyfOHY+wlGffS5tkghkJAYJiz5rofQnj/AH8PMqR2uYI6tVje8waHD3UWWhj0sdUlKsvahqhfcTiLapBwVvoK+2F/M0q8bWFl6YEJSDM1KdzTfWs+v4qa5rJkJABCAIoM3TztEEkglydbLly3K1oGBwYwoMJQSSIBOCDL1c7RmhYr2RU+m4/0fh7CEOTdsM0BrFHIxbsD45sFJBfG6lNJFLWUsjHmJQRJCQJJAigBCQIgBUzd4NUbYgNXwsbO7xGFcrYy29MKT3RucyOje5yGWarhZupAx5LQKSAwzVaWNoVLfr+KGua1M5j0FEMCKRhb3P8ARICCokyNrGh3Z4LDGoubrppE4OjRIkmByQZujn6kVFbp3Wsr0Tge+8/uAI59RFLGrrslatomShXGHobXpzT5GyGb3hPEpIlJIEUASSBJIEEgTXRFQwvjnqEbmKwQXQJAnEOJJTnKY/McxoFygkJAwsmUUwDL1cLTKyS31fJDXtCWRksjUUwFyDm+k53o0BJUpcbZpxSste1G1wCIOIGOSMHva4YKcGffp20VNHM1GZXonBdnw9dtrhy9Aa5IgZYYtIGyh3EpUON7nia9OIJRIBSEEkCIQJJAkkCBACGeIuvFPHPRGJAqjMiZGpEDXOcJqGTUOiRcpJAgUDcnYDdS4iKPFj1O3z2xvb2cgDmBNJBPIiCAcELA6HnujTCKAogYRTIHMkCJqQPjkjSe9jxpFBSvUbo6l2rcafJFm8+3oIK8/saiE0CATXgGJ6KangSSQIgiQKAJIEkgSSBJEAiAUcgHXZO1awqVFRKUhGpWJKrUq0FpTEkgSWPU58k+r28BsZDo10sGxo3nUsOPTyNrWqzA1yY21BYQC5IaSg5rqOW6kEkgSIKCSFBIEiMGFliGeFDpY5QCRCrcrWwikJGIZyO10fAdr53ZZSGOpBCEkhJJDSSBJIEkgSSBIEAkkIoMKBBBIEkgAcgAfGMszs4u/ng1SQKZSINKTG8tJv8AdwAxTdPG1Eg0ojAKAVrNcTU5rHzwzIKJBhKRzHVcp1g2JyEEUMJIIw5oRRWIAsxTxApGSgA5BFOx4FJFFAA6jeUV003CdTwdekkMdEQgSSAhIEkgSRAIgFVl8/e250vn3Wl7IIXMkkCBQBCiO/FjVC9LORKCcqbSUhpcgByam2OhmaF7q42OB6OaGSGdARQIJAkkAgsV2Jr2g6WKwCSKAkQ5XreX6gGoIHAosJEUEgACpcqDuRyxCMsE4JEDJBBJIAUgLSgVO4UDquVzuTo71cl0fNvaSM1wXVcT1Kz3kx5oiCCBQue5vvcV9nO+gQOMbKzKhG7DgMK2KdRFFpQwi4bCQwqtnk7UWOVma2454c/psr9fLsNo3evIpAI5YZRkFCCcAaiQbBaqgQWA+xQuA8Bwwig5/o8rVBqKEWvaUik22OWNNUr+fLvRmNo267gkLUxyYkOMCCcMQ5DGAkUM7kFESw9rvpXnlx78rz9GnR8rr2OgweQdelR8HHs+/j412k9VW59M1Bn5xfSLj3579Y3k4XPXjJu7czq2hcrPnJukyanDjvaXJVDQYcmnMfIc29p9mFDXB7cFzHT55VU5ugaMlqyNTiINTqs0VwVHp2IHRjc9OGyRj03CKeoaihJEAE9AkQMElsXqNjLZgst5PRus3pHx4Whdc4rw81XV9LTx+kFWb0YM+fzt/AOrMo7WRPo9LkW6nR5MzH6XRx9BtAzHIx7mOLPxelyuTe1gv0fL64jn6G+dHvMWHpx6y4ue7cLfn43OLo5ptoZbw3LV0zsswt/0+QCpgTT5rT/O6E0DK3BqZJl6GdtHVSpelyNIylWvWVTHslZoLHuldsuOGlYKcPZwhN+uZyvaGeeOgqE8zU2KU+lyWnUedO5HYg7PBanDTEByAIIHogpJEDJEctrlSxR5PU66xyVt8nSrna7nXy40rO7iWBdIcBhnqZYyjexzu1UXZW1szXrnyvTeT7br8ZJJqDluwwWs/negy86zuH9E8P5d+w9I8j9Dc9xLjbfl78fn95k7KbTSwfI6lrR0IpE3J8pk9zzXXGPpC6nTZ0F3J8rpdG2TPvPSPNtajb9THdNzou3nzOd7vnJqpzWm3k9G3Rs5i7OvdyspzdVLyBJ1KcVktvR4JF0K5yIhQQRLryBYprp6SrDV6fJ1A5vRwpFAkEDigUiEEehVo462ed1WcvoUxoSLTJWu0WbYnLUMWPjrp6qPmWl9OOVa11CwOlrmi06LXh03pXnPovT5ZWXTqegiMgci3Zxgoc1L3XmdPzh2fK7/AKGPovVeeeieP0oJYMFAKGZa5jU6ba5XqpEgJbkAIoBNyDAkbmUbUepj7fpYdYfL7nbj6LzLIE1BVn5d+AZqqfUoC/mLWY5Llpqw1ZXNg19QzpufG83LmIjfq1l67xj1sDrt+OYE78LQ5oJFAikUCWgcHcp5PO1+rl5L5DZ1IRRvzY6W2aDB5PD38pevM2uF0TxwNbs9hxnXaeU9sde/Pv8ArvnvoWqiydtUuNk64Blc/tYKOb6DKl8vqd4f75wm6w/c/H7rn1oI+TuHNLVCevm0dEuY6ZMJKQOaRAojpY0lbqmWl0nS9WXC6HYnrxztAq03F3OcRzV63q8u3O0uoqjxeW7vlF0826UT67U5Cj7Xj+mfFsCCWvP4ClrZa9mxaOlr5GJusj15uiBWjAciWpyAJwLQKBYetq5PPk1m8l07ErgqPkFKMJoYvG9RgL1qbbbV0122Qx3Q8/vaeSxtiK+HovQ/O/RNZSSoSSQks0J+Jd0HH1tIXN0HPpTUYnW4sGZ1QS5csrJ0VoHZ5boUTrNa61Fn02Xm5fU9/M3aK7MEkmJJAkkC4/r+El19ipZ5dpWJybuO6Lkzfny5HrIhAeu5/tTisMcDg8nr9Liv2J97E09fJkuYe5pzbAI1AkgKCBIooJEIMu7PjU1t55Kgj0HswpL2haw1ulLgua9C4letSivo6s6PUjFT6/E6nXys+K2+uG36n5V2eq6JYc9LVVG2EPlXVYPL19iiuToaUk1SbhlZ8U3NaP1HTjfxc3OP3MClV6CuttNBRyGiSQLJ1k1Lu+Wek+j59pZdLTPoYuWrtdHSykFnKnqp5u1j9Ryb0DpPkzec7fFNfKX7Dl7WQ7UIrnSZfRnmUzbcc3m+R1vPv1pbkOrt5VC4zT0w1Q9u0tRAwigJ59nJ0dGeRkVdLRxeihXhctZznx7M1LBg6QUucfvMpczwnrPn0+hkBzJ9BMcQPVcz02vlog3wcx0ea2NvRm8RYpdceKjZ0fPRZGO/sT/Julx17NcwEb+DyVGr0uH7HJ6eLvO28M6HjfqWXxFrLXts7mtTXXYt8XbZvaHDTi7DA5XKZrdHwd3ow7u35o28vTavmthz6EvO2j9No+dyB1fVcd02TuGikaHP6XOztzoDz2YxOAXoHDdm/PuupyHFzHP6vKnq9Dt8V1Gvmvmy6N4d4uRU7daObQulWEgnTD5nckgEc7c/fHtbHJO15OiqZ+kyEW69SyOZrM7lez4lek9RNnunFYBZ6Lj9u/P2G1Fr5mZ0GJucneyKeXPQyXYt+Wk3sTS4pdzziec7VlFjN2EGPDq7COLs9TYFxh626nx52JysJ2pAykLkgs9zqzmZ77rM7N7+qLz59a9zdkTnmNGCSEWp3XFdJ1+fotoSSWua6HmDXz9XCe1TdaQQ99xHZHJqNfI/N8/wupwj1XbuDrbebLhaGK+fQsYcvH29BLHJnq1FKrJIgDgANexR3x7C7kaGnJfFGmGk/NfZcigLVXhew5BelCyZT2wx2mhR6Cpu6+ZQllh08/O0+Yh5urpfSeO7vTFpsZ156fMbvNNWdLI6AUEVXODckpWwz7FeEOpETlT8+XgKO1u8ZA13NjiKgeiDzHrgqu8+mpd7qeZVmevP8p9YzfBY3e+e59GkkuDvCICp23CegdnDHfbAs9rAbzJvSGKF7O67BIdD2nl/UnJ30fPNfmYXK7fMnqy9VzHV6+fWxuhw65ct8bebr65NOHQ5JBZDm50CiAmrv2x6HB0bOvLjXtiO1lPsuuaSvBrjcDs+Uz9eo2xAbsjJJh7Xjte+DXrY9F8cmlS9Nmt6/BYvKCOtqhg5dx1Kj0+XdFhWIXBpUNzIDPltANuaOOai4TvuK0TqunVamx+0w0ZXa89sJ88DdoorQAsjv+Vtp9R5z6VzUPhNXj4+bs7RsVjm6dLpPPNTp5exWBcvLV5jqcFa8a6EL2bIrOCx2XFdUcmwLCrzOK5foecPUuWqNm/PuYsEKyeEsttrTwN/LoKCmrJCzbUQABTFJGmNZM0UBndc1RcKM2ruJPCfthvLWmkZrtAIpNuxNTdtl7/f5tgOympm3eQqLj69Sp6jLq4qresc9sD6Dn4FWVmbM11W5VsxZ60vPO/4nSRV2KNLrOL1+Z5vR1N/mUVPdz5+nzLKrllnOmcz0dc502FeS8p6p5k72dvjOx8/uSInRRPLVKLSLMtusCswaiHl2LpJqxXSTjw7qoxJtQyZr9AJ1XTkZAAknIc60abIghLSlKIU4DBSBIpCBSEQhJEAUCABaErKXedvHNqCXblZS0QPNxOsDnlr22BcjF2bR8Xr7yDnYeoDnkt3QSpMelWbyneJnAs9BVLlMT0UZdPnk/egrzGt6sdeTyc+rIXlMfrKHx/ZAw63jnuHn9rz3e5y9y9fViSPl6ggmFJCQQAkIZQINcHjYJrtPOa41TRNBMIFISIEUkGlZ613Vlh9NFIueCvovU5LHYBtsZVSd71TTxo6NF+TqZTKCcoAJBqKBrjR0jZ2btb0PNJYROl4I0d6vOkl6OPMiL09nmzmejP8zso9Gb5Y5v1AeYuD09vmBD04+W3Q785FQOgjwQG47BIb0vNFnRnmkjpHeZSB6W7zK8HoGDQLOJp9Xx2O3ZWOd6Lh72BydNIuNUlN3FPiHbWg55i52jyOdu62RUaUnCovpMSLqCuew/RKzXn60MnOpwFDckgjuzVNeu1ZxY2de/hQT6A7iNXXj2+H7vzWiajPWy9CbX5SwcPbiKXkpzUUIgjME/LdXN3T+APf5/dZ3LOH0ceCR78OQhac+KQ6SriIQRIa1vnp2dHFgAN5mGA21iMFtOw2o6F/NoNmLMYF6bMeG7BjVGbMuIQ25OfAdDk1EDsXSzMteh7blO15vQy7+vI4p1OmsrLyPd67hl1+gHntmeavqkKDhbyH5rB6gq2806voQ4bWikeNKtZhNuTrdrzk75yrLM9dfFR347+TlwrqqZmvzy7IOt4TUvPtvOPRvI9/NMM3U8nTk9BYZz6NRUsOTgAcgWVrZ1zzljJr+l53QO58B0bedIdCedAulXOPDoTzZR0J51B0a5xB0bMBw9tYaDbGIQ12ZZDSZRenaEL0FPkCGG8isk7CRkP1EPIbtAXO3r+hN4noeG/Ho7m1x3YW9WPH1VgyZrKXH6nQ8vN7ehz2vEWJG1lDKGtz2+EdGObq4YTZnDoYMHqeX0KWdpXZ6c1SpXyr+WhPR6vHoNVugdMVFXzhp588d3p8ufK2ZBz9SRCZQkQwTAUSlTIhMgyaXQtqeaXRhnOLoSznzvtFiO13Ix3axHmPvlOgL6HnrQAUn2QETnEAUgcmJD0xCc6IDnVdrdt1Mk2RVQ7IruB4CAAoRTVZ3FfiOy2WTJMXtWvshcZW/k1DL0iXzr0HLla6QNc5X2Jtop6EWZO+4OUz56e8xuTul3FURp59PE2r2nZ1RRdy7COOHTg2IVmOus7sqqm7aqgLUtEBfFFIuiCYGCVBALJHXlIQAWsgE6aYJUEAsoK6sAcD3tEXxSg58Ylymqxu6Kj0WBGQcmkAQAMsLWTsiTJjXAWxReOUtKEAVNRt5WUDfA6Tb6FSN1oqqthmVqFrj0i74t3jyEfX8o+ylT6OiawTZuYV0OTi5hjuLMRKIU86DmuUCGLcwt2NGIFUQkCc1ASADg1wBFAWkAkgBSQJpQyEgKa5gSQkUkIFMSBAJJCSAEEMSIEkkBLUMkJCILAgQJY4HJqG4BIcmEHFqAhATk1A5BDJaQOdfDSlz83WOqzcgLeWCzpLGloObDeileMxKsXsSaISaOwlFpJFhySGlIC1IHBIAUgKSAJIEkgLUhhJA8JMASaJSQCkCSQIJAgkhOSAFIA1JDwkwhIAUmApA4JAikMFJJhSEQk2kkD0khNSBySGgkINSucqZJzpRpRpK1JASTf/xAAzEAABBAECBAUDBAICAwEAAAABAAIDBAUREhATFCEGFSAxQSIyMyMkMDQlNUBCNkNERf/aAAgBAQABBQLtw+Oyk/Ovj/tF/tdd2biP6X/GP2xa83PDWneP+Nq97cz4xaYwRsnbskvaCvC7dH3KuOKo2HsovdNKAAFrwJPC4T1OnBz2NUdiCQrRaFWonSiWmHrlEWAygxtaOswwwFl+I/XV/rQEtvXByrtAxtu25GNt4lv0qwK9cSSQTuuVZYlblkGLiaHudVkcuVLHYqPJDNdbF5rXC7PrHcY8d+HfXuvmQ/rIL5g081rQSWc2yyyGPrWbTei0N5iGQauvbp1zF1caFqPd1cOpsVl1FNdTScufj+bFEyKz/AfaD8uc708lqMfTH7vQmeWV9tPsSQQs5tpVIpmn5taFnuPSVa06ubMsD7WQtWVtaUWMUeQuMY4gFxYTVyliuRNGYWPa8eXNIZFskP8Aer/np/1o9Ote1rwGgAtaV7cMqN4m2MTWaVJt3k8sYbRx7C+pu7Q9rd2QtbZibE9OHZs2rfhH6EHuU8pE0FWaZnQzg2HyV31v79DU5hsZc59eXQVJ9OmsJtecLkzowTrp7GgrWNelsE9HZKNKwToWufqVe/UynLc+zCdYlftxUoX5K9K1l/K6tu5ILzDJNXmWRTbuQabtu9ajnu3pqhmuI5K+TFbvxiSa5IIJbzJOodzT2O56hkY7j8J5DGOtTkSg23VKgkc27Ax+VqcxN7pz0R30799MHPsmrscxVoXQyI/34xpbp/1WD976LDtsImhhriGpumcConMa7pajS+Vu14eJa7t1iM78jc72vlx+hjHbeEvvC3azZ+4Yf0/hzWPYYRWzmH087QO1rJY3kuAE+RcV1FjWK7ZYq07J2rqXaCySyGw2V7pK1mTkxwV7wDs3F/s4PwLxSyU3pbEbF1lcoOBbHIxz3naA5zgZVzHL6yt7yg+TTdOU90zVM6V7GODx8OaHCrLuR4Oc1jHyySGP3ib+8yEbvL+Vz3zzMgY17yZRuR92R/VI0aRO2P1BBsu1Y7cxx/yDR++p9q3tcHonbuisQubVpnVt92kTW92/U1ObuaFOHwyudvk7qFnNl3cZffeSnTO6guayET6lpBV3t4lw3+9nkbCyWSSYtBCklfZZt7hh0EQKi315guliUcLGpleGNMqsbLP+C5/u4f8AZw/iXiJ80Fk2rBRmk3c2QjcnFang3jqeGqkP6dTTmSSRtXPcFHo258LIE9GQqcYkfM7lPF2dQTwyNzjdGNcWprnKeN0UfOcjKCz3igaWwvaSogQwn/IH/aV/6rv7TVbtxwE5KVdVa3RZB4THtljDWh0/JI1qKPp9/CNkYuz6SCGuHtfHE58fZ/ZajgHEDeCgWusnvGBMXxt2i/8A+SYdwGcszOmlGqAULdq3pzt7Q4OTZNz6x1ruPZpJTny82F8jnz/gsn/N1v8AaUHmSovEveJfHp78dO3CQfRCGlo0Ad7M2m9qOE8fNh2O1xWtZZd2+JQaCxcax0KBDZJdzogezvfF1+fZRQR/2Mmnm1T+tWAN25Z5Me0rQLTv8VpTXm1W1vB7WuTAG8K7ubItNJGvD3TgtcPYRY9CCmU+GIRj2bp1x+35Cvf+S4/vl6sZfPeEfPG7fyJnAcmGRtmmnxwMDXR8yr+EjULYwPYxrVZ/r2NPO63+yxf9VeIteW77Wib0fHqKd9kYIjT+7K9Gs6OSi8CSGdiNew2M6OGwtWXDQ1D8mVlIqsH1S9nagQiVqr0rU6pVWVIE73X/AOm4k5Wt2pV3hkz3nmaOciwraV9YQIcKMu5j5fra4OR14WZOY9oaG8NNHEAg0xqHVtWRVHK1iKsrKszZYy8NsOyVNi8xpkNv0d9iRs2dx3+yxw3OsH9xWe2OWa3LKo4Q8PhIVGJ0z/iiNtX0XP61kaZmnp5ljPsle2KLMzCcOexq50KL4gufAEJ4Vzok2aJbmac2JRFsg5ke2S5QjHmNPS/km8hmSi1bex6F7Gql4gxMFWPxDh5DDl8XK5g3KzRm5vTWGq/HIbCj3GaGvsdX2PtP1I6F5ayNkTWSvjXNjMWoLV8//qx98tV7UZ9eVJ3c5OKc/wCgfa7uauvV2mcqRjtV8GYzOthgdBK5yFiVqff+nmSlMnmYOuYjCzTp4tzg4RYg6Qyd5uP/AN+LGuUx32Tf2JyXSWarY60PIZDM+s44z731y617D0X/AOpcA82p/wCyxP4zDLat+S0gwYek1eU0U3FUAvL6S6KoulrBciBTdNDFkfEUDFayduw4yOcuY9EuWp4BrnEgtJ007bVFYniVXxBla6peM5WixnK16+KdV7Ioo4m527y2x/TUeA5uMc801al5MbYyopHQOY9sjEzvl63fLVO2Nu68iT8ga4qFjuY4FwczVOaQ+qDz8i5bC1fTvkcyvBFuVjdFZhe2Rsum1n1N0C1ajwl/Dih+kWF9gcZB+9wn+2lsPc9seikJE0jXyJrGMWmoj/TNedzhFPqfRd7xX/8AaVf9hjO0cP8AuD7+juvjLZ6Cq27cs3JNF9CJ7oINJMMQauyPdPrtTo3BaejVUcndpPoeL4jHH+7UmjYx7wR8uJWDvt8Ma76So/8Ab0tfOav9G39VV7CJ+yHZzl7J32RSGNwc65BFY0V5oLDIbT/d1z76uonUGsc3otf1aA+lnayF7AaKYfu8AN2YLSHyv5cUTdGn2TwXNDQBCdlj3VZ2sXG1+W//ALCt/eilMFNlvJXAbOT16jJ687Jab8kUHZBPOR5eTy7wX7dSvZDh8BqhbsHsiiVqFoxykh3KSN7E0Aogg8adqxUlrZ2KwqVfUng/+2vnG/cov9rSG3M0/wDX2RrBkB+726IMdu7oBTu3l6pfQJ26OjgbNGGcsxD6r35aLTzlbGk+o4Hhb/qVE4/ufjhP/bwz+Vfqv/UvjSP0wjWdVPx8bX9jJa9ZX7XNP2WM7UEfYoL2WXyj5D9rlqjoh3RTW7lEAAte+q14912Ikg7aHQ+mhftUZMLmY74V5pa8okBUGGOsmf7WMf5+v/r7A1gyDPpHsRqGsITloAX+zxpDN+rE0lpceaWjQXe01Fm2BXm614TvZpxtD9rTR/sj24S6C5QH7z/s9/OhYdW8XHRtaPY35ibsj43PtyI/dQf2v/jxf9F9gska/cjJ9UYc52auuC02jbqoIJZnxYHI2W1/CkRUXhjGsEfh/FRvdhcW4eRYpeR4op+Gxb0cJi9ZfDuNen+F6pUnhg6SeHskFPislAHB8bpgHog+oEg4HPByc3cHV5YlBWe93Bp/yjdPP4T+xudoYzvinrujQcDwCe08x/dD6oqx2Onj2pv0puga5hnsov8A1CARWbM1/KuL3Kt/1qS+64F8/Mx/eUR+9WndjnB24remxzuUUAZwhiIJ7N3OK3FUiSy7/WvaFN1E4A5OMbsp8Gg63ZXyp3hq258HhaLS5WwOLhvZpzk+aR7mSva7F+I7ld1G5Ddh/iexj1LiMbKrXhSBxueHsnE6WvNEfQFgc7JUUT2SRyZOIOjka+KGVsrR/tGf7+L+td/qt0EafHG9GtCumiXSQpteIJ9VqdVlW7aJGjWzIWRU4eVGnfmKrO0s8Z/69Pujr1vGf+5XlbHd59ZQmBwinqxptyuQ2zGQJWlMYmDun6bI2ML+S0KqY9Ln9S4f0W+8j2R1McQ6novdWrXKdiMe2nEvEGajxsdqeazOtFpww+RloWoZGTRfwyPjibYz+KhR8V4/VvijHOkE1W5XuYTG2Bd8NWo0+pZYT244TLPqMh5baGH29NTfSMzdDlIu+da3aL/9PTWLatDoPt9ToYnJ1GBzjWcjXmRrWNeTYRrzF/1r24T/ANfGHcN3+UXx82f7zNPMSBowgt2tRZGQY2aGvA5tfXm4i+JJbLXmZg0iJrxOkHMhgDgbY/a2T/j4dSKUTXQcghbH6bnVx4crunkXiPLtx0Msj5pO54aLTh7LwVkP1f4M14kjruu3LFqTjUsz1ZcLnIra5TkIV4qwglYRpxxWQDWxyP8ALZTtgZ/s6+hy8v5rY/blzOVuYmln8Luw5r91mQxReYxbZbTIybMIZ1ESsmfkQbzDJ2jxfcwkHLfN2CWw0Kwf8gztkD7D7eLfen/cx/8A5BcfabNW6lqrFrX4ve2avG1omGsUv+pq94cf/VdLG17Tqng2LETBGzO5JmNp2ZpbM+iA4adyCODljrBqXXeKJZrmOvRXovRK9kMefz0lw+jRHh4XzZ4+Ksb0N7j4eyLLFSCpMbETD1FfQZR/57H4Rbr7OfU5fV1NZrWkULuZGjw+ODvYQv1yEcksFivMI56sorGs9mP5PGX8WMPdo/y6+FYI60f7AsfrG2cO+pO5uo14VR+8oEefWOu5rI5DNFDNBNj6cutWPlQSuAjtD/EY/wDr0P6vzI9sUfh6q6ODN+JNj71uxcm+A0rsFisZLefSx1SozOYlk8Dh24arwbaMeT4Pc1jMxnpbMs96zNEuyAWnZaIhfA7LwtletrrMUm5ChLG6N/BpLT4cyrLteN56+r3yx++1+CHbt0AZVFSOvDJVhYbdddbXRu1110BXW10b0IJvwrr411pXVSldTOuskXVyrqJ+HxL2ixv3gAZP5+FMf8qNev4H0QdrsJ2ZkEHi5zWC3dc5znO0tH/AU26QUdRW9k6J1y/40uy14S9aJrSnHthMU645gbGzuSK36XibHcmXj4aY9+Y4eMJTFhkAgFovivDLPIzw5ZMd6lYpu1R9nKlZkqWcfaju0141o8q1xpWJKtqnerSTvnkbfrFzo7L9kLcrjnMOXoBeZ40jzHHLzfHJ2YphDNUdXZyi0+eUSvPaGpztJHO0AvPKOvnWPQy+PKdlse1ea48rzfHL6SWq0N0WNH1N0OS+OEp/y0Th5iC1dloitFtKa1wuVoxNm+ngXTwI0I10MQTaEQLqMBWQkqxY8zVG163K0e+k0eHWCSfx3XJj7cHdlhMY67OxrGNaC4wwiPhbrx2IspRkoWviON8j/DONbSi4eL27sKOGq174jDvtKrXhqxK1CyeHJVTVnC+F4HubbCz0As494Idxw1mQxVpL1VtcWGtkbK5j9jlqt3bRpXZaolNJCe55Wrig8rU6abRqUQCtjFsYtE2tcTK9wBtawE6tCwzQy7eXkiBDkgBDkUalrmtx45hpMK8vGnQN06ILoo10MKjqQMY6pXK5IQrR68mJdPWTq9Urp6msbK7Fsr67YNJOXFFhYeRjL9eK3UyFGenMNd2Lw81owxxwRRQuemMawccnQgvwS+F2tOKxNes5oDRwlYyWLM4SenMRooK0878Zg2xLtohqU2CQrxBi+fXOoKPvG90bvDGS6+jI0OZ4kq9NkuML3QyxSMnh7r5WoW4L39Wo9R9PZD1d1uK1ciXrWRayLWVayrSRbXlbDrtK2FbVtW0La1AN1ttL2qbXYe6bHGENzzDX0U1urChmcZrDbqz/AMT2h4mpBzi2Rq2SFMrylMqtCa1reEjBI3xRR6e23uncPD1s08g+Vzl4rrcyj88fDVoB3DRbRptGmjV7eo/wbWra1bW/8IrRaegBVfrzXB8EbkKrNbt2tQXT5K+oMPjol01bSxiMfMnPv4lQTRzw/wDAztJtypJG6OR3sFjonT2/dTt5tedhjfp24RuLXV7TJoOfEjYiANqNC3GuqaurajcKNuTU2ZF1M66mRdS9GzLqbMwXVSrqpUbT2rrSB1UidbkA6yULq5S3rLC6ydG3Z06qyurtLqreos3ELF1c64udaKE1pdTbD+fbKM1kJ0tpc6wnTzhrrEugnlXOn132NolsoS2yWGy1YIGTM8cnddCcdj2VT6D3ErfJbw9v4HFrWy5WSVzamVlXltjSanmYVHmLNaSCaKaP3GfxDbCsVbFd8FS1YOGxopM4eJ6gbPC3eOOBe2QdPHtNeJdPCumhXTQadLXXIh0NeuumrqRkbGCGDYIIdRXgXIgXJgK5MK5Ua2sX08NVqVqddStStStStTwBXstVqjqtVqVqtTrqidUSdNStVqtUPfwuN3HIWenjx1MVW+qzCyxBgXyRfwXLUVOFlWzknsY1jeL2te2zjJ6b8XkY7oljEjZWFh+OOah5+Pq/bO3bInNIFOUwWeHx88PlBWezIvxI+67LTh34HXhpquy7cO6HDvxHt3XwvhdkePz7cBonu2R+FGkYjhVgcZf4Ms3kWvVbsRVa9GrLYn9eZx5mOIutvVHAOD6imidGOM0fIyNtuohaXvuBE6rFS82h2C+FqhwC+JW7mwfYQvdacdCu+mh4a6HVq1R0RIWrVuC3BEha99Rrr31Us7YyJyRudt1cvq13OC1ctxC1cm+ylkZEOju3214xFB6T2GSz9Oo+x4qvOczxLlAaPiljlFJHNFchFirjXuko+gkAVQchb/huMGNyfC8NYePiVvKycv1Q0VZka8LBTsiX7lOkDXe6KK04aJyh+13sivha99e+i2sVsNa1rY9u1uu1q7LaFoF7L39HfW/9Lq+4Qo+ntr7CvWs2jUoV67tB6vjxLnHSvOvowOWloWIZWTRAAemxEJ4GNaxkj2RMveJ6UKPi2zrU8VV3Kndq22eixEyeDDvf0ynGsPHxWz9OL8QHKgWLpy3p8VjK2PimssjUz+obarPpqNwe1e/Dunj6Iu0Z4ace+vAq/wDZW/D6/jhoskO8XeNaL50WiGie7Q08YN3x6/GWQMFdAdmtLjJBLHw9l4LuGar6snfgoV8tlbORm1OnCrYmrS+HsyzIN9AY0SI90RtPDxHGX42H8Vl+59WF88uJrQYylLae9oHAKeMU7nyOGil+yL7HrT0dhY7rsvjJabKn9b+LRZEfp1+9ce+iAR4O3bsbSFb+LxXKybLhfHh/E1sbWuV4bUGUgbVyPx4EH730nsM9fdkL4HfTVFvGjM+vbpzts1fVYGk/C7HzabnbWAauwlHpq6mlZDHY6mwI98bGHVluEWK9OTfHwPs/7Ivxv9Ov7jXjkvxVf6y7+s6r5HvkPwV/6/ZDtxnkELMRSdA307lqtVrw8WQOizAHDC+LXVocp4xMkTy6Ry8EVeXT9PiKfp8MgvDHh5l6AYDDiLxTihi7oGq9l4QcXYT1XhpPwCyUfKtYOtz7nDm9VZi/HcbtMX4lKDFldOMntF+J+q+OHZf/AFrRELIfjpf0/QQj6NeyyPaKsNK+vdaL4w0HVWuOqJ46rVOmO5p7eKceblRzC0k6rsmj6SsPRkv3IY2QxenxawvwScvBucrw1rOVx1aPxNlDlL7UV4Vi5WDQc0+m+O/ALxIzTJeE2N6ZZJzhXrV2Qxp7Q9vDKfSV8p/2xfYeHzovj/2duOQ/HR16U+j3Pt6NDqr4/Sqgis77lp3u7nqvEyCDgUSiVqteL3bGbJ5k3sszgY7Ss4u7Xdy5VFTuSrG+GJ5VSp16UPqnibPBkqslK2e67harbqtNqxVKS9c58UDXQSzp9hrFG6ZSzCMNduCd9QdC4LuOHiWq58fhkFuPW3mZH05UfsGd2LsnKP7Hfau3H/7OB9sl+Cj/AFUOAR9Px2WR+yEaRO/IeGCi597gUeB4a8NeAQQXug1o/jzOLgyUV7C5CoSHa6LvrjcBdtKjj61OswMjbM0SN/Sgi3WJlFBHEtfRoCpYdBMxssVGv00KeWQMx/UGH0Xxuo1TrW+UVH7H0/8A3raisp/Xpf1fjTj86cfharJDWOL7D+RW5OVXw0PIxqKKKPH34jgEEP5pqtaYHEYxQ1KsHAlarVblqteHf0yN2P4Wv1pfTY/rUdOi7cWfa72+FpwsnS5xyWnT1BpV4Hh8+rIfij/G/wC9ZVpewDQcDwP8AQQ/4BKcUTw1Wv8ADZ+4+6EYDvTdO2nWaW1SvlRfa72Xz8q5/d45Q6QVv63FuhX/AGKPtxCyR0rwfhf96s/7HiUfY/wDgP5ynIo8fn1yO2tPc/wZZ2lL2aeHxF7enI69UVqu6yn46v8AXXdeyZ7f9k/Tb/14e6ympqt7Nm13KV2zJego8DwPoCH85Tk70/I9/SewkduPpkdtETt3G4edkF8jhF7cDwKyH9rjlfwVf6y/7yfZH7f9077Rrt43u8MR/SuFzU06syR2O9J4aLRaLThogh/wHIo+nTgOLiGiR+8+j5dro4v1r68JXtjix7XEO4lR+3pv/wB4rRfNxnNrQ9oED9c32R+x/IpO0bfsXxorf4YO0V33YPoycfMoUpRPT9GiI9On/DKPHT0gLRPcGB7y938V6Tqpmjax3twcOzXaLt6PdXSevd3Xbh34j8r+7Wfafv8AiX7Gfaivi4P0o9Nl3sYvx6dvDr9kfr0Wi0/4h9ei04SzBicS4+m/lOVNUyMbWwyxTBSObGx9qW2qsDK0SKI0IRWn0j29lpxt/wCyIXb0/wDvf9sX2O+9S/ii/GtO3xc/HH+O4NYx2Ce4U8n/AM4j06LRSPawSzud68vY5NfG1RBG4BwdTrOPIO1tODd7cNV8u7lEJg1Ht6bXfJLTjpw0/Wf2ZEfoP3qX8cP4+NlusHsH/bwnibNFgrJkr/8AO0Wi0Wie5rFLaJR1Pre5rGUA67bH3fHx6fhfJ9o9dq04fKu/TfK7rt6B98ndsf2P/OpvxxaiPjN9iPD5CmEkFitPHYg/573tYJbeqcXOPp+ESAJXPycjGNY1v5F29GunAcT7R/bw+OF3Trz6e6H5JO0cP45PzaHSXvFH9nFw1HD5+Ue6a+ShNBLHPF/wLVmGtF5yzdE9skf8MkjGCS24o6k8dPRorNyCujDYvJrWsYh9/wAcOy0XwuyPB32xfaPTdH+QK09I+941bH+OT+xopPxw/iCHArTvx+eDGy1JKN2G5H/NM8RRzF1ixosP/R9R0CfaYFJYkcvn+CzkK0DtL9sVKkFccCv/AG+jTh34Ed9Aj2UPt6choLx4/PD/ALO+1n2S/mUn2x/j+dBqOHv/AATV2SPr5KSBzHNePQyWW/kqVgy+vPE9JomxusTRRtii4ulY1OtNTrMhRJd/BonyMYjkOYZat2yq1Wekorcb38DwGnMP8HzoiO0RGnt6cm39z86+n5kO1sP45TpMPaY/pVzuiWnHt/Ce7Y4JapjzPLdXsQWG8LEFhuZeeYo3tkj9NiJk8QxUQVavDVY6xE1Otp1iUlznO46erspLELAci1y/fzhtGDcPZWbUVdOrXL7JedTTdC3gPyBfOvf1y9o4fra5wYgQRxsxOdbOnp+fmX8bO0c35G/ZY/DV/EtfR349+Pzx7J+M6pBuQgDMlMxXrNec0CGmI9FkFvYFzolz4k6zEEbQTrMhTnOcVoVoVtOvZb40ZYgjbqhPyNJobkRIhJkZVe62GGrVdLHHTrMQ7eiR81h1GhDW4H2sxGgWkOCb+ZD0HXj8lO+2IDa9ocAO38Z3OG4gWDq8TQgPlge0SRNZzIyA9q1atzNN7FzolzYlzI1zGLe1bwjK1knD3UcPW2bEDXVm6k+xs1obLKsrnRW4uux9erzGci4FsyATIci8cjJrkZRdPkl5dlJFYpZCANhc9dNJpJAxqFZjzXw7E3FUAmUqbEIoWoK7dZXdFFJLIfTB+6hrx8qPiLBlNeC3Wm36BskYeJoiObCubCF1NdC1WQt1yuphXOj058blvBH1oc8DS1ox7jL39Hwvn0YklSWLgt8zIOXIuhnT39IK1sPFd2nTwroqu6WmTLZr2GxvhLZeXve6BzZLMUsZuPsQy7p3JodcxEDuZAp3cqPFVDVqqeEsvSMDh7GePlPx0mj77RRv+4IW51WeGrVmjZTgamsY1ZPIQUWTvs3U+iA/9dp6KNwr2X1pCteDiGtmuT3DWrR1weGvAK47nTsAa0r44Y36LV03OqZ5hKTVsFdJa1jr/pdPDrymqVh2x9UXSxzOilim5duAcyzXijU9RvL+stxLzHkMi3bkfR39Q9sT+e1uZbgkeJWE67hq92jmO3DI5CwbQdde2OxfY7F3urZwt9nz8rnZNo5G0EYaTSQN5Vg6BY2sLN4cMg3spGb1BtsCKbky5CSSQYadlqgFBT3AczDuje17MtlWVCyGSSxZpOFUyGIU9z2sDnGbHc2tTnfDJorVmGqx7bF4tAY3Vd1qj2Xud4a3FsMk/GzO6K3NAa8WLmZJftj9Su7bNG/dGHarmHdPKY4BctWJt0hUd22x1Cw23VVoa15JIuVAC9rA5o3ct+a7Rn09vVh/7GRB391H9+0hxGqaNouUIbJkx9woY64qFOOmzhcbrA9jJW7N9aIkxxP5VnLtLJnB89qrCyvDwnZvjQUn7fKZB8VXJzeIrz7VKY4nPWI+W+B++I9w9l/GqvCIRRg2NWVqtmtRUezGtYAsjXbvbZsVoYKxEvAuUcckhZQeSylA1MYxivfUaDQXFNDnmCk3TO1gyzCdpliNPLXwoe08PtG1wJYF8T42u9DFyaRYlrVG1kUaPccsERgRTTj9y9ocH62sDE7fF6e/oCwx0nv2IUyasmW2oXmrqUb7A7zBi8xYvMGlMtbhzXadUAn5CuF1WOKFqkC9+Kc8yYpPu05qPhiqWVvRej2vWVr9TUibFlsdagkrWmfvsPgLnmGJoSaOT2h7IKZbLwgbre42YhNEIn83TVzKlh6joM0ZWgZ6Z2BuawzSK9eq+VRRsjavEMckuPqPGzKgvovfDYoHpmFs8DSbMBXUs06mNNmahK1c0LmhFzVzY2gzQ7zapbrNjGTIOxqqZGjVhpTRmb+FzwJItkyvxOEYawyMLGjmM01YTozXRiD26Eo7VsBRga5dLFp00QT4IGoRQBftmqG1Wjj8MZFxl9ErA9kjSx6oNEE/jbHCSDHWXVLmO/xWd+qOZvceimhLLeWPnl5vHsPXrosnGI6+Aqk0+PiG1JUpVbNDJ1Hh26UwtqM5W3ZqthXKK5RXJftFdCu5Cq4rogujjC6WBciIDkwrkwKKOGJ+KH7Ur346j1UIooYnm8U0WVsm0aHoc4I9Ytt0nbe25KO0136i+vQxagQoVnEVazOodTrFdFBtNONeFmCOY+0t2JhGUjDo3tkYshH2HdVJ3TZBuyzWzVJ2PyGFfWt1fDmQGSu+mvHz6NawKwoa2sn/AAPe1gktEgueVYY6WpVyteLF3cjandB15jgmutbmbknlrGY2aTNw3LFeaO+89PaBFa3pdN6vIJ74XUZFR3crGOuyyjtZWSR0GUTqmSK6LIp8twP3WisZHJKugVuhqq0LYK/o09T61exYMDI01sO3WPWDoS0VqpXR1dehrroa68SRwxV+Y7XmvQlcnTO0Mn01pNbJrvcOlcjWAbhq87ryexr1Li6by7FWq73ZK5WNe9TtjKjpq2KiIhrymKTxVj+vx1aV9exZk6LJ1p2Wa/ELH/gkgikeAB/BYn2I6ko2Y90NLJ2E3w9T5lalVrhaLKRQdPRmsV0Z8Q5Pjx5bsrk8uustFEbPJXLXLK5ZW1yoxMlr9KEK41uRBtwxkqm6tG0uxxTvK1hHQCnof4XAOZQlqMYynVYjUrlGlXK8trKXGP1GLc4jDwo4auRkMdYgeYgEYmowsXLjWxhTYXb+jZoakKMdJi8OVY3T+jRXMVSsq3jL3KgbehZDNFMq1uTZd8NXJZji70FDwfkune0tcOOM/pul6lY+xMy368iYq5hZdtKDDMKihiib6c7YdDBSmdNXEAe11CqQ/FUXLyOgs1jq9abpo10sa6aBciuFyKyoY+u6Ly6sugqLJ1a8d7kMVEiOTn95JCsOwSynh8rVfPofZ0yvw1m4fUEIXlchwJgcV0a6JizVJrKpbAW7IdNsQP6aJCoyRtsmWojPSAfar7fDMzpJ/XZnjgikqMyNhoDRws061lTw2caasrZoeGIHLis4+xG+hTdC7jotFPagiUbMhabVxtaB/wDBnZbRVexSydcUq6krbh0rgjTn25+tLC7lvK5TlyXLkkLlrExmWt08ujq02k/NdN3WL5r5f3S2zuOFLjjzx+fS57ebVxtN6ZSZA3ppUKjkarin1HvQoSJ2NaU6kNMhVj2mlU06WgF02OXS45cjHtVd2OjnZLXCdO/QyWivDOjLHqyFyGlWp83IO4m1ahdDka0qsWOcsU4QW+FZpGWZPJPPZtTslkkZDHzZ5U2CTXp2q3RdPHVFzFx4/IV7o/gKzti/FkqzKOViOJp7/L26mk9Ox9lxzGOMcnRQLo4F0UWgpRa06Vd9hmPqsHRVkKVZZivVhvHo1T6XnFtQKXy4MwzWNqd/R39HxJBFKsVSmbLuyAZFLe2m1eanZOdg88LiM3HtGYiRy0z1krU0kZd37r60Wu02yBQtsPk0uFGKRGNmnht48z9NiVkMcxmy2RHb024oJYYd0EuTbG6PFmTy5STdLlr9WKyqodHLDC1nqu1d5w94Xa/odIxqdchCdeeU6xO5XmzOixwiy6GLlauhvg9NlEI8yBna159URytQZIuXKtkgWMoyysFa4A2vcRrWVlYLHXGu9UYau0xY8IspbcHsZJx+PTkNDUx9KtrytEw2mjqJGjrgFDcfI8WGLq4gutYs1Z31zJIubKubMt8yL3qo5gsufWXU1mHqXLFWHw5EW5gm3nJt6NMtQuTXBy8RzDdhzpf9FiSwx810TPyxEeNflKr6ce3lqRjZG3MfQbFjqrale3YMQi38v01JulzRniAddiCfdkKdNM5aLRaLmRq5EbdbBxQTx+XxoUp2oV7S5VxZ1svQ/VqeAaFiHyhw6vXdb0BtLORu6nYwKo4QTdVqp7VhrMZDI1npAXdbTwmY10WLwdF1YY69EXdcwixMB18QU1us6Hqq+3qqq6uuFcnjkqctbO/I1XKAX6ShDOb7Jxm1/cLJwzmxicqXO0Wi0Q1Cy7ZJDFbhbIx7ZGcZZWBjtNtilcyFPG145j4Xnezi/wDVvWZWwwY6Ahl+R7Y4YxHGJnvuJxaxti5vV2div2o6jKfPkqbSiNA6VbZ3DkhbVf3ip4eghdV8to6inGukmQrXFnoLPS7Zgv11unRlmTJLG6u61KNLa22VmTadJy5FSY5sw3qzFOa+MtTzv0Wh4acOZYIc2Vy6Z7iKbgTj2LGWbrWNvuDvMKwTbVBy1qWF0tZdDVKdRrrpK7VI2o05aSmLfNgRkraCSsFzWaRWHNmjnuTAi+VpJtkrudefjqr1G2WJhmtlr5LhW65ppaLTjvoqwWakrMneYhmCpsiJGTzSObuyRZDfytaO6bFuwJ7UGQ87yqiymQmUFqeFWLU88nmsgQvTC6/KTOjrXZq0HmdtX5btoyVA89AF07mF9e09dLYCEcoQ6rUdQFpKjHIUYbDmYCu6arty7F1V5p6+deYsCzOShkXWxhdbAuvro3622vkqzZRmcahl8fr5lSXiG42aTfcKp9ay51Vwp/mUgjY+O3yBpyUHSNX6q5ky7LcieEr9keHY6yxkbtTG5GPVPhrJlWk9DGVk7G1V5fjQr9Woyr+iDrCt8enMW+RfrOUL7MkQZYUkbND03UcHkNbFVtPb0kwXIRiYtsSbHC5dMEKoXS9unGog1Bqh7XUmrlkLaE2DehRkXQTLy+ZeXyry+ZdD3FBdAV0DyvLZUcZOrdeesozHKzlMXKjW1i0anvaxuGnrNOyRNa/TaFovEWvl+2VcuZbJEGy6gTA0JA2uZwF1BWb5klzYVjWlkwZMnQM0mmoxy9Yo7LHrcxEDXY1aemlDkTK+bNRiPJXWoZqNprZSCYOuU2uflMc1eaY0LzOgrOXqMhN1q62JG5Eur1PUSpz7bjRguSRSUIQmVabBPHLFMV84uA3bniSeZsWCixtKubGIXOxaEmPWab1UoGPTG44ud5eC04/SzEJAcqWIZdPycbUL+90DWvLcTX1lxtVxdioXHyaNeSxqPFcmxDh5YpRhLTTFjbsbMRQmpgaK7Dzqz3cq5pp6JY2yMxgbaxoqwNjEc6HXhb7AGckmNUOKDluW5czRULDxW6mRcyfXNunfb/daMFvmGvO9dHSYrvTvsqv+fb34fPoxZumwMrtLMjj5FvoyJ9SrIvLqq8ugRx0afjw1s1V5gljsRu+pDdr3RLdN9dQNrchk1dh1tuUv05DnQKR/OdTgZVrFkm4McODsnKD5laKp2Z5pLVuWKaO3aen3Jo1fvNqOZmIntORbv+lfStGIWDp1Z1hle907Z3kbtO6LtGujyRcIcjoIr4UO4Qg7jo4LOVRI+jLz6w9FeOw/KuuXYQ3LVdYrdCYs2LPECuXAHc1fShtCBasc1oYivEliMyyS2NkU05mfaiaGySyLIRzBwUXafj8ejHXLDLbMlX1ZNBI11aJy6GsSKsQXSoVyuQsnFpUdXa49LEulgXTwLkwNVUVDY59dqFgPQdaebceyyey8L0tGx90FzJJMhdfNHB1ma16vLKk+WSre8zNk18u5UY7nUXX3mvc/JPXNtxySvDZpdwbkXvjoxW8y5r58u1rLmTis5me15tyLzmy9fAstIJcAZoQ6u+o58zqDZd0PNfZ6So1wezKQ76728m0V8cHwcy/FXt1nmw1qfDj50MXRWeoxsXTOC5ciMZJbB3Ndyx+NmfD5ZOjiOYvEFOKnJ7KoObYY17Q4AK5PVcxFMO5q7erDU78c0hyG2Z9XSJ1DVpchBaK6W5r0dpGnYWVbLG4xSFch65CMDFy6wR5DRVO6B3WuL6x0kFVtnHVTdtgDhYlEEOPidFXy0WQmkFfNBOpZSc2onOpPo5Z6ko3Hx4itJA2zVyhnbXzjFWq5E5E97z1l45psbBTzEIbHnAZKuWllzte67KtrZjQVc0Viq0jMKce9p6CZdLKjTfrJj7rmY2KSHHOGoyVXe3HWWzVx344uCvadybsKE9tofdhCaKLx4gZHryK6FeHXlLkp0P04+N5p8iZdLMvEEMLFyYFBE1AMcmxP1s8wH4+KD9Y/U4EtrWsnWa3MWkzM1Ey1jLKdjqEiGMpBeX102hA1OoVysxRgjgMSMcS0pgmSm1dRXC6xecERvv35k6N0hDDsw9ZtGlXYWsCsjqLk2vKkr5Uv5GULada+y1kIZ5xHjb7XOx1lUY5I6NincehWyWmO6ll9uptWCQ/KTOr0Dkb+4z5YQtyl9r87amrKO5kJpZLmRhkhvyvxNW5fkr9Vb1F26usuldXdIo5GXzArLxaDJxCC93aaznvrqSHV8GSytcN8QMCizmJkTLFKw3PRQtrGFq6Zi6eNdNGmVInLFU9V0a6Fiz0Ude6ZIFTsVo5psupbNmdBa8KLX8/0FfKPtqVuTmxPHTRIwzhxZbXKsFGKypK0sjfLmLyuuvLK68vrLy+vp0UC6WFdNCukiKowNkugCSyfd2jW41p5WQqS2gcTY1diJHjH1BUY/F2A4Ym4FFiXMsXq7rMDcVfAdi7+mGoT1p2jQyfnzkMljFCrlXjkZrZJSyzx4jgmmgbUy7V0WaJwlG4yOgP2nfThqsgXtgjeJYZI2yx5CuZ68Lt8WNmO75KPB8cb0alZdFXXQxroGromromroWpkEjBsm0fA5wko813lsYPl8a6KMLo2IVYl08K5MXp+fnv6+61K3FarXjqh6bc3JgowjHY+rFyYAsjpK+xIIa8TJ5GurSaRvmZfzMvNt8l7nPhe1mAm1sWJHyZHkzOPLcDgp3T049Q1w/c52bk0CHKxBHFENSbEzn+GWDe+WCuG4uZ1fI1SIZxZrrn1yjNAuph1klgMfhl7jiwe+ejMVuzGK+Q1LHNdzGLtw1XbgfV8L346rXj249l8I6ce3AL4Q49+GnrYAFhoestxN51xyCZD+7yEBtVGY+4vL51QpdPZlxdl03lVxHFXNcPQdSM2OeZ/LJtH4y2W46qylTWn1ZOoy9VODtoYbItTsRkyn4uQYIYW8vJbqhwljqMtWuMy+67oBdKDLoQFxbL+nheG5Cfm7A23TykZkqN+puLd9PD4Q4fH8HZDU+jv6ZMfaajWsNRbMtJNBHKuU9aELXh7/wAfsgNVd3SvhZHVrVoxHBotFotq2rb/ADaFaFaLRbVtK0cvqWjl9S7rvxb2WZgEGQjZypaz+XZKPb+D4114Dui3RN5QPImkZtfzYhoZo3RPWnHQcGM2Nrmw5sIyDpDHGU6rWcDQqrooQjWjTqcDlZr1YVHDHK59R7BYdyQw7mej4WvbURx4Kv8ARdEzmCzkl1WS16rIoWr66u4upurn3FzriM1xc68ubeXNuLmWlzbS59gLqZl1Tl1ZXWFdZ28xAPmAXmTQjlWBebxrzZqGWYvNGLzJq8yC8wbr1wXWhda1dfDrmJ224sqzbIVVk5lZw7L349uDYpHIwvCDATFTmLo8Z9MWPqxpkbGcLlGOdr6th0VapIrkL6Unvx+FzyhZiXPhQ2uRaCgAshVksJ2MlC6NyMVSkyxlJXow6vN6J0MezYvj0aKdhuXNA0EFaELvs6jOFc+/obWRXU5ANNjIFdRkSupvAR2Mr0gv5FVX5WyeqyQk6qyhato3LiF23r11xddeVazlnmw524ySlcyZcyVcyVb5VvkK3yrdKE90umzLbRFk9DDkSqUVyM6Lur0AfXgduhx8ojlKA7dggdxNaURUJY2yRMbpeqWeZySmDRvC/dbVLr16Vz58i1Nythj6dmO3CWqRgIs42SuY3h7tWo8I7U7E3I20MmCG3qWrbsT2MNxc3IaOkIbObT4mRtcZrTGOMUk7vo0xvKbX49188MPUhtZOWkwyNo7DJVsPRq5EEw5ELbkAtbuwOyBTn5NM6lMleBedJYh5d1qb17Xm/kiHWrIUks+3mWg10txc68Fzr+rpbi1tFO56+dWNRfuBEmn7nSu23LYlijYZHVwC9pJ6VzgKIfK/HlGaiJ2yKWTe+qsfFBbTce8RlmOjMcWq5VtZTHONTp3GTG2yxRPDxsG8b45R34ZSj1J2ywEFmkbi+xhqklZie4r6kWwyK7C+vKOD6WifWRiKdEVtrOQrQEmxYqrBtkbW1DVMHzTDlwtlftR3PFWoJnwxMhj+PTcDmZLaNC1q2DXaFoFp2XdaBBaBaBacBqFzptDJJqJJVzJNeZIuZIt70STw+VpqNAUFucvi4NYw3QLRDjY/HS15OHdC9z2kMhijbFF1D5mQRMjV2nHabMJqliORQzElNa1o9U92rCnNZahk2qX6Xns21jpIR1ES1KCk5ekvRKzCwujpRWEYo2Or22XIVIHhxmC2hqq03yJrQ1vtx1WvfvuWQgMrOujLurqaCxCVzokJo0bEK6iFc6LTmwrmQLmV1vrrdEtY1qxatW8A8wLmrmLnIzduoajZC6kLqG69SAuo1HUtC6luosMTpI5Fui1Jj3bodec0LqGLnNU0+6OFvLj/AO2EyjbDRDtUdkb0WAotc4zxRzxPinxZiMT4YJSCnODQrNqKu433qe1dcpHRuAZGFC+WpLVsxWRJrXZHGI4YxI92+RdtbVqOIutMe4PNp9uSvArdqacGIOjwrg23I9sbb0zbd1o+uvTZEu60K0K2rRacDwvF4qyxRyrpIF0kC6OFdLCuliXTRIVWLpI10rAumZr07CumYumiXTxLkRBciJclgPIjRhYVyY9eVECWw6/pr9JaMI2arkuXIeumk16WVdLKulmXSzLpZtOjl0FGQo41xXlDk3HuTKUDVZqxzKjk3ROIZI1hkrmOQODpo2jqYSmPjkFmjJVkpWIbTGOIWnb6oVJHHYiljlqprd0z3vah9MDGfothkcYOYY7BfC5vM5OkybYx0ro6hLpmV6qmuzSNDexkbrydwbkGwXbdixde0FVqA0YNjT/E+pXeXY9eXyLoJV5fNr0Ey6CRdA9eXuXl68vCFBq6CHXoqy6KsujrLo6uop1Qujqrp64XJhWyFfQF2Wq3BcxcxcxbxrqPTqFuat4XMC5hRc9cxydy5W1Z5qCrzRWYXsfGo7ZEnWb2MycMcjsvEDkbtSR+MykVgs7cC0gsc16uUHtEVS8Uyi1RxRRpz2hcxhW5WclGw+aWU2KMtLTGWMkenyQwu5UthSywVWSyTWC0NYqtWadQwxwN9LWPcuVKhDNrypVyZSuTMuVKuXKtjwtHLRa8O6K1C1C3N01C7Hj29Gq1XcrutHLa5ALQraVtK2uW0rRFhW0otK2laLaVtW1bFtC0GvcJplry1L0FqHoq1yTymuF5bAA6vTapG4lS+QuWKzLG2GnVqOgTr0IPUxOUkpjjc9zw+xBGjclKc6aZRU5SuRUTmFRbmOs2ZbhihZEJ7/dsa+oKpWeHdQ5q6iRCd65z1ziuahO7RlyZressldXZ1NucjqbmnNuLfdX7zQ9XoX3NvUZALn5ALqciS+TJOTX5Zc3KA8zKbuZkdWyZEISZBb76Ml9b7u3mXkJbSEljXmTrfZRdZW+dF8y5ky5z1ziudIjLKuZKhLMt8q3SrR6DNUGBbAiwLlsXLiXJhRhi0NNhHQtXQtBloxPd0fY0YyuhroUaq6KouirKSmNKWVnpz4+/Xutss5kAm5LjaiemX54w7mTviqSuJjq1h5gp3yPXPqI35CTdcq98NZK+Sw7sOEBAlcTu1XZD1d0Fo3UStAEpXOcucVz+3PRnK57lznrnSLmvXOeuc5c5y5r1zpFzXrmvXMkK5jlznac8rnJ7o3L9Fawhbq+gdXW6ut8C5sS5rFzVzSua9c2Vc2RcyRb3LVarcVu76rVarctVqtVqtVqAtVqtU7RwLJK7sRnGTqxBFYY/EvE5rU6zX5GFqlnuTl760CluOTtXu5L/AE/K+Xcff1a8NO38Hxw7+v3/AJjw+fn5/g78de3Hvw+ONiAFQZu/Wq0MhLLadHummusa6SWeRaNCjgKa1jRqgu/DtrwPsO8X8PzxOn83xwH/AD9f4ZYQ5TM1RdK+PsBFE56bG1o14aIIIfanca/4F8/PzwPvw+V8Hh/2HH5/7NXwOB90F8L4+F/2Hsm+j49Hyh7BfCPD5PD5Kb7+r4+QvhfK9w8DmMA3Hh/14f/EACoRAAICAQIGAgMBAQADAAAAAAABAhEDEBIEExQgITEwQSIyUUBhI1BS/9oACAEDAQE/AezCcuRypHKkcuRy5GyRsl3LRkY/ZGaaOJlXZHSikLSDMBldMUqY3ZYhMfoxwHjRs1xwTXk5KMP4yOeznTFvZklOJz2c+Rz7Q9Jt2Wy5G5m5lst0Wxyb1SEWPyiMHIa2vSJgM3vXb4FA2C9EByRvRRRh9aQ/YxQS9kqOYOVj0Q9J+++Ed/g5CSHrggpLyZI7TcyM2btwiJhMqtkcaRsiSjtFr5L02E40YmkjejB+4ncjLkpm+LI0S96RHpLSiiitMT2seWLQ0jaj0cM/BmaelkPOkTAfes1aFpLLtOoidQjqI6SHpwz/ACIqnZyHNnSo5bgPRex6UUVpfZfYpNEnrwuJKNnEQryQMHsk/OlmSQpDkS8k40x6slpg8MjLcLxpP0T0iMkbjczc+2mV3NFHCyTgcS/BjMHsyOpF6ZH51ZJ+R6v0S0xEMm1kMqkjekTyWSdnKF4YyeiViwscEvYpRIbWbImxHLicqI8ER8OPFJFa45uHolJy9kDB7Mwp0cwbTK0m6QyKs5UdH6HpjLFkOaKd6bpEfZL2SkIwwpGXL9LWMtpCe5dk5qI87+jnSI5Iz9jwJ+icHF6LyLwYTP3OKZyUxYTlPSXolpj7IiHVESfskYYW7Zky/S0jFydIlwzSvSM2jHLctJZ19EpOXZhyfTMsdy0TE7MJkimOCRtNrNrNjNjIpodlvSRLSJRRQkyhRRGcUiVtjgzbUNIxcmY8axolKzPj+yjFHajJ+uuLhm/LJ8LFrwSVOhGOW5GeFPSHsxRaJQ3CxHJOSck5RyjknIOnOTA5MB8NjZ0uMWCCOXH+HLibIiiikbSkUMq/B0i/pGEcY56NChFavh1Ix4IxNxuM8L86YpUzNjuOuGe6Px86JzonPic6Jz4nUROfE58TnxOdE50TnxOfE5il4Wm49lFC7bLNx4ZkxNMw4W3Y14MkdstMeXYdWdUzqWdSzqWdQzqGdQzqJHUS+bh15+JsS1aojITWnFw+9X8VfHRDA37IwUdZzUSWZsjlaIT3dnoeWIpp6oWnEK4aRVsjw9k+FaVr/GlZjxbe3JK5a4X+XZlybnomYp7u3IriV5MODavJS04rHtd/AvixY6V6KIom0cTLjcXrhh965P11Rw/vsQyEP/L2Z43D4F8OKNvRCRRRtJwTHgQsKQlq1ZPFRsIxbMWKhQKKKKOXUr7J+h++9fDgXjSIuyQ++iMBQooorvl6H7+ZaYfWkWJ9kmPviRXax9uWVR/w4X41TNxuHIb+CAiyyzcN9i04nJbpf4cMqfZZZfwp0KRuNxu7JS2qzqXYuKX2ZOI3evkvuXgxytf4EyitX4M+a/C/zRltITUvgxYnkZnwrH2UKBVdk80YmTO5f6YZf6KSeivswZ1BGTI8jNooG3sckiWUc2ydfNelWbWbWUyiijazZIqtN1CzNGGe9UN7TejnQOogR4mLdCZLJt9j4xHWM6mbE5feuTJ9aRi36NjNrKKNptZy5HLkPsrTD7Nv42PK0b2xYm1ZLHKJuMKsxxTRxUKfZgdSMhdmSAvJCFCm0TW4aojBsjGtZvxpGO50YcLj5GvxseRnsXDsnjcCMvJAlBbTMql3YfZH9aJ4GdPIWKaJY5v2chmKDiQltOJW8fvWDpmSToxvTbXZKFiVdmR6RdMxT+iP60Ph7Z05y5f0eGUvbOnZHwcz8TioP33YsmwhxiXs6yJ1sTrYkMm9WtLZl4nluiXGp/RN2+xRuJ6ZF2viy6IxumQ4nGkRzwl6L/4bv+E88Yezq4G//hLi4xdUcRnWRdyKK14dVAs8nHe9H2RkieNv0QuPh/BKaQ8o5N6LXhX+evGLwUY/MUcV4mWPtXbw36aWzjP27sWL+6VZKFLs2m0yOS7V7Fpw/wC5RRxU/osx+YnFfv3rt4XzDXjP20evD4/G7WKsyTS8PVLVqzJHbLsXsWmH90UUcRe7zpiVwOJX5ldnIZyGPE49jOCn9Hg8HGx86RxbkPhpHTSMcJwVFPRPaZITk7IpiizaymUzyjJic3Z0zOnZyDkMoowL81p4OL0wS/A4v9yKvwdMzp2dO9cy7eDf4lotHG+tOG/UyZNiOpkdTI6mR1LOpZ1DOoOoZ1DOoZ1EjqGc+RzmY3uRQ/RL3pg/dFacV60wr8Di41Mh7FN6VrmfjW9ODj4PGnHT+tMU6iZJ7n8FllllllmCe11rk96cP+6LLOK/XTB+hxn7EPYu3KmzYymU9OGrYWh5Io4tqfoUGP8AFV86H/THmtFmSDbNrOH8TR4LRxdOOmBxUDifyn4IxrSPrto2o5cTlxKoo2o2olSRKW56N0btLHkohPd2cPwXNhusnwFQcr7YOjG/GlFI3Fj8m1FI2o2orW18fETvwLRo2lFGxCilrRi4meJVEnxeWapsoorXG+6hRNps7d8l9EnJm5kH/wBI2RxtkuzJLarG786X3WWWWWWWWWWWYmQ8rVqvZzIoef8AhvlI5Mi5w9m+2Xrvws5eJnTRfo4iHKRwOVybJNL2Ty7peOziP1LEyy+y+6+y9MXsh6JzaOYyOeORVInjp6KTXkXEMnm3HMRDJ/dLFBsjhr2Qv6OMjeM4TLyxt5WKO3snG0PEco5TOUzlM5TOUzknJOUco5RyTknJZyDkHTnTshhaIxaJJSHjo2MUvpkkWZdy9EssiN34MbbXkjNo5hya9EYJeWSlRmz7vxRDERSXc4pmxHLicuJsRsRtRtRtRSKKK+JM3xGsbJKFDRR0vm6MfDnS+CPDwj7NuH+HPgT4iK9E8jn7IR0s3F9t9njsvS+yyyy0Xr41pEoWeYmPMn7FL/5R5+x5oR9HUP8AnZD/ACV338D8kfxZLiH6Q90vYlRfZH/0ktFr/8QAKREAAgEEAQQCAwEBAQEBAAAAAAECAxAREiAEEyExFEEwMlFAIlAjQv/aAAgBAgEBPwEd6nocTBg1NTUwY4x9i9GMmLKJi9RZYoGh2zGL1yh4RuMxxfk1sypNoVVlTzExbIr4NVgZSpxx5NIGkDWBiJrE/wCRYNTFmx++DWVeuUvXBccmbVvdn+g7ri/ZSXjnnBu27skK78K9co+UKJr+DcjLJVWWasn+loxyaD4y9lP1bNvHHLO4zZEyPu8s3rlC7tgUcnbZ2mdp2j7vV9WTwbD4fRjh7FG+Mmg1bA45IxtgkNWrlC+DBgiZ4L2O1T0NYfP6EjU1RqYujKM21GsXyZGO1coXV42V17vL0OORrHDFkQs3g70UKbY1JlTeJ3Jf07kjuS/p3pC6mSF1f9FVi+DGhlf0UjJk2FJWjZvBu7K8rYyOA44u7RWLVqmfBRpfbu1nwVI6vHCFNyI9Ovs7MSVOUfMRdQ17ITUlZk0V/RS45E2dyR3Gb2XsVpcJcFarLCKdHLy7NpLLFXTdnBP2VY6u0en/AKJY9cK1P7RRnq7yK3oo882xZPyK0mZtkbMmTJsjdGylUtKWPLKlTd2o1Nli1aW0il+16lZRI9Q8+RebVI6yKMsq0irJMhU1O8d47x3jvneO8d8753pHekLqZo+TUJVpM7kjeRvI2kKTMsyZI+zbDyfJJ1HM1ZhibQ6snbJHqP6TruV+nn9O1WG0SjLEsXqw1l+P48z48z48z48z48z48zsTPjyPjyOzI7MjsSPjzO04eXZLI2l6NmKb+yUccYwyar+mn8FmLIVFJFSokhEHlWnT7h8M+IfEPio+Kj4qPjI+Mj4yPjL83VP/AJtnHCL+uCj9sc83T38Mfh36WX0P8ueX3wyT6pR9FSq5+7wpubI0YodKLKlPR8G9n4OxIlSlG783oPErSY+qa9FPqs+/wy5r3eUtStXcn44044jessxuvJTpqKvWp6+Vxh+w34K1XL8W9HTVdvD/AAMXJexW6irnxypz2jevP6vS/bh1H68UTl/8z2xu1CWJfgYuX3atPVcc2jJx9C6lj6hsbzdPBTqqRkckirU3fLuZjgQ1aHsXrm+f3bqX9cl+HZjefwK8PYvVs/k+7dR+3HH+aksy/Nk+7dSvN8f6Onhjy/8ADXhlf50ssVBYH0zIdPj2ev8AFWp6v/KijTx5d82X+GcdipScf8caLkU6KjyX+JrJU6f+Dg1apPDx+TB4R3P4UKk37/wN4NkZRlGTKMoyjZCebMdGLOtoaeSjLaPkSTOxI+PIdBmooZF04umHSivZOovUTLtRo/bMYM4N0bIyjKMo2Rsjdc6voyZtkyZM2ovh1izEpJwlgaaZR6j6Y5JIq9RnwjL9kK2rIyUkTqKJUqud6MNnZvBOWTJkyzNsmTJSeVyq+vwweHwqx2R00I+c+zqaf/6R6Y6zksDZKo8YtSrOJKefY5ncMnTq0vQ/w0X9cqqHA0NDQ1NTUUDtkfXCU+3VyfuivDSV8f8APgkjPBI6T1Z+hjizBqampoaGhSjjlVeEdw3zd3hZcKsJZ8nTVMLDOqgqkcrg1jhToykR6X+kYKPqzGZG7ozaPojyqyWDPB3jaPrhVqZ8W8oqRyrPwSTYqbFSKVCAljhL0P8ABEjyrYMGOULR9XrT+uEYN+SXsTTMXUsFOWyEYsx++GbZMkX4I++HyYnyok62/oyzzyhZ1VB+RdTE+TEnKEzC+jBqU5pLBWpJyyhU9bYR4FghVjE+Qjvo7x3kN8UrYI+jOvk+TE+Sj5Ksylji7wt1HshDZnYR2EdlHYR8dHZO0dk7B2UdlHZR2kdqJUjozIvf4Yj9DjxpeTAomDAzNoK1WOWRjqsfgUcjiKBrg0NCSwVY7RuvMfwRJeh8aTwbCkru2CPg3R+zzzdojyLI8nk8kkxFSlh2hJY/BFk5WfLLO4zuSO5I3ZuzdkW5PBFYVorI4iiNCgSji0DBKtq8CrZeBXZNZiTVvIpM2ZszeRvI3ZszLPN+2xwZh/hoQwsjsmbMyzJsN5tk2HFMUEbM3ZvaJUj+BJmo/HPCMIaROOFwpw2kJYthGDBgwYNTU1NTU1NTU0NTBViNeba5NDQxbFmsjji/kyzYprYqwSETxgd+mxk1NTUwYMGDBgwYMGDBgwamDBV9GDxfNkZthq0oGr4U/wBiqskp4HLPCEsSO8jvI7qO8jvI7yO8jvo7x3jvnfO+fIPkHfPkHyD5CKlZSO4uGBq1PDNUPH2SSXq+TIkfqTqmW+Sk0bs7jN2bM2kbMyzZmzNmZfHBgwYsm0K+o44Edxjk3w1NTJJmphGqMI1RhcVwxbBgweDBgwYMGDFlJmzNmbM2Zt/bLhlcJf8Ahp4Mpng2M8Zf+IuP/8QAUhAAAQMBBAUGCwUGBAQEBgMAAQACAxEEEiExEBMiQVEgMjNhcZEUIzRCUmJygYKSoQUwk7HRNUNzg8HhJEBTohVQY/BEssLxJWB0hJSjZLPi/9oACAEBAAY/AtOajpxOitEFX1FFTc0fmmdn+XKYvenHi0KMesiXB1ABe2cFS9XGuKyqy/ewCmkfERfF1pQpuwWOCEe7OvFNZqze4nAKkrzTgMAqDk2Snpj8xp2ntHaVSOeNx6naMtEYa4C68OxUvjHC+9rx6pC14k826RxUllfMHAG8Q45b1NA2UvdhfB3YKPZpdqVI315lH7AVlA3yKW8aB+I61rnPAaBdBO8qXVyNNecOtSSbiaDQ6d4q7dXE9gQ1tndH/wBTgg4OvM9IJjxm6gJQDTG3tK23xuHsraOA3oxl1XN0XI6Odx3LzOy6qOF1/wBCs116epR9vIf/AAk649rNW0HELVutsdRvovLIu5V8Nj7l5V/+tdK53ZGufIfgXSvHwLyo/IvKifgWNqd8v9lU2t/uK8oefeUfGv8A9yDS7H3rYHPbj90FmAnU4BRZZp2yLlBmN6e0G7DkKZlOhbzq0a7qT4ZXc1uGCfejePdhoGBzVRkuHIy0WQE0OsREUDpW+leoCrsAdHHvpmqkY76rmj3LwZspIPnHnBVkle49bytmVwd2qkxM0XXmhOHjVkVDlVrgexNbr8A4nAY4lPcHmjzW6o/YKl/iSqP2QoD6MwHeFRzQe1UDQAtpjT7lhojkaa3Cjdds/mU1kmdE4M3Gh7Kq/stA5qa127BXPROCj9YUWpZzn/RBrTux0fVA6aClV5p9yirdz9FXnMutPNdRYDDcqWiB8QOTjiE524xBWljMzB+ipcrxwVGWdx4roHCi2o6I+Kqj4h30XQPRGoeq6h1V0GPWQujFfaQo1o+JXS2l00IWyNouwVliM74aMLqsO9eDt+0rVzapp6tGsl3mjWjNxXin2OHPOritq02f5FtWuI/CvKLM7rurGSyD4Cqieyj4CgxzrMG76ArUudBWvOxTSHQMIPOFUX0spJ9pXWustPYKLXOg4ghpwRc6WJ1W05qax+w12Ra4rBz+9UvYb0GDZNMiqKukvdkEXN2G9igoQCA4nHgtZIPFt+qa0M8XleGQRmjG0MxxWSw2UAStkqm5GyyYsfiO1PvZud9FJstbGTs46IvZKl/iSpnsBNFf3reS5wTb3ZkhLq468VRgHatXVqv6mPuV2P8A9lzHXfzUZ5tMlK7rwThwACzRKGG7SB1BNw5xxV0jIpnZoLHtDmncVNAwm4ImkA7lNjjqz/TRVxotiRruwoveQ1o4q7A2g9Irp396xcJB1qowIzC4qvg77vnmvNReYXDLrTGhh22X6q65juF5PDBuzUH8FDE9GmdmizSakviYw5Hettso7YysC6vsFVLJqDfqytW1k5/lFVfDaafwitiyWnP0F5Nafw15NaKeyq6mT5V5NL8qws03yrCxzIXrLOKqgs8ocDmRkgQQeOjejE4m+3ed40l78GtFSi57zT0RuV0lQxhtS4kJt3AA1f2K5CBjTGmACdI7EMGXFOOGdVeW9XnDDgr1AmTAdG76IEZFdHUIGlOpRD1SpgfTlKj9lN65WclzQg4jmu+iczczJBmRcaLPJVz0FvFEYgjBa0ed+aq4YuVOCAFbrcSdHVoB6ghupwUeDdp1EyvBUWCmr/pNUnsFXyr0gr1bgrzNkjeE2tMNypTFVWNQmvGLa49aqs30rUi9mn4Gr+caplG4sFG4q/eceAUnYrN/AR/hGqZ2aILTG+l0hlKVzWMv0V6+7tVDI+navO71iVnoy0Z6M9DuoIkChcwErOp4BYtbRMPpNOlw4kBEDNUexxAzu8E2eOrH6zxa8ZZRd9V68UaerSibTzzRG7xzWBQeACN/UsMlShoVVRNOYaKpjaPq2tdlNHUox6pVo6tYfoFH2KHrkb+ei7zpPRC6FneulHZTBePZs8WqrHBzSthoA6lSanUhStfetiZ3YdNXnClfei26KK/rDVp37kXmMFykjpTHRmO9Z9y6uBXRtUA1baX0AtrrVFL/AAWqXhq0T5uQXO01oVVm5fkssOKadJa2nUiHUT/ZUI/6Kk/hKNzs6aG/xmaclTTu5bh1LEYXQsl7wm481pOl0eVVce1zX19ylLiLpFVAbtKzf1Ghrt9KImTzV1ApjutP7CvzQTI8bjNp/wCnIj9lWoEYXXV7gofZUQwreqFqmdKR3Iue7ErPRmr9TcPOGjLRtNqqAYaHy+bkNF9me9OFcW5hNlG7ArcqDVd62dWOwpz7oNBuKFFZydzkNMmH7oKYepRXSg1jAKBXaLC6AhrJBUbgsCBXiFfdtN3BVawtQrowV6gvHetkAJ/YouOpU38NNb1aP5zPzRo6h4ralHXhyMeTx0upwQb6g0EjdihML22K5rxb73U5AmM+5X3M7cVQiqu6zDdUZKx0r0v9RoZTinxtG04UKub8kW+iqne1UbU/CtiBzR6UmAWrZic3O9I8hnsL7Q3+LNPooz6qZIa4VV92JcjmjiFmEfOGjVE7TPqiKYDkCzMOfOPUgBlpvtGOXauornLB0Ve1YFnuciWgxniDmqsyBooS7m38VQyE/CVz3fIVddaLvaCnSsOyWUUp33f6p7vcnHrT5H8FncbwCPaqtIV1xwAw0Mr28mTsURp+5U/spvsJ0j+aM1A5nMkkaQa50W09o96oJW96JvjvXPqVz1zlg9VvIYqrAXBFxIABpiaKjp7z+DNyFyzyv47kRDZ7nrOkQa+43Clc1tWqnYwryo/hlRQunfsjHYVBbA32mkK6y3Q17aKrSCOrFOMTRc3CuSpqSrPeBaGPAoes6AIxtrWTHFuJUs1NgVcKou9JNBtD7lA6iDY2gBbOLfRQkv0aeKqDUaW/w1buFxQdbVsuoRjVN6wgE4jEBAjRVR0O9Vza5CixWrgOHnPTII+c3a7EWRyPDm54raYJPoVS5cPEqomcrt5pHYsWPqqbV3tVbp70QxzwKekncKqHdtcgHhGrRTMR/wBU89afhvTWBMdjewqvGyNbXrWxKE8q6Mic1TkvUJ/6Sl37Kbh5itkE9stAe1wpcdRt0jgg03zTLFbLKBYx1ovJ+8qngzFXwaPuWFni+VdBF8ivzCGOMbyAtXYIIzxe5qJfO/HcDQaOeVziVSuigC2mrrXXo8VPIz2XUVG2tzh6+0rtrsrZPWjNFevljDSl/cVVtXNORDziqRsDexeCs5zhtdQUh44LJC/uNNF6lXHBo4lXpdt57lej97dxQe3IqqHsK24ZsKhru/VYYbQTMuajiqUoqUC4U3rEe9MpxTIBhfxVCx3arj6ivUqnBo4J08layfQIPaMVUFEkAqrMlTSE/wBkrfuUPG9XkRdbVaCThq/6otZsjqVS6qN3F1MENa97z24KgaFQhVbsHqV6ov8ABUfTkhvEqz+wQp6+gU3HzArbn5v/AJRy6nBFlmAll47gtZaJS78hobn1rLThisaVVcKrEVWyeXes07mdW4+5AW2zuD97mZFPtLJNdeNXlquINoXV4JrBo6o2/U6Xx+ia9+g+wrQDvYfzQr1/mnYYnJNY4UOr0YaTXAUQew0PWnGSl+M4FXZ8DuO4oOqA9uRTb+TdyA3pgXU5YrVu9n9NNdEvsFOA3UUZ7fy5EB7VOOMX9UWnNOOGAW1zjiVXRgVVAelox5EA4vVm96tH8MrWNAJEaitIMbBWpDdm92rA2cd6xkgp1Lp4e5eUM7l5SxVFsb2AY+5eC2eV00mTpKYfCP68ui6+QFiqtK2gqVoqcjWWeV0bupBltaIj6bRh3IWhsjXM82h0ze46ZnDqGj4FON9x35rv/NUPEJnsLNAufWmmnDQK5PRaQudtjeU5rhjVVQNU48Boa4Vx/oqrLTL7JTvcoNO5QAK0SilRH9arE4oe0FjoyroxTerHQe3kWf2lZverSeEau0/d/wBEz3rDTRZY8OKdBAcMi4fkORloyWGiqz0UXDTSmCqzuWXKL7NKWE4HeFqprsVoHc/s0Ml3c12glCvOdtaPhU+P7lN/73pw4kfmmyDNmHuVNGLiQqBY56GY5UQlGe9AjAq9v0ZbkDle2isVUeaaoFc7TL7JT/coRhv05KA9qlxxu/1QIV0mh3Ku/kceriqu5x0BvIjd6LwrM7rIVs/hqnqBN7Si02eU8C0Vqj4p47cF0T1RrSpLPAfVlkB/2jRWhVIozI7gENaIoG+sUDJbq1/0wtrWv7Sr3g97qJwVPBGjsJCH+F/3leRt7yhWxsw4YLyUd62WyM7HLZtM47lWK2Y+s1G6Yn9jleksz6cWbSo9rh2hVbmseVWqbZ/tB2OTJT/X9VdOIKowaxm7iFenF1oyZx7dOB3KbH9wh7R/NVPEfmgT5wRdELzOG8acEaEDtTUN+5U3OWGm781NAZhiiOKkhDHSUosoO/TJ2FPr1KHDHHTmoB2p9fR07IvE7ljG8e5Gkb/lXNDPeqklzuKyV56K5xr2rN3enAk4HenUUR61bv4QTd4LU0VvYn89NBmv+H2E1lfz3A80K62VgY3ml29ePtUjz6ooh4TG1x3NOLitXYIWWOLeGZlXnPcT1lXm4HqQbM7Xx8H7vetZEe0fd7bGu7QiXWSOp3gURdBaZGHg7FF2qEw4sKIkje0tzqOULNaayWfdxZ2IPjNWnetmKR7Bm4LWsNWq8y9TrCHsKf8AgBNb67vzT+GCbTho22grmkdhWTvmWLSfiQ2Q6nFEs2SVlUeqVdka4doVWuFO1ceCq4eMfzjpyV302LJY6JB6pT+GChAO53Is9M8U7WOo0sXTM71eNoZd9pG7NCDvq5E66LD1lW/GfiXOaqqpVUa5UQb/AOtEyNutG+qcGAqT2VAabwre7PZ/og5z2tAbmSmXdOqiqZzzW8VV23M/GR/E6NXHR9pdk30esozTvL3uzJ5LHtJLPObxCbLE68xwqD91fke1jeJNEa2i+R6AqsI7QRxoEB45oPnFuSrG+OaM5jNYRal3GNF1me2ZvbQoh1nkBG66sdMlnkJMTxT2U9tW1cRTHNTX+ivJrY4XMf5pKHVGrT1QtRjOYe781ImYVwXMHzIbvf8AcYxtQdtCmWKwkB7QsBGfiVbjfmXM/wByabhF3fULoT8w0vHqlO7AmDDBh01Vm96HpXcFmsgFzQsWtPuR2ArpiFKKRmtl8W7Z2ubgjZJn1mGR9Jc17m9SaDwxqqF0bXLxbwK706sl4blJ7KjPC6rdjSpA+iBeC/arQnALYnma30QV5TP3p0r5XvoMnHBP+0pmkXsIhwHHRq46OtLxgPR606WUlznGpJ38qqdYHu2XbUfbw+51NhuzSb37gr9pmdI7rPI1tnlcx/ELU2u7DL5p3O/RYrE1RttkbtjpGjf18htln2mV2STzFIwtAaHAAqz0zvVHen/w1a3cGNCkxrtn80RxcPzQ/JdH9Vh90NodivtZrDXJVuv4OwrRMzN/EUV8uo2tMt65x7k42ems3VTNbS+RjRPw3KT3Ijg3QxrJbgaalf1UHam1NKsNNA0HTa9+IUJ7fyXiWOLRw3qYyh4rVwJNQEXSxl9WHv4oxea9pw61ebkRhROHUgT6Kk4ySDLsQ7ShGX7fCiw/JR2JnnYvPBqbG0UAFAFrDjI7CNvEp00ry57sSeT1aYrQP3bgUyOy2eNsdf3rs/0RczZc3BzDmOS6WVwaxuZKMFmJjs/1f9wyw2t9QcIpD+R06yNviZcW9XVyP+F2khjv3T+vggJmUaw1J4qWXjshWscQwfRS4eeVvpeCF4P+VX9unsrePhQkgbfG8kZJr6EV5eaxLc1q4ruOdeCiuWe7StWsKhux6xzW0IqrlxznOdUhu5eQz/MNGCf2J57ECP8AT5Efa1NpnQrZlp7ltStIp6KzWzdp1raI0T+5QV4kf7VfiLbo5rf1VoMjzcdg0V6kRJZ5Hi6W1ZjVOllGrqwtaDmmRXQLoyanVwwW1uYoz6/9FnvP5qu9F7jgAvC5qa2baPUNyMP2dRxGcuY9y1loldI7LHTgr3MhGblRkYcd7nCpRms0YbM3c3zljyNUThI27pL3GjWipVIy5sIyaDSvatXJPI5la3S7DkVWHJ8HlPj4x8w0Pgdzs2HrTmPFHNNCNNRmmwyupaGYH1hxUkdcLmStXst/JSe2fzW+lQnc3ayxWrY0DtctW6Vri7nlatjwAulXOPcq1d3LC93LM9y5sncuZIsInrCBywszljZz9VhZ15MSvJToon14KXsCa7fc5EfuTfZOnPkTYHaAVnLsBrcz2LAjTV7qdquwnY4+ktmRw96vZ7ChN3Zrh3LLzjohse4m8/sCiscBuCQbVOHBZ6cc1rptmAf7kGsAa0YAKgCz2kbSxuw47fUdGeiz3Rk6p0uAJGseGnThpDIo3PJ3BVdNE08F41uycnDLTVMniNHMNQo7RHk4YjgdDbZG3Zl53tciO0Rc5hqvCQ/Yljb7upWmezEPZsg0FU4mlbxWspWhCDyy6DxjQ8WaewuZ/sXMp8C2QXdjFW48/CFQtcO2ipT8l/7Kl0/Rc130XnfT9VznduCrrfosJvosbS0e4rytq8o+h0uuyMbxqpHdgC9mPkRV9FUr5pWYKzCGnJOc7mlmCia5tWjE17FzG9ywY1bMsrexyxlee1Yz9lKKjrQadoRgbNHgBs1qoaWiK6zHByIM8bWYnPFeVDuVotRGXi2n81BahkNh3IvyYQN5x4oMYKNbkAqNxKx52h0cgqHChRilHW0jeFRBjGlxPBX3DxzhtHS7Ct14OmqotZNVkX1K1cDbo0Oje28HZhGM5bjxHIfY3HZeLze3Q6IjD8iiDnyHWC9da518birkZiLesJ1+lXOLlTZrVULAVgG+8KlBThRVIHcsm9ywDe5Yhp9yNLoJ6lVrwD7IVb57guPat3ctkAe5ZrEBc1tOxYsb8q5re5Y2xU8LQvW2Tr60AyyhwrXpKIaiGJhApzlSrB2ELpPyVDI49d4JsuDngU2nLWvfcfShuLnkDsXSu+i6VywleBwWL5O9bRkPxK41rve5dFTsJXn+9xV7Gu83lm751l9VzGobIWy1o9y5jO5Uo1OeGN2W8FCwjaIvO7Sn2eYVa5XJG1buduKyxQknBii4nMpscTQ1rdyqcGrZHI1U7a05p4LCd93sXigb29zlQaXRyC81woQjqWulhzB3hUcKINiie7sCElso4+huQGGjBZU7Vs0Mg5p/orpVdF5ji0jeFdkdWeLB1fO60WuyKdva/EHkMlbgQahMtEeDJB3HeOVnor/ksFw5GZW9YactH9+Rms1zlmVTErBRwj95I1v10bOao4Aq81jB8Ko0VKq/ErxtoiZ1XlTwxi8TaI39jvuqFXrkbz6wVLru5cx3cscO1bRqtkU0XStc0Ua/Pt5DH+a7ZcsULQOdEfoseQ6xyOo1+MftcjHRlopyMuVlyMuRgsdGf3e5buScFVWaKvMa6T+mnKnYsSShHS9I7mxsFXFXrTN4JCf3UefvVfB2vPF+Kp4PF8gVfBmsd6TNkhVlc62WP0jz2fqmyxPDmOyP+Rc3fTNGMijgaFdeiKJm99dEsXpNIRY4UcMDyA4HEJkrnNBcKntXSjuXOJ+FZSH4UaRy9y6KRdFIe5V1D+8Kngx+ZeTf7ljZx8yxh7nLCE966D/cugb+Iuij/FVdVH862hCPjWOp+Zf+H715K9Y2STuXk0ncqeCOVPBHFV8DPesLL7lXwbAblXwfvQrZx3romrFjAsP/ACKpw+BULm/IsXO/DXPl/DWD5Pw1jJL+Gq1kOOWrR2ph8C51o7bqI/xJ+BVrN8qytFexcy0LN7h6xU8jgBq4g3kCz2Voltb+a30esoyyO11pfz5XcmhTZY6iwzuo9u6M/dFziABmStX9l2Y2rjIcGBXp/tIRerDH/Vfta2V9yvWb7S11PNlahH9q2Mwj/UbkhJE8PYd4VFej2ZRzT6XUrs8L2oNihe73LWPIdM4d2kWho2X59qd1DkPs7+1q8/vWD5B2OWb/AJl5/wAyxDvmVbrvmVKH5kBdPzKoZ9VXarwqujz61Whr2rmBU1Y7lS43uQ8W3uXRN+Vc36LMcvPRnyN/JzWfJwWKw0Wyc+dNd7tIEbb80mzGziUXvOstEmMknHlvhkFWvFFL9m2g1lg5p4s3fcGWZ1BuG8ngtd9oVjg8yzg/+ZBrGhrRkByC1zQ4HcUbT9kOunzoDzXIsoY7QznxnMKhVHjkyBuY2k7tRGjFMk4HHsWaxVcuRhpBzNU3DFV0dWnL7r+mjJV5GOjD7p0p80VTXHz3ufpNqn6V2DR6DeH3Nn+0W4XDcl9k8t00poB9epC329tHjoov9Mfr9wLZY/F2yPFpHndSElLr27MjeBVCKrYf3oElp5E8PXgg9Ad6adDPSZsnRjyaaBives+TjyMx3qgeO9UBGjnLMLMLMLNZqlVQ6AKOx6lXUyfKuiIQ2CuasGHvXMPeuaVzSsQQNAL3IsuGywnNz8z7kyJuTW05VStWKyu6l4qOKMdlVUyMPUWIC1w3PWZ+ibLE4OY7IhSQHz20ULnij7tDySSaBC2v8njNIG+l6/3TbezCCfYnHD1tNeB5DZdzmo03hOKoN2iRjq1dS7TGqqPs6009lXJKxv8AReKFV5GOjHRloz08NPNCadW2pO9A6tuS3LJZVXNHJ4aWO6iVHXO7yMByCSQFWIXI/TcPyCvgX5Dm9+J5dSjZ7I+kQzI3qp5AF4mFx2mpssZq12SoByXwuJo8UKDWijRgAi+RwY0ZklXbO10545BYWaKipaYXM62q9Z5mv5L4ZBVjxQo2ebpIDcP9NDh1ciJ++tE3sTq57tDYIGbW87gFdiYC/wA55zKoNpyuTAObwotdZrxh8+Ph2IOadk5FZ8jPfyqFUVdGKZXimdnIz5dE3PmFNPUsNGaz0hrQ5z3c1ozKEtqN9+5nmt+5bY43UfKKu9nRVUYC48AF42KRg6200YKSzOziNR2Hl62Vwr5reKrKaMHNYMgqaRJC8tctTLszgZceSXgYkY6aaXGnMNU1UBwCaxorVAc6V+LiqDZ48jDCzynD1XLqR5I5OfmrPS2vFMp6OnP7m/TIEJnsjRhoyWabHG2+93NatZIb87uc7+g+6kc1xNNkgjKmltxtZnDbk3p0M7A9jswVaLOwktjkLQdE5/6f9eVU5Jz/AN23ZYOrR1LPTHNFzmmoUdobk9teW/t0zM4tTuxUTXOAvux0F7/pvW2DHH6Lf6rxUjxTza4Jp4hPi4jDtVDzm4HRlo4IL36c9Ab6ujPQ2nFR9nIPJyWOinFR+yqci8RUnAAbytfOazvz9UcPu5SRg/aGjqTYLbEZWtFA9maMdgs5aT579yc95qd5O/RJaj+9NB2DlWh4rUtuj36O1C2WtxER5jG71c8Aip9e9XI6mGQXmE/lpYD5riOX2jkSRnNrkzCrRmsNGu/dRYR9Z4rHNXhvTfZGhwHMlbX36aaBhygabtGSzTR6yjrw+6x0M7VHQeasRyDbnDxcezD/AFP3VyJl879wCxzWtj6SLHtGj+mi9oEbW7PnHgE2KMUY0UA5U1PNIP10tsFrcI6HYecuxX5bZCPirVawVELcIxphrm6rtGBB5LXe5U0yHqaVJJQXr1NGqj58puhNbTIaKOFdMEvrXe/RTRgs1jox01GjPQ0+smV058jt5I71H7I5DLNFz5jdH9UyGMUa0UH3VQ0u6gvHuuM9Bh/Mqm5OlsxuPOJbuKN+B+HUqat3cqR2aV3woPtb9S30fOQigZQbzvPLfC/mvFCnWeQGrT38jHPQyGMe0eAQs1mYZXM2bjd3aV/ipdn/AE4zTvK1NkjDnD5WrE1PHILadV3AZlVoR26KFbJquvQ2Zja055/JFpFCHnRXdCz6nlPf6NHIcgIlV5F3cVgNLfaCZ9zTRRCo3FRjg1NFFlomtx5rfFx/1/yHNH3dH7Mg5r+CNYDI30mYqjq10UaMUHyN1MfFyMEIIrznbyrrGho6ldJNOCyDGBbA1DOJ5xRLRVxzcczycQrzO5OjdzXChVwuvGta6JJfiKL7QTeea09HkzD1Co6+iNPDTnyB2chnthR4feN95TK8E3t0Pe7IBQtPOIvO7Tj/AJ0iWCN9eLV5HGvE2eNnY376mlsFNgbUh/IcqT2SovZVPuQcBzdNE2vpKOno/ee4pvYEzHeslHCKeNeGqn/LRpLuJrypT6pUY9Ucg9unHRwUfw17+QPaUQ9XSVgupY6MNFVis+pM9lM9rRYW/wDVH/Laqv3JbjV5DV7qLNVVeTiqJh4Bv56MkFH7Sj9nlnk4ekEEz2tFkPpPu/X/AJZU8vrXXpjh3RDWO/oqcg8oDiGj66MtDSPSUdRu0HRhpNEKcj4k2nBNunJNPEKCb/TlBP8AyupXVysMSqmKSvYjeYW9uh0kh2WipT538+U19yy0YcvFR/D+ejNVTmjHgmNdnd01WSC60cE3s5B7UzsTezgmjqUrRnSoUUo85oP/ACmqqfuxY4TWmMp4INAwGGinJ48iMHIU/NZco9iOjr0HfghyBxqm04JhTcNypxUlidz4nHuP/KKDEqp5Rhs7BIfS6+CuWq/DJvvheKe1/Ya6L8jg1vEox2KrW75nDD3K6wHrO8oqip9y3tZp7eR7kUKrDQU3kDtTR1IYb0Boit3mO8XJ7/8Ak20VQYDl3G1vybLQFt01rsT1dS2mtPaFXVXTxZgg0Wi0Ae2rzmukPGR15AAYaclXT18odTmacuR7kdA0FDTREe9DkOjdk4I2aU+Og2T1jcf+R7RVIxTrRry3PcQGtFSeCdb5RSMYQj+qOGX+SDvWbpwPIOgVQWCKH3QtkAq9uDh6Q4Js0Z2Xf8gq40VIx7yquNT9xedQAb1qoqtsgO2/00I2ijWjBPJ+7OPJx0Z726cOQQj3aAsEUOXnyDPEC+F3Ss/qhLE4OY7I/wCR1kz7o/NV8Fn1fpYfkg9hq0/dbTlSMUVSa9v3NHklxyY3EoG0+Li/0m/1KDGijRu0O5OfIJWHKx0HtafuQUNBQWX3bprHkcXxHJ36FVjNHDnMdmPv3SONAAjNNn5rdzRobTKp5eJotmrlndHV91cvF7/Rbito+CxcBzijcFXek7M8g9nJosNOek8puWN38+XkihpKboyWf3O5CQExyjKRmYQit7dndO3I9vBVaQR1cloNolijvua0Rupdpx4p8MuE8Ro4cevltpkZG1WeKFniOJ5x9AcU2Ngo1ooORi4LZFVhgtok/c7bmj3q7ZIHzetk1ET2q4P9OPLvXiIoZR3O71ccHRSei/kYI8afdU0dfKs2FbzqfUcutUSUKLHdoJQ6lh97QioRdYZrlfMfi1XbfZ3Qf9QbTFeglZIPVOmaKGkbb2uEhyCbbIsZYsx6TeCD2GoPKMUgq05oASPoiIxdqak8Vzq9i2Wd6zA9y2nE/c4lbT0WwRukI9EVWJbA3vKvSXpXetpoXXn+i1XZQ2zx1qDTaQ1w1sP+o3ze1Vaag5aKp3Zpp9wScgsFiqjLkWd4FQzPq+4KAXuQRXv/AMhuohaYmeDxk7L24F3WqWe2CVo82cV+oVLVYpGUzfHtNUc0Mgd5jhvQr5y1BcdTPjGPRO8aOcO9dI3vXPW8rZYVhRqxJKw0ZLJZiq57e9Yys+ZeUR/MsZvovEWS0y9YZgtixCMcZHoyS2uJlea1jcXH3pstoltN70b1FXVAn1sfzWAp1cgx2PLJ0v6Kp25PSOjHEb1rIqmynnN9BAg1B0O9n7vEVWCoVQaMeTXkm7FI6m9rVtRTD+WVgHfKV0gRaZY/mQ8YzvWEjO9c5veucFz29657Ke0ulj71z2rB3csz3LzvlKyeexpQje17HHK82nI8DHMznPVw96MYGQ2VhmqZLbYL4Gy/eFdODsnDgVUDxrMW9qD47ZaRUVpfyWzb3U64wq+GREdcSq22WZw46teU2X8NeV2f8NeWx/hheWv90avvtU0rPOuYFqvNt0zh1OXlc3uV6W1zgdb1/hxPM7iHUA96vWh7nH0Q40C6GvxFYWeP3iq2YYx2NCotUxpmtH+m3+qFptdDLubuZySSaK8yrWned6DcPcORIIYNaGuuuAcns8Fl8HdizI3e5YxyN7YyjtcPNKqHt710jPmXSs+ZdPH8y6ePvVNcD2LnH5St/wApVQHYeoVsxzOrwjKpqJ/kK2bHPXsC8hlJ7W/qnRSwmJ4ANL248iujncq0Nrk+v0U0cdXAHDZyTQK/KF0ocVz21TjI9t3cM1i8fKFjEw+5V1EdexDValrN4MeKLxgRkI4wUxusko7eGCgUTNZPGXV+iu+Ez1V91tddrkmsEr3NfltUVNZIP5i2zWQsz9YJj+I0Xg2rsmt9I8Fdeb0rjeeevQ4+bzgutUOabaW5Sm6/qO4rV7nfmr16kMm2O3eqhYITUc6A9IwfmE2SORzmOFQQVza9pWDWj3IXzV7uazeVW0PMbDjq2H8yr8EhhdlTMIR3WukORBoKcSqznWv45BvYmw2g1YebJx7evkFzjQDEkox2LYi3zcfZWxzjznHEnlR2BpI1nPpuag1ooG4Dk2yO754f9F4k7AHFc+mOOIVGzPHXVYTt94QEurc/fsBdDH8gXNYPhXihHe6wsWsYE57q3280RnNMcwz7qi8Kpt7W3SMXB+Sj51C6hq6qLmk1A4obI41qU1rqC+3dxUMnpsLT7sf107vubX7TfyRLfOZihXiqErNAKqdZoTq7pphzitl0+JwLiQqMkJpneN5OvNuyR84btLTepVNEhrXimv8AQcq4qSzk+s1TQUoA68zsKK15o6Gz8z1pN592lr/doqM1abFK0to4q7Ng8G7hxRM/2beZHtgl1fyTi3F8bqdg3aKy79y1kRfJYidtm+PrHUg9rg5pyIWohbrrS7ms4dZXhFocZrQ7fw6gqjF1alVcdkcU6d9Rf5o4NWy0uPYiJKV3hCy2nf0b+PbovTOpwAzKvWmscHmwg5+0rrcKcnBFzshmjbH85xvdg3ciKJzzFA8dIB5yMslrtLwNwp+inuse0lreec0OtUGZCDlShQGFd6kkDSSxtacU29aJGNfzQzAVTaWmS8X3R42uK8XNrtqlx2XemztBFcxocvGbQ7ESXbJOCDK83BMfndNVZ5waBkor2HDRh91a/aH5KJw7FeTD1LfTtWKwQeaxyjJ7c1haY3drc0Br4WitcGpwabxcaucdJO9uKo5tU6J+JIIQNcd6hlGON33FQWkc3mP7Cm2eI0cTzqJsUYo1o0lq69Afe2Hmv9kbTaB4sMDgtYyXVw15gAyQq+9Z5xWvFrlVuLdyBVDkVJFYi02aTml37k9SJLi97uc92blrHjaP00R2eFuLhflG6i8cfc1XWCg0Fr21Y/ELVFmvfWkTuPajaLQ/Wzu3nd2ac1sMcV4x4A6li292lbLQE2yA9I8h3YES3JppousbeKrLtHgoZnx3rEMJWjceK8HeQWno3ekOCie01jdsnqBTD1ppvJzVt3DwIFFXI9Wh2re+Auz1ZVPDnEdbAiHzktPmtFKoMYA1oyA0URjPmlOYDgRUKQEU2qqlc067i4xYdo/9k13FoPJ3cq1ku85Ma+QsNcKtVG2wdy8ujwXlsa8tZ9FTwzHsXlf+xeU//rXlTflVRa415UxbVsj7wqG1x96oLQfcrwnK1jqXic9EodeMd2hwQtchq+VuHZyb4ydnoLRzxiztUTJG7TmuGI5rgn2eQUc0q5+/se0OuPePcrr+ms9G9rUWHzsRoLTvV6QggZdemeU7rrB/37+RdyO4oscMldAJK5l3tK8Y4uK2YhXk2p4PNb3bypHu855V52w381dY2mgtY4tFQX03jghZLQDEXdH1dhUlR42Jt6vFMeZbjXAG9wKINvAPuX7RFfaX7Qb8y/aMdO1ftGLvC8ujPxLypveF07T8S6cD4ljaf9y8sp8Sv/8AEI+vJNc63R1Cv+FXXZYBClud2UWoD5JRU+apLNFfcxmLXEbuH3OCax14NOZAqjJZRWLLJGUktpTMYIu38aqgDO9c2NYsj710TfmXRD5yqCId66JdEuYW0V51Towr3rFzvmVdojtXnK5qtk5rwOV2xTxOHDklrskWndou+Ybxb7yhb4xtswk7EyYC9TNvEcEwE0slsZsH1XZIxupfZyrS8/6p/IKrJfB4K+LI5z0+y2mmsYKtd6Y5GGH3FtnuVe9n9FHLOM8Wjq5GsEd+KtJeIBTWscMRQDzmlOs8+LnClRk7rTLKBK17T4wLBsiyk+i88LDWFVuuWUgC50tFhJMFz5+9Y6w9pVLn1XRiq6JVuZLmBA0aOJojLhWV5P6Kv3NFLG37Uc2YOrdvK6603xwc1ZWen8Nf+H/C/urt2zn+X/dYeCj+V/dYSWb8H+66az/gojXQ4nPVUQD7V14YLG1OIHrLatP+4rG0t7ysJoT8SrrIu9MExDg7DnKlYO9YGHvQIkhHuUrAxr6fveHq6LpO1wJoiJmOjb6ebfog9jg5pyI0awbs1RWl3mClxXXiocLrgnwHm5t6wjZ7Wx8r7PWSBodS8N4/qpddRst68werTlWiInpHyCqFhtjhG+HZBOThxTrXH0LGXA70z9zVzqKkYp1lYvKls96geKV4Jj5th7PFlm8kcFtWkWKPcwHbKpAbS5vF390C8Gu8FOdAxriCNY13o71Ha2f4O0O5vm/TIpgicwEecOKjD9RVgoXVOKxdAO9VEkQ+FNZfjN4V5qwc3surnM+VXQWEdbQufEPgCDDaGtr6gXl7PkWFuB+FeXDuRAtBNFXXnvUmtMjgMjrFhPP8yia2SW852FexNiBrTf8Adm0MdG+ouuvOWw2SnqzIUmtbT1tBWM9oI/hBV1lTl4zBcwe6RdCfnXQV+MryZneonNhhD72Gyh4qD5V0MS6CJY2WPuXk0fcmUgiw9VVpZyPYWUP4S8z8IK5Yrbcjab0oaRTu0bTWu7QqiLVniw0V/wCzrZcrzmvGBX+MsLrnpx4hXYpmuruUzt1MCte4UdKBhwG5V3b1rYhWWLabTeOCZNHg9jqhQfadkwhl2wBu9JqZPEaseKjknhfd+aD3tBpxVAAB1fcXW4u/JXie/Rcha+eT0IxUoEtisbfW23fohJJJPI4D06LxMEbeumOl5laaEXaDfVNsdusplut2XsZeoOCNZI2H3tKvstBdTdrV+9PY9fvfxUNW40u73VXmrmMWEcapq410cSY9sUZIwOC6KPuQOpiUzWxxUDjgqGBvuTmWmC7vbUVqq5fCVUkfVMijkF87Tm1xH3OaunIii8CtlkEbGOuxynIjrK8XAztWMLO5HYp2OKyf8yN2MEe0tqOnxLnye5yprLRj/wBREytlMdaMdrV+8PxrFsnzql2X5liHj4lgX/MvFmW91FY6wn2yuY75itpsI9oo2uMR3GtuMLPryquhuvzvMwKdGy0NtMJ/dzZ96uWiwytazJzdrBHVSNceCuwQ68VpnQD3p80Zs7L7q3Lxw+iksdos95jnX2SMNbjv0R+z7SbgPMruPBVaajkD2nH6pzpJnshOEbWGhd11TbM8l7Hg3CcxT8/uNZLI1gdxX+GsurZ/qT4D3DNVtsz7QfR5rO4K7FG1jeDRTlNjbZvCDMbtL1KJvhd1lqZ62B6wgZGsd2heTw/IsbMwezgubJ+K5RCPWNa5p/eFef8AMVlJ85X7z5isb/zlef8AOVfvSUrueV++/EKrcf8AOVI1jX0w85fvR8Sdg52zXrXQyrCzvUtuODidWG+jT7t1nc5ur1eLHmgJ3Kv/APWV5ROP5pXlNop/EWFotXzryy2fif2XlVs/EWNoth/nFdJaD/Ocg/acGnEOe4rLuJXnd685b+9HPvVXZEU52SxfB73VVdbF8LV+8f2RlSsYXNiawbDxQ14j7h0sjqNCZarRAImjmxjBx9ooAAADSDLEC4YhwzC18crpod/pN/VCRpBrw0yxXgSyVye6y3Hscb1x5pRGaZwdMRTDJo4DlEXr7/QZi4+5AtDbGzffF5/dkFraGWX/AFJTeP8Ab7nwexwtdK3xoLjw4IC1NjhtFaPifhivFtu+w4hU19qZ7Mip4fbB8Q/RftG0f7f0UI8MldeB59Fja3U7V5VJ8y6eb5108vzLp5u9U8KnvNNMCP0WFqm7m/ojS1zV9yeZZ5S+uK6WVP1c2IHntqunj90f91jaT8gQLvTduzx+6EIfGJHCovuoKI2iRrLTfGDjiB2K5ZnugbnRpwWNsce2Nq8pcOyNqxttoPd+i2bdL8yqftCbvW19ozj40APtWX5lST7Sc8Vy3LG1s+ZU8JB966VneukHesXN71i1hqPQqqRwv90K2IX/ABGiwijHa4qU2h48JkyocKct087qNH1TbfaxRucMPo9fbyHa+xuc0ZPixr7lzqO9E5qjeb+afZuax4vxjr3jTaHDCNzBX2lI1ryy4eahBATPMchuHar0rqIamO4w+dKMe5eMtcz+obI+iwknH80q54damDqcg2OGG0w+ddF1/wDdHVOIe3nRuFHN933UAssMbtkurvpvCjtT4w943O3dSvNiuniCQsJ5x2SuWzaZfe8ry2RvY4hR620SSEg0vSErm/Vcz6ro/quiPeg0x58SVsxXfZJC5h+YrovqU5upDQQHDPFZHvKIF9mzucQtp7vfKUTsH41syh941uh1bnV90NZGHUyqrQ2C1Tsa04Brsls2trz/ANSJbcLJD1D+6xsFR1LGwS/VY/Zju9Y/Z0g94WH2a/6KjPst/wAy8Z9lljB1lYWD6ryMryNyp4KR7lhZ3IMZBnxWOoj9xW3aw3saAqutcxHU79EYo4DIwCusdzme/lOkeaACqiE48XUm56LR+vKOuaCE2E4xu5h4HghfF67V30UBmNXFmistRDNTa3AoTxFrsMS1y1FlY0Ozc45MH6qtS9/puz5XhEJ1Voj5jx+SvEXZWbMjeB5OLwPesLx7AtlgHasZCOxayGW5NHtNd/Ra7UtZM0bRjfd+i8Xa7ZH/ADKrD7UtHvYCsPtPvhC8tgPbEhLa7VFsGguRlYTNC6dq8q+i8sPyrWttdA12B3r9oP7gtq3u+QL9pSfhtT9Za75oNot6kPHjuUgncx7q78VS7D7mVWEF4gboVNEYTHKTfPs7ln9y+/O6EDzghbI3veZGDnPyVWTPHtC8Ebvg0naS1eMs4+B4KpqJQjVzGe0xYz2TuWFqsY/77V5dZP8Av3pl20wPx3LCSHvXOi+dfu/xFzovnWM0Pem+PxHBbVw+2+qJYG1/6cS2YpndWSIxi1rCbjnYErzT7ljGPcVi1wXOp2rAgqOzk5i9+ixIxjpyfF2cSs30fQq65r4gNzxRSyB1LuLT1pjXyOL3i6+g5vFNuc2gp2aLr2hw4FOk1FynoGlSrg55xeetXI235nYNam60gvpjTlQOvUZNWN448FUyNWyHO9y2WALaeVXRwWBr2J8BBFRhjvTorVding8XQOuupmvFWq0N9mVYfaFp99CvLSe2MLC1s/C/uvGyh1Xil2Pf3rEH5P7rJw+D+6ydj6qxMlT6qfFGWkHHbbRbTIaLmWeq5lnr71G+dkVS2lGromdyLrobUea1bMUx+FGRtkdsjNxonWia5rJqHDcOHJy05aHCRt5hbiEJIp5DIcatdSirFbTJ1StqhesYfxMcv6rGw2j6FbcMjDwcxXqlnaqOnb7100S8oYpBG9sjqYCi8nZ3qgsze9eTNXQM71RzYgmiNl81yDVRtnk7aAKgg+Z6/wDDs9xKhkE4kk4DZoOK8Gt+xIOa93ncioqEy0c7Vih7EyeOVhunjuQew1B5Gy4E9SJkIu76qcWauqYdlvpFWiJ4d4Rc8S3i7h2qX7Mne0vgOyQc26RHUXIhfcPW3J0rsA0LwiYHWyY4+aEI4elkN1vVxPuQjbXDiarUxNrGweMfwPDRecaBODHBrBv4qzashzzMwsCyvzEbEYzKjfPHckObQsirxwC8VG5/uW0bnUAtqru1ZKS5rOadpmbetRB9jM2tF50hyqvJWsPq4fktiadtOEpWzbrSPiB/ov2hJ742pustl7bFBql0zSOthXOiPeuZGfeujr8SbciN6uGKqYGt96Pi4x71zGJkckUbaYjFYge4oucaG7QDOq2GuPwp4uZjKuJUsckLYhHg3Hk7100v+1Y2qcfGsbTaPxCumkPa5dNPe9pGAeDubFhkVR9mf2scHLxjnx+2wrC0Q19tUErH9j1lEe0ArBsfuC3d650Q7V5TZmntCvR2iOQOGJC58axlasCD8KwZIexia8QSGnE0V6Owhg9eRY+DsHvK57j2ABNxaWuZt1NSua73PKuRWu0NAyxqvKn9t0IDw2UHqaEAftCf3AIt8PtNDxKLfCnUPOHFCSC03Kd3cvGQQzew66VtWCcdhBVGwPukY3qBXLP9nNi672Xcg1wvXcqoRMka0N3FibaJBG2VvnRi6SmWqNjWvrV1Bg471lF+GVR0xj4+KCcInscTmXtzKi1urdEx14sG/gugB96daDAx9WhrRe5qLWQNY8jnXskyKOJlN5ccSeK6OHvW26K56ArRVMMQ6g40V4bJGV0lX4pXtfvdfNVR9ulPxFdO4jrcVhaD3rytyxtbzXcsJz3BY2iT3GicGzzZUxcmy2e0SQzMFH3TUe9q6ezSj14y38lR9gY7+HKtr7LtNPVo5Y2O3M/lqOgnBFcHR0WN4e5YFYlYHFMeXjPevKh8pVPCB3FU1rvdG5ReCa00Br4sj81zJO5Mfq3OpXCq6Bo7XqgnjiHqtqV4OZr18VeRgcF09o/FKr4RafxCqa+T3leUy968oKyWWlz6F90VoFLamGSzXqbrwKxtEZHrMoVhdd2PW3Zz721W3FEO1lEbkMDj1LCN47HOW1rPe8rENPaSU/VQxVqPMVLrfw1kPw1gxx7GLCCVYWfvcqapg+JNcGQjvWMzB7LP1V6WV/xSU/JR+CPBcHVddxqO3SS40aqizvA68FtGIfEqm0QD415VZ/mXlln+ZYWuE+9eURCvWvKWd4/VV8Ki71QWiMntCq2dhWDmnsaV0ju4qt8dxVNdF3rCaE/EufF8y50Xeuki71z4u9YvYumZVdOyq8oYvKI+5YTRlVvxIEsa+9gKFB4b29SrdWS5i5oV57ro4q5aaWabJhOzrAsJO8Lbuk9QXNXNd3qlw3r4oXLoPqF0A7wug+oXk/5If4d9E0aibr2KroZ/dEvI7V3BFzvEC6KCQ4rG0t+qftskJGGYXSxN7Ai60TFzeFaBM8F1ZkruC6Md6pi0oaPO5Un/AA+03WV5uFFtAfHB+i8fYGH2aoA2WRp9VyzdH/EXTQDsIXT3zwaC5V1lP5RXT0/llOfFJrH8LhXOf8q/eH3LBrytmF5WzZ6dq5jR2NQJtbmtPmhoXj7ROfalWxZ754ltfzUMkbWwlztWW8dOtIHgsJw9Z/8AZeCWcODnCsj+rgr9okjdLJmC2t3qXNi90P8AZcyP8A/oqCCvZZz+igY2ySagHaOrxX7MlFP/AOOUW+AOFN/g6/Zkh6/BlT/h8o/+3QFhs00NQS46u7XDJU/4bbqewP1X7Otvyj9V5LanYVwYqN+zpqcXUClLowA6lMOpVdJO4dqqHSs3UCwltA7v0WFptI94XlVr+ZMkhe/49ykP+HmB5t6op3IP1tnNHVumtEWgWJ1XV34KbWvD9Y6oDcmrJOaMCcu1B7sGzYHqfySxwqCtXO0WjV7Dx54/VN1ethFNziF4u2SfEGldJE4dcdFtQNPslNa+FsW3zr9UauYT7SyafjXm/OvM+ZV/9Sbes8h9kDJYWSc9y8jf73hU1UbLrd5rVYGHuKb4yNtTmG1W3anjswXjXmU+u4lNbHEGXBWoFNDe1XtGfKkmhgj1F7myHMhXbRYrRF1gX2/RYzxj2xdWD7O74gsYY+5dDRYXh710j0XMc4ngU9t0l1MBeQZKxrXUyJWcPculi+VYzj3BbU7ljIe9C9ayB6IfSiu2azSSn0g2g7ysNVEOy8VCZnF2BNXnJV1zO9MstlkBkmN2vojeUyKNuDRQLp3U4XQumefhH6aD/wDD5D/32L9mvHaT+ipJZNWN7ry1cdkdLhWtaLyG72yhNv2Zt0uANJcvorroZX4VqxqLhZbR3BBosdoI9Ki5oXNXNWFjmpVeRWnuRBgeweshqptUN+xVYmuguc5rRxKw+2LM0ewFj9uQ1/htX7bid/LagJbexz/SFArrbY1x4CixeXJ0dABNizqeE1x542XdvJa+xyMiewbd7IqstiMw9KE1XjY5IfbYti0Qk+0tk1+JMacSX710YXRLmDuWS6MK81tFkqlRMs5bI9vPxyWUI+JMvFoAeMgjtg/UrYszqbi/ZTZHuj4UboZ2/czCzNNphzNAcF43WRO9ZqF2aMg+squijPwhV1DfyWzrG9kjv1XTzj+a5eUT/iuWM0/4rk4h8lQ4Y3yqvJJ6zVc1YRroguawICWSNjaV96PjmO9nFbEUh7cEejiHeVXXuke7n3tDrbIKGTm13NV/jl2aBHG6kcLfG9bjkEXWeHWybgsPs9lP++teSM7v7pj523X7wF/h3MbHuyVfDSPgCHhFovNAxbRN8FijcymNSmjwWIekS5RG0WWDFwGBUceNX1WGdQpnxc+7s9qBjvPG83gsC4u7QrOZpCA+VrXVIToYpXtYIgaA0V4zHEf6qJikLXgVwejaK4XGyfkqFwr2LxsrhH6oRjjtVWjeRmgyOdrw7FF0bRrGvD9YDiOpNkbk4VCdQbTdpvavCWu8VNi4denLRZC0ujc59y+3crzdXaBTfsH9Fdks88fYy8PotsWd3tAVVW2dg9hxH5KItdMK4YykrB8nzrO094WPhXXiv/E/Mspz/MV8SyMvf9UldMfxH/qqSAOH8RyhuRijgaipWETa9qDbja55rZZHH7IXjZhTrKuRM1hrS/TLR1oO4jTksuRLPZJWR2d+LWEVDiqT2GOUcYn/ANCv8RYpWe1Cqx2jVO/iFqo22ydtQ5ftSX8Nq/aUn4bV+1J/kasftS09zVqPDrRICKmq8oesZ5FjJJ8yq5x97lWre9YYnqCbdZJkPNoiGRxxj0nOqV/ibZIQeu6F/hCaUo7ghDnHnJ2IQDKm31DhodK7Jo70NZ0rzfk7SmiyPDWUx26Lpv8Aeg2ebZOBN/cjDZyGGlG9SobeB2OKDTbL1ONVI+ZzXPefNNaBSvhtDGtccBU4BdPFL2n+yiktJbq27Ro5N4MjP1P9k3tCljs/SGl3Gm9UbGB2OBRoPqFE6aK81j2uO0NxWtsrWmsQGPauiiX7ke9Nslpo911zTiv2LCTvo9YfYsIHtKn/AAOGntLZ+wogfaREX2TZ2drlBFLz2MDTomswz58aGscA9uya8h8cjtoZCq8Xar7RukZVDWWeN/sPp+a8dBO3+Xe/JVa2H8ioIw3DE84rm/VYVHxFdNJ3rppfmVfCJvmUYbbJh3Ly+09zf0WNvtX0/RRxPfNNIcavfWgVdVXtKcWEQ03tGKo42uf6BeLskcY9J5qVR+rute6l1Y6Lno5LLlEVpVMjjMckTBQVGK8ZZO5eME8ftRKmuhcetVuRk+5bMdOxxC5so/mu/Vfvfxnfqv3v4rv1TZWXw69TnldJL8y2vrIsdX8y5jXdgqtmE/KtmLvKaG2O8QKVc5YUiHqD9VWWrjxLqo6tuXBX387nO7eCJfz3Yu/TRFB5kfjX/wDpCNH3HEYHgqstcQHDFbVriB6iU189sc9gzAOBTdRaNVSq/ajsssVXwwOeMqpjJcJabXaV4r7Q1fuQvW1hp1EJ0U1q1vi7xaNyl4ANAUVN8ilmZzhSneunHyha84NpXmhNvuZcvC9s7lC2Eht8muFU1jHip9UIse/EeoKK1zYa6FrsadVQmOda5L2RxC8sk+i8pd8oXlJ+ULyl3yhMstpfebK3xbiN/DRrm+ahIOjm/NVBpwomPfmdGsikdFIN7FdJhtQ9bZK/xVhmZ1t2gqa8x+0KLYtUMg4EhMcxjKufS81Vvy/MsXSfOsJJfnXOl+dc+X5lhLKGD/qFdNJ+I5YukP8AMd+q6VwvNrQuWM31RkLsKY1xXiIT78FR810HcxZaM0HNGzvPIz05oYrPRtMb7wvF1b7LqKrLXM3qwKx+0LRX3LG3Wk/EvL7V8yuvttoI4VWM8h963rM9yyKy+i3/AEXOcvO7153emxRikcG0ab3oRDmQ7Tut27QXOyGJRnfz5jfPUNya1s1xu8cVhbnU9/6oCS2yH3Jwa9z7xzcnlltIDnF1DXeq+HNqc9kqOWS037prS7Sq1bZDGa5qn/EMOoFYW+p6wVPPanXpJKD3Jx4lQ+0fyU8UIJkI2RxNVR1jp8QVDAafxEWeC0BwB1gwUEkLL7435Dgg9lmNaYHWAEKupZ11lVsZbA0CZgaKGvFPpudX6DRnpbPHzoHh4TJW5OFQnRu3qWzu6SMkt7Qg7fvWpJr6PJ242u7QuhYqBrmjqcV0kvzLppe9YzTfMsJpfmXlE/zKgttqA6nryq0g/wAUoVtE57ZCr00z5TSgvGqwVN6y+q/uuaqapq6Jncurl58vNZ6afcUZtSv2YxxK9KTf6zigDzztOPXogsYPSuq/2ApJa0utJVb9XedVyJ1rSRuD1ZYonEPkft412RmtR5sX5lYQvd2K+Yw3HirTBuaGnsOKtAvOusLWgVwyWX+9CoxTnmt0SELazqo8MA139Fw1j2x95RABPYEC1zpHHMXCiDH5vnBWGSuOA/MKj3XQd9Vs2thIGVN6s7r11rn3He9W0SOuirsOx3910iwl+hXSjuKoHHtonBzsHNIOC1MnPgcWH+mhloB2Zdk+0ntu7Em01B7TiMkHjIjRiur/ACNeR1Lf99X7mpKd9oSA3G7NnB+pVaeLgy63aZbQ84kXWdQT4WvuE70L80DuwFYSQ9xT7RI8PkIuigyCle20xUe8uF5hqsLZF+GvK4fwyp3yTCV8xBOGSkkina2+68QWVXlLL3sKgtUQ69Xj+aZZ2OLruZO86L3UtQ8luNWuG4oXbe3Di1YWyM968rh+qhsLJWmWJ1bxyP8A3Vc6z/Mf0XSWfvKiMs0Vxrw7ZqclLJDZXyxON7BtQagfov2O78Mo/wDwd3yr9jyV9lfsmXL0Sjd+yZK7iWq0m1ROjY+7dDvrofCc6bPatbdIkhNf1QPUnx7xiFT7/DRj9x098/wv7rJlesOC6D/csY/9wXRuXNdXsWLSOVvWf3Mf2fDz5ucfRYqNwZG3DqTWtFN5/wCRu/05xe/VS2d3mHDsTHe46c+RjyqDFUdge1EG9IeDAtiy3QN7jmtU6VrHbwG/1V2e+1lczuVDiDzT6XKyTheto9GjnIeMtXcf6qOjbsddoyZkLFgPuVDCzuWDLvY5YOePeulHvotkMKF8uZXgUWxTuPaxbc8Le1X8JY97mbkHNyP3DpXYNAqn26YeNmy6mpjYXRijwXB+RWLbIfeV5PZvnK8lgr/EW1ZYvxF5Gz8VeSRfiryeH8VdBB+KsIYPxF0Fn/EWEFn/ABF0EP4i6JnzroIz/MXkzPxEK2UfiBeTn5gvJX/MF5LJ8wVfBpPmCxss30Xklo7gvI7V8qxsdr/DXkdr/DXkdq+ReR2qnsKngtp+VeS2n5V5LP8AKvJLR8q8ktPcvJbR3D9VjZ5R20XRyfRMbFC6+x1bzsqb1DaRlzHIppr2oLHkVWaJuFYuY33rC8/2WoXLPdHGTFeMmeezBVEQJ4uxWwxrewaD5j9zgtXNDXra5Pilj8QRg0netupgPNfw6jyuaVtGhVL4XOqsdDbk10DNu5ywjgp7So1sQ9K44rWWiQfEVcsUQY303j+i11pk1jvSfuRhbfoXeMk4DqQ1V25upy8lDYRzOkm7OCpTDcsVgsOd1o1YWnqjQ/xE3X/h101oP8ldLaMf+ggDNP8AglEeETU/glY2p/4JUtr1zGxxm7V+Z7FXWRH4URHqSRiepXJNimfi1hOPw1U2oD4F5X3Rryqn8peWmn8NeU1/llMddvsLwCdXReLJojVy5y5xXPKxcucucuctiTaVLzyfS1yxnI+NUNoGf+oj4Rab7aZV0yRuwacim8d6LDk7Tiadqo0GT2QSi4gR4ZyGi1FtY2R3myUzWw1tOpGVsjns9BeIiZlvWQHZpawNvyu5rVRhAO8RjLtJQOsc7sDXK4/Uy0zoaLWR+8HMaCx4vNOdVfsdXx74ju7EQxryR6qz04WqX48UK6mReMsvbdK50kSux29tesrZtbH+5UAjLuJX+Jfed6DE5sVyE+bvK1spcZMiXGpV2Jl9yvWh1eDQcFq4m3j9Ahdka6/tHHfya6bXrLTJHK0gNa00qKKrftwZ0oSMPqqn7XiPxf8A+lh9p2Zo9V5x+qp4cw/zgvKx+M1eVN/EavKjf6pWUWza3e+Vip4Q7PPWNXjZ7UTuuPYul+0B10a5DZtM0jTgHQgBD/A0/loGOzPG80YUCLJj1RlRE+EZeNAh5p6l4ue1DhWzrp56/wD0ywfOf/tlzpf/AMdYyyAf/TrppP8A8dYyuHZZysZ3D+Qtu1SfgryiY/AuntXwxI0ltp4eLAXMtZ7P/Zap3hUY9I/+y2rdaO4LD7QnB62IU+1JPwlV32jMOxn9k0u+0rQW+cNXn9EdVabYKngi4PtmquYMBxvdqPjrTnhtbltTT6vKhdmpKZawp8TnObP5nokKs1pEdOAVHzSTngHfog+y/ZzfafghrLRFCCaABEsdJNMObiqXKvYNphwI7FdJ6l17wr2I96rq8XYZ4aWyxmkrBhwKeLXDIy9UF7RUHtTbkzKR83ZoQgQ2WbiRFiVI+Wt6Q5VyGhzWCr/oqtJDhmwoi7ck4jOqe+Wl15526v8ATT0NpZ7OKrrZh7UJWD4Xf7ViyvY6qullD1hVZJQ9qBZM54G6R2FE4ytO0ah5zcFXJPffLInOJAG9UbhXvK8YTGPRHOKFfFs9AKjWXWjMq4zl3gaCRv1WVAgsQslksuVu04VCwlk+ZYyPr7S57+9c4966Ry57u9c9yxLit6z0Y6MKql53foaN15UFAAsuSFUjnGqNhezGQ1vVyRs9rbroT5/BHwZsYductu81rc65OQjDdkZVxWax2XjmvGYVLU0BxOzMMn9vAoVFPRegyQUO47jowFORlp25hXg3EoFkmz1HApkD43tf5t3GnvTYbQypOUrUWS0kjK1lj24/9I7uxY3weF0rIaKPp71hFG49TUT4JHd7kSyC6PSvYK6XGcN31VYxl3aH0wIcak7lSz1Lt8hV6pvHzig6WrWcN5V1ooNwGjPlMkjprIzUV39SuTw6p3asCO9Voe9Uoe9fqt6ODl5y87uXPd3Lp107V0ze9dMzvXSNPvVA8LnNXOas2LNqzYs41z4+9dIwe9dJH3rp4+9HxzO9dM1dO1dOF0oW1LWnUvKn/VeVP+qva51feumI+FdOflVfC3fKtXHJfe48KUQbXJXqm83FpG5Cz2hw14y9dXoNg7xuQjlbcdx3HRitm/H1/wBkYpmh7TmCnVaZ7CfmjVWvD4DiD6KEUm/mu46KuNBoa196r8qBbFmd8TqLNkI9XErx8krj6xwXNAb1K9FiN7dzlsHaGbTmiZCZWudvT2witMmHzepFzA5jhmNy6By5571R0oHVvKrq5B2lFtme1pZnVq/xEpmkH7tquvdqY/8ATaubcYFdZzXt9yMkjgxozcdyc6IEWeuR3oNbRVdR7/y0Z/cOLBU/ktupWTu9ect6zK3rMrnFc5y5zlznLN6zOjeslkdHNWIC5oWTAvMWNxeYua3uWEY7lhEa+yuhd8qrqH/KsLPJ3Lyd/cugd3Lyc9wVPB/yXQ/ULGNo94WMcfetlrG9d5C/N3BZXz6yBAukbwhBbsNwm3HtVHAOBVMXxfVqq01G5bTgFme5bJDgjaPs/wCOHcexUZUOHOjObVtmvXowBMf/AJUWvAc0qjtqLdJw7VtNLjwrmtWG0ZuFFdLau3Kkhazgr0bH1Bwc1ATht7qVILPW9m5o3oX7uspjwWcv0V5lqfG7tV6K1sk7Riq2ue+f9NiuxDweL0W5lV5g68yqQjWu47gr9pfepu80Jjo49YGbhvV+0Pw3RtyCDGtqeAV60DsbVXamg4/d8yh9VbMp+ILpmFdJGsHR/MufH3rpYvqumZ3LGdvyrpv9q6f/AGrGZ/csXyFfvPmWT/mXNefiXNf8y6M/MV0X1K6CPuXQRfKuhj+VYRN+Vc1vcslkt+nMrnaM1u0Z6clktyyqrr0G4yQeicwr8Tw9vEImIgO68insnaTK3OmSvshkcK0XMka7zmropxdz2QmzxMnimbvbRNhmc1s5y4PVCdFWe8IjvBV6zYj0D/RA1ZEOs3ivHSvkPVgthjQsXDvWBWauxeNf1Lo4u9VDo3LFhu8WlbDKcXlUDr71emN1voKpp1NC2/Fs9EKgFFXms9IqkYx48rZaSujK6MqpYVzHLo3Lo3YdS6N3csWu7li09yyPct6yPcsj3aM9GazH3XNOjJZLLkZLm6MAsllp3aMdGOjDFa2zG4fO9FyJJDHN57Sck60NdK2ue6qrrZfmXTOHvC2rbd+Nq27ePnC27Y35sl4HJMJ4xzJgd3WgQag6KnBUF53YFQPp2rKvWsXFZ3uzFVijDG8XFVcXvr3KrthqxtbO9cz6UTXbRDTlXctXC24xuavvu9ZVyytvu9LcFekdecd6zqg+ZrTwZVXWsYPesGx95WJj7iuc0e5dIflXPd3LHFUa6g4LNoWMiO3+aw/NcPiR8a/5l0klfbWLpPnXPl+ZZd5Xmgdq80e9dKQe1dLXtWBafcqkx9yziPVdRrqe5ZRn4VzI+2ipqo15PHVY2aP5l5M351Xwdv4i6Bo+NYQN+ddC38RdC38QLo2fiBdG0/zQujb+IFzW/iBbMbfxF0TfxFzGfOsWRj4qrzFm33NWMjz2YLnS/MvPPxrEn51znD3rNzveub9VzPqqXSPeulmHxLymf515TOfjVb8oPtKnhNo+dYzTn4155+JcxdGsGBbDAPWamawEx0o4bu1VhftDNqewGlQhBaGmN247ii1gMlM8E5rQLu6pqrz3Pf8AksG3QvHzNvcMyrtls4HrORdaZ8OFaBdIzuXkxp2ryVyIfZ3jHC6EHz4DdGMgqLrTSRo4fc46OaFzR3LILIaMgsGhZNWTVn9FmsysXLNZ5rNc5c5y5xWZXNC6Nq6Id6F6L6rovquh+q6H6roQuiC6Jvcujb3Lomo7De5ZN7lu7lzlzli4rjys9OGnBYrPkUcAQhJA9woa4bk2G10ZKcGu3O/RGOZgc3rQuT7HXmqzyCg4lUskBeeLsAvGTXW+izBVc4A95VIWXR6Tv0QMjjI7rW/u/wAznyK/5Pj/AJfLlm6MN4Rhwmpg1xzCMck0kb5Bmce5F7nGU+m5XYBrXcfNXjJaDg3BYD+6q/BUaKaK58opp6v/AJHvDNEPb71qpJ3uaN1VsiixwCGA5DkUeQUOz7ofej7kI/5MaAj9wPucVSibgOQdH//EACkQAQACAgEDAwUBAQEBAQAAAAEAESExQVFhcYGRoRCxwdHw4SDxMED/2gAIAQEAAT8hy2QaocR7n9zJun6gMjk84mgS+veXQzTBYb5mF3jXrGqwEbm67oly36HP/TPH09442R/6v6fEm46wtXVbnhihson1qEsqx9KmfhQBs67+0B4Ar9zGrVhW3eyPKe8ZgY6xcvkjidGpebFxfZgrcXXVH1ZcC/kczBlVBdGXT+pgdegS+m+s1KPvQacTidJm8BD7NwaxJato9CWEHQXdXH+kQHqvgmZBZGYoqfeN2DnGeFxCcyWlKx0qvaZgUWcJUwbFBrqMyw1LCyoelSzYCiwY6gCfBAO8GDUOCMb0dwesJkiiyFhhtuoH2SkVGzYdLiiNIXR3KvopfpXUrvIKV3lmXBRWrIarmVWOIrB14nmSP2dZslXDWTUZydmLZzhwQOR1c93SDe2W6lB1tc9p6WRpbZn4nBtmYrNK95f/ACzZgTUE2NQjKLNxtJGKotYvNMLniaHv8MHsd1WGR9VI5afj/EdS48V/U46fSQvJ+T8ECriXvY7w62Q1occ0qiPBY5PCcesr/qvpt8TLzw2FwbzzNUaPkjgNK/GGpZDa9V+0Ub0Ay9YxDQubcPvL4+7kV5Y6XlDmqndy6QivBUGWKLR0l1UW1Hnq6x93zLfxOtg9IXqxfeWu+fMWXsOegi3Arxoq8SEo9Ry3zx4IpuOqzfmche5phdRYzB0GY0DzmAO87XA6dzp/ukbg6YSiJ6q5VmX0bNm/iCsA4jDXXc6uoA512+kzd1+KJVauO1kpCzNC4NNNAanq4WYAAABqpxCoe1h3xfpCNFplG/F2iV7GHft/dJihrRW80a5wBvcd1sWu9SyuLlvMVjqKcgSl6IH9W4697jXBmF9qu0am2DuY4eJlzVdZhLTLtLnhHbERDLNOkHVJdDPpcbjC5cwvh9TX1NTIvA9NxYkVU3OhilrikCeg1GGsRWQuFdpV1eJmTywiSrqIRbxcV+5ZuXiWdJeP3EFGdUHILqrUvw7y8I2fWZfM4UhSkZoKccMPaJFbe+C3oYiPKqbXx9Mhn4MBGuRaLB06Eyijp1xywt9X2mIVOcsXOX0/vixUc318w3qRX7OIEJAerXCRzY06mUXADetc1capNWnDnrcvIFzSveZZBbZj3lZQiqkPRIlKa9HHGelbfvNOHDodpWbG9k4wlBlvtAec+IqDVb+ofZbYF2u7FHUYMj/PtMQT5b26SzLbXsiYcWLfd5nC0TPZiKmBxcUKY5jdNHZ5hmV0wty65unHBPMPdzA+zB6whzCSz6/SuvcSAijnPEwovoQLy211aYZfP1zE3wJbyzHJliQhXFJRNr0aP3NMCUEyIF5gWHqrDELEqtUfK4aIhWmXB1+glRjMAvB07Sixs6QZ44YgZ1OMczyn4I9Btlu0OmP2Qg+37S/RNqUA3BrHEui3XzHe6F7wvuwmOOq1GlgcCs584Q29RbfabVCxS5Vk395aXleyKg0PQTCxTSD+YhE8aU2RvPxAOSguDvC5LdQ0i6JeEZKsqzqBe4yssutmoQ8P6BfIDIpyV1o+8VUF1Tv4hgnp3/tFRmZRle0BOd4WVVkxcjijTz9415q4i16HLNg+kcvvNCvvKcocYEQLV4UP3MwzAwP5gMcHUq7jZ0NPEeym+ZQL8paSaNkAHNMt1R+oz2gOkLitsQ7I2xQc5mT2InYlSgYxg9UETRRTBbYnGgtmGVZcAYO0SgfaZZZXojtLTXQwwADwdY5RY568iWIsLuHKWDA3u5dNiXGSFuCYI1udj9wYGcMS/EJ7zcOkz0lTiJvCfmWGLFO7EYDLc+syd8EmHdO3cWDglQs695UDVKvpLJkPDWbg/AZZ+EvWDZd+0u6xNG8USjixZx2JbpM8uTxDl2kzs3ZX6RvRatKpZMgv2Y6JcPtLYAu6OCCi3vcpQdKWvTX3iLxL4OrDtDx9hM2OeQMADY9estazKvMWkFnVhWfclOXQnDpKIBwlkesp3NN69Zi1gqK39S8bgW1+YJrBtaq+PNS/cv8AaKwOubQtHpJ8L9vofscALUvTS+03U+j9Tm1rhG5/oXBDdh6wq529F3LCrV5mqa9YjwIt08XBc5V3Yo5v3luCwa3Nsc9oWlyMKuA69tuYBm33b/UdJWqjZCY2B8wyX7zXeUCX8yk0PZZj4y4tKdPiIXAvJUKz5l75qfZhejryD0luqU91wNVF8jBpVd0nWPEmpygNgsGV294qFRi2GXqvEubp7dajmctyu2YhLsF3KOdIJmMqLqF3LilcQiZjj9ozLmwW1weXiCcLxV4PfN2Yp6HlvPT6ejpj52hJYB8pSi4clk9Z1161D7xrFRqm4pRQk6ws0vN5vrCATXGwxETKVI60UuVjDK6IcPlpMDQPVFQ08Alq3ubiBsAvPfvNGAAxWJt60GsVcAOXLB54MShaL6k0X/qzIjTi4C1d9calHBjl6wdgY7TYHNlIXVl25j07MEX1sK9pRaXFyxRrovHVlHorFGpzeqHRdG/mBymHrnTgH0+g3tYeNxS1mTsuPUT5nYQOxc2pEa+648seYXWQIcrAFnXecmJxq6gLLMoTyY0GgomIdcDKkFVjzqCWVBCu8Bdx7eHibOBMmfrNExw7f+x6wc+MyW1xO5x5zD0XYcvInASjqA0ZXlTjulRFvgInCB+O3qirfWXuJlDrrr5h8hFqAUMafmKoyPIDDK3S6d8b7Ha8srzRrHmFtDLK+xqZzMAHzNMW3kgFu3WKhR8QOi8yB4XTMZdY3MDbeif7F6XctcUtHTMQGKDJYwe0ohFFbuMs16mLWbuxA4i61wR5Bs5Yhji97zT7Rx6JTD3jqmPpAfUyRhYo34IIAZqOWYlKmUDiXpZd4na31szmZ2lx4in9EGQJgtuc5ywIVXlBjGKeogdXvSfPy6w069ZdQV17cR9NRfps7aHsRbZ5RS6loGBwrn8Qs5c9ZVFzNYyk3sOalNYdy6zT2mQHUw+sq3PDcdwFYcQXYcojCwdSVR2j8MJfOrVPNkwpPgfcgOT+dS92qsAs8wTdrFwoMFdjA8ty9gzxl/bxAYjnz+Vw9CwZlGtTs1C9a0LPeJj0r1HWtsLOtk76jF9/oeKhnRY5Qhh8SHR51he4fdTLo95YbSLAfdldWHfcQljoai8LE3e5Rs0FmktFfA5qMXWd7itypqBbjESk3xjoJQuAlYsz5gUNVGmFJY6JxtCKSMOCBOK1hMu5uujK4NVx+x7TO+yL7Sk5RpUrPBGftKtb1/nErBW1tfEtcU3epk7NuvCXGuaEZ6acJoOjrEkM7PS8xKaDtcz2VNRxQci9MCnfCkUFrR93039PMbi65agtJnmrlgIcN61G13wuXBA2oCeKJShg/iLEFyb2gz9Gi6g9DLEmQZxhjl4XWCJXgaqFWlLotxLrVrzeJTVMNGpzJJLKUn2ZCz1RS0uLdPiHHNTAaOcRNXAytK8EWdR4PtOozVMLmStXqWQX82Jc0OM5veARi5dIx2WikOYu5dxsqBFZD9S6q/tFe45CLmoKXcY9CC73mJGjudopC9wGvEOIukXLdd/iFIj2LqFRk0mZpxLxJirb/qAC02v2l0uS6vWFbkfB0mAqslzBp0dY9UAVhmBUXdkRRLyWR5FGheZ8wO1aj0bTjz0mrc+0SkpA6suSq6MHY6sKeuA8ubgoqYNj5hlBdQgCtnV9/ExyCt4b+JVQ/hUqx1jMbrDGxnzAss1RnLxoYtTjpKFoVMwImgWudfMvO7JzqZ9YHrAqHMr0TLJzhLV7XlhABb5mWpuybLnreoFfe8+sq3hQMxkW89BCiGgqcTtB4hHXdKgMq7BLD2dX2mV9MPvCkCWEA1x7RoX9tiOYehuV0hwZqZMDm8rKhHlBuUtLaqBBh8Yyj5MJbcWcI7ZRw9OeDczl634yTYN+czhpOzUvU+ogurPViI9ZmOXMpTHmaQOXx9MNT5f37IUD3H7p62Sfsy4x1YoJv78wueVXU8jKhvs3Czme/wCNwmdkx4V17SrSqleTiYu7+IO48YK32G3DwT9V9j92dkWkh6Wj+ZZ9NHHcgdMh+6K51bfMOXbNzM1FuoG3Na2zBZWIIAt6WiKtUxTEVebQ16/qZeQWcekLBjVZrAqZMDLMWVArymfsFfgJY7bJXPWAxZ3XEofgaSbYWNHE6Dz9LQxHXylDLpPiULAwswk19kLLtYhV1WepKcWziKt35jMAyRaDZlwj2YnLCIVCpx5iC9FB4Jjm6dbjiWntHVhdbXKPHRESmC6Z3nSAxvtLgbIgzZzEmumaK9IcoIap68/CWejHxH2lOQMROZ7IgXADtjuly/lluHwL7BOeZQ0Xt9oHQIFrdSlWytmzqE3dz7QLFdlMWxDvFXgairi4JaDMSmvqUhfrMt+bSC0Rk5PGyZg8wsHQ7VA0ZKgS9MK2mLFhbDSbhbMAPcfip4dcwx9mAc6n4/1c0C6lVbcGMHYp3Krab+5LUcgye8pkWU2qjOmIA5YTrMTBn7RyPMJZ+wmGxtov4lNyiHvERHy05L63bvGsVl6LiaC0xJdVa9JiDRdBzE4pnEb9Fr+/3RCncz0lXVscQtKarcdN/FQRloDcQM4OHlNMPiZtXepobbhfyagcDmzInWGsMu1WjosRlXka5nMFo45iNAYfE1wa30YYoCdHmYgxL2RDysanx9cz6s8Stj0yllqpOWJMdg6uicuclIcHZG4NuLfYB3L2UK9cupWeRiWSgby0zPzjNZeo3Kh2rRSyq6kDhd5tzKNC4nn4ges1yJBBS5BldTLOXC+8nqvi5kvQaxDELRM5mgbqUKJzmIW+eY7scXzLwEYVzGZ3BJB1Yeyck9TWY9+EE8e1xnV9IOgQ8QINmeHtHV4h1HMNvKX7Z/s4hzXNUmAn9D+4nJy/sljgsm+Mkqp5RNVPtAegDcbpa+JUtt3LM3T4lcug1Lb6y/eUyp/ZigsPhMVKAO1qZGtEyZkhFXcdTmenmYOK/P8Ai4UmWrzLjhn0IBViMNZH/KVb1iKGNWnxMHd2mimsEbEMDXiBKTat+JkyTXkQhrLmo43EHeM0zobhenHabvLL3hpvDFP5uZfWD/zbtMrT3y6svP2SlFtxcbIDNK4jGuj0biNrSZBaK6TTuzLLR0jTFSsA3AWPXx9jvzEQ3e41mYH+ROgRRmYKqCsOUsYX1g1AE3cWrt7ML2oky5YgpWwTQdlzdZtuXgS1q2lTiWsw4L6pS9V/wYh40ooT0cSqgGlr9jtEpeA4hB/U4YqsaZYGAyvE0jVXr/kTG8zjttH2nS7r7kaXU5T5RFVsnwJj9cvy/iUcx2l2XV4uM10BFYhkMM0ShtuVLVQx28EAEY4EahDmFkdKRrdtx5qUB3qYetKaywdJcPSHfKmqg9pf/wBRMtuWBRiZq87Ok6r7I9rL8Ia2qeM4jWtpdgK1O05JS/baWidPUYWRHVtlbryne5eqcVG3JHWz7kI1Dla0dovInWbbKY3cuXKBSF9ZxTuO0Rw8o1wBRvsQgo3afLCqI6oPPEddA0ijbOtEvcOy3EeATklvPZ6wPeestfM68EO8/DcQj+daHgh9nF0LfhWUD+/0J7prfZCmHb/UMXaaNvL8x/l/zMc9KM/sZlgeNv3Pml/zE78jb8Q1i8Sk+GV4Dhpv3JifOQp6EcdquMEte1hmhT3lf8mAhNNzDr5k9P67wVEBWdMzE770u8Jlde6HPE56SogWlT0lzgwBPWYcrRrvlEu3Y8IY8wr6kW5EgwCnjkmad1AYfLcpVgWXwyll1TnMdLFC0vH3r6xmuGYl3V4hJZQZu4BNJtLQbm9aO0qIYLWUHuqMzsiHhOG4U6uzNYEPXiDtHcsEeL0i2vfD0lVep1uicnfaFeHiU04cRnCVfRiLat4nrMYTASjZrPWIwcVXPeYK6fvCwEPZZnE55bV6TUZVaArhdsS8HcI1JsFla29lzlCC3riC2MteMTYWSn5hsi0KQ5bW47MpGNq+IG/Gz5RbIK3leIoXW0RgBwM6r24r/wAlMmnK6sGocPTAGOVJyPawxW9A8qxIhGVW4CSrSqqJx0W2/chy33NfW4v0z9Llz1gNeu0YD7LT4jYjoK/ubl1tvmpgOoHKlUw4j9Vrddb/AFu0PKa/CKbjo2CDQsXZBoWZ1x4erzOLy+95Yywt5PdNbYV8ys4FalnWe8ukSUeQExn3EejGrWIGHiEZlhXwGGcnhhUFFUq0wbcfSFCn3Fjtyr8EzkvzL55QqdsbfRYeR/1i2wbw3zCkr5med/hHoch36RjeWvtKrW4bc4nBWGYDyZ+kTMI4zqrmJUPMU/Q7BmeDgGJhQLgSiOgwzGho6ZJqpfSc4Y8qIL3ErwV2ECVAumpHbgtVu4SLoY2vpDgLhJ1kiQLqLmY3k63mGVC+s6qDMLTKEbuot50P4qHSXWEvgH8YmcTEAXLdZTrErMPIXbhNw/gQuf8Ajn/pyMcIfMRHRj/PUJX+QtxZ1WQZeBlTTcHuOIqM5hq+NRUC5p+HzN8Sk7gVQR7/AFpZXt5bydu0SqzqYDqdpn9C3qqzNMgMw48w2VbfmXQIgX3ZoJdVraDVvH3iMBi21xEVcmCCnSLmTafRx9OZRzUb64nPTnGWZhGrQm30z/KUfMZH4mxd+34lGq32QL2F0+l7yKfmcmcXAJix+xEEhZg4nBwtB1qXgRyENdoijq5ekKtxk8IlHHSzF7hnEvW83aVqAeGPVViY4KgGJiRFWewjBD5ZNeu/Rmao9eArXvPSUZQyDYBQSNdwgNiQ5F+FYiI7yhodCK8YMR7CW5hFT4iXvYTJXVuxNXp0U9o5Qats5B51OJy/hunVLZLFyp1I61OrpuUbbc8TAZ30m1L7RgFQg8c/VKj/ANHViA9Rd/brE/oIHpqZvpA4n4g0CKt/rmWataX/AChfWAcyoz9nEAqZtMVp3jOn6mNZWky/DBhC1yLaf3WZiod1LuzQLfWG6N2kyfIRW2mVSas1btADgw9KV5+necfTLuY5nMe8djtDExd2cgjlVIC1vvCgjpwULpcC0EqdEsEyHI6J/wCompFxY7xsEdhXGtE51UWh1a7Mtdt47Ex3/TAyhaLU6piVXgkuIBkOczddYnWFViyccyqFTU4w3fMF7UQZmk1eKgMwHGuucKopeI36N6JQxzD6EDxMu4bV3/G4htjym8OT5gWnUKw9eZ3OZHpXGBzxBpZ5VMAccVyosiwq0mnZBq8IVRb+0PLmFTOBwReBeR7j2InZLDLI1W4l1MVTlOkA4OJmLHSyZIclTafSnJyRCApdL69QUarlH8zj61bDo5bsELU8Lrydu0XdTA5jxZExCyQZy1Lb7RDskHP9VE4jkpydIWBXgafP1EtlG/ngp2mDDwlzmAA9okluhNbZgMCB+/K2pF2/UiCxOb/eGMtbdojZuCy1M7CogHl0mkLuncqdH06PojzMkcsSstcqKiHIRkqKrBuTLVMKMB8WXnmNmD1CnjfiGOV9D8zKlneNOREZGqcLjKYniUHbVx1lJxfaW1wZhD5/MwDtWRrU15ljFnAvK28xRw81L6M/JM7ZKxRULuvZJm82A/veY1rc9UCzgoEL657lXClJQYOOsTQqxSxiWfrKzI2wDMcyVfa4Qq1pReg7HrLKm7vqK0iBVVcNSiZrdYksrdxwCIfYpg9Bz5mNY0cAPBqHyiuAI6MoLyVSm+xEzryRMkzkqBzjrMBwgBmUjjrOVwXn7Lrs+04v6G6QR4CXBpn33M+05NhFHvKUKJhO36wJYXFrCxHlc5eOJRsxrnaMn0786v6Y4vRDr9RO9wOH62hQckFsLJ7Tv1nB+E6G4kY1U17xHa+qMLZBEPMDRvboNQtXWi72Iyzs2wKHq1e3rB7HTTHq3rgiidtplmmB6fThYe1/qd3+D9xfb9oIvhWy4lv1/UzYBXT9IW1Y+X9TQFzu/qFf8/aVyXNnL1jO4ftMSsdL6MQzaVHEStkjgH3lDcuwiVXzbLKnTwurK7Q47xHNmGdt4xPSPBeIW8Av+9puC2UoyibaXjdx7QtbNSoQ9VLnA4ptdu0ArBFQsL0Y+DJGSXEDf72lyZfshqHpL3VrOsj/AHeWMcW6a49G/aJQCfMH0uXNVKKop0hexHr2H7gvxoaCFewugjGXXHpGczCGuv4ZjpEtthrXJMzVfaDK/XCCAdNv2jab3Ls76xIAZSmY1fppiLASXe2oPPKBRvQTs1Nu6bIaH28T/UNAQl+HL6D9n/FaGOEw9pglQGmlyvCMplVmkbI86d9eWXQyZA2XHuDa4K4mAMjdCveFp4OGIVC9pTEDylOIMkHgv5iAseR+0rpvexOEXXlc3JPaAnJvu+YoVZ3iDXsTyfmWiHUqVZfN5hu4v6I5x6Y5+J2n99pdhfGZvi/eMJAFuuwNEV1R7DUVszgf8gLyjkz7yrN1Ks6s9cDcaRWt2tx1N6+tw2rqblNIMdK5l+kG5BBSwhDjDLtK6Rpfmo4cfgE3EbW/CE+9iR5r4IVCvYFGJsalIJcq51qi0qXCwhSaXjFTSN1l/qWMbHyvlXtBju3tXk/MANDiVZii49c5hIFW+nsILklAwEp89CEXktv0BD5AmMewg6EZkVBsx/dKWWHYlv0vNgjR2T7pDkvRFREqVxaKausq/j/hh4o7eXyxVNwcAv47wbWn4hlK8mY9RmJluMn2B7N/H2lS1Qsj0NQm6DSdPqQ2HCTkDJZGt6WoK+u5QU1QOsJlAC2YqJfVhKlxI9gt05m471YoakoFi7EWGo0Jl68QxCk+4faJrXnQ/wAQA58yLDG6rMIDY+aATDscVe4Mil6kLWq3bK8UXslf8UA2S96fxFA32kzyBpQ06ZmEkRXRe0Uuzm1nnccwmrV+JjJ94roRgxnoLZmLhzsr1jgUmsIiqI8Q3PFAvChMMRSzo+ZXtMYi7yMpquOQTEWvGlQOYsqxb2mZvMVVo1U25ymUA0nSch1rLB3vcZS5PTLkc/aCvpHyI1EZoZ2P3lYh+o8JGfLDMEvsKLKRtD2yCFKgShR+ZlGA/P8AxuwLDa7RCt8ax04fqq6ErTROYsMasrkl5SKBg6MSzEcVmOiPQiyDuBkeXmYAABQHBLxX2lmgvgnDjFW7h3OfVLMERyRyUYZK5VCUx+bDWRxGiRpj0LD3nX/hqKZvE3qpVf8AmvwkUe/EQbGpSuM1Ac0uZTyks0jWYXQGNvOPMW9Ro2RTHE1ol0dPMcl7mKqqYtUTA2MvHUl92LfGOs43Diyk8cZl2cMwum7Vy9S8Sw3kh/Ozv+FROz7RTCxEcHiXVdE7S123Gy1x3hyFH1nZQfFhDjMuXjiI6PaFr9qFhhQ2CoLF/bV/EKNamUwVPBEuJ2w0gIbogda+lwTBoHI37Rddveyb6+hX7fSvqf8ANdbJigNU2RjCO0GAJGnV6qZ5u3iC0A7S+0S62NSE1Tjn77lbW0mQmQyob8vV1H/ZRHGU15ldcMYI/WwfSzR/sx7SsXKQqyU43AkKX4B3zHivER26SysGGsYI443Gw8Ss63NsTO+fpec7maxjzG7thb38TMRNMpKtMDjmUVxK4ee05w7ameidrxPd5nB1vUuzHxM09yfmUVnfiXL5BQhffrA747wHp4meg7QXp9EbpLOdysDTFDtO5EU2dblMgGTvVPvGOopdl1jLdmWCMuXx8fmDrhuszulBSW7L36yuinpC2XD5x1Km0ezq+/RCzJYf/G/pf1Z6/TCK+HQ8MaVRERixZ7BBMyFugbZe3EGoPxkammh4ZyfWnkljAq1+6+ZbmisbRZmeUHrltThoKdcvYhVZlZ/jA2WNQwJTlpMOk+TDIJ+2FFeSqJXa9EJTpvMiV3dP1EnXzp+pabNYuRrwmZrcMX5GnnMRfpcpIErZaFxY9FksQZ+oz/UJtq9OUxCmd5MTfbDMcYVqxO6H0ShYP4lyNgYwsL2Cm8oGjpnFsRrJuLRgchDK7cQMwO8bFP3ShnYJCwbKN8WvaCuk6r/MKBYOK/xOcC9VuN5dKrBBtcuKl1mO5UZ6U51W/wAfUmNePRfGRImQDL2Oh/zRAEdjE7gJnpO390lEIj0r6c/9cw0LWigJcwDTlfnmA2F4lHqjpF1X+kBC9Cl+s0h/Wt/maF8rZEEWmPYBZdDq8dY4UcKYfWECHph7x9RM1o9CPmHaIzCVzTOcErd/SncuxUKr95fZw7SzoEMl5/KZVqCys9C0QbFgstTLcEdLRVlB3RLKE6OBgJuOWM2coWlicx/opQFk7xStWQWAprBOXD96TRhg1H8CNuvvDuuo9BrzHItSXDbm+sqa5iZ8qgPPEwZpct4vG51Gu8vbhMzcbpMhPmIFMcy57LLrV4six1nq8RLZSZTPfMV66rc6E3FeUUNUlk3cxtmo9h/v1W9NS31PBtm+6Ft9uh2h/wAH0Pu4r47xe3t9S2/6Iyus4D0Q5YSyO6S+iuvaau2Gg/42xiGx9JYbspvxdGPXFN8/U9q70ibFNPDB4YO09I6+ikrGh1rfxKlYR5+slZqcOahe4PLlM65GEnWMVEV2bg2a94FAU1A4HMb6X5iC6fMIKcEIWqvFI5w3ziDs10lUGoq10HbrAbDnVykvadGDrmesouiJTjpOBMSl2nKswM2ldpgJuDRvsdwse/SJw86mNrCAcHpLKbz3mbXMs7nWOscxKtpN413nQZ9Iqq5RjrU9TMuEaLxm50TPiC15L1D1BV6QK0c4dX6OC4F7VZb7Xv1f+U7Su31z5Fsct+H7wpLP+D6caZ1tcDvObtvXUev/AMCweCHqnqpInuV9CdgOgl8AaxBuX6xbO0xpi790pTDdNwCHPslb5SVDtiHd8l018VHZWfMOGNywBDXaCtaq5Q8zNjjxMsOnSZKdO0IO9i1FR1QoBV+qXlnRxH0EyuNSm9S1QZ4nS6Vr6LVrYRNGCuic88wwFFlm+u5h2Jc472Y/6GoVmLmUsrcq0xvRNgLZXMzxiLNWu8EUboXEgwYnI/cH2XdJeUI8kWwt5uKG1Xu+gG11sBBRHHz1lsu4o5oCjxKoVtF5XwRBCVav2gtKEfQ/5JS0AMqx2NXsIg6Ru75Z4aM18R3u5rPdDApbrGLrQlukemVN6mPx/wAdoDIC1eJtRijHUj7f8V/0IdoFpuoKSxsefp1xWzN1Wp95nJ1lIGEwlsOS4A9iGr222CuKg2XkBZdKgO2XppftuH+5z80KXLmCs6hTv0lgplaMCFG30qY1h+pfNOekAULZqpoyVKYjhVTGWszK2Iyyb4nkRPFHpuFl6GGIgpKHBEQAMdJh7NMrelt4jpN3SdrJqaO7ldEQEAPSNa2uZ63A7BGrZqtCFkBcS+Zhe+0DNbmK7nDEqt+I6Kx1qJZTHGYcriDAPve+56xU39RvQ7E5Lf8ApQsUG1iHUVyMubbXOZip3neNnJnrydGEzJaIDQDeP+SpMS6QR5QGg6Qy9XTBG0l/jc0D7ljhmHXJQ4dByeT/AJv5CMthd+6ht7fVp+ZdnaF8Q4xTuxxVZad4TqAK+UsHoRh2n4l0h0DiKqbzNQfCm2bp1/SB1QvqSi0dC9zRu5myqxEya+ZUOiCjlyy1Y9Ce82zfrMl4x0mTB5g0YrxAco+Jff4ht4eZW4D/AJmzu55pmTTiV1qGsKcY2TJjDGqMh26QOCw6VbGx3iUW3E0DwZlJVn7Sur3mizqIoCUI0M55uYJdaVbp+u8IODP99veVVDX0r/rLmhHJ0ev4i4YC061DbZqwwEV3LfdHGNzgxr9CeT8/f/mvoiwlz5c/iYq7y3GVvUUMT0ggF05mIl1lg9T/AJAYGF1rX0wJ2iKyqah0ucVCLpPxEPaKnZpHeKXS4hBXvB2PSAxR0bYBompp2gKuiHrejC7I7S17SjY1GwGpZ9Rmp03TLDjzDbPxGzc4rBXSYDbcwAycPePcnoje0yYaFj0ia1hEs1PDuVdFmY9DESnpAo3T3m9+ZV8Uy3kt+Y6pDrmWMQc4++Tc73dcQcptg6iOd+ZwoMw4KRXHhdTv2IM1N4T7H0v6ev8A05H1AaqPv6wDucOO0dSJsysaOh2gh6oFxoqo2gweLmXX2gnw/wCkIlAtZYF5Fr/UDDmKFrAXRaNmLlxIKP3O01O89u3/AHXvKFQrcwDlYLsDoRiBawKVVmsg8QrQUEZpq6oWroQgu22z6oO2gr+xiYnA/EQmNzpwYjW30PCR2Mq8EYA5lOe0FNu3MOvkR3VSi+kTh4ZlF1jzKUM5M4HXrMxz47SzUvLHpNSsBMxCzPzKLfENH5nQ4lYs9Jlq3M7LPDmdTKpwIxGOIjyk+GPVWR9oUBahtzCuleJlKr1JcSoyymgjml/Hof8AhvrFI9kz5+gPMvG5Q9cXrZLnESi/CEektqasdwRm1fnuA5jFXb2E8wjWURCvU934/wCrNC5HFqg81MMN2M9oq6kVVRq14Is0VXX+kLpyBDqpkVxmZXSOpr/e/wA/9gDEv6UeLuJirCu3Ey6wHs/qjRpUxV35gn3aj3ptTK2cwKKg011mN5r7EuX+AmV4P4iDO+0DTe5nqajyzm/SYUZXMG6e0URiWqmvMfB0xKtVa6wqxshxM8nGIOv2mRbMsEzyOXEvgZOqYTVMrmvmXk4gd/M0depKMOOs5W8scJd6imTwV2nENjr2ZRUCu/EMBRUOC9dYC7WmYEvrMjDIul/k+vMaXGdRZf0EZtm0r9Q/qIDE5VqCys2gZ6X5lCdOnrDXaG+ATvKvJUpp2TFOZrx1oYMoXB/06G/Z6TMwTPENyNe5N26RiICwCvAIspGz06+sSDXJU3IoTlp8v+H0Jsy6wzj/AId4NQdE/szsJQwH4EBdll5ME4zBCcO3XL7ShpwD0l3smHZ0eY1Xp9L1mC57f+JlDdzWxIj6Q6jFw43hbWIMuS9Zm9+sXkluCreZQ0wRa3Eqpds5meiclQbVY/mCwrc3RvLAoStrlgbIvegmMlh1lZVmYdOY2XHu3x9B5zEcXW3Sp/AmIQWrZed/EoiWlYqHA7e1ylg59iP0VfSwR6szwly+0v2xocsGnZ8x/jiYz90rNd1d26Mxw9mUOTPt6FK79lco/EMl5jur/wBkaK/EwRCpdYHCdpfy4mWkmWiWNquBK2vZLagt8PIyjHzofsEsyq9ih9x+06psTHkZWQ6tz2DbD96aK/QjDZ9NoL1hN+MvHwuYlBSdDPWYkRXJX/qoiqzCdiV39IZMaoX1M/FT0Y/+zfE7Su80i2p6MSm/MDndd50vtAuVxMmt3OoEzsyuq6lKXE92DhRNntMYO5LOjLd3VjRUrpS+fm9eWI5G8TlY4ntbBwme8SyvaB1TxUDi87mE4TXhqVhpEDcB+oY/AExtFWWsCAq3FHWPteh3xb2o95x9Ti94p3+i+/0D9D7xVMCks6Raw/SeCX/xj/jmAcXoz2PUh10L0/ZMFAYpNTHT5ohewV03Lele+nYgIQ1ZXrwSKcCpva8hq4WqI5ojsNuvB2OPWNq7Bv1JSXL6we0RUCd4VRrcCxcAuWTVN8HwRzxGNqnu4lx6jfDpO1zj7wzWfpzneL0hIF32uI1gBHbzLCEFCrm5emzc0V7pQcjMvTEvQ+uJY565X4nVDEyzn3nIXiMydj5h5lZ+8f5URV9ekDpXZZrO5QDkjhVek+cTtHnnExdhmZeeYdq6qgmGJr9oVxbp6QMVY5+kwf7KcvvOX6rm0dfR9BF4J1imJfid0XSH1x/8cTlBhBfeKc/JDAouQv3ihO/UTHtiHGY4xHEvsS4K+hXWdmXJ1dw7M7W3OQlP6G3PpAnnE9J5nOpXJz9qHCE7vWX0PaXvm+YocjM3szMHeZw4nGt8Q5UYIuHE69GT0WOMYplBjErlvpCLDrXtKGuE0dZh3dzEesB5RqdFYg3mOC5cyYWGc3rvNOvMF4GthH0ea/EqV0cPiYxVLmxQniz9wjBQFH13Yk2jPMek1H6Gj/5nn6a/4vE8zF9FFqczJqUg9ZzLhj6H0XtGN3TM6Et6E5PXPaotvSc8YlYmazHtOz/2ogW3fBzXzLWtVHDxA0aIpbO50dMvbSOnSYYLSZ6nnGkE3UplXzuMM24ezNdkp9o543MavMWzaIbg4YpHwJa2d/EMHRcqm+I4wlaw8zNWzfwiXwrEm270hbhYrdpT5/8APo/TLP0BKqOZmp5lM5qGoYQv/wBGOotRVHN4mpfWOp+ENV9D6FfRs4gItxKrmZNQzvmesd6l2/5OO8xdyq3mUE0T6sBMBoA9JcbRmW1TjBHFDWZT35jV7suarEzQsMbe0zWkYuFI3Nnw6+oYo6sfDPhpmsdZk1eZ0XitwF3eZ2M237yhdWQ1TtidTITijcq1HvNwdWPDCCtqqgw3hHxCWMFTvRP+ExNIJ5lJUGcTUrOoaIIIQ/75hD6k6on6O84t9JkJmN1lrdyHSHSViBAiGSiP2zUysN3ObY76x88Stpij2bmOIdoWSezLgWngzooCW63KxBfalYBgbDc4Zm7Ag5YSuG49UpuuDULr9o137EaZQMr8MNYDGYxVMPJOflhMsLjrnfETvhlXYxHgAxNlzheIecdJg7McHOGEqHOEWojlGZqwWNRleGXD/hIcxO0f+AqECBmZmv8A68TWaQXxH6UXKzNjEqDMMcQJfnEW5xwIc7ju5jOYeJ0SjGUYO8SrZugn3hJY2qdpglGS4dpgLxu64ErTfLiYvtPKoUesvuG46oxc58QXFDPOPWVfdLipYnqmmXX0XqSgyqsVzC3KgGU1QYiKi3buJ1yZgGYGMDCs7BNwxUPfUogGu/MGwNNymljjFi6qKM6qzbIVIwuPXaz/AMv0CZlSpULSoSv/ALpiG4CJmVNpzKiSpRNrlzOeCXaOwcTcMmYS83NGGdIanFLOrth1jUsQDJTj3gMwNO0XMU6xpe2O9YlFhxLxQJzKrfzDH4RVqGQrjrHuzcRYcfuxkpw4nqg8YzDZapnKmu80Goyis5StOusWHedwKTJ0SnOOEzx0VzMHiDniHLvGdWF+8IPStSxZZmZW8DcQqlaMtdlA6tY+9/V/4r6gJXSB/wAVH/6iJcSV9A7Ssww+kGNY/tzLa5Wvp3+nc1zMYwpC+ljLqNDJm/UtMSYdRcBbSiVL06wePLMsh2ZTllVk3CZvvgljtUwb4mHiFMtTQJeJkc32nJqZW/eI+K4lBXT96M4GBSZp1UOamsF3NvKyqs8xxKupcCi94MVGSJ2tlacuNTpOKlNd5srE3k/ESNwdEx1qpLUKw4JjmqqXQp6RpfYjl71/1j61K/8AxuY6+hXaVn6V9SzUdus3G/vAL3OsqyGJ3+89Juw3IMo/Sn2D+zKYDVUDMWC0l/iKhfwC/erg+5l/fCjQU0S9WwsZqdV8Sz6DHQ3AL3LjFQFCnxDOQZxlsgOpXPMwZWEr9KdI+WJrRuKzmPnDDO4xDspxGRfvAmQLJWau6nnuJnbd9oBectQpbGGF90ICrE9sAdzXvM+vXrGjr2JwUVAbWgzTk7Wbx/8AsYn0UlIQNhIB6giRNXqw1PO5VHac4nVSJfJOyDAEVom6xooGK0DM5W5hesT0ILxiDjGt5iqFhUMt4vRCwp4Zqgy5gOOah7tQKwamV8MdZd7hXdErrMM6vWUzeWVOmT1mKvNyumOsdQAo8QKikCYBRxFyMr9rgd/TXH0HRrmeSpkG6fzDr1o+Z15nRzMjmHC7ipw1CcbL8/6S50Vl7OycP1P/ALVOv19P/nX0IiiLWIBWpzmG8ZnrPtO76I0AtTQS/HRwvodoHKsB0mwLkqJWoAL31hrEvOJ0vcyUk73iW3eJzTDVBkYk4EpkrDFMrLWusY4ul9o9XmK+1jDKX06T3950DMeJdYv1mSfMTY1HZc3CK83zMMGqzDQV1hODGdeyHWrh4nBTfmYuryMctTt0mhtD5R1bV9ZTbWovmLPfj3PmCbSw/wCOf/rRlrOVdA5jS+RA65XB3lsT/wCO5hwPTmYgHq7jvp9VOckz1qefibXLxOZfaEVp2wLfSMLV02/ueJU6tAnU4Z7wGJYmFxAq7lAb+005VDh6w6rBQkGiw7wfhzMKfaLO7SabgGhJzkuuZVaTDmpVqz+FM14z1ngxu4mJhzz3n9iDLWSXiQCCA7CQp3hvC1Emd1LXfRKdeYB3e8qlZ3qe594TdZm3BLMEwEWsEOqWTZw2XrkL5MbCfuf85jKf/hlpMzTva/oXBWJ/5K7Gh7x+h9H6PIA7suywe0w5Y4jld5nYJRdVHr9OIuPob7wc/JKUibO2y/HxFZ33khdzPWJ1iFmTFces278x7Ea1Keu5ZS0qoSl8TC1iEtcOs6GqhpvIS0i4npLOY2fiV1alzWwR6RXS58S2ZtaI3tuON5hWr+J7nWU0cMIV+0F8rUgd/LK4+kN2YxMYZqaBAagC756R2bqa1NJhh3vvN7yS+JVubJmqI3B7lftgZsq+JeUGuelWfTPWMJRh2rZp6inzHCHaM4PZj9PB/wABPQvG/wB1Lc3bmJsNf/J6SiIAdiVKjRPzQhjP54jdUPaZvyjNYS4HDM8GZXfMrvn6dtzCXfr8WSAxYq9WDFPwZeYo+5w/3StQmQr2eY4Ll9pbip6tdJZkcMGPEc7JeNX3i7QZwdYYPxMXjU55tlUsbl+jrczLauArcaZfaBtfSZ5zHX7lehGup+RI9RmU6/EyYvB8zN9ek3m5ZefErGgnZR0ludiMToC5RFahGF4gektym7W5t+Y5Mw6buAMmyV2uUW7thwdIVTz4iX2jl6VzF6JVQy4gsFyjCtHYrvHJKIPpzD6ZJ3lzZX1w67qVM45yJGCOFlPJ+RC2DsY/80iXQgCMPLcOGLA5Xdl1t9Uz03lTDAdo+8hOMB9Dqx9G77TmcxMd4pbojFDE0QNk+zHzMq4Ob0+DXvAVOFfHtqUwMB2he86l9WfMeekpht9Yvb/faM7WkKk9v5IyVFah21Mxrbx/MoXuXfKcCqIKDiXq+PmDdvpLz5dRH93DHac9PM5UC2o0tHcQM9VAex3hquOsqjrPEVax2x3RWy6+l1z8Rcu5eemJddU6j7T4kFF0jq9ZKQ1irE5DjiFzustw2+Jt35jk2HSZazM60TIckK67hdlJL0wBFNytcTBhudjrL6sxiFrHuDrUJ8xTo8A0TiDK2+JilcGRd+SAXKdIXkse5GalGgiWZdW/xG5ZzHYGEYkeE0HoEpZfmW4g7EsPnGV6u0OlKtZdIaGUUNJdCzNXx5fo65RCFcPQMsw9cJizUmLHyh3ixPjczRmnnoD8oRKynCPYIl5dd/dKHAOgoirid3UHF1BmadgdT9obVfsLp7fvcNsA0AnIsY5JDdank7QaxMI4Z7s6jAJfeWTx1lNXeJ5upqtrMAwPaaxc54hrvNrQqEzb3KIr3hUKgmeTUxDTeLmrDE3uX2Yv7TeWc395xmgnND5lFDVNgs4h7ouCF2TwfiALHs4+8zEXBBQmV0zOLDti2hvAlHb7xzH1hLnV4Inf2sv170obF9UMWrzmdW39dJZ/ZekxAjDWfMbrJkhdV0gZYyToeAnHe6/ZcAmGAcVqURs4jaK1Ky5hVl4+YVSleUOyYDdU48esugDsTa8meiJMDCdZFtLjPEdcTIYdFHgLwpZijwP1BVM3b9UOgeMMqtzTHkJzDMxoNlM++7VDRQwYZTMfFPkQfrgfLTbMpd94Yz+Y5ma8WpajS5frsm07riKcYozF0O/eJF4lvHvDd3fmBb+YVVEDMsmVqH4RnV0dAg01PMLuvaXdaIjZ5mdLYrXyZalAyRr9GK688gr4lqM5YbHixriOA2j0RHdnWkctP1iwCOxYUiZdc/xOI97/AJQFY2yn6JQomjT+070eL7zCu8D7saCUl1JZd0w3yYldHpNPeq1MXhqc5Z7zeAlTMIanEb1RUM6mOuZx2hMjCDpZgrllNqVxLWz2ofPELUSdYKjTq4c1v2hQaMmY+xKAp8hJf54xWOvIxalWeIyYpLxOFMSqfbkMHLxmLqMLIWPViZagXoBl0VE4JfMKFirkONSkBhNA4Se57kxzq3E2TLRkC5XUGQpV9v8ABqOpQ4se5udJHTC2KhxD3L9AV/RL9NZA6Q7aehWmgfs+kEHkyJPIZwqTdP0dJrLSSntKbNncnwmxSTpXwkQuhpL+541A6MWraeIjXp2BvoRGdXVL8L+ZrC5vYfxc2wHvHlTLLuBGPYUBAp40M/1zHJZyLt92aYM9Yp08zbBDWMTpplgQre1v5mrOiuCaRagF3C8SolL9x/ibJAuoX3lcWHBqlVV+7HYBwD84zFoOUsPtALB+P0QHQvGBuu2uGB5kecZ6GP8AJWPL9FeYRgwrLuKrL3hUDpUFuCu8Utvldhr5hba9fhOWF8N0ikipSaRnn1h0NL7rgPvCU5uAjR8zOucCuS+Z8ZR2lZwTtzKy1idcfS7yJWziR1Rgz5TimXHEGI0qMtgu+bgUrPM5RtAcF84NxVxH3wLKl8DpIHnklFvgBtek9pUrNy1yOGOssepX29oTOwPo4nOETpUXZ38/eMl6nM/3sjFKBy9IV0Gxx+AY83NPphuxt6y85mItGagDvNOceGMFmhLU9PO/WaKNX8PsmxaJrqq8Y9JgZJn9AYP5nlYft/8AQQEQWixJgMXZ7ngjvQZ6PR4Jpa0TpMppK7J4m35tuLXvuDi7aIcAskXXSnrEMXReJx3TyzD+cwK+2EparOk9V+IcMGgTLmpek7mKmGWUBexFTId+EXlFC/CZmqd9onVuuI+COYngO2BviHpS0T9otEgCxFVfvOgY03Mx0ovvxPFGZwm8WYh1CNLjoEA9kFsShPUbruwMEXKng9IwTZZl9OD/AOTKJYnCNPyS+7Hq8F+2ZQnA6rYjhQBq67zAwJqdmC41/wB9IGgQeL+xLD1nFwhUcx9PE8yeYmOkcIk84JhpGo1NiIU3n85ehSn13NCYa3BF7gGPtDrvUGqleKjdbJ0P3GgPNtVur3irx7LsvXvHDdWD04ly5i+8H0gkAS8y+2g/AxUApgdeYoBoGdyv9gxNW/pofRlG8Slqd3XQLmE4B37/AFDrxjzNLuFUOQ4Hp0fsiqLIC1S9d7ftGqMAe+XMwhs2FZw47/Zi2mhcK/zWfMApjsHmKZU2trsHMWZVstu8ougjol4lDpgNglDxlv2g1R/rmCw9IilZ/wDY8xQxrJ/86+Zz9Dq7eia3mehAOHeUa85rEGe7DCsz6yAQ/sRYgaBs3MCbpHbRMrpghXQIMLh00fuU6kt1a4fU4hb191913PtGY4EvYezL2+sj3P8AISjXZmX4ZeJxxckjLDZzFmDUyOi3SL41BYebLiPZmvFkJgx41pEvrKquSo2fCnD01Hi1CfZ/EANcjzmM1gEvzGOLAt/W4qu6uPSePWOiaeaqaJTJFZxmb5uX57E0OOsqILIHpD7REqM/36nFY01GAZXxFYG91TlEjCOjfsTKZ15fqU5xPKGQD5c0d9YZ2HriNunW42SmLwNRQIB1NEf57FXGFywgysHWFTTyTIlzvZFPkZ8fu/g/5pCyehldJhbtuggUjscgy90Y3KpURbtu/Ib8Me2G88GGWKxAzSGKnRYV930vEI5kI7Bf3j0jBjp9ToMvnHYOelS1BzoMwjheaviez8wEr2i5csMFGCLLPo1OxxWAn5CIEirPQZsTq8xWwPv9Ddy4VTv7IfNJN28+5XD5OJjycBodSCsEsfk7ytEdW0AotMqdQbHaZ2vZf3FNZtf+0Vk8IRQt72kV0+kS0GodBKlqBvGL3vUaiMkml5S9Ba4rUU2RdyJ4qKRWvOn5IPcM2V29OkEevpmWbeNRME1+I2bZiWdCOsNQ6EprG5m7E7FK+zBdGA1TJuMp1yP8RAILNNY2Uzp2g1EV8xyCfOcLTilOuldIBsT5Tbe/RmC3DRmWLGaIxyA0ODe4CRX5ZM5mS4wexiyOBvXLuVdgJRve1lKKqc9DXiiH/AdWoqOVC28YhvkIrSakwtw73FhrbabTYV5JRzwC/wDpHEepws5u6+0SKlNZjR9PWDEAvFqvQD8RO6iB5Dm+D7zLYLk6bTr+/pxObrMDQPA+gzHf61FrtzAvcX0K/wB4htHgvQs0dCD9Khk9EWItE8DF0eveGHUQGFx6+pGdHScPeAnxufvKWeHpBdVEdyK8LyQypc1xiVI8DKOK2v4lBGOhUSyl9h+JevAzzwtZPKhopWcEVyvm45MNN1LSnsktOb5ATMcovNWg+JblDSa7xKCdz4mSfaFw7ITYq6cMaszqzgp5l623TSKx/D5iiMe8llHBdsi6j1MNuI9JLntV/czDeAKO0InaUqc+0LFAFYhGuhzigB7+XVTupSdV7JVwDGrNIrMF/wBzGEPe35jVJMIH9wjyNTORX/jvFVoOBbgL5hcX1nvaQgAWix+lhLogI6oClrqdbc/EaxvL+Zn92erqEhO9lG30w8ynZAXkUrvWJ3jPj6HmFXB6iUgV89EI7zMq602pb6VPWcS/o7+hfX6VJCKogfTpcSn1osSwTmiPIce8FL/Ft5H9TGsoFnT1MZ1GCj9ojq1ZX0mLkXbN8/Il5Y2tvuKyQhsiLn1cQsMZWFZ9omge7fzARfg74q/vM0F7FRpoHxNdG5k54C9lqvV8R+6K4MAfBVJbhisKhLs6zZ2aZ1PotFPbMbWBOJbSuTwbWzrKenK5jXEeLNyq7ThuqnojbmvE69o7tqo549poblWwnoK7cj3lBX6sbAgq3PBHXlHDt+4L7YreDj/1hqJ6/wBz/SkY83lswo33YrPHiNhcN6pEVGuKAuNwSFRWjGs00Vlb0IA5YfnHRj3gymNexGzA22j0pz9NNnknl0X8TEXJusd9ko9piSGFPI9iXQ43w+zGcstH74/MyiQOhK+OfWZkzwfzBoAVBnm/KPZRN3gZJ/PaXxn3Jk+QTM9ZRDN02YhC/hhiA1hwKCMYfS/pmpT3G4TrbFHRuNZH0V5dE68xF9nD5mMoGanvjUpXZWby7YFRDsGLvBrlYHyx+pYrgmV3IWNER+FiJyIyG/DM98UTHVldZEs80bvKCQS76x7tj+9SnaeeYkUBM+GlOyUol/hLADsgShI4wKOOJnBvORB6Z2eiYhRTwpmYSenOJho5NXitxDiJWZSGJWsj3jdwErpHecTeJiF3KHeYbqBdjAGR+IYfcZkbXUpBctui/Mvc+9gg4Mv4pDgJ6gx8Qu/7O0Y1zop+IBhWGHtOO8SitrvaU8rvNf3PCsUO80opcs1BBSlyH5gLWk6sfeHXQbo/LE+mAFK9ng9/+UOyJVrqbrriO6loPSf1NPkBB03XQi1L7Dk8ky6NYe5d+lwdqmYz4uOE1nIVk3bBLSl2z5fVBZE5GMZxNxxfvHMwKcO7Vh3vEQGwm96r4d4/Tj6cw+ilR2WyvTvGgXYZr5XxBzm0P7D1hM20EfED/lJdB2VWN+krSYmPkmYns5pZkj+RAeGrb7ZY3x6/2mTkA2IneOVcOkmnFUMBYO7M4yv87nf8f9ZYHbBc3t+uBZnPeRdZtQuS2KC366Cp1BlI/wCzhKvB+4qrPajPzB7sqWRg33gz5nPSPVdysWVPAlr6pXbPEekwzhh4HNHbijrzLtBvi1D3IIO/mhlYbOy34gOn6PxK75BCvvV/iUTS9qI4fK/fLogaJb8sQ474jDC+Vn5gKj17JhbSjHdOOmAkTSM6ustCC+fzmVZ4LPsQBrJiqB8RlJDmha6Bu/T/AOBci29XsQU12TI5DetQeyUAUH1USnTP2SNRF3MXV4PzBcQ5WTgIWS1dUuBbPvFUYBKbsE2T8wbWD7xlXA+gyhtjj+PIk9dQn8OZaTf6Df2VDX/bMfCOCLhy/uGPm0nqBzL4oOv2RlOakawPWf3hFCvuWgAPLawqu0W5K6SaewVPFd4jmePeL3djolEXKlEOI/LECc0HTF9o7IoPEShzbtJkIBNCvc6RMWuLGmO0AkTRdK8plKpEa8ysMMWly2d35hd2fM0mZpaUHeROp8AVLhGvL8upuaPWn+JwfE34lckHGJCinelMe0LWE6/6l62jx/qHCKNJ/csHAZqdnMSm0cH+oeVk2DmP51lmrulJUun7oXcGZRH5guY5xfepzC6D9lxX1NH4lbGgOQbwHXf/AHR++ja6B1jzr3hDr6r6M4hy7ZtR32JfAyLRqniJTBJrVlxgGC+H3+jqGuBQOxz7MsyKIoaGrfNQ3N3ZeerZ0lBpD3exMmRLuez96loldj4n5gLan88xMVt1Z+IV5fn+6ftArEnqWX/x0gKLOlobOhrM2ClXL6jTP4ho0yv0H+xBfeya7JnWYERzVx3tvM1F4euC7fRyqd3dLV4qNhh8O+8h7MrdmOf3yzgV/XMd1Ah2bfcgBmQkkTkX7fOekBvoX/dLBwF7L95aSNM7y5ZoiXMhVwqjeJ4T1SV1n27TAIym+Bk8MSCEqb7yOG7KloCOBH3JS+A9Sg07Av8AthlR5BXxLS4H94lgVnBEdFt1mMoGLBr+JZly12PtBbsRi6r4uOGzN6In2OZQ3+qErkK0gMRS2C6wkLn+SrZY8ixAekp2tdXD0/6tbMojPG8eu74EAArUuP1Ma5tMniBKTZWTR6VG6htcRus1xfeqjEYBQdI18X6sS1y356QSR4rIsycrglKuVW3+vSP/ADQ11Yvl1GMLY/g6f+LnyVfQhEKL6q4JkPROT7r5XZIViyXG3+ZjtCdAGUFYIFNt3aC1Ce5+I6XQJFv1lp7cjKX4mBOodoCX2YuwoKqtMkV8n3jrp+r+InNTAQqdBhT/AFA0fTE3gFjgQelx/LEAkrDL+oa8eqKLY453PVHVXcMcWzg7menzHic509Jm9Y7w3qoMeEr58euo/slReOsUToYD3ruVabuH2YhC14U+aikuK0hj2YfVrgeveXsSt2z7srb54h/zGAqF0kz7su5J6ZoqvtOhuS+EPMWEB4gQQWCGmneWU6fStXtf4lGTyH3CLllPJPuZjrmGQJkOs23qRypBP2q51a7agVmdmXGArDl1b5lgfsC47l/W3UnQ9EcPvPIfjPnUtCQA4tioUEQaThS++Ot1hj6WXXYWTLsyplwBBZFuYt9F9DXpCetV16vQhJbInC8x6Q/4AikI1Qt/idzhuYxHtQmmvqts3LOg0TBp/sp0gDLh3jdVs4yqGtc7DDJPynopc73C/Dd1+8YutWj+CCqsSapuj0YEodR1PujFCK7Yyz7BiKq8fYP3A4F2LXzDxDQxk9Y9Z7Lmi5G7dQZjC6w3ABA1h5z3lwpftlGOtt663OZn0Sm0R4aukvPDh8WLR+JUzWp3xKYapWlZlvL2lV2CXXYXMJAA2Z8XIShKr/YMw2b1YgHpSUBadD7DDH7DTCDJeKOZWECuDBXHoTao7RxIqjb7feXUG0h3De21TJbj6sV6+7IB1zzE33Oxi8/EMqYP4FlMAK8fsTK6Ogvq9x0BWgoWeXVnRGcLwe/ePYxfSeEslockRwpsG3z6VMzDA56VCEmsR+uKtcRU0LArnkCdIZIvtg5g7GSUV7okHNOzUEWdlex6SndfRZs8gMB8FvtEPLS5zUJTKcfa5Rd/KPRmYPPO4+WKg5i9E9+sqKDntYQWOm9QuunaXnia+/gBgjEZ1u0Zx8RE/FLM0OXUsMn1KBNCt/ksvp7G9zgOfSYOC5D+B+JzXPPqDbxibBtLT94gwr9Cn8ss67j9qBrVHRP2CAITZQHm3D0l1ADoJQ+/BKqUXZ/qDKqO3+JfqUPd9px1NKqerqDWancz79k/2VqB1De5S1lHgl4syNsphLbtSM7Gp5jYdGUKzouu8eky4SpkviU9Zk5h/LjhEzlsfiPGS4KfYlwsglc427GFh73mX4hlEjor8vDKl/UIfZ+IIBd4D+IqC1xQlByauY9o63+kZlCvRR9py6vdfuU8/wAHVl2qjoP3iMxGql6i5XNYXEbnsy0tOETD3B0SxjboLHTccgz0L+Iyr520+0yrZ1A+zDOxbIgcdjJqZmjtAVKVBIPcgU18bX4gVH5vJ84iuw7aH4jgJKaGKg6O0eUsEuy0d9GZoXue02SrZ1b/ADcrQYR2dtx+04qIayaqB3zvcG/9AffvMnrs8cL3go/zkY9Duosrj7fkhDhNZG+nSYEQc71GnpGrAgpc2fWsRFR11TbaEq1u2vLXtK6ADL5BWYgeDO2sq7s7t5UMlVyheeZS0hQGPSBop2B/MzJhtEwmkGdX5mRi+t/MAxs5LVFl9Pf3gNRvQi90i8yyBnp+BE4rT8Urw+LBepjVa3LnuIe8ZrfUfsynBupfmgHyhf8Ac1XdesM4wBpvlHGL3tjp9hIGywaBQs6I4oWv51GotjZ7WpdtvVH4jNZN3A6PMawdDQjydqVdM59Z1fcFf4IUacv5BmbHb+fTUygLcb2aGiROuPVg5Vk6wV/hIvUlahXSHpLUtWJc5tC6jPp3Ab2aedShKNyyHaceN/zGWDX8KuObD7X3k8SBVfhgsqpWN+Za2V4fzLFLMzY1GLtaeIrPJr/Mq17z9SqLFYtdNH5nXTuMuiy6s0oApzvqNGp6Z/kzhhc4P2TGqIk9o+Uau8TjUGoRlZ0fosT6bmZhcNmaUPuZZpz8ztNe4Sro1S3l8Bhn5mFhsuCp9hfuX9VFfugADdUP4lkAef0IILIu65PaJrVcL+qVtgXGUficNu002v4eIJk8l/1LN+4/UMd9vL9TMVQ2g/qVwewuYHS2s3V0MGIVqfw/3LNF4ZQo3bJA2tOGV6Qm2cBMrkZbkPRgFVfzDte1SrWbtKqOqiM79sm3D3TUoK8bdAV71RKqwvsy/wCibkMRKece0F3h0S/Mc1eSXdL2gKys6pjAFy0yuSuV+iBDe9EmfF/cvuynXAAjri8XL8K8WlsYA38kbdh4L35nUl0LCUVelTeeZhzQ1cT6kLBWWZDmdyNB/MyxExM4xLxiVsHeuHtnmURVY2j6uG11VJv4ZyBwD9mpkWbqv/kzxp0T8QOyl/4iYJueMn2j0td3+ucXWKJ51BuWHLGTcIth4qUD3SYcq6uLqBeLJe+Tbb6ynLBtvD2JgEnOt6xeWAG6OePWX9pvkyyNRvxc+PumIsYwZ6vVi2kS/wC6PedXXwjF9hq3KdBLi1FllCbB4N8fM3jvkKUIXZU9tQUTC0w+ZwJYqc29YECryWFBYGyoizKJ3mp8hsox23uWPrFj1ZjJ0V13HeDyY1TXTVwmQCilfIwhSm8yxUTr+CFVL3xT9S8DTm4+ZiY2HV753mkuotnvs9oGma6XtwNanJ/PfNBvYfE0zGdcNMrprvR/cUvMbv0mEu43wQnQUya7xtjh5fdP5rmWppKKn01O4X8NQNpt3fYy/ueLf1C0iaVFg41KHjSORR4QwQ8cJsWo7CBGjTwP3LCLrmcOZl6J/cwVVV1PMzYTzTYh3gGhoVJNvq9mI32kE2vSKTNSIz2cf3eYEzEDvbKYg8VOKfiUdc12TOKqOGc5YUCI0Yl1byy8CytM/kTzP6Q/0C18kPiq0CtHcjIp6CkKNHoTZwB6TgABJZanZix8WtA4OJr0QUNL6JfaelF3VXAhEsepbAXc1QD0z9E0ALvsnyGiCj0YMH1DUt0zxmPAgv8AAQNx3g/24m6XT/KQbJe8QdQlfGvBbfrFW8zUDXK9h0wkqQq0kPYuXl0f21HGRysbNDUDbdfYDtKmca63zLWDV0UfMS0E6XtKjTrAN1TVetQvYc9MpQK7hYpOg33mAWjF1Vw7oBAeSgmNm4FWcie0grfgMaJ/tSfSNYAdS94E0vCEpUW7+mf3NKsL0G5SnfvDWIua10jqJLOp4qxYbg7mkJfzHg68sTAxcBGYHG7Qd9BQr4ZSBCt0Sjh5ohe8N9YtXXEa5DsRNY0bitXSVqwDm5ckI0gaouCbiIVmw2TSkz6yyFmcPxTSlbX/AK+I7uVhZLerxNHDFdcFZrl3PUldyNcA9JZe/aDNPWbPvFHhM6esNdpbA5Vh94qcbJzG/UaRwldtX9kEpB2cYaM/xuWf5veXqmfx1hkyty8+s72GufMpw7Eouh7yrdne5wTd6x7yzLFrMjRM4o2/4QBUzSa/MFO0x/lKK2LsHBrxHRcBvMu4N/T136EuFFcXThMsTdslP/AmfaZ/kFvzChsNtwrmnjNKgfy32F4+JZVsobPfMQ9BEIHZao3w6JviTfvsXKRvXRNY4Lje62IivFMpAlonFFsfV4e7MCBp5sH3iv8AKQz4jMWdKGBaakCLnU6g4tlZtSsL37biLIwWYPWobkNVHFqpsyXNoMc4tuRZQx+8PwzBDCYcnbUsQVBBCX3FXLcE7dkjMu9vfuA1IOhMbfOfvKBjN6ldTC8sPUivsQ3I5+ZmhKUkPuoB3d9wtNy/bfKWWy8/dEfzESR4zBnH1Q/UL7W6JLY3hViNK3rJ/UT3GLJMc506Xiopm5qBqUpyn5gljsJaJn5mdDzynE9RdjHmLwquhDMFc1S4/aMO4f1OvWJATTMCyvJOdy+qe6UCFCX0IHJLoeJ/4VaMBNMhUIXyjKX5JiFown2UjDE8D8aPNJ04/iK3qK4/RFcn9naVry+T9UFolww32jFYP7vHANvo1Hmp7xlohpmmtOW3ODNLXXCb/PUVkvWleD9wD5SAVen7jwSbOVdx5jAKS7pfXrqGTlA/E9X2nM5LBXVwerFOt5f61g9J1gEDX2ZX44OP8ThDRyOXGZTfVlSmOnaAVrtn7QTBPLhDJ5pQBxmZuK7oB2l4PCGe/aXLC00VxljqVkPUCGKEs/NNc/3IDv0jUfgQR6Tml4T9ri+e0iGVFqSe6VDwaaIA4BESmvaKfWG1IrRfioZKqzRelQA8EXMtJNJ3RCHCq2yjvYHSeYgC8c/R/rIg4XVSpBuOIiOJWIuvDRRjWxzH3kbixlN6Hj9oLg3qx90HqLkKP3TtZDAaI81F6KUND4T9kSYBOM4qvSlSoPhBNebS2byZJn+5BZnuwTCl6F6ukefxAyl7CkgDoNwGg6y/qhrmP8JMx0Thtq+8tc0rbJMryn2/Vebv2mVJjrfBDVMFaIqziaBvCr3gWsV5Xv5iS07zcnxAG+HKn5lkd5YfhLh2t/bmPBwMTK4X1uJl0uKtiC9uM9WXDfuIMtL5osPpRomdyHf1HSTKyrG6YHIL+hCO6r+7juv19MxaHDUeDrac8Iqrv8XT0Tadnbut/cz6TB3AdV1jXjlNIWPGj76GVBtMmjPvMrCh3nWcRY79ggeu4fWPLl94htrWcZn7yu41Odr1u4EVT3HdlEqFYcsb9ZnbiK9YV+5BO+A+F/EdkKzSwUF/MCyjGQqgVd4pNeNxFuSsORcuP7qixWC/MOO0qHvHK30v3lRut8Bg7lf2pYC7o2DXTtAcPUP0gLL/AOOkudP+9QRxPb9MDoGoNd4dZjEAMqmuj/sDfnzo5wbjY5LJDIKPfvMrqUuBhilebd/cmJRB/IATaD0WKOg5L4gQgNFCl4jthdo5offJsyDuhZXzJrcWd4h68YbYO1v/AI6y6pG4/kLaymM3xBFM9acKK3FjlZVFygpvdB/c7+MWzzuCsPujbjM63h0uMTBEYxXSFq21Uo7zxD3Tt1cb0xiaeV8QYlQ0wVNXLc19iUYVvWimRCjQ95ePTKfiDls/7xEBWDRObh2rG4MX1K4O/TlLmj4B+oB1eCcCr4TBR7CKm7fWcfvmtssgXpKvBfWjMYxpOhwPTcV/lEpAdjwEcc4S+h9qhQg6n2QeM6KgYrG6P3YoXsU+JQaCGCr6xJvNs35mMG6tTWb1HuYQT4SVyilf+qAVHFi/eBgyAbro8ahDmbn2r8TMavJvUAFUnwBr4ll65un7xo5tVVAPecyAHro+O/qLUUpfvHv/AHUAlgrkpArCs7Z2wH7kRA1Wuy2fMyDWCFbb3LpqlKhkVgqbHIDz/wCR5BPV3LgM4NQw3wz+4jtUjHVcJi1X2dSPZ3nZMlzZKN8dYmW/UGNuyvoVMR2QX5lRYXSlFE3uWQQPKhJvJ5lpQDqRmWGqZRh18yfMIHzn9iHQzYah0hSUPzAyxlu2HJPqgL165Q3F9V/M6j7I/uUmLesN4c8CVeblPSclFXKqmYbZ1Mkb3HasFGNxzpqVrV9YJ0slaw1NELhRZ8pbF6Ny1EXql51LJbqI7+ZlNYj0x7S9ZxCnS3GIb/UtAC3RfJ/3RXdr3T3Nu8dNWiPK+7R6xBA3Dw1j8Q23TaqLhuQiG2rC2qv8CVIKqvO8nwV7ym3mxUpjKFVViZDG3k0hrbWac37w1hvTSNehF4bjEUHbeoKjuz7xlrWV3puBUtygaQC/i4gCzjJKpXOsuWThpYRNISvej8EWotpdA7x88yO3ovzAOqIvFYF+tSuhh2f4iaF68MsUO4CEfQg5dAZtqVZwC3SdedXTfwZRBiD2Br3PtCDTD/chSA1wTHa8Ra1NuycuYpeLvxAoVXrNEoFcSjGcSvCzRfWGG9S25sZJd7qB0OIN4xcvNItRRxi5k3M406xsmlweEwzHRYv/ANJbSae89S+8MFRixjg4j5qZ2JTctWp2uA4ekeoytXc2lZpz3mN1Ot4uY6y29ResCamL7BGtVvSIlZ8ht/RNs/QwQQFfdfdmPP0rZY3k6QAMVlEvzMQCquScc79L76xgqwob43xE3HPL9zXV8Yn7xtRQUKD+4MU5lPeWvLbCr9xFZcUVD8ofYsipbbFxORspG6wG4LmYhOgqPwzAdUbMwG67W8wz9RMypFWkuslpXtfrlS50BEV1nxMb1l8gXXeC9VGpVKprY/3M3hc317wLJCU5mT/cXViqZQRfabygmFrLocjBGSg5q6EZxLaGvcm+c4TL4JqhCsY13nKiW30Ijyn8Znf4jxUu+a9Jx1j6l6j2nlmxpBUATm3M01iDbeYUf3EmOa1CtYfWY6/EGv1Q/EYBamvwMNwfH7hBQU54f8xBw9qfzEXmdVHOQ8So0URerbLB2li9zUvOrubxUezM3Meso4ZjmIehNmp4SzWcwb9cXqMBmV/YCWHFeo5ZT1IbTvmlCRpKSm/+qmL6TEqB3lZiZnQqdqWguJatTpE7DK7/AKdcll91RipTLUqXeXhq50fs+sa9LnfCPxN+gzF1vmZcTm4wHXpiOAyk47StmUNHWHTcrKaCUbzMlFvepeKn6iNsH/FlfziwK9peLkrIHa0FMnG1fn+IcQHYmPCFrMBbzOcys3V9YaKxMz3Ouw94gVnRZ+Ex44wPQHPtBK80JjA9jNpPIIs0/Gf3mXVHNFCVS7P6gmeaG8iXU8HvLkR1sRksGuRbtyeIGZZS54hWPifjcHvKdGW7qIFuCnyS+kag2Xz6BEYFzaTjHeVlw2KGHQ/9cQq0+X9QhheP8Tynh+o6j1D+oZsPn/Ex4Z/nSdTO/wDmYM+5/UuLT6/1Cgu3n+kLKaeoIZj2mXst4Mrdps0SgG7uSz+y4X5iV8T5/mc4T+eY0GH0tG/s3/DF1YOtP3BjAYLNRxnOy+XFNedI7Svx/c5MR1H7ijx+H7g1LZGfxP3MOQgLSg6o/mUU9m35mPJmgFa5fEDYn+MOBm4weQV5yyzrMZpjicBudLGNXdxeUsxL6C+2YAVXWqlF61b4JXKda3w5B9tc9GBh2x1iPcIt8wKgOwRziomFU4GYgreizURjr2htxWpihX+78wTwZVmseZhcTBpc9/eVuWJaryRC7Be7LFgHZhNWTzAYCZs3bb9SmNvgbmeupzOWs0HZrcSDYoyNdO/tAcE0ZnpKWYeT7OJpvenHAeXXiXXl1tn0zaqnVqZxiU6qVy0spZ1bmUu9hwdeplGKAoamTlLH7RbrmGBYuHiNE+zczjfwviUnQ1Tpl81O2cPAm8F+JkPV3+iGK+Ly/pqN0ljTYcHe5vG98iL+BlAOiLQZES2nn0iAirdXuAbB5bmym91ZE3w8ZER1mdUDsrXri+JU+myxvL2K5gzod7mQHtDSeupUja9YLuF22Um7essrR6TMbRb2jFkDtIXEA+kWrndZnuwMy+yvwRiC/WbOM+ktTm76Mqtp5gytp6HIywXhjyih+XhmREQridC71UK1R232lUewAblTVC/+66Mp5Aez9vVeOscV9yb3T0YBZFZNBh9Finwte7xF54CShgbAn9FcSrCZ5n0dXAllawE6My4WAZHQFjHDbLM+f8RFsZLXCx5+J1WT1lBXL4U+YOiPm8MpB1y4esUEXvURWDSQwd4TViDZWdioSBert32P3ERqY/wHzEKm+wGU9H7EaB7UEEut7DHkgv8AsEBS4DiL4Zor2mXmppud3ic18wcXuNRql6l3qVs8vZjAmhHktnvFGDOTuHdSxMfj8ka3l4lwtXM23qPQJnyF1/6IkTY0BPE8T0HmUJo4Mt7Sr05qj+6gqyHPTFnMFA1w9SbRbhkusLt4AOqJyB0vIDZOVv8ActVQYzTPvE1F5/eZTqTFZxbanZW5lrS6/IlNvXq/1C7WOxWO11oH9QEBG9jX2hrg67nxFYb3WJsaa0IAHcEPHc5/syyhtotwAp8ygJAzo8xad97Q7OkCVEOBg6FkunvFHVlOaZbUvl/5GxzZYF3jM7aFzNKTo5G+YQFCmv7sAJjVh+KQ7FvhEe+Zv0gK/ZjprEpC/GoIN4T+icniPmg5cPZ6eZh3kbIEg3FIKvNdZfAWUDIXhWruIGEfH0bA8WcG6ZgplC14pj1nlbC5NHr1mBPVxxrVRQ8re1Wi+sSIUCOT5TNf/AV7TH529dWmbNgoUur9IWrEZvN/MEnslT2YIAo7/wAkKvf7bTDXpuoxzkG4jU9urA9nGZgIxLdIjsKGbi43Giy7hrCuEH2RrP5ekqyr1tfLKUvRUI6D5gQmatqZM34l06i4xDBeJsfbDTQq50jR6SkqnCJlkxNYW0THATucQ8kCGAMQuOkDNUXMBpCBdhR1isv0UxAAe8RYueSUkPeTc9xMWwmeZ0L6izr+Y9dB1Y8rtGqCpn2+Yj3EO2dTDFXFEwZIcWlWDmJgeQ7cwq3gLlWYF11mxk/UGAt8w3nmbqj0g4KyO+8zalol4gpoMeneLhVjl5VrzCR0YM+7zKuhG7sUHz6yyC1htH1lnR7wc3/T/DuPR1MV3qVg2f3SWgkw6e36msjKgQ7RLPqg8PaJiNhbN+f5QRt6836QzKRXNNPWAqQ2ljHXpDSQ6urx3ijqy2nf+JRg85XHbUeUnoT2TMsjwIxjp0Ijxty/dHKa4v8A9xPrxrH8wqwXS/hAuhMLzAUUzu7GDc3pDxAKkTLZZ21L+FQOfX0ELF3UvZS506TslnTEPBmDio2Pb+eYCU9TViJbhwGYJk7X8wWvYCeg6olGqee37guHwfuGUjvWP9mLIYryF1uOenipdqre4rdV+Mu/QmI1OyfKeSPKkeBL7zNqzPWcb8M6nFxcEVl3uZqt7TSL9Fh3PxgWXeoRFl+iAsr8JLmXeMw7h6Rbhq6C/iGB0TLENKnzAsvDUOQUcpLWt/n+o9H/AL2m3Q/vEGwkU6nSdFzfWOAASwpXUYLJiy+EC7WODZ/EGifS+Bl43UF2TddZxJdRUGZOoB/JmMhB4louZ3c4cH00Y9SAMN92bo9rljK7hChfWxZ7ylruUfZqVlqmxHaFl3UH4ZlOZNd/neWE2s2zx0ol5Ar6tGwC2N4g0o+ZReftAbsmX4oE6gAnxBHEdF6mPSJ0LYwHqH5hIaael8sQY5Tx7s1Nc1yTk6TIZtlAlgv2zflfLLKKNBeAjZ12pjwlWc4gfEJkcjLbxL9vpDEy3GLi0tGkqMgMUwqE2bjrU9Zt1rvMcekxu+xFpTdohxesdComx4qxH7auBu3yzJm+nETD7JewoZ8sLSlWAUluhc+GBK6LzKyDyNe0w27NRM7tc5B6QAZk8nqycp3W8tQe++HSHOZGxroycPtZlv34I0PPb95bpDv+6BL5aWyy9scVyZLZXouJ09oOV+IpgNWFOky6b/ka8x0YNRZ4Jz+4lPKbS5TDU97HbziAUI5T/wATGfvqriE0ZWglV2Y27NUzk5EbfDtCiPx9yWCt3Wej/cduROF8JmUpgsnqwZTbjWfLAp3Ycw7nICvljKKmbWMGKAaBegf3C6vQOU7T4x+0ssWMsv3iJ45u73EIuceC/wAyrSuiFXUci/Ojn1+ceZ5lwLuNPQmbP7SshPSWFHOUf5e8e2ZrIyytXowPMrb+i1spue0ykyczmczG58x8TPt8xm9yqoGierUV16JJeD8z+ohSh1t+o8GHv/URXVGfIeqCcDspmVIBpV9v9TZR4MOizqH4nUGTZ92eI9TnWfrnJPn90tcG/J+YV6wdbz0btgevaysB/AlnPtCB1w6BOIcpwDrEHXHeYlZZZoeY3u3rLOt+sxRRqX3RLKWz3jVpKjDb2iXU7M3Vp1luqTDqvpKKwi95DTNyR2eqP4gFsxZp6dmFtbIbUQjPUXi4WhzJQZ94T2NUF+NygZT9DcRM1hC/OYBKMj4u/aCuYcdvpb7eV0/qC8pjeIgozdry/EY7HN8GIozDZh+IPXeat95o95g0BvVRAW0i7EcPB5Y3/mwCKqrlifSnQiifaPtctU46zbBhyUHTuwTkcfcfWy2P94Kk6opU+Q8RVm9vbLvFzDir6x45mb6EVNjUGs7xHGNL2+gKY0JuGVidYn/mTPh+UJjjhLYvKlF+otLNlXe0pWBZrUxfNHeUYJYzp+cF5Jh0Pol5LzLL3UsvDMufaPrLrpcv05nqlEcMyaI9rLqrCNjl7xU/aNV0S8CWa9czdevf6a95suIMiXzHgqamFFeeI5VCBXUb6EuMb54lDS/E4musEkoPeZPvRyHc/O4RYrznf3O8tAqHBTmklzBOcKfiOlv8cRewV8h+JcUL2P7Eb0xqik+UR9dFdg/mGTAsTmDKbUAyz1418D5NxhX3jRLSMsN7rBDU074pYE+eZ6EV4GpxFTTzcRBQDyf+4Nq2OWF8OYm1wSVgAx79Zb2wWuCBbglsfum9OUs5iJdBoA2ytG5wffrEAIDV8fEarxuv6Jww9oWZ9E38xRcR2/3B6vTthMHTcFI7SZ9m4oZZheBZg3ni6MvoBeMoBgc+i3KbOTvmb2twmLZ3UbUVcUyAAtAZ7GWlUa2SGYh4/wAQ7msiw8kmX1s1WsK6kYFALu3ZpnXLBXV8APDNwrC/WLUKBHXfmApXv+cQVnp/4gmVH86RS7N+P4mPVFZxnPMw/Xkg1W7jHo6MwkXvQcFnPRAhu5/hLseb+ETaN5fhLDAfRihqYXda4EdRH96S1vzKeY6tRVwSvNLujd390TzT3ROI8ormKZOxYmIKWAy+zdpdp2MRRuX4zqmczibe82YLefdlQtPWOc9nCUoNYEg5QTtq4dGL+oLZ+41yHBiaz7Z8bFGItDH1uZivecD0w+Jacbo/GYfR9LB+AijCNG32iKL1KEeR/VLSMulj7RCuzd/+QdW2GCYOF+8HvKwijoEsrJFiYus9esBnWPmZLqNKuUTrDtxLsdEvF1cxWOfoZWfP0gMjfVlAAr1mVt4Yo2sM2mZjB3zF4PoM138kx6DxMGh4gr3lkMrYzn18S4oVrpFKuV2rHhjo+aZh808lzmAfcseRPVgKun1S3XprOPVMFr750H3QFXAC/sSksxxyF3EZOrMGgxi5noZuqsWaJ6THv7Ro++lm/lM9kFWDXeFQLG2E9dTVIrW7JR2M72prRMDR6QHKVr5ShtK7GXav1l9XQQefVMaKhs+p+oFxnNP36u0RiuOH6iqFb6D2xshEjMFBP5S43mObac43vuWCZlDJFgBsGyCJdp/WFXGbwZ1wk8EV5J4o7QMgC5tmrBWcdodOcxOnEy1xCqF5mahqnfSFdYZ4IeYUM5zNAcbqIyl8DX4l+vrMdZdsU45j3TFKxddJ7R6pzG7wTLsEvFIXN5uMNPaAOY5mk2Yl3xO3Eczy1ONsRrcvvUpu49y07ztPTPWYFXeZxzcvhHqcTqh1X0l9G2XdrUEvEz+ptuetVFp/fM4ZAl/+Qe2Y9AllTVd53yO8cqsJYLcvA4mA2y8074hjfzLN2B+JULFt0u/X1mWDauvQ4SkGh/fESVNzeg+YzSrs6ftguvN3R2HPjmUAIlu8wytdI2bDcu0xNkunmVi1mlfGpglaM66il2XuHGJmrxCt5i9pec/aVWYvBiBoHzPxuWVz3l2YIsCHp+5nEvmWf+S+pOcTluWZ6x7y6zNzJjHiN9voKDpBm178TuRM3dsbxHWtRJ3mKcRxt3HdXL4rzAoeszr7xzwHrHL0nio+PM3ePmPiYq6ljRqeKmOLjvmuY1mWaJ5uNvaZaTMybqoa1/kMO8seVIau6COdRSpZdXUsslwTZuNuD4s9gohgfb0PXrApAIrfmpuHR2mPZLxv4hjs+lrGVnSOvoNMd+H0B+g+yH2/Tkn3I8Q16/R49fqf5HecobPMOZzjjGaesNvM18oBn6XWaR+z6cp+UPu+pGibseIx4nJ7wnWO3xOI6/TZNIb+YzFK6Q3B9AS7+Jr6z7ENsdQ2zg+g58zhDbxNCH3R58x08zmUYA+YSgV0qLv2dJp6zpAOP1//2gAMAwEAAgADAAAAENchOE5TXsW7TFggDLryaq8b5HHX8lqOJTb4pR3Z+BdWfhTK4zNBCY4iPG7Uf1u5Hsb/AKIYMt6GOELMMpvXcFPir04+3/YJ5sqL88fZPN56l2GnkW3+eflnlMZ8FPf+fEXt+sy0Qd14Z7kSKx2gUAcTccpuFKHP1I+AB8IvNyj7ghnJNrGoskjzNcryXglBJQMo/wDJwRAe4VNDhGeZ9ADP1Td+pb/86ie1xyddl0FFvxihf5eLZWYj6JwibRhti45FREvbULuyi5dykPT45oIzIlIQlzNcDTNQNFVMa3223b3lVgmMXHZ/uXZ4W9xLNh+g48E//sjBuvF/SqAYZKiRjh9MB0lEr43CSk87dgXsrQ7545CNZp2xHbq/OMsCgFuTdQ2LlU1CZ0NDjfybeb/ob9QcBxPFZBgIQNnnP6H/AJXtUCJw098Wn03ZspTXrrvMeUGDdC7xZGcqz4vu9olq8fByxMArx4oNh2usjw30jY2mxlPtCc5dydkncQ5bV6E5hcRoa+JAmCHsoq0DAFOLRcbNdSETIUWLNURoJAwWd1a0h3WidhMgiORXex1fTfMWjYQYaoChJaFXioyr7ZrVAY9SYoQ0Jn6LxD8+0YLHspkZKg6I4H5KCAbjiX9XSeiZsAvBTbCEwbI3pmcaQhlnPJDEsvojHf4Py51pDax6l6EbnvhtX3DULS93jFZWLPax/BkjSwN3wlZiQT030yAHGjVWKbhnuN0q3r8DNvB1gBGJPMhedJd41y6z5Zd7r0MKXeZTZw3OAlHvapZNNJKaSRV5/Ib0BFhJNrDECKU/dRhPfZeWXQZiqVT1eSGmWKrHFsAiwzs501VMiWMWOW3fbWQYfbaYXcWhM1zjSdhlLBTJAjqygo4JCczv/SQ/5lFfhWPEbebSdQGwnmqAEm/9AGQOKNEETCqb/R0im1iBYhoafQVCCf5SXbVTQhTy5fNe0jBhomf5s8xxwt5h63jpuBqvzwUMvLWb3/wl0JpwR2ay25/RsF7/AM/6v8Tte4IIZ6MN866chPIY3kFuLQvMhl+M5Of+eM/vc78YTx5+fS67aSWPz5tPweuhH+S2zthsk+8h5TFPJHBh+PI6AbQbFuCY0R+y58DNhn+9MVUjtVV9L7fp8kxjWLKfff7b5r3kBOuWtDlPxnlynuZkXZhMPeVQT2BiAlTqm1JIcM64YPRR5wzaSjCvSLZlLQffcGYUfyNowa6ghPsYU4Rhv76bawxPNa7uT6eqyhIUq3o1URKvIgJVy1FUP0oWCUeH5MPYoZ+qvpqonurHz62C93B36owp3Xzzwrpy6EXTLBX87rKbojf/AIr8InI3Iw0x9oU/EFHwBPq2RUOo3DupYLn7kV49L6SaXQkkT2hivEsxs7yg/dY2Xh8WZUZglaYTjCH2agtBjn6fGJFbfGXngwWNsDH2F7wgCd8Wecyladp90tf4Ejx+zvYd9E2Rf+vkcTA6jJlZxYDjk+tNUVhoPIkQGLD/AFzlQQ+yqmNOAzbrsxZeLBTUT1aq3X5l4bsWzJorSQLKX4eMDr164sjU28DLLnQHU6xlXuHl3NyrjFWEvDXF1Augdt8m8lZ/yxoljH+6aNGOSp+1+2GuL9aI+AuAQ/tVRyrwGFU5vmKeojeDmXw4uY7T6UY2Md943e6bqxpAxGJcRb9CgjYHsrvHkRzbBEZlQo6D1DauPHJVx5wwU7qK4rWCUUCjl8j6ThOnN0fkH6X1rUFuW89/4/y/UnoUd9A0SOIqEp4n83sfv6VbqneNTt9Qia6BWQR41mv/AEAXJ6U0m10YI6UfdCrQCs86wo1/kXgpqMRFy2/tIdlc0ZLpqRyGyI+V76+Kc1Mt58+Ic5LrgwRzgFUNhij2MGjqpSXGygig31j6rcWxiCgZJcIP4MJyIBwAKJx2DyDz30Bx4CJ6IDxwFyB6GAB1x32B9/z/xAAgEQEBAQADAAMBAQEBAAAAAAABABEQITEgQVFhcTCB/9oACAEDAQE/EIJOjgLgQx5CfUbeSR5P4X8r+Xw9sh1MrA3AO58BKvC3njtZHsjeMBLyyT3ls2VP3eMbSXWff64DjRU6hh/L6wuzyJawupfzmsY/cu7YeD4tq8dbbA29tjzlOF42faPALhDt6byz68ZAdbAkEsuGwOwDg23S7cRvWF31Ad5K/ZAj3HHDj3eoukbfjuxa6wyIRJVBWFg5HlLu6Efb7zGEJ3KGZbv5eOPqEGQjpts8DtDf1kPWXG6ePbdDl6WXq9X1d2TbUcGoGPVmBslvykVYPeIzGMQPNie28b7SHa22CAJ1PXsUaVeDYdcdsg2h+pXdgD3uQOMH75vUrl2ni6Ji28Hb4AdS5b3rbtqP3CMXcb2sM28MDLDot4eGTgbbPrk+yJEAdcEaDJvd62WFvkF2LLH8n8IRGxHOl0YX/IcF0G9oAjXGmJcb6lIw2xzDi4Wl2fsXmLaBb/YdccW8cO8JN6aL9SfAtvqfzl/qfy4X3jxij04QZPtLbPtel72f1Z4lnfORWPAT5es5mLbNBdkPuWlZdokyWwbNjCrwiEg0+Hrs5jtdQeDYJvvZQ9r23q3gtsL0iO6EJ3l/KPOD6TdGbeXqchXq9L1FAISuuvOhpMchemx2UDWNENbeNbTshtM6sOBvWR74p/B8ATa8mGePIOQdIGLat2rd5Zvv2GyCEJL2S+uyzBFJvEg5hLhLi2tZZkGvV+W36BKyljsQt2BxrpOdzr2V+5f7Ofu1+3+7/d/q0/d/q/nfyvpL+V5pMD8L+V+O/lYPqPysQMsDUo6Q3r2JYRgem7AOE3qY3cl9e5AZP4smeHEu54HHb2Lrl74yzgbY/eP3tfu/rY/d/S0+5D7mhvu/pIcBYJRA9mxJl9MfBJb/AC6vZOOXTjqHo6icTIPDbtfnAtOEfrx/3n97+l/SPLWHnXjbW1LW2L28Zr3w8Jkco9Fg7wgkj08tDZ3RPVhh56P/ACz9SZB8cssshLhA7CeuTNkvb7CMx5wtoNYDm3nvCQxy6pxqfyJcCD1xATOcssssjjLOXjLJVhAO/YOXqZpiUAQ8KHbJ0eWyDpOMeMj2HTbYLtggB9QHl7Bg+/8AuTjvci0e2W3C4uqQr9yQd2buzhOsm28Wty2MXiGmRqGfI42rPhnwZ8DjNs48Mh3xldzTcbdd42ByAxnfR1alsCx5CdwZrxHVzHA1kcx/wZsnGcnXGWuBvAeGOXv55fq6/IodbNiSZ+C7x72WWWScHD5znL7utLBu6G0l/wCMGtgQH3wy3qxk5wG8bbLrvwfJss34kwWWmeBuqOQ0l+a7lGuLGay8rP8AnFnGcHHhx1PBbkLeOpYfnouqI5nUbZwGiR0WbpKM6Sq9/FJ4yTgx8NskrSHmz4eW/M0khvsDgbHqLnbxnz7Oc4zbLOWWwnBxvDxiDyAEfgJtPYPjlSG/sv15ffyY+SQZw9wfIUdLpyeQzEdw7PCcS2/1Db9IBeMGSfd9pAeXvvEO8Z83h41HcLxfzv4cWvy3b/If6vwJXqYXjjhZe2rG6NZGBsIlyAbCPRKeEr6nmqN4+hKvvAMfqfwt2oT5D+EN9X8oI985wOrtMdBNeTDtyJ18hHl6Lt5a0uHPeWF2B0Lp0grCHs+w+bYNZ1kzCct4yV3us2C7p5GZFszLuM7Wb7mBFw0nbz4ZvIfMV0JbwFYMHil47snHZKFCOY+CMGS7jwDtxnAeoBh8OrOGDLZjHSb0uv3BeRzYy720CB0SF4njOUWx2C/nfzv5QYEr+X8LthFZNFPh6d3XYfMngvXHq7eBDLZ2nM1HcMI4W3+JVAoJtt5G2c3kd2NjsK1Xjd/E4wmNFsw5bMnjcvsL6y9Hj1HBAG39thSsAZGiAsDbHx/ixk5PTbbDy297yXkFcLA2BnAm0xwJl30Uq+/A7OxZHrafq2RBojuWAS94J9tt5NtpNt1u7/2cPuejuAzYd86aQZwyhtLd4P2PODONvEuW2zilk9HKA5jALOO1wWRIN3DIbYTkur7Zw/q6qWF35KeuP8og/SBZR0cQZcSUx+Vn9cKd2WkTrMDgu7p1MChHqI+xC7IA9R3ZK/kYTBm9s4yXCh5LqynCGl2fCPW/lC/I/DjfhzP6w7WI9stahbsUAkiZtkxNOg5bcjuxzkIxty7WzG16snWzOfXhuqfRsn4nkwc04BXbq71989Hb+3qv83+Zj2tLKcZ7e0XcefA3Akzy/lxYyws/UvuoQn4pwyX5Hl1GbAbGF1wgb1iUBjRpawkPqXat4A0FhGxZ9sdbY/k+nwzbNp6X8L+EHoWXg/hDcl3PG67NvAXk6zOMNuuPs48WZyeWzLXHBvg1as+p/Hi++PoJMcDfcpHGWWWfBVnkLAHbHBV7vJ46sWlupT1GdNmxx47d43SbblllraZWwOLPW8nl+pntzLH7lTunXu3aPRAHD4uZ6vCBL8PPkPFmzyurXqUdWjEYj32X6W/BtfXuC/ie9GuXoOX0W+wLuAgBI3Xech05K9OGNmQ2lpacNtttt4bbbeoYM34ncC794heF5C7M4vUk4x6IRwYeiaJpwbwnIu1PxaD+WhctYvUYw+BONg9Wvq/tf2v6X9LaFaLdu3bLVtHOy8trb1ITGaA9hOzg6QpFsZ63SfXHvWWrHtZiawjXogDwAnVk9cdWj1LX18gHFg38OEOzZ/JH1Y/kNtvG8LIWPsHN6l1x7YSnqS6Q13IjtHvEf0hfuz/a0twy6lq3bb/eNL/Vtg2Fn6nPpj/Yc++G792vNtf22XPuM2YN+VmUbpuhdcaekHiRNicpLD175MYNeEknC9+e2/8AL3lkfAtWy222w2xBjJ2LFjkvRFP8TP8A3sf9Dh8+Jw3ifg//xAAhEQEBAQADAAMBAQEBAQAAAAABABEQITFBUWEgMHFAgf/aAAgBAgEBPxC9R7wsVpbIbbtWoiuQg7vC9o3kBBbOwDlMC09kkVfRiI7k4e2y12OkIz3YWQm54I9QZQQLJIbOMR2IdzdQK/KKA6IDyyDzYLpZfTPMXz1BxoXzx5J8vjgfxqxKcnXUthYN9hkQ8fEZ6Y/o+LgF46dz72fZZtktOfJBwhPZGSZEMWc/8RKToL84ZlkwkF0hkecnkJ17Wli0t+1pbPd5Zt9paHdjbpDzjJ758l55HUERfFr1HE5DI+vBv5ZpSw2f4Y3u36ty2B4GZwR0lJsRzN7jvzgNcsOPJLq3g0XmJrY0RyYM4O4lw/sYS92eDMA5xvsD82LRksnIZGyPfLwSyzlrHV6jyVvM9vN7JFj/ACTJdXrghrZrzS8xyHsxhH7YKB/PCadC+ZhGYhsp2wvLiLiZkWkdgmHXJ7g1ky88J4KjYIYQdXqly0Ytbw4A6tePPgwztfndqXUC0RDIQyAIdLv1Z/AoXkQr7ajix3Bef48cbN54fq9kh8t0Wfhm9EecCuE7iozk2zlulfmO4cnt5QEssss4GJ7w0iL3WerSBafdj7jz2B92LP3BfN0+3oRAYf8ADjuHtuGsex8WM7fHHTHbxxAEkEydsunfjjAbGYNgy0/E4+L/AJs/Vn6h/Vv6unxf8373b7eA2nzeu36X7X7z90H5j5219zEotYo6dk1nxbeEk9krpE4tsIdJQwQWHXOpxAn3d8+eE0ziN5P6y/GPpvxvxj6JD4hvi340/i/OPrn6LM8G7Lpb+0brsXsPH+U72fsd+tlq+S91ez7ljtjpweBs77ZswHxxH0WXxH1353585ZxnGHDjYcZY8MjC3eMtjc+8kHwzdPiWFPIx8v3BYbdOPkQ7wjph04zhi3+FzhttttsK4tttkhrdVEuWQ+IXsicybb4nt4Pe5MBDm3YJwOTCL7EWLPTsJ3IZAeQd7J84222048R5bycelsQDWwXiXkiLk1XkKwjS+2bIJjGvg422J4LXV0XiDTWPpIK3+erbzeP5L04Lkjy8bbbDjEEeS2ZzyneWYX0ssiWMpogjdzjDtt/nbzNyHf6bac9uzNucB2UgDsjMDJFrzs0hAXuxdgt1h4Q5xttrenP6gHOFhZdP78wdR1bbbLbN7nXgyzwIn+hyD+ZfTba2zDwSzjLoboLeG27D3wvUW28HG9+BwbLN4BE/4Lv8kRHONHnKw/cPdp/Wt2vtbJlmeGWT1H+LzjB1EHBxs4w/3Pb5uzPifqf9ssmBWDOC64l4tXTH2mYyHhyeDjOR/j54QTGTXhs48/vP5y6Oe3ln+SHJdjEu8Fz/AAY/sRjJ/n8PBx0eynBZZZFuzzQgshv8rJd/wf8AExjaO33yDuA1wWN0l1ZYWc5DZU7lHm8h1/4A9X6x93Bi/a/a/a/WDxwB+OJVBYtl5JYNsdMAQTWQPt8eVNWD5YfYbolPWzXCeQdCSO4+2/W0+b9J+6/Wfvv1hE0/rrVb7at7lW/u1atfu36l6tg4xZ8GzTHt6BbRpdWpdVjCR+rPfnChFowAYWbYT1E1936WpWHM0f2L6zCWlpaWkJOWdDvOuSEDpbdE/Ba1IuyAOAct+qAnXxCWPeuDqgkxaW2ltlm9f3Nwk3phfdq193T5gfcj7hT2MPvJszZLr8WXBtj226GtgnDeAbomKH3jur3kjy3f93b5t/cL7v8AqGntt3+nk/F8GcawgJC8WRwssny2Ue34Xan1LE9iB9GVfwR0Rzz3Cwb1sY6gSHbqWNqXi7v9Aw2Hy0tLSYvHUTP4G3J1ibQ6Y9gsxkrqxllew72xzXuAYH8B1Z223q223YtvN7/rQ7kfEYtD4l/J/wCWwy6/kY6X68dkNi97qGx8XnDPRuxhvAI6RxSRLKtul+LSbmWWTtMAYQMFt6k2xsbzxmJijGU1clHtdLB62uM7X20exmWns/SPzYDCL2gs+Fo7ac43yScBCn5W/CBCeGwfG/8AsdQ6296sbIA8BzP+UQS2fdfrJPGf3Z+7G+wXzDfMVlH1TY/FqfRbMJ43j1shu5Z0ME5ZyO3UlsPIX3CLXza46NjhywcBs9Rxkz+OHo9mDpwSFv8AJHXGQsyZsIAttu5dJ44zkQ9wCR7CNs+4G1fYyEPAI6verAj2X1NvOroljqHptu1B3Zem3EkxsM2wfmS3gNsZH6sDuHMlvf8ABwAe2d+0/ZfvP236xSdNxqkOy+ZsTS6+2M22slfc3UnBF44e4Y3cXfsQh6YZ7b/Nn3sfdfpans/bK2/blOFBSJ8Xc7xv8dt9eSnkpxaTG1N6jqEWp/WC6QXIXWXWNkpHO8gvxItwfX8N3ZwOXnDLw/jCIBhxhzlaXEcnEDl7WSM2xtlAYU6sfqCMF2syD3P45wwU/mB5ZJDvCPWtneuV0tixzrOUmebXOcBMwJhUvbYI6keC7LLBYvhZNS6bTsvznhyfSMG2fCd628sSRh3EvG48GXBn4LMix9WfqRY49bH3GsVgw3Vv1wEiUiLdwHZIGRjtb1azuddF3Q+p32fZZJlpCW8AHNb318WnFj836chq8HDr+MGzctOrGBtMyyaN15egyRdyr7N0MCU6PmB8/wAxH5WfljZ35Y/Vq7PC1+rN+LH1IvxP5sHsj6g+liPxx3b50y+xbfN+8WffDYh6S0th+p31eDYsvR/ecb/Gfxl5bbaW7/ZYfyij2WDu6Trk49nD/BP9fH8vDwT/AEf0e8PiY4//xAAoEAEBAAICAgICAgMBAQEBAAABEQAhMUFRYXGBkaGxwdHh8BDxIDD/2gAIAQEAAT8QRBcLAcBUaJOJ4ylhVdr/AM3m1Q05uh584x5ak9uw6ytSQE3Zxol5bm+8BDh2u3yGEF0QdVOVO9mIKKc9kEn1lsr3fWAS0/OIGFFVlzyYF85UYZW8byPKP4yPhyB2Uf1hsEDhdCResRoSngwPILxSZw//AFHhzk4c3kVqYE3T89OCTWOCL4jz+sPYjApEHX7+8OMwPodB9JkLWlToatXPTWOpaWtKMdHnN/LoExEm+yewucb05K6adHv1llAit4T8POQ6DROz395uwqJbHR6nLnWKXUWNDwPrGCfpFHs4antxDjlqU3zlmmd8PPzhZHaVOV+cG6bHgYkagPK69e8nkFoWo4/3my1VuHGlxlGSnGHe3jNGPB2+huJZzuehzlKb8YDSrzxjYVKQeLSb2ONF2hyPXtuw+clIStk03sRbmx/VkaaOnrbuYLdYpoAAEqO9A6wOULHvAh9njFRp+VIyQvAfAEwvywrVTF+zBfETKIGn1OOc2I+Ukh+Df3hnBjClpG8HvJyHPp3o8lecjoSNwX9HqWhdXiH3hXawvT5K1rlvWPcOwb/Jr2ax2bnX2i++HjlxFxsOqj7ScB8Y1uzS8vCMpiPxAII3XvhxEIa2Lm3xcMxrxdB/vOWKbWJyC35aMM9MUSIfI49uEDXhfRw4xkld4lEF5V1XNQiK359YtcCXZdAYoiIeBvnE3qFWpvIecQHRDh4cIAkcOwYBz41wmsQa43zlvjCtjJOvpxa7upimrBWqrEHr05XQ0Fofv95r0Iils+coUzIoh6smEh5inI8dTNL59Lx/8xoAzbJP4xG0E1MPSLwUNRDDKMCOoDE+hshPxhcK9AxPYbPvI3UYv5cyIKRRq4q8YQvKxBSDVDlxjJxziR/9lKYHm4sO8DUcIj1WEGq+X04IigSjjEJ3FhiPgGldCMuabxeNcn8YmJtNKFa6gcJzg7XCETtKMHo8d5y0JqaYU2ET1cCF1Nk1D1Hr5xLUGBlBA6Zz7yQLOxD9/Bj+s8+Xs9aybQA4egzoayyEP2vGO1VU6HGNj4kjW8gFBYKVIGeGISUdQ7JeJ54uLtEtL0lqnO4ZU2yN5ySdLs6teDlgpKT3Xa+bijcng75Hr6yUpRXu08cctTrESyhozyKrcJCnS6GuX/eS/DoDhsdcW19OA6AhiFn86nm5MzISg/GNF18FT5MYvbTjDEq4sLOwzQsN+cdSwCnqn74zcimeFGpfHrAooGiWsaw09Aewl/GH5RAzy+cL6+vD4HWXmkAkU96zW1QAA/7ebVTbiJgG8BX5Tv0Ydw4oRG/Nx946caTVMfhtTBJFpsVRHHRz94+0gEKoTRUlo/OBEhnWwIN5lmD0CgPZEK+vGO47nT1/vBDaVXPzd0oP0P2MxLKqbKda4xCoAIQhMemlNrhfLHgFU+RhEPbS7/5ywdrAczE7WJrBKAccYNLYFu5/HWEwLJnyDr1jZZArd2y1i4ikRT9FJlKFJInW3h5xc7IZzrcIV5y2tqTuZoFiAilqXhuLGCAKeG+fOJyy2KQvldYQIdEkeeHeRg2x2neluTKpHlD1vHrOgC/1ZCCdFU/a3ebQHKMnV+mQla6ITi7xVU5rQfWPafswcIgVEx40gInZDyTJVsyVY634xBlsLaJoR5aTrIgTYsCAhV5d+MVYPyFir7uRwa6nDv4trjaugFcUKyDk4OkvSE9Z4YrSB9EU/wCuMSWoIHUpGnwSGdrqohPDASenvHDwh4n6wQGtdo2frlhobCiIbVU5+uN4zgPuS70EuEnQxKB5l0dJeKYQglCOwaQV4mJCYVG09s8GTsPDCQlj1x84Hp4Yq3sq4eXrXtskXyd5vRibC7vfjGkT2HxOmSWjDyo5V3/ORK7gvARNAGNNi3VM3gLonXp/vDrFoFVOnvJJHCBpKcrvRoxfgmKQKhzsSe0ecSMhEg5yPBSuEw7AV6IbnsybLklA2GdN3yPeBAQ5qz2D3zmwkL6BOXvPPCBw+3JNLmCg9Y2n7EAju5QKOzHjb0APkHvHpQNpqA6Bvh4SvObMwIm7XQhVhtOMrRAXXxj2qi4k7yI1pdc9PvJjcPb0GFMAvKaAfHRzkWFOX95VZDe854F+cRNTn9YWCyk8qB/OFAbBuFqrOO3FIuiAPsDX3itxbxd0/L4wlvUqQPCf5y/uIIb8w4xwQVCb4sVQ0CLG3R5uWwwC3Tb85LCSpFuj6esREoPkLrGyipofjm8RQ3oPAHzlSYDTjXGHYqDacYjqlHxeH3g6xc9EjGACQKEQuHYo2y9RMkSb2qfT84B5XTtzv4ZR+WXSgJIR9Dp6mLlMmu7tL6n7wWU5Cf6xM0eED7wlDK/hAcPGKqaHweXB6XgV+RUPu47NoMYE9GIsGgHB9P8AeWw2F/B6T2frEBgFF59GOzUQFwanKCq9cZAwNBMNTgKuK7xAloAHl1+cJUyEoFZuM0pMHHB/0nK4cKr2uGvH7w8xOUNnQnfvDYdf1mOT4Zoh4jmNB5EdYsEOwPV6ZrYIOT7A+uag0bnkXXnGJ8Yc/Er+MKiAKH4Kwp83C6Zw9xo38MCidYWT5b0/nE2FIWL+9YG+pKZftIwvIGyv7bj4CTlW9bcQPrXqdcaZvfqD4/YjvA3pSCciK63+c3sUIUeVOt3Crp7CbMuYNE4o+k4feGQZ7ilfKcfjJAbHuYxFZOUphjLCCsePLlwjIFugDyaq3dwJ0uZ2Pl7zSOWA00etYsYlBUVvXtylGxbIUXt1jjE0xYGG+3OqCqAtgPF/WMnLeBy+s8wQnM9ZeKbsj0YUpW6JtqcTAOmyeV3/AE/rAJgB1ju/sxpqehUdGRGdYSYVTkfGAONrXQzeu9YA00Qa7gzETqdQhcU1qgJSWN8O9ZJJroY7V34mKrpHNQf3hwqCB3A/1idmrlQFfjl+c4gwSlCme+MS32oYIFT1dH5xIAwbSV5vr/GFQqCj/wAYBEOBt1iDLXR27y6xAFQIv3gtC3kfBo7Tj3cWneohUIDnBALfMB29+cdKLhBPZ3jZ0frBJoYIufrGyijQOB1AK+RNv4xMskJAB2PKuJHTgWv6LisuYpNFKvBrJDIKW9l1zleBZwJnMReft8vzv9YtNMM3R5fxiHz0Tvxf5xUwLfgeh9c84KM6ts/08J3hjXBkHuvya4zVYqIK+2CF6xkzxDvLPygf1vnGUqAK35X+cVZA+B4wDtBelVm6a44xFsWkqrDw26MpHtRE2070L2OLEmagBGoDsZXvNhsE/wAsRlTbrmvD+MUG1A7Gprxz+sAGECZeoyHnnC21nBmEeTsSkzlwGNcUSc4jIGaHh1xl19BkT2WJgcMuwxnzctfIkB93Bd7VTjrtx4CgTunxgKiot8vmZWO3y4TfWV3E8018Y64NAnCZqQGQ8JjCVDa088vrGKAXBl0/vWAu4vEhXVk36yMOFNnbt4wqKM1KTobw/GF86KHQBp86x3HjwwanA0mEgkJNeV66+8PQRYr/AN9YnQKQCToHbPpnO4rWEN0gLbxs5mDs6tA9+iP5MImW0pGm4I4CyLRbPhLjhIAe1Oo6zcuWGjeo/PWRmIar6H/uMgcdwC5/l8ZoFtoR+fnvFXKRnhS9Yh9ZAqDb7+MJe/BCI6aC8cYC5K7LN5sSp9ux3JgBq8HGD76xWwLeOD6yQeyeVRnvjCA+U4uT1FsGn/Te8CLlupHzYGbRHUNt64vHvDA6ZR+Tz9YXMDwU3yJ0+T1m/Unlv7uE2aaVD6jTGKBY5jybfrF2pqn0AGEjWuFtXBXv7mEAT5QFl+Xf1i8Z1KbunQ4fJMAIil8SzN3SB1MSvBNCQ/GJKUzvWbZDd8J/OVjK7oLOuHBeMigldEmxx0MmtlPBzg/nBBsjTthGom2abLd8ZRyIMgSn6yQK2o8ucKiujU13m1+icRFcIkOmCoXfycRRXAg94kJ0lfo+c4soVeYP9YRtRrQh8fjERuwBqHkOHKVAUGlPHyfjAhVkm9zxjchrvtM0Lm6uAoCjOcndIRwd9nHXzMEkFiDt3t940oo1/DnBYwI81E/eLXjCNnJ/nGJ2qDyQ/RnH43kkKr04f2zcnK8d5RFY01zcBUwPFN/1gFrPM6+8YYcUzTxoIln7zqIdmz9Z0B6FreBhA7TrWpgvT4+MUdzQJ94RqQ4I/n5zZqktt05uOKTjY4GpCtQ0uvd94DkENED8Z2ptk9+feSuwTwoAfW8AppqXnOAXprbnQ8BWaK/IZZKYLjPCcWm9cY5DkUryCLy7GvWTGlbJsiHgGvr3m4MGiLxgYEuJ5R/rGgTqywkr6yQgWqc8yn4/eTyFgaEsV/N+sUxNxwaLTGSHSmoHYGKSO+GtOzrJddUdYjbyv0OMKxcvnHL11MKy3u4ktgoe8WgVqUjl1hpYuXgP9DGQAtvcJ+stk45IcU+ZwZEQZvWi7X6wVtZGpGESCI703FVY3psC+ZjxdJAnADyJb4wAWOVsEe8T0xVBW/OA3Dngauc/9ZyYZVagaB/WCAEO1OgMkW8XJdC++WEp8Bk0YTDKEo+Wd+8dSZfb6TyOMZaEYq4X4f5wpgBI7985SaN3YPFu/rAZQwVS+Dea429JDwjpveduAsK60f7xBpOxSrt/zgjSMf4/rHreIPjWAnA5QaTeDp4wbodi8Jb+j95QKiVm7k9JrDK5XKpS+Wd+8BFYMtiVxMd1Be9a618c4SyimoREZwawyjSqpR5V4fnEcyIN3NiGx/rNsRrtYVMV6Xqs/rOBV+cBJBFcMxCGRDgd4iLcgS/9XNF717nWX1Q+2w036uHmEAsof4U/OCA2QOee/wA5E4x8jRSvQ4+sLLi1+DTO31k0WIK9tivozAWmFyp95QLVWeJmxAU/P/OSGsP2Yr0vI3PnJAg0dhT/ABlkPZRvzPOcjdeX85Cggh4N84ZIJoif9rIjFzXjyuONDe4uus3NSdq1785IC0SDv7zyOgbZN8YZjPiCFrs4v5xclumH0A/Zihqp5nXGPISohvI8fGMwnoXQ8UwcrcFQUZf+6yo6sXmbqfEMcs4bgfvBemOvYjrGZhK1LJ/G/U8mER0OodnrBIXZudvU93EPWVbRiw/ebEjurHhDjw4uhBaS6Lf6DGAh4Xb8HgOjEPLhLUF9uexVmjE0iUt2bf8AeJQI8Ee0PPGSJKNFBa/9cDy0Zo0ge93rLcG0Y19eDFExULfHhesEAXk4J7wMRw1Tt4mJ51eVB685v6aNAPp6x5W6E7efk4cpGlpSnLrKFD4eHnOfNxTrCNKOImneM6oiQHKdr64w+gUAdmM08KnLKRQF2+cREME14deOTBiG7d31/OKDSvgPHOUV8LivO8oBgeitw51lwLBAp8L7DcOhp360vxrENIdgSvRvu/WaNwkGJ5mAZskCn+GeCvQC+WMgKHqQpfuY9dO4ugT7yDIQPV85Bu5S9GjJRezBeD2zGu1Gi+Q8vxjxtpHmcVvnFYYEGo/DioBhf1DwOCOLtOYMPxnDCg8xKfziqHN69YFOt+XPRH25NaCdYjiv9bhkC+TyV6xVCkP2PtyAJ87frHATkLA5w2gHV12nH32YlF+RNPpxU5wQWHm+cBbh50wfoMQQ1lruwAN9j8c5sJUF0vzxON5sx5FlnPOEqISRPjAiiiko+UxA2ViiO3etZyDG+rN1PYJ7zh2xknTpt1snjnAE6bAK9Lt+jPcPMMDTh48+sd5amRtezh4xY6QEV8ijOGumgqOt9GCBNAqaoEvmHxlk0CpviVi4+YADYLCQXN1BgifZTI1FamjZF844johEabb5xrl16Uh39PxkbEZsP094VSh7Q9vjnErUH2AWPREXXYZFoAFdpyem/jHpCZc8kd47kqT0Lsb5eesJW4D8+PdyQqGxzvlPDlzoDOOkb2eMJ812BfkxditNqZoq7TjBEKsa66YwFGHnpfI9TBxQyuCoHomW4MlcgX8gn3lIp6hs0MwEWGh7e3EFWKlveKkAh4IXIDOidresEK9/DZlLSLqe6q/7oyf0NHXm+fOCm1kdoj3iJhqsIffWP7mDQHlfycY6agKVcF7bypsCqj2FHXExqWl1pDwafnWGdy8N310fe8FbcICP3pg5y8eVZTFkAakS99YTHnCDtpu+8WtSpUZ27/nF+Am3eE2neOsEP4J5b94/WhzG3r1nEcOwhZQ5yhmroHs8e8FBSN649YCOEXot1b33j6hhrkdEzbtgrqhsPvBOAmZeLgxIuTegT8/rG4aILY8zwmsRByJxq1Qu812AhXHpw1hClOHv/u8azIo0nMneEKU4PQQySOF7xactMucng5qtc15nK+dZfgSHlF6/P5MSITTz7n8cfeKrgsd3yxbbqBQ9AabVrvKgTrINKIG7vfvEhusir8u8InKgX5BLmix3tfe+PWAh7pAjnSNwprN3cnz/AN7yecFVo+d5HGvP7PWeAQm/RTb6ML6bkEbRDY7U+Mj2pDV6EAJ6x7Y0m6p9sxWGVEUT3OcSQHJWnznQRbaX3jMoLtN4QWCA5TATyicKesUBfZrw++c3pULxveO2OBgE7Qv9jH0zZhfsr+8PirtHy7h+kwMFswoS819gB1mv49D0QJ8YFeeovsvb8txCqZZK8F8/wyk9InzErOt6+soAV5gfRyoJtLNsPcs+sQAAfH/OM1VC5lOC+Dm+sdAa0KvJwHzlzMt3HcI6Hw9ayBu1DYdnyNH4xegHXvERvyOsMqqGINB/OAemmGw4MM7tBgUm4htGO6aL+s08oBG695zAKaDLOOMoZEUs1imA9yPxN4GWyG0OZ/Wc/wANnBt/LLgKgaKcB8/GMtMABd8a3c2k3QruizNZWwo+hOXCiFJNkPL85qns+C0BOE1flx8Q3AljxfnUyqSeeSzenEBBnkCaP1ig0tors9uIMQHxr/GJYMa3VcFAe6LfjGgliakayNoW1QW9e/GE9LdDpATrj95BEUoyHHb3lnBiofx6yiE1xNftznBD03of5wMiDnwBMbIso0L57Xn1nLIi7p7XnHdagAL3pxy+8hGPCuBwccYPEBslXyzeiCR6OGJ3NyBxs784DavCa4fVwVpqOi+MQAiHcyFHLzcoeM6grHqsvvTs9e/1nSzUTXNnp0byw9FBgCPzrGICp+GPbF2/wfW9feKN0WazgSpgU3B7w8INOLYpA304jHhWYz2DOB+8SLyFrXl/prN+XdYHgtB8Zs8n1jS4elK2/wAI/eOUmNXn4x0Qp3lBAimjWEH8JMqhe62eP3jXCAcX4nOK0H0zQXjEW+8EoOEGgLrvL6+k3jIiJp/8+sZUp8MwTYN+0Rt+MicKI9FGgeZZkGlcq6xx2QhGWay96hbGtqnrC9WjkU188YZIGiTar+rMai4c649YrlFV2bj0wPzgoGwD9H1lGlTgtw3klDoh1/xvAqIDt8YTpbxdd8fnAvVaXUR+MZS7deYWvGQhDZicbvNvOAlp5/7xiy8L5jCSAfIEf8Zb2S71+vnFQqpScXN1zVX7AZVG+Zh1Gtd4iCwea0GHCes3PxOVJ2vDXEKdMefOn6DgIOB6Xa/PvjCHExV2AcesBQFskiyny5RPjopXfvWVYMvbl+fWDxQgnBtD6W/WH5CchkGr/BiJELcanzgQAAa9mCUM0tt3wbLdFeHIEL9qqgGBeAoUOjW8dKPDTz7zZY+dPnHSVp55H/Qx3IRBqQTX26w6z6KBNWmEoEyidC4YlNm3aHo8ZagIBcx2FNLSdxcdFFG+/R6x8Sa+BzvGDYUk1TZ8cZfCyc8YmUVa8nP940SmL0rglqUPGNCsCbNDzgEoWddcpiXsESt61MEpe+EJV8c45vqusCo2QtdnjC4fQU99M+sSZQb5/wCFykCKtYXrXjNTCzpfTvKLTNHX31gEhNQGeW1M2szdQcQUAN8quxQOcoQ07/T/AHlEqeLl2TlrS6ynZF5uRTxVcDLyAdZQ6TgaXBWxt9ml0Zpl1VJ/1x8ND3C//MvufUFdXAGgRbOFjYSsyodGO9+TeA9JpVuO0PBfhesZjHImzAnZmQOuMINkH3nOtpcH6XoRM0E5VbLKFa9UvRnBJ0vMIeQ8PjrGWEhuv6uEtQjuWGOPdIatJz9dZcXbz8+MYywco7xUZbKTlfvTK6LN1/xitIQb45/pzQUHR8UJ54fjAAKJRe/FjNQJOgtrDShKZ4EwQ+FAIfHeO9LWEI94XoFVrQZe6wYgy+HF1ADRq/8AzI07mll3MNPud4K6fOjN3y7NJ1/zxjrlzCumrr6xqp7Oy0Q1ijg7F1fHGICE6DpKz95TRMarad/Bx7xrKh/7rO5Qu+Xp+UPrLOAaHhlOxR9Zu0LacHxMBqGaeX/WaKFGHLtxlk3MhoAP5yf4VB2M/luENGD9iT584GmBsA1v1goINjeGoSeEab/ZgIORvKg+Sv6xhgoZ2u/+/vCyVCepe82oCprn/wCOEHFoi4mPbykuhxrIgIO3xm4UwqnGG78BXxAc1W6LKd5YiUdfx/rFHvAgobe8GMkHl5wU2knAH35yiMxnby/GCBAyagv84bcE3bUawUiMCOjYjhlYHSvP15yHajXYfjEDbB1qqePnIn4HQcCSugUeAHvn8OA9kuAg7Try5LwaQjUBpzxiqFGbvLiiGmo+WTKIb8vnJgCHHnAZ95484SCKOxo8ZtEEns60eMFAUNpsPjKy4HXP5ydFx3t53yPjWAp3jXr/AKYp6JXH385B3aNB+5m59b2SX5xZJqEdnn1itS5B18YVLUbps9ObCbOl/wDe5jdh+MoOGgPslfMuBRRYV2W3Wx+5rWTkUBX7wmpJE4XO+lT4fWMiQCTvCJwqXDOQN1pWhvZB9ZsBDebjBrqJ08o4FQAUDUXZ86xsIF13eZzmXtFQUfzh3iIHKIL9Is1hptG78OcDgVW995xUpgn5wnDUTh11i8MghtfL7xySjRfx/eUQJicDDf5wXocm/wBYyRaLY+Sd/GQhGlMOeT6wyERnkQ9ecp16NXJ3PGs8GWLvfH6mboB2FTHTC0Hgad+IuRLrHe41F8+sp/syDCpANIe3AqlR0/4xISRMcJv9YiCEkHpNY5qzSMALn8GaJEcgc66esBY72lWJgo5MdaMleG74H571lNEBRiLR/TPWWKB3RwY35YDsHF1lsiEJ0mkmMUhJ8z/OIU8pWy+/WRWqEbJgzUKTKPBrF7Tjt4B8ZsWuteb0YlLf87g3JHANuTCHnfvAQoYeB5YsUknFLf2YcKNwJEO3BACmXo038ZwcJShkAnDrUNtFXrG6dETW+eXkyAwusx4CrvDx8JhoeGxfWDFKAAz0thgjajdWwcqDB/zmqXdNIfOct2I/ZTR+capKU4nLTXtcPxABhOwp7mb2bKicegy0p4wY5lCzX2DjhDnqeqqpnNDvglltNByIPML94oQogqA/OE9mSu+nC04xfvSM/IxEV9GffJ9Yktf7ECn5xAixZp7Rf1i15g/cQmsj8BKShr86xO8OhHBijqYYc/8AjzjcnEIRGkfnHRdPBJof5/8AhvFnnRCKbj2TvHEcbID8h4+6OGEGBFPa63NdzEUqUcpxgHsxgRKXIMN+P9ZB4wgGpf4m8QPEdVGcuN5AKUfJirgL5H/Q5vRWl+k8maR/LInw7yrY9mnf+MCHo/8AwMawbiDXZ895cCAmu/jz8YlSWmmof3ihOA2a4CeuTFch2LQ304gVGEN683DIqmgW95BtsIdJ52sPvxi6AQJDSGQtC3NJxDFigK50n61lvECEZroFDZ6cidHkqen3ggUDta8q4Cy3QDX4zUgTmc7axuoLRsu3OapKgPBy+pcAix8i4fnAUqI1Th94SlI8Lgr5CvouNWm5OAJVe+f1hwJoM7c1dWlX8eHJwkSjPR89YAmbaWFOSnvEEhwfvE4xShAR6/Bk3oBNHaHVxaPf2YZ3iL5vS5uK/RMktnco/wBZB222G/HOV5LtAhS+Lh3yvN4Lk1WgMRSfjb+M3Du5SKl98YBjEQ03n/H4wfMBqnP/ADMQDbDlJgKp7M1hMJfg+f5fWHKuO0SqcHQWvPsaBQpslc2apvbOcn05Rn1ur9TGGymUyUrj2w1zgwWSsbqWjNaxNVBQDyK4qvlwvgjrGZGal3kjh4bg2tC4Vvs5LS6+mgmb84I4zkyt5x5esL5n3igrXC3swU4X5w9BcR/nnIJ9j9iiOIIBSh8FJH5coJFQp7KP1j/8FI3i01evOVDeCowf+IsdHnIpFDsH8vNs8YIDgGgi38b/ADgZArprBDlGdzF5lPgCyefWS3qFLPVx9UiI1owjpC1OSQv4mNGAY+MzTI2eYG/GjKb4Ss1NfrPEjEC7OCv5ybScaD4yYWmjsx7Uxs36bx3doaj3cRdQoC/IXWMw4JCvqjHWOtRovyGbcqqGvSGDvCAStWj4uCgEJuOw+i4UC0CV2dY4KsBDbkFAqqo7Of8AOLz5BeXIfjAUezf+3jEEI0DXu5VZvuOPj1kDbPME5d5vN6V+Qe8MAqHYif8A3AWIrXy5BZkTjVz3WZLuZWozUgTn+5+8qWHRVSUK4Gz9XRfqYnpkVI+eMOjLXf2m24DV2HQ87dfeBBzwE/lc3NlhKvYLzgRUkvd+s8EOPFxCo0dnWO3siHgTk/OPYJ1Ys1om8eIkCUPrDHXzUHNxhoSr+TBXJ3JsOB94QSzw2i1vvf7wcNxEdO1ZzlvjlLSHRerw9mFTJzfTOCOE0LvA1KaUXAp1NvUC6ccDyQbtnpUMIANdwxLdFos4/o5MOC1QNUqvg9B0cGUIauaogTxkOY94hh05PCm8YInmBPYYoD66BP59dOus6x5PWHMTnN9pjI1X4zlRwsxkKuBwYBHKjH3piD9B3z8P2z0fOH6yFeyU8QoUfO54yQ2oIS8P0XhDKhWqn7dj6PnLkcBI+KYvhy4xUqA7k494sKmIIj/4KcYiVQvJAdKrfakxoNoBSiN3A8aPvEFQ06gmIeu+O8GjlXD12RXekyObRed5YALHW6H6cYqToJsxLkQ7y+9DE07/AKGm81rdqXrEigNmn4uERxRX/t5bHrAUptxbK/Gdp93GWqOrlmC9OnBFubRP2EcKanSSklja7ecO05sbz1V/Wa6Xey/LyyRzCdD5xY672Gn42Z2/Hg+turgRzf8APnAAuqh4XYYDBswapJmlAKMVrUwQ6l0MT84UiC9bqp3mgCg0u/rHdKIoTm+JMlMotW5ixCUCK7qfOLpgmSyn9t+sUDgoNeZnQEwRDyveJ4QdMqzi5GsXZpvLYHpGB6k4xmyiqNm+ExEBS9cVas8DYGGLiJgJSzQXfn1nAaapE9g01Y5dFIjRhTfJvvBsZEZzJ1+sLsGIg3OyiZLnSFWrSHV7wIguLi4Q1YvYBz+sDhYuqDRPMxkasiXtZYctxau6hbPKM1kCCUKXjrjOC9G0KBobqy4k8AbBLvQDrQzziIAIBwZZmyJt6/F4O30bYqy0RyuNlDIddZ4dlkOveJpyRpcg8gIyI224dGAig3U5Vc5OLZehX5PeXJvn/wAOzW/OHWjeUsuCLskw2usAGgPbDCv0oLw4OGeePnERLgp6TgPQZUuj0YC3Z36xGLbWvOPUwtxHkTgPhpgQtgrxxG6+yfGOQHOTT6zcg2rCvSTZgqfTgGlLxmw5N9bmZH/02dc8eR7bSMCrjLrp+Am4TARbKByiD6zQSDh56fJL94qeYDSA2+O8VgCi9iuMAOAdGygTOVc3rZpPrGRAsWuPOFpya4V9ecJvZ8ZLBtnGc7Dk1PPWQmPgTjKJw3OMeo66yjhvjEHSoE1giQg8TfNyH2E7qVWgPOJfrJN9qHOt0yfPp5He9bUJ7x2KAxKkBB20wQsL0m/xhghPWU3y1ZcCAyVBt9YEQJBXR1cSIkNYv/05xKMRgg+Dzg27HCuuOcM/AGxTjZynXziCGAAeMcFANDsTbz94QC1cX/4YhJGpO4wmB6wUaExRtE2abPrA8jLeh/7rB0iBuMESwe8dT/QYNHWFI+MPKH3C/wAYWMs7L3cQN07cgeTQHTK6VbqmsmhVO0DZ5Dz0xjZwhqng011jT8EoVs+T9Yb5Yx51iyoMjp0PH6wqWcQUHd185NKgFUkUzZBvinkhvCGpySi/JvFYL6VtEJxSHyYdJQIAQDOgd7il8FhfkOc5RX1fB4DgOjBokGx4x5bNbjT0YK4w2iTESOnelw2k6E4fGRBRqd8cZYEScXWD4qXkJ/YU+8tm/AbrmUDXO3LiNuPSqKBjE5jkKmBx6zu4r1cY3l8kJ5x5Abem8odPX8vArDNn5wgsX1g5MDjqXQenFibDowxoCcTJAFa8cZZtTcjoj+F8HjJbBZvAKAhFHN1jmxDH231aekOsedf+PfOKET1pI+/WD2aenGvgrSA0O+3njERWtCy1+FcOAvMTdp/28oFIA5C/94gOxBsDmh94AOcqyngGImTBsv1NnvC7fgsNYWjlNEH2qm0m8Gbxjg+cRG09ZSAH5MRt3c1ti24ktsvJkJGuRwgg0h8OXYpSRS4ssUaEbQ0loc9ZtyoUzcLBEEXrCWrGlQEVGcfxhQ3zNThooAZ2swEKibdz64/GABssDjmVmt9uVm4nfDFcS4OxBFJkgZZOS+vrLNxQ8fWNCtBCtYQbpsXjAGyQWI6XI5iRDHG31195GmNBZ451h5qEZ9KrvKagm1HfjNymVQNfBjdkadL/AJwGRVdjdwk6IGas2+7GDQDIwNqk9t/jHcAJxWaEEqR1lK0EzAkeRLODIE6FHBG6exkzVAVtYSGAeMUx1IrKvZKvOB14JdmuzOyHGmAT+zND5oIFJ/OsrAPXOCsCATopZ8OGPaVMX4+ciWIW4dp6Bv3kUznp8NT5NeBI44MRCC6AD6YNiG01zmoQN8Y15h+8MPOGWbR7f47yh3wQPjZA+MBFHDb6NB688YIAwJvSJqYdTT3gGhOjmyOS3FbJqtAJX5g+feE9DvKPBjD0OgKq/WUkYnF02O+QoBgbX4zJKCf3iURPWIgbx1IjVriY6RHNvNyYALbenIIdfnLCErlhbwXk5zf1Adnj3muaW+kIPcaeVvbm7nHZejH8Ha9OJ0YLEGI/jJ7ww1xUSJ/jCQNJxI+4Ej2PeLRX36Dfs/GRLdEOXg34yMqagbgxuDQMAzB9Z7UkPZTm7wycI5PJxwHPnCGcBYM8F4C6MoaIEqO0yq4zuR21fxgFA1lJ/sy9HZP5t4IA3lBr94kSqTbcdDxgjH4wAGgLEcMlF6e30uRYqzTv4HNUZqtmYmuV2F+TCaHE3EbivDk8ZWGVOK6xotPYDYYMKN28MkBg9PlrFIkdCP0Y+oYvSc/i4CKh4hQMkdm3W33ghCt0a4yzliuZzg9FrhCK8U7qH4wBQb6V94kEwANTd8Za6gkDzx+MhD8QxGdjffGAFBHCcPvJmCe+CL8aYCIKl6Lv5f1hNB5AhcARQzSXDYNGnn8YiP8AmY/eddvOew69u8dUwb5A7zahdBpqnfHOWM2jHufd18YTFgaHltcRAtTRu8Nr3gNoC+yGvDFu0bAABOFy8kduTkQ10PjNlYO3ziglH1xnMQa7OEJLrYpz4/f0+AqjFgOjLqunKxglbBs9P95HPs+14dI/TTxh7K+XnJ4ocQ4zXo8lMmSncZtD1D+Mdjy775yGJlE2nFC+GD7ckLE3fOTEpGQ8GBgGpdeMVJB2L11irksdOJQaAr93gPnIGIiZeFCfi4MBWMr730+kHABFmkxKXQPOV0wYEzWCj5R2hRMSObg1LTfD+pi2YIDKFsBz60PyOIn4zjOt4uRBdeRekp9uITpEz7cGkB+fExduZrR1TfDL6xi+0NPNTp26wBHd2QKk7Z1j/wDBmUkY3s/GUtbz8Ykc+cCX1yxT0+/i5WO2DSeTuYIdt2i+0/WdPGfyDjie+kGLIS/4KvzloTqT6Ej3/WBuB6AP1cpuBBAx2Xh7zhwBa555G/jnC20CABPUv9YCBMNv8yXXeCowsy/jNU7dED8YEYpQU+Wu2eQvnBEAasRvxgJaPd4/nIkB4CNCy5EenhHSoeec5s0ZPLGvG94TvMAp4xCj1wRF+cAJQOPeMMc/By1/H6POWHI5RUb/AEmRhnaEVTeusoGgOB2TnnAuQNq0dYMU2a8veKlEpzrTfGXjzCnXrLICiMPR9148GBU2nLTHPCPyxNJzSIfiDkA2Tns94gYyhF8tN4iWyThj8Teck95h/hvxgsfcDn8c+ecebMlDqDnnGccGt8MLbv5zUR1ebh7JMNaCQsvyfphGI840Cnyj8R1izqp1oX7mIVi4Uyk2NCczFYtD52YWDP8AsDfPjAe9mAcGURDroHlcNyJC4PRnArvFs/J6P/X5MfshUoixut+TpzZFDzUwvyhlTBuQibK8eurinOJN488a2QiX0UesbzTeAwi6hBzhEPEDIZUdB5xibKXkeA9e892UB/PY/wC8Uqw8ecm7ohyHCeB0mApJU82j30nSYmyM5H9YiiPh4xqKJ1izKx2HW8WvwxjN4ceKK78wdcYrt5RFDs/95byiqYitA3RAZ5MUVqrfziQNL5cv+eFq61svxiWiThGyXnjNnOtCSW8JMoAuhC/nB+RWgj1/nJJaQOoeOOMRCrQBDr+vjGwG7BX6ykEKot/ZnlWJyoc7Mn+xvc21I/nAs4qmrfWQd0DBo8DONcYZBAICDeeuPWaKidkr5n8YnMKf1D69cYxbxAEh5wYWHHM+ZJgrYFXsxuyfU/xZSvEoQfWuSgw7NV9SfjNySAwWFXQmtTnAphFRjYfl/OJEPu1uljYhrZixk6AJ7uNkW0Qus26KZIaBAKc6CY9u0qlVvHMrrgxVCqk62iLXvDUAhSh8ZeUJCGj2GWhAAJFDwesaQhzdHqcTHZUDI9vn+uMB6GLD7Axs09CVcdq4aX8j6wcjSAIH24jrQEj2vHrFq4t/X5/XGabq8u/bm34XkTJ0YGlD+ccaCQHf6yiOzaK/WDj44njjxgUJFQAF+94yLucc97sfWa/Jqf5SHZ+O8h0Gqemj18O8QV1xpf1nHjAAeG4Pbr5zqqNY9vle3N+yoh+AzcW8pz8src9uc4DCuC+8r+es3w11P7D9YsYzzj2CQveFTnwZVxs85woarciYvhBe+IHMnJ+scCzSR8N9Y6Ns2R7V0YRD6mj/AIQ1gjYWkA4Ax3P5D/msI3vEo/rN5vOVt+i45yzND+iBT2YVU4TkTSYwqKcJ+sIp0TvFGvTk+kxkqXZLft6fZe8BoWE+9YvoA858L5u35x0/+ireYu14/rC+g20AD+Ie0d6oPI9mbg6U3gJweTtwSwEBPOTKOXam8WAzOL3nRId8d5CAeNPONF2h2/wxwLQ1w4AvJpf7wA6nYPWCQo0n7wQWxqjGamz3w5IIiWJcfWijD/OBFLjc5MIXPYzeJrq+DBjUBIdXGlLY8Dy+Lgvak13iZU0PDrBUJEFF/OAg1emcsiSLlsVd8t37x2ovGlOH1TIqAdiMD/OTI0dSRTABE3sX/WaCF3ow/wB4lSJtNbxgk+hrOfScgbjohWtQvrIKBPwYM7BPPHlUs3eMEUrmgYE2AYqznEg3fa4ewEOt0wBKnUj+8Ogk7eDCG5IKVmMwEo5in1hvrCMM6B0YHxqw852LaxB+HA4a2UfCFy6o90Pa9YN9k/8AZlENcL+y4mVHOh+Umffov91/WIyImej/AOKT3mgg6xeDLqYQ05rNAw0ezIYkFpl4UwewCTR9TrIGia25wCC29BPoy41TY1iZv4BMFi5s+Tkekx80QjRn4AY+/GELQeEvjGoTY3fWbFDKfpFeiFPUOPLoutF8zzm+ERzVY/hByBUTxxir3gmKqfExL8ZhHqXrd8jEQlWaF3MZIe0TnEN6VseMSEtqmDZpNpbMCAPi71hKD5VwYvwkEpjqXDUTBKOg5M1C6R1z7w0IFQ3p+cCEKzYOO0vtXvzMVuo3rjEIeqPOvjKxRHBpgfYbVmd464MAyhB6piok8nguSmjd1yOvqvP4wWKISTJNBFScsIQBDZgXEYwSl7x06EcQMXQVfEeMigrzCdZTVOeXfxmkAXkXbhTYOnfrFNL3ZgAFnomOxoRw/eDRIj0uaJzDY77zfu04WZxRA7oylKDrCAEkq3ea1qWQzRGw+O+8YNafnAoigI+cDPAC/jA6XrSL9mIuiHWfzYn5VtmHEw8AM1UiV6Bjgs2nfMwmNUUvWrw8D/GTrejN5dP1hLOZEvxMX5aF8JolPZkMPBuTf/Q/qhhbns6fT4fJ/wCM7LnJrCQ8504c3CzZ3/4Q5TrWOnDjt3homJmt58x6w+cVYBCFl/GqPpca3xGtjh5lHPz7whYA56PeXqujyqp4gOOw2sUqcgWVf3Ma9TnQUT9YxsOeO877/wDF8EA5EafvD/5pYI/Dl6wjBHyDawlN/WWQ12XX8GbszgSfvnBKKR1yfTcEE5sGPV3izbQmJhjT8Oz3q5OqOzX4uLRSZOX+82RqGin6f9HNgWbo389YuOu2H73iwBAWYLx4wItHYj4cNmg5U041gEqGJ6ZvAhtqq/rHyAILcC7VsvBiBtvlU8pM5kWFbZATWfnizEg4p+11iWzgdgL46wWgpqvli5gUJCetXNJDoVTrkzSC1KD99YWEDG3p39ZWlFlHT+8GUWEFfnw4N2YApOrq5RRigxXHzh0g5ObeNcmR9Gmpv2YoJRwQ+IefOPbZCDZ31kSoA7HwHWsUDWiB54xKH0AWeOGFXKmyPqHXrK4sFpde8AhOUUfBJgIOz6N6TWEeUHkHlu8Za00gAb0dXjEyoUsEt/bHlf8AzS4+14WnZ4jqy/nDExtFpr4PgD/WJr/zfnDCEGgKJgFBg+CHyLeo6H0xBASpUTyPjOfjO2mZQneHCecfA5yT+Mgd4HlrELyIBcqugDGu0YCOLlnpPVzkod+BeW/nOQLzpv0f2zwMl+vW37mNIOjFXKER8j9YLPKan+/WADSieTGV8ut5T00z6OLRXKfIDT9Z3NcTXyrR+cpmS7Olbt0V+sAtdrweMRZrvA9+kHU78XX7yLmyk1Xr9mdAiamGBbcS4ErUUa638ObTD2CdYrHoggf/AHDYRdDLcN2CG1R+vOAjqChX8QmBaCAMOpY8/wDzNMcRr8JvWWgc3D/O8YZSaV/nIgZU6H+slqB7AL5zhszogeMTCl3VO/zg+OWlJiylqiTWAghaMPZgLU+VA/HGK7GWIlnGGmjPjiRBOd9HEY0ohznGC1vL7w4CuqubIR6OcETA7qa+MGvCbDTvrFuM2qaMGG4tu9ZQBI5ORPGIx0V2v4wadiCl18e8oTBdK71z7waIT3RwTsbCcvjePAVDzw5wHb0uvnCDE4dpMQCPB4/3iw0q6EtxIMG43+cdSI+n4xWEBRV/y4juG4PHpw6mjC7sPjOSM3tvPnGFAdXQP1icorDp6wrm88lnSRy8Hs8HvF1r8u6ngugTR6M0xV/8pYszZ0mI4FcIF2ND2MT4yOtnt6r3Cz1Qw/8APrJkLnLzlPeFf7idLtH/ANwRT1CHI3Pb+nYfzAU3gDFgBl1/4APoabwqmX59WBvVZ6L8JxmuULoJBS81r/rickRp8rzlQFGFHEIcN6ZS2lfeKdx5YcOUruF5yE7eTLo+8SVgSPLziQIP0nNKc9YAigUu4i/1lygiWU0Pxl3OoO5Tr6cAEXyhTjOQAGLLvCLdiiOxxERsZOWEKrrB84UacbpM2DBTTEAxJACadGIwYHgI8+sW3Q8L4xwDC86nly6u8B7ecS0FX5wbizFuligEukLWb8QWBa/eB0QotMLOf4y3Y6kmUAIxNaxQQb88MwIokMZS5IALt21xAVDVcuTWNKaHT/GBqAhdCvWb2XgpxbUCabXGksCaO+85Ozmn/t4GK2kAzNrXYj0mGirsace8lLx2W84MLRt5rOM5gAJHqP1iUJb06PXnvKeWaUYfGWULWwcu8KPDF2XjFoksizSYwAsAEmFYEibEmHY8K8/GVsbtvQv5x0NjRdB+QHOcV9mbhy+ssrUkLUQ1WkuXXEMWy8mBbnVw3iYrtfWQnvHWLPC8Zwvz/pjCgiUTs85dXBHvDvOF+85/yY3URAq9A7TozZ/A63cHb2vHp4+efWK3qf8ArjTnPJ6xtp4YBdPCpYvw64G95Q9Jp0Mp8zkY2edbOPjxgb+yh+c0IiF3i/GcqLXaYNqBHLMsddhLTxkOQBZ1Y/Tm0FBfkZUKQroHblcZQa8hJ/OUqlHAkDjEa4U5PZ/xxmjRja1MBb0rxs+MRQul2VxFCHfaYkvlwFvvEMQE5WzKpCuxwMs02quCIjSeyeXxgCHVFVX3khodnQym1pGmbxxEVN7KGTeI+U41g9ul3r+cAFQOjJitIF0PR+8I7Z61gfB2lTKRJSeTApoUCFT4wqEbG04cWh0gUXFOgWO+fHeEWcIyq4UFs6jt6ZCMLw3mzANccvjAT/AGUXOxRvxgtuiqprNBXgeDC1uG0R8MuSmmQj+8AFsxn11od4BqLVI/H9Y0m85EL6OcDBeCj+WCRkqQA67wYDUUCh5xws4asfnTiaMGxg53NsV5fecX/QU+A2vwYOwxGjuC0H2mL8Cl6Aztzkc40a1/5yfjEwbKEAO1wMRpNFmiu/1iTfO4Z8w/WDCfs/6P7wJ9Qlz5dk+FmGj/ACR/7rHJabWk0/TH6MJlEGNVv2p/8t7T6zvzh+HGIkEloHK4JVuuc0wcuzWgXWb7bu4FxNzDTnC8OfVzu4ZecZaSiPcXBvTfPvEAQKB04L5nyZPOyHodOCGeTXvFFJpYVVb5dZDcTJuoRcVhIBuTf9ZpKqGpUOXWGLbYAcdZBAUIYQV4EKkkVd3Gxvp0P3j7mCEvi0cpwH6XFAEGiPf+cclCJZurjZunsbPOWhXo33jANAIv7xgCb5rh3iute2F8ZSdeZck4n4F5ySKeBmsYEiTlNY6YAW2M/PnCltnaQ+HHQfEk/OFIaNHzjbY3cmHp6k/c5t6N6QFjhfBs9KHGUNOnmeMiyXkgMxR4QUjDjucaoCOgBgCBAdAGp5+cIqEHhO3vNBAER+bmqWHLNAZBwpQxAR23cBwMESmwhp8mIPAhbVBaub4htvrGQFFDa4AUouxNOJrVeGzXhwlsR7deXKGLTP8Aj1lggWHxnlsAgHu8YyzI5B+Ze9MkKJQatRSeIAzloT3gk5y5dTvL5/8AGwDKiAHK5NeLpA23svGNKdoqrjCbvrOQDD5yowsw57ja2pu4Lgw298ObCmwIVa//AIJ1j7Gq41yD1Sn3hp8lgiAMlLkAXy6+s8RPu7xdn5DHv15L+bjAh20Z8LcEMJWD1JscjLP/AMEvYTsTkekYj6yPbjiTX32d+nNT/OSwHZ3xreF6q7axaAB2xBNCHe85hKAmnv8AvAy3YJ1JkQtyD4FfrG3WsUgtpvkLoLx2uHVrAibReHow8UavftjWN25P2f4y11i1999w7r4yXZESV/frky+wwJ2ycApzecU75XC1xrLeF7Y4E0KXpwh3vu8nrBzrtprvzkdQAwC9/GUB3chvr4yItrL0yHHzt88bxEgmUceveWQatDh4yTX7YQq2/bEIhcohy3iVio3RrlmAjU3oeY4i2nFgJcVejw3AAJDXHPvEGyU2I3NiKBQ26yrpFeEwQTm6JzmhPU2c5FVTp1+s5AeHn3jWDvhl2a+McMKo9CLMNghuzt6PeHApNrcqgW+brAiJyTbkTgvwOA0bdtSuJP8AUX4nQ1VowpzwbT0fva2zIkwEmJWZVW8/+6+8g/8Acf8Al06LCqFHmN9YVpt8+sZ+sA/znL1Ikfgq45kYHF9MGEUMXT5MqNZHn3kqXyGSgOoF1glDedXrFvGHGbcYE5y6pYCHOD1xX3m3nb6JxZ2u38QyJpmpC/L3gSO82Ghes7eavQvCdmOE8eDmx78mJP8AxcVmucDoheT2fFcK4K+xQ4mqtXqOIQ2M2JhVRvr3htiBdqtfzPq4worQJI+MdFz2EY515yBe+lh2/WQWjMLeU8A183H7o2X0ejAq3+MHctOr1j7AgjcR71GzlE6EX5MZ6EB38fOEJXqlMgoJ9b+sJBospr/eHhKUOz24IXchLdXkOsjY4KznGWR77Pox0lGxFuS1R2g7yhtLxecRQUKOCY1II2wMvZvvnBejbanPrHxWitO5/biVClXvVxApEe03gAjGq64cbposqBgWNDgpuYCoL6TlxBaDbXB6x5ao6a5erjRFaK9mRBNmFX8vWUBJnk3hDVvE3hNc31YjT+vrGAW/saOsV2qmgCXBFICg83OCA6AZw4FF4x0AjknR/vFOA6narwTa4fmU/HR4D6l5cXTNXDZ6wLtcoMrNhvzjtxd4P/ec+cAdW8RvuGtuMEqvg84Rg9AQ7/8AmOD3lShU6XgfvG0Jh3pPZ09Y8NDajBXzoyRqcn3ibsR4V/wOLnvJgHvJMG5SToO3DObq6i8/K24S9rvxi0oDXlL15wLOjleMKoSmbJceaOrCHl6TT6c1+iVtTafI0yZ2n/n3DBi1wI3EaeYb6S4noKrdYE9nsxplPBeUFP4w9WJ3Q46vvFhI0Ha48heI/wAID8YKbFKf1hkxBoBgHa//AHBoTSryYht+CB7wYHb2edNA8aDAfHxOw5QlSPct/UhkjzTJUiPxPxMmjXVXkOsiAJt3vN0h2UvWjCAiob4R6+sRbVNDZXnKJBCOTLVLTb684QDy8cmMoJO4vxhRTnKI/WBvCvju0lf+5woRRS7d5fR+MIFgHSo5Rw2H21n2wzuGIAHO5tDFHV4FOnJS3vRFvxhegSon/byxLRYh3PjB1PbSnJ4xeoneqzrB0rwNptuDSjM4wiQtKX1joEbRHTgL7SNe7+TL6TXniOcpIapDXxjUVIfU6MClbOAcv+MdGKGEeGHrIDtyDh3t0vScr2r4xOXeLn1cgR0uD95I1p5xprA71nA5esA1H05GJocQV/I4gCBvbDFS0RS8nnAe2YZoHAvYmMIfK3+SI6VQxANnlQql7XeJvcy5hm7KfkmHKXv/AMps7cvZiwRS8rX8ORXkPGNSC2Hh5/GP6kYmEIqI6NsdyZsP0m35lQ/DlG/AGbEdx4exxajjWMCVDjhOWeIy79ZxcCH/AJEbhlg1LSeGZTaiOiYw5ns8YKCAERfSf3gsgsOLbt8Jr4xu9C/JwwdQZj1gSrx5xJAg/jibz4PkwlXzgImIdHEVav7O8oMECXsB/WaPT3OlxXKTkB+zNCGN1qYQKgEEKi8Yl0dhZAcWQ0jbrT3hEtta6BuW59CHB3kAS80Z85RKJqNmNdhDFTvENabFd+MIRhMeRofXf1g7BLUGJD2O8IhABr+8ilqC7HAxCCydgBT+jALBxUOfWQbJlHhlEtHi4GxCfhZy4EAbcYElmuEnObJGJNBvBUSaVTesFFnba7+MKHdY83ENDxE03JkDWOlPEBsoDfDX5xoMPe+MR3K2jjNkKLV5vDmngo2XnCTxBXTj+Jfl6wdAky7xdXBQWZpkmIDWvvNeG4p54wKF1lSmg+zDfwH6xqgEo7erjEjK6DY9n8HCnmowwBDRN+3nJBK7cC49HTMbBA4g2JiieTLoV78eUzpEoAED+MSf+wuNuseAmw6AP8uALyDpmU6wRs8ZraKmh154rF03Gedhi6Qr9YbM9sTu/a3OsNRWL8j/AFgpefzieCpGwWfkT7y+K9aM2uJVijE17xcdXX5/8+cESAVTdo5YxGF+cRdx42YpLu4nWc7mLyqT/P4xcIAJqEl8c6wNYqNXHSyAaHxfFb94koZRqPHziK3rw+MaEFFDkOLQESPx/WKw6JxcQxiTdAc/Ywhxa0XlxtFFbP5ycRFnx+csdcdJknLWGlzQABDliMtAFI3eMZG7iXDaUwHsYqs2DTc8mEWgALVOz43iT08J1gR/TitLjqSQz4YdHxgJqNIOkY0A21XjDqLBx/HrIaEe0uEBaAWm/nCA2Wxq52CTg/nDsRoJ46xEFdaXjACKA0/zgwKXkeDvBu4B58ZzJiNbQYfeONFeZrwzcuhNcYAmlhziA7tGSY3XBxd6vwEfGBPHA4Dv3z+cqaxwYe8pt2+MVVQ/vGC6OjF+RiE04ceBgQoJij86Pl4yLaRQG8dnxhowgIVr8uPVlFCDk93fT65w2hqKQPN4/eHe4lOagSb1P2YNcgjO4F4fzcmDVWK9Lb/xlbjl9mXxg3F411gzA+dCf3cVYKvIbXaI5WHI8OsKOjsceJacbdYBiRhcTHcPADziYBZrWU+uvOI0PnIQBTp6W+sMabRj3Ad4eJ6YpJuifAOX0NxrVBTB8RD2zAzVDCPQxArdwfo4BtfnG9eBvjFfkLX+DiyDMjvICFfDhO9GcAlP2uHecxwiNsfOnCOBTpjjYh4XMe/5HFjNloOJ0Gg3gEKKL3mhKi8nORADS8ZcVUV5TU/GC0ghwu05+cFUTYb0PnGja+fJwyguiamEIoJR2maUOa+TrWEBca4NB8YEItcHj6zVEFaNxK0EOJxrFIrGzw7/AFYYidBFI7J5/wDBtoiXg6+OsoVW9IPJ39ZsdkJVpy2AHofxgQSuEWYDxYtHD9ZWufBb9YFSKMn+sE2oI3q7xxpIbX4YRQDgmDpN/OjIQu+DIFzSpz9YXifYUPoYXSEMcaxjKiK/FHGoCF0247SA3hPb0hJXyC+zA6XmbzY4wvRlrkOhiwui6xdQbO8bUePOcoRgtnLgfjEfrEU/DIK/eagnIo05eK8hw9B9YaRy7y44nlmjpzV4ceAn3gSDesHAfrHtDyfZ17hSGkOHeinyYBJWon0cQ3lH1DyYxqCEVPgMm6pQjN3l/OOxKNoTdMQ9GcdRjD/eDBHscfCkZlXaXDD4CuJgw2O+RvD7p9Gc/Ct+csFqv7w30P8AWBhHGC7S3HTaajN8Ozbr1i3kgGMfD094wrRYiAfQGCmRfBmjEILyIA+YB84WkntA4+uMDpd66MZRSu/DFVdMRHRCf9Mo8QD7J/Gc7WqnR/EwE6ry6yhgoJDKjQEr05oRFx2Z1ZoD1L1gKOKzsesFO1QbbvAsfRMhdSirAomrpTaPrrCvCPenJ5Nt6yAZIhd6yUHTHPHbrC3ADS8RZyRp5wgUjom2Odaa7HmZFCinPnEmohoDvHKRDdc4FsVA0ZdI4nI8PvA0HoTz1m1RBx5yAUg8NfEygEJDVNF+5nXjtJxpiIb0I6YyAotaZPWClHcPW6frHlkKHf8AEsfWPBTWLV8ZxzkzdYVaxm8QTdnjzlBLAzZ+yYAbOz94kYawY5cQcJeWsfgX7xP/AJfOXDM1m+kw42v1l06fvOZfGJl48Y9B/O8LhiJj8KfTgp0PAL87zq4Yb9F/ecxDGSAHxliRciawxRHrWAeWJVVb3hAn0THqS+DGu9jw4aazH8HWQal1vLK3g+B4uVshg3Zlx4yh0FnGm/KFevbEDnvrh+DBGI/yw1QDrrr5xacA7nNztFxedZShIV8FZdGJS7N/8MgLdkWbOUIGRUa1moUBQTnBoltq6/1hgsKccuG4lburDLy4CCOP94d4G7e/94FEGpsu8ffYMNsDgGos/JnKNmtuaKhTpWX5zgo2Wi1143hbc1Wbu+s3wtGt8YcUtKTX5yyMffr7yMEB07cWsQeZ04CBD1/eWiZqe5046XlZQ4/3iwMva+8SGgaQ5PxgoaKlT4wxWingk1X5/eEmO2ofDOaw4PGGYoVucJx9lQTBDhhOg4/Uym9Nx8e83+LG29ZvHGEPC5zv8Md4PvHxtmOg4CPqdOGwxthxih7wJsmdZ4MO3/0C4aP/AAupMV0lcTWucqMTGVx5DFe2KCQfOCs7O83VDNFVTEBwNuJTlDC1yLjEIyYLU57xUo3CLveUmzWEA1d6cjU294KgE/m1lbIGEmHIg94OliQOwD+M1YIdguKoBB5YU9ld6wmAb4Tn4wLoX56zYenScrAflMZ+VgcUHXrOGb5nLxcEQYOLP/uBPW2j18YnaoU6+/WbIXHZr/5lCchIcXCEx0XneXINC6NO82yQ2+8NqbbPX/wzeKVf9YQNH5xIpHYS4Rw6BOz9+BAAbo8sYSB+R8mNcqt2fxlBpR52Y02CBvr4ybANDubxLBQJMk3REvDEqDX8rkAXQ7HWJEB6WdvjHGjewmKjEUAq1IfGt5WaLyhYawayno9ImbGiF4yhyn7sL/P7Yxa5XNuNg+8G3lnJlrS47l3ijxi8H8ZaryDVMEGneBWD9ZoCHzMY7/GS7yi3WdXC3nrN+f8A8Bq4bM2PGbDtwbvPLOzvAg+8QKZV084rK78ecgaNeMGr0xT+mJUWXFkqo1wV3qPGb7HJU4w1ttyqj9ZIBVfxl3HoeXJp1zjUx6AB1nwfDOID+8Kbbc73kWgL15YjAxHrvDZTo56w4YXJHJ3IgV0D9y44woOgBN/jJSJCBuYC4KuCod4IME9byita1Xf3jBHkCnGRIeBYd3rJHdzXOaETl5b35xNVDyCY6iIQnHb/ALrGQMEFCY7aKecCFac2wxqpdZObzfjJNgyjMQBh2c3QY1f6zZUAJQWZEnfrkjAjqSuAOm+Dx8fWcijRDNlFJ+jNwoOpb7c3ENh50ZO1ibT3hCgQE3ez5wFoCYWkDA1Q4hiHeJZqBrbcbItwkEh6iX/7hIzE62+cvRswPngemP1/OIzRwB0Yjh7xHo1kQVuaC8j7wsQkzqc69YiazhvO7k5/9+ceHP0mLpcUaYIDpxsLnLfWA6GMrYBjR13jpVLNeTFLor4YiKVcSAAbxrAoT7MHAhDnDv04wJwfzbkoQ48ZE4PWbMmADblvs4nrDhQ3pziS6NUz0VHmYIha5pg2poQrkoajU5wErC26mDUAXrN3kzUnLiGEgnJ6Cd6r94+67U8bwVJEJvnFFFLOP+1i427qpyJ18ZIbRPPnpzZIbp2c+8IoEsU6wVBwefLgQATVXKgmzv8An852shcqifp/WJXOQol1gAPHAQtg5DEqNtUNnz8zEL4tzz5wLUiS4SFDzzAwbNqR6waQS79YFZaDQOMAjp4O8NNyP64xekT/ABgQqU2+XxgMGxzO8KFQjgcrgr6Pso5hqCaHxkDiSrtcMNQh0szbhOTgHd8ecnpuuuMXnfWQxwgvLicjHTeC6G/GNYrnHj6wh32ayYXTlFcBGmAMfRhaRxz5/wDOs6xybz4cmsd6xJrEiLzhSLzhpcRKe2BgOQ+ceQvGRCEZvDaODiuMTYNZKhiyiX24xlH5cneH2mBaoLresTAXTN5apKmJHcPDu4QRt84UPKA6x/hw4BMTtDQ1rZBdXznCv0hlQtG0xzPfj3gZbNenq/oA+Rxknkb0Zg6NVvffrJSOF0TrAmwDNuR6x6OfWc2x0veMKeoL5cSJjvU/eUiASaqq3FRT4lfzg3HZraF/WFWBLpezvL6xUDeTZiDbZaZ2a7qB9uHIKv0wuHBPQGyYQJZtPxkADo77yAgosug9ZRSibRv6xVk7cXXzcom058Tzm3BDnc1gNiQbpu4V2lRJxhKGkN4ZJImfLbePqmHlEJynxiOmCF5OzWII0jJrRrIHv2bo3+sEIpo2IR9NPrHWOdZpwHm3IC8/WK6GKu//ADfW/rGRfrPE6wzw/OHkcczCe8pLk946M+VzXvJnrDfebVnGDOXODOTJXa5SLxlrcJrgcgpx8Zs1KO54zThHrAKLuYGXnBQHrJ0SGNSjt6wZTvIRLKHeNgvqDxguw0OOdYPAHWAFa27plQreMTbBertxabEHn3hBIvEr4xuhnvlxHlA33ijSI8+s1cXWBafsh63C8mHqgBwDINYIPJDxgkQeA61lNCNBfXrEodNh1gpUu6T7zQpJwHdwQMQ4MSmtWyYwmn/0uSB3HDrWCYxYJyP66xIXdQ7MnmfV4zVuAfLfnIULQIYCURd7zXWQQABiduJHA0XfOSXAgnrFdsBQf5+MIkCN/fxizVHN5uMIgPyObAoKCo684kDkBfWCwLJdHWNGOhz2YdDQB3oX5wF1OhuE84oBJnIcO8SCDuPE9Y2hGkomCRzvQXBehD1rE24acDVua8Z3mukxp3MS8mR4Zmx3kwaMDRvfOAGjgxu4TWb1vNjBHd3kD/zrD3rO7hkdFya5w949Y+MTrIbmeNiydGDB1iV2cGCmvyweyNwxYUjKTJnZfHjIU2DTpf59YjXs28ZBXbq4Ikbb1htFyGOgp5t3jAhwu2j3jhSiIroFCj5fvL1rLbO9O0L5mJyzGmA9hsxFos51JgX5owfeLMLgA2Im/A9c+HDjy7ahKPO0veU6RTSIOOEQbezE1XGzd+8BqcOXAyaVr6wm6uF7/wB49ZKAZz4xWKDkdDGIU05LvC1bLom8QOhLanGIR1xvjYv5yjBuO5cjfHRizvSgSZa2XcQ5MSvQNfxkNqBtkLgngMNbyznCr85FMCoOPWCiLbzJ1milUF4A9ZzNzXtf8YS67um+O8VRQTu+Mpaw8lwVigMpg1N217IwwAyoVrdckWcAq3TTswq0I7G+MEwW/Qc0CERZwh+gLFEoidJnG5jvE9fjI2uO2cmjAmrc/DItzWJvL6zWBrjOss6zaXPWfeL8uanfP/hk3c1bvNY85onGCodHnNngPGO2kmPdr6wBXg+sLOF98ZZ3blT1kkPAc/DHdiTTt94i0XsS4gQHy3eQV4X7xA0LvfOQqDRzgSxEeW9YnzwAtIe2n/GCqDG4Edr1dvavjC1ZD8BprCyXVQ/Vn94jAqpegv8Aky2p4RL95+jJY6AEnwHGAqeFMJCDwDlBUO2kiecUBzyG+Oc7ImipbcJWwMO94TmjXy+MPcBeLx84VNA1Hz7yLXZUZcSQ8t13lgBiJxccoZDvd48cZXRpPPG/OeS3zTeDZwKnrGoEe7OcAONdch7wk2TovONXUdro/wAGQw1G/OaC0tW694xNSAGCBoCexwtLBre3fGbIpUnEOsA2Q7c4EAANF7xoAHkmaASKrav5wDFiVwkIaqvgPGJC0SJ1rNB+1u4xpzHJ4fpjmoF8mLQekI+z3/4f/GxJm51cGPGPOJP/AAFOMR5zv4wnExHzjcdalMJ0/WeKW5tNY3GhP/Or4w13XDWD6MeeM62ZoSawE3gF6NYcyuseaOBN3L7Q6Hl+sabvXO/RiMX27c2IlTAjR5Fw0NXxreIgRcTUD7xgYoXWogBtcb5qc4p60LHy3rKgiBDlvZklKKxy0DLBhswjTV5hhqKC7njD2Ch7rmgQ1tiXP4bfvAghUU2ZY2ezg9Zs4OZkx0k6PnCpsLQaAwWAqKIWPjCKtDq4E4HSEhgVlHBeZg6KfIuF2w4WzsN+OcQUKJAxow1hsoOnTeIORXTcZUZW6bktIE7v8ZxWyWXLhE3evGCddNrX3m7dQautnGKWkSzAJHA2HK7wDK2XXtckUXl7ylZo46rhwePeOCAFzcXtgLwFrbxrxnahDYGaUVTW7Mqo3wGQaLiOsLHMcXj8mquk947bViN30B0j2ZfvBZt3nvkNuF4c3D/zxnWV7/8Ay4mHtgT+GReXJkfLN+MOM8nGR6ye9+P/ADfGpmuOHDjA9Y2KOuV+s00ngj9GPPIi8fGAF2ePvEa0nZcCNdd+jNCmx3rvAd2+GFVob+8ikR94y1woB2r1nAgIIyKXihvv9AbZcUDj94UYj8Ijz94i2I8185UFU6cOVwTHaIU3vzj4BTNH7wRhgWwvxgwEh8k2OUdM6hzkLMWtL+sDYnyMYOSiXvCoB441csh5iPGA2XTdW+sWrXjesVQmjXhkII3le8QEp0arp7+slCSrPNj25B2x8DAIAl34TBatAaPnKQhfJwoETZprDiaBw6+sAFp2WAORMrSNUMTpAUJ2k7zQBWxc3Dx3uDvn+cD2D78LjNo/B4f7ywTyuzrDYEK62mcarkOoODxFNeDGQDPQ7wKEMLxmgTns8h4xGht12MVqEbU5x4T9zXfrgp0N7K0kQ+if0nZ1nGoTzj5z1jvfjPsxF4Mn/wCuN5bkyYzPGCPgBtejPaMSLzB0fv1hLB98Ob6z5wf/ABHUx5xyce8RQHBxiJIana+DnGUYJev66yw552J4w5ABNYUdh1nI7C8YBHJWTGthNwyKxnwYoSYSW7y0RH1dI4+WYeJLajp5l9C4TeYvWAnTAg24yektHPLrAiZviXFS8rdn84C2UbfOVDWzRsZzB2OcMW2n2wo0t6XjIFRdswVDyGv684V01yVrAIN129PeLbdwHf3kp2Q88XCBsWnvETRhwdYIW9KJgBTV1tneMwCjR27IfxcRySL5V/1leb6zgEdan7wFO9RlhhS6JCDj3iL8RnTEAYQfnzhXnF4oplnELYTeFFqDl/6YyVULXc+84GTqOGBGtPPOIrUdsA5O+Q9YBAPBwyiTgo1vz8YbBAT5/wCmPQqAHAd5E0dOobzdazmuPokHlyF2IVH+MAkCGhwKhVKtd+g4TnsxskYnnzkns05zjwp5w43/AOTpnDK5Hx/+Os56zvWHQSd8G/z1948LVffCLKu3z6zST1IY34pOk1fHrnIOdfGKXlmfbHIurgb0wcP68sDIRWgBK+XAkCp3fnIHMcm7fvIjs3vzjakwnMwrsa63iFaL8maF16xnRimoZEElTzg4IaV9GdZAiI+LoPZcsI58A4ruv5d5simS7zcep9PzjooX3xiKK1VH+8hQCXsmw/1loqfAJvEJzEgd4gbWFfPxjuGBccuQhL3XjNyIWu7gkoxedj3lTq0NecUAAiO736wsoLQC9mMtVDHj4ysAE3xq5QSDWeN5Y4I1FzYEXxdTzgpWiUD1iF6HHvDy5Fgogt9MJ3ctEz0fKYmx6xQlazRozQGKJrf6xjbjgJg0Ig6GPvGhtVvoZoNKCvEwvQgcNn5xJANxJPjG4QU8mSLYX3rJGFpl2rmUPzlEGQlcFOj+nFW4J8jLC0E/GXYBzav85SKScvnBDTdlaxkJkwfGbKpTiG0xHtiaxWiTKr1hqK5Vf09NwqVRH4j8nGEVmiJfCY/nIOmQu94BJvJwp5UAFHbI6kZP8tsOg+Avp14vDGauDuU+f/ZivRpsCyX1A+8qEqFP7uDGm7teV7cDtwjQadBDFPORcXLo8ujKc865fgzfu6dDm+m8d/vHREXTOcgBOBcBYM6DNabnnrFatennAXaZ85p1OfrJVQ9mY23QXLQULrE+sBfDmBxe7fR1gPqBUB45n95DIdISlirfJ8Zbunt/wH2Yqk43TBPALtLcBIAPMa4kUQlExyk2UNS95rkHhLP+mCgAjDcPedEhNYKfInkcRCjttdp7w7KR/DObcjceE7wm6gIamvnJJyW+57xRSqMJNYthg3ejCCsD6H1jEoo0jXzmlC0tNxUAaeLkMlAdmn4cBUv7MEd3gPAHXjbi7CDXRjXZ/LO2hNHhnuZ3GsgtDOQ85ARGQXnB8QG/Gbk1YG1zZykheQy/A8njAgidlOcTuyIcCusExin2jx63jHyHP84lUYEWMhot2TkwddtFHj1gFIk7a+s4USnx+sTkLQl4xKJQXOEsPPjAwCwvLnBiuFUmSfEEmNIIQ3gvAEJRHm4zPL55xfw6wCyxH7AbPY5Ch8k+BLT7M5Z3gx1zh2IC1MaA5kB3zk0jlkDeV5lNxMAq4bz/ALuvnBJrAX/2PjOS1QRnkThw0xGGoe5jlBP1/abf6xwBBicX4wBMPAA/WPLrxM9Vyva8Mn4MNIE8KZBRTZ1gCT5X7whE+vjLUnpDALRefxllDt/b4wCLz2ZHhrKpM03HfXfvP92UAj9hgNRYCN8ifZZOwNVvfWL4bgihRJAHg8ZabojXGCKuC9tx4F97ejJBL4sUnSGtsPtjwzTgpbM4V/J6wx0Abo++9YFXw8vODrA6iWw/zipVg0Ot/lkVS9XERdn85fIcA8zBjw28zCUGg2mtssABJtw4JQjwaG8piKzBvIIe3g/vJIASm9huPnOds9fmZT2qh1NaP9YcGpBdObPeJ/55w8qernGkSHhHrAhNAOb5yqIN4XL3qGILaJrUwSauLa8OQwECpAxgQ22HvCRUBohjXYNfLKTlCreXHWA+Jj6V5J0jhNqAJ4zWIhHaRvfnAlBUnN4N/jDtKacecFV0u3851EcrW8JrYPWGtRHp1gpo+A3+8lVQjW95ELuAtXIL4pDeBZWprX5yIeRsceAFNLi0Uh/LG0CDQnnKmgth4MYrbFCQbNvU89DmiMHuWAEBjyyzJ+iH8qB93NzqBmfAH2XAwMtSoiLrm4K4LwiG0NcnE5/OJKUTS/L5BDpTIlU+ccnzwMNakYgVztn4F/rBVW+f/XGL7ABktJyWf3lk043/APfjKSJVwdMXFbZhvqriOcRSQ7JcV9yBIfDkFAXTgUA8hAwuQVbB8hjticKQvWsDEhjqOsEKh0iPcf0wXGr9gREAeVxjYEKO69M3zve8iyytl/lhlH/Ay+DgwpqJoDlwpuUa1ikt7IusILfhDdl0oO+jxcn4SwnkDd+1Xk4xVkB73oxVRIBB4R0mVxKduLvavxwToylGl4POCAJCpyGAgLQrw1WZF3uGyU4xbgppp/GD3T2v+cdM2DVdvjNhaHY8YEwep7xVqRO81oL5XFggVbXrAglG9953e7Aa+D7x9NeHw+MHkegyOHAokO823zNeML3puw8YmpAdBjByDS5ssOuF4c/4mQ6Pl16wsQslGYmoJTXKYC0gPRkNkWIHC/8Aj1+Yd3U4mEbGhSCmjjG16HI35cFGjDbsfDOPKMA5PKARB/eGgrVIH3cRcJlUX7xIjTVEH3t0YyQO2L+c4RiFwRpIyHV94EkIwha+OcTviZfxiCGDVdf6xoybJwYJzhqGIynQTIyCJbqcuAqB0Tj5wiki5dYh2PQHOEDPFG84ekJhoDLEsaHg0E8YhKpB6nkyMgdOnOPeAF2hOtFOHCjmB40Hx37zfFQ3SO16g/Jjm3C1ES7IDnWByylr/nDsBDj8HaZu+UIYHPDjWuThdPu7xfWibBPjAv1BByf2yVrW0f8AAM3gRl6JVHIzZkuFBAFERbTswkdlum9/eP1YQwr1xt/OO2uG0vrONwr6zbyv7IaHzDASQbTL6YlMZNc03f54qHeuc+jFAa6ZE8aenrpf3iUkClf/ANGFCAqcacE7UN4ABgeFvC5HSumjGAiC1IAVXwAK/GACbCInZweE2PsuaKdB6qh/btxdS65syh5dxcEpBGV3kxXe4NiEI+LwmCO6Mo+WlfU4185AMNoUPP8ArcGdTwA7LUecUceQCdb8frEOoOtHw5xR1UhYfHPOHTQ804+81WiCnl4mJAbnSTXRh1FulDprvgj1Aaz494eC4WPy4jLVT0dXvkuIdGS+NM0R20KfWvC0VQI11e3qZaUGSBgeGxH2ODhIogujG6ZdORm9IjbOBycAARrnBS2Dh5y+b6NYKtD0e8A4Pby+sNACHPcxdyvC4vJQjUN3G0eoPBv7RfvAuAkqLOFF84Po3oBfGz+mb7kxQziyPxxm5EmwZVfYmsHQZhsedBzrfWJSPAT56wGWIP8AlmHE3kEwVyARgLT5L8PnHNmbEdgbGrOMdxZKQkQjkFF4uKkS5VjXwbOneXuS4IJeCXb+MHSZkIgNGUuyeclJsNHMkV1vFGG0KAebwP5xAJHZJSHw7vvFGUuqo8J+bgMNBwDgvvOgiF8qfVcPuIoIaHoAej3/AORmDSyTYH0j+TFMaf8AVhabNL+coaBF0d6BC/reB6aIeJP1+s2QlHCD1oR8IwcuLpQCGkS6/OQkiG8OglfPxJxyRhfsBKDk5YyugLV9cYLSPQZMI48XslK/97xXofzYaC2vI0k3zgFoAIxoX37HLN8bIHJ2Smi2gYyNKsVOKUfet3ihEX9rhfB7dN85TaZpO2BpFOAO8N1FS2bmMp75AyvR7x1RjPl2Dr5/WBu/7gKn8Ygt4cXbU9MEwWyZTANtvMzamDecgAadErzwxPj5wJBgcEgA+Jz27xIGd7rhUY983HCrPxkWueNYdQNIiMhxrR5IdvYdv+jHJJIMDZuRIb4cCTFoST2K/rLSJ5Avyv8ALH7DFNx1w4MqpO1Ar5uFRObj/LMkzyoga3E7nFwfBFqnYoJ1LXt05cNzSRBiM2UpjaiX6lVAhSHT04j1iE0BBzs19Y5PkbXKK8afnAlY9SKD5eueS5QAJOxXl3MGZTfQNvKGBijVKJfZObLEO8uUKyUO2Rwo+XOMpSNMaNOjs8YEAv5YIimtbyC7FPPjI42t13kE0rNPjCMNp/OQEKKNOHmfoyUIlGkC8+MeFBhGwJv4ZiLimPHnBiY0G8hCArASeshkLJy+ec0Hm9ASTjOgcqc5J8gPUOeQX68XC1qESVKBsnV79Y56qVdil3Gvw5HjT6yQIFCC8hhBuubnmE7u8utAu5DDwl7fjFm08nse/s/GNJuHRDXd+MF0HLU4ietMUuSR6VPQvqwC7KjAeXK6ruiDROSR527meif+ah5V64fvGKiPjBSXaeH1gHgy9qhL2gnvA0TxrNI7mD1hzBIQ0VtHg3vZiV0hike0605OLQ3Bwc442v50fL2dYRsIrELV/L4OTCETKIcImkwwCsOjeAf53rzjMZmijjgFvfLhvW5OtEgcso5H1NhgO3HnnFRirio0nVVe8d8Baj7evvET4pBBVo08nc3k4a6PsHRp84hav06xtge0T8p+YGE1sdoKB283xwvNgAADonWAhoG0OsgbQ24kFScJgiVeRPGFgB0V/WNFCx0Cv8fnCIPDKJ29CK+abwC0KdgyRKBw5+ckNgT4xTSTEOIiERvl9ZtCct/EEPswKbSelhVEh/OS8I6GmnPtxNxa00AdO+MZBfIPKc4DpIsQvsUxBQQNCBwnnOcWzCEh+v3m4SFjGwNFScm+MQA5yDgjYtN4WBrnHc+11zakILdm3OTEuBqwU5KR7Jmg3Cntzny/wn3kjVQFIdknfY4FTCV62PPJnw57hDv4xWtE3lR38bJljIgLWL4Kn1ggFOxBuaQCva6mIRLOE6zWoVsvkzjEHA11iFn5HBWG1eOMTSA5C5SAC8HjE2CR3rvDiJ/Hhx313zrkZRkLR4E/wxIDANGjtjYXaPmcmSEadgr37ZQlD1s77+cQKErAbPxr7ySAZkHF6A+bhoQKLBsCnhSawXaEY05DKnl1miHABe5BoFdGVw8HvORGZKBr6cu38Uw7PAjZd6TjB+URcsvyNDg6iRRQUCcmxxugLPQS/ClesPueI979fyuamqg3qa5AvaGD3GLtcq8q1XyuH/irtpHhsyInQxvTlFIF0W4jMcq7WMXi1fJ5cIZkuiE8mB8coYL7CGC72Xc78hqGTtMjbZggiLOHBSFRRpHZvvCS1xfQ5MLGkBQPI+st81WQ0Cx2DAZXlVUL3BO3jwHjFJAK+7e/L+sirxOOsb5oshxFg+5hiIgFuDw/4GFQ+oT8veUZoP5wNt1Ot7B5A8PxgWEdyVb4BOfI3zmohNII4PoV3/FxuzVdb/eKgMX940buwH6yQsuMF+XWPHch/gus1znYf0QyPbTWYh27zt34qkz9PIAD4DeQFUfy43C7hs9rwZVICtPVeft+MD8ikoRjYcvFXE53dMc5OEoewPThX1OSD02Cd8OGkQSvDsP3iTTemH/bmXWljZQvfvHDtG1D2KmLExWA6+TvOG+M84Gk9Q9yrGtvAYNZIevW+jjJGnG4cCleF4jvJB+QA9BkzFSaRfDlHQcVOw+kznGQht/4e8kmCa3DtPC4AMqHpP7zrweD9+GyxQiKocI3aPBzQAJ385SBGjjj6wiSncym7t6w6k2HeIhBHNyIilx8Yux4EhzjnQumSSFtDjrvGQVJriJeOG31gR1FSnQ+tmbbtEsQ95VKPNCfGsoOURQM0+4dJ+jFYRFa9wTUpNx/jAEdZT/yY5+gIH7c56LgLuFBXfQh7rgIRuEfaZwD3IueZo+8HVDQovP5ygKNwJFY94qlBYCvSb5wldXdZ6Nt3xzlmbIFkNZeAX0HnD/1LhzOSPy/eCoIOetYhAb73BBPDJ++spUUUTKL4d+9Y7qcmk6fhEcFEB1yoO11nky+OqHfMjtIl9HnGJYUXs5D5z257yWli7nhPZkh6G/LpHUxVNk9Zyb6wRLRhyXrk2fgxApplHDs9ZFGVxDOldXH15wRVy27cvL+s2hAWq337wxByq34bwCog0/mc1xML/8ATnEAQHAEDIqbfeOzvrD1vODid5IPNR6wqQYW7I/eX0e6Bq9HR7wfyGzleV7cSYBw+VuWh0sPq4Umh+kAR0eQ8lI7JgsF0i26sGdJMtWU9AieAxN5YSd215NfxhxWSjeW9z9ZUjTaD+LjEyXbX8YQIYtbDBu6/L984TDiLF/OcWPuafvNo42/tby+SBUTfGKaZ7Gri9YyABOJe48mHIWChURP0fjLluiI2gpd7E2ecEl2MdulY376xCq0WqUNLykNnzl/FTiPK2Uo8h1gFqMkMErbr4XAqNvu94W7VHj3kNZjgUPXjEo/Z6w4CDWnlwdAay+MZrdOIwSeWy9HGSbV6tvW9pvntuTbCSsMIIibLnJQIzhwBAPWWPyVFT7biThmb35ZhuL4mjzhudNF/LMlo4i9o8ecCAB238uCgSDXCefOFaPicT6xiZKm9fHGMhsaoN+Yb+OsbQbVARy4wTTIeMiJNE9ewO/eMJmQ2H+8dYn4VfeTnLgpOg23vxh9yFrjlowFSlVd9YN//g5AY+veKcZnw9j95M1HTeOyUdp+Qgd+GdZYSpGv5NHXw+sK9SOjInYiYSNZKVbd8RrxvEcBC/ggicXkdXFBOJ8PecAfnFPLxjVB6bcgwOHF4gZ7PwgxI7QlVFLvNBsc4icYNJXpAIUPDNqTj4yvHAONpLNzxcMSpz2OUCVdYqw4MoVof1gkvOV4mC5uMdCdeWKgfnnwz1or5xAg7+zfkq7+8ofAHomBMXN1tMFCaJq1NtDxgfKCesU2BKDWu8Gqgucjbjr1sTTp5uOiLpjSvrjIu1QWsGWkUMEwBO1U3j51zm3k9z/rjEVOFpbeMspHLD/WGheJGNTrHalKV9iY+VBFaHAnJlapHFAwyEJVVx6HIOxXZO695WLsK8+Z4/7jBodwBM3ObFIFe33gkMEIC8s/rNXIk8D8UD9sksACPdxENPsMAbREl5mEpdW3GjtgVdsm6TNSr7tl9YkCAFh5xApsLzsxVwAUNId76+cGQ9JBCodWTZikVlZp50P4c4NcNs1kEg+DVPww2Mzb9WT1haLkOdypHRriHrnG3pNxq+HAHBAYTptJ7wJFb2VVGB0HvOUfQpR53cFlQAF46485c2Az+fm2ckoJ7M0I6Y3fjeX5RFTkFBGdfePN3sQDv/XIC8WoL43m0b1gWJ3zy4h4kOlKibXbquspb6K6uA4rAs9orH7zgNHRfLL9gPeRlSODyJpMd5Mij6l0/X95AFjm6wKKkHkkHsL953/+EEg/vBJknzQ/np9jkQXUso5XUjDlyUqBddpDX25yo2vjIHW1yaDUecNa0vjCFtLxMea+VEKv6wuO9JYqDRFt33iNmwgGgeQDrmZexJNP/gVC4WyYJrzg7dY6R0/jNrBXeBFjgeX4O8smmoW+wML+RlxMLIFa8z5qPpwzwJcWgfYDeBd6waxxlf2l1AYYFoZui8zzXjeJD+IH2Upgoa3HWtxs1erxhkgZgYd6D57U7wFs1RQB0GvC5OwZKLy88CB+J/2dOcinDaMvyn+MCPG8dBFexieuNDU/nD7uRQKPymBboRJC/Wa1Qtmr+MjSFGSdGJswFQOsCFJpUfL1OtY21EOLDcdhh4SKgxHj1imMjg8fBowkDYNR0NEDa5S8y1e+nZ7MJrvfwShPAadXFXC9AFCgOD/GMXRHROcguAIP9YlJPhceREaHxhoRR5nOd4XinWIiB6L4zVQLV6zgQeL4YQiIC1ZA7cfaAmIkdfT4bxhA0sDcKC/qYKGuEnxD/OFRpptH5v4xaZFMSugDCYiTJKSTDrYS0YuOEheP4FzRafGrzXhaQWynkyflggbUX+2jn5/WDloNgns5cBlh7b385qN29LPi5NIAQZvHZ2JVE3pZOPzimZKSqvRH9YBkOLZP3xjnnViAPPI7szSc8gHj3DTqcXDBp1AL+Rj3msgXz/YMNu1sy28xvnf3nCeR5zl8Hhjjlv6i488C/VxOB8SXUvsResFlH3w++9V7wQ3z7E8PZ/GJ+Jxp23eiPCe8WagRqGxOx4Tspgh++R4AKvwTIRT1qXpnCbH4yRs44zk3HswhtcGg96MMCmkZqr+xfvDIvIKvFHlNzAoVgT0AAmceLkDPDMi+8FonWPLYOBYG8ggT7wpAa+A8vv1isufav169YOmhC78ZQ49+lDSe3L2ClxPMhPlwpuxUQtRI/ATD786j7lqe1xhMnKh2mMcDBOJPuG+u3BDAARGM5wNDTfvL5tpF8wsgyCEgcbHIT3Tc1+A1qYMw2oan5uEWm7CSxR8pfOX6UIrneKKAWuVD9YA5a63AwHW72KX5ceVZqjr8YbRI4mpp7gl6fnDUW0Qi9nGLJFp/yjFbG8JRjpwnFxwDoQCz6MKJpSJLsIWE9ZLJGqd88QxSJryr0BI8Se8XIWQgqVoGtcb95zl05dTABIrr2ZXFUfG8dr+I49YggNX1gwGg5O/XzlRsHjv6wa8B2Jqec82FesARVEnBIj63vLMDH0juwV2lesbuNpFzxW4wcGdhfrABmxdF9afWO1dJz/q4pttuoHXZe8am4IaPMM1UiapFwo0Bec9cYbEshotOV3HrrrBTWdUwY3pl5NoNYZVINOHtLifecN2H5x40uK/04FVlIh3xuYcjhUJ56wem5PlEsmIadsuXAtVkDQp0FAN4P/UuDSg5ECXcbu3Joc4eRBYAEQoLqb4ZF6UcQsBrwFDrjHMEnH/NNn2GWi4EH9iEF6EbwHymckqNCbZihzBQskDRE0cD1gX+/gbkuzhPZ7wSGcBP1mihddTKpC/OCCrGa9YF0Aq6ggfxgthqSGW+BEUEN3Aj6nhbOwJ5DrdyEo06TvHrJo5eJktM4y08/GPjjLtvukhQcr0GLTxsweQ/ZHvNCgqXxDEfJc19cGH0DJP/AOHHexORUxDxTqOsqZ5QH9ABNJ0jrZiIoX8N2OPgldm3+sulCFzOeWZGZSEoH5yPyZdYmVdLitlwOCfnCbQ6NIv5xZjp0V8c4Eg4rR+MD2mHK0f4OSwVJrgc1+D6zeLJudjxvOtfOr+8MhBug6BXzh4CK73HkuH9pJrAEqByxSqLVV+eMjaa6X5yxgCwDjTns9amIgXeldTJW8DuZ5IezaV8YiQ5xXdwU1iwB55TRikB0N9sG4HRUlzcthq77zVtN0YEuHeBY+QI3O8liY1dvSf3gfLRWDeNrgTkkEp+Vpc39rdBFyEu3VBcbpaaCHzo4XaLk3vqZ35eWK+NHCtdyBIQWI/y5OwHSt784EaEuv3Af3iC6EC4fJN5dI7wn+jAxi8Dnpo5x80l36Fgpo5895qiFlSfZltEdbJ7mO3OYRDojPU+MgWAbKENJCna4P8A9KS4zINPoDteAOcRJQClFioQQut1bgVIDgHABoMW5YcYasNQxoxI35wel4sx3DR7oDnKLzjUe4+MOQc5ROW35wRKFFdHN3xH04u6iVSlGjsGS4WrwQh29hrFW1DgAzV1x1lKBcR0kfH++MVKGIlb44cQhRr2dBs+2HlzaodfBnI+WcU8rJH0xB6IwoBl/wD3xyP8WvjHldbZPbNckzmt0sO5+HgpI/TpPh1ZMFfLC+Ko3NyZq635cS0mrS+wOW2/WlPTw533rFHEkMED4msYab4C/jHcAGum47j96rGPFeEtv8aMmyQvcxSvLy84GEYc7d85DBajLwOjv84UtWKRF1o6j4nrHFr4tgxMOZBVI0kE9sXwTmS/tZOcNCfv3cS+lYNUknmu+5jRyCdO5lCGkTAoX3Tf4zkQV4R5yfB+MVBTXOusDfYE6OKiAh2mCA+wmGesKAMaUvwbx30NgyjSharefGSZoMpeYxfjEg3W6B1y+ebhvKuy85PUrd6XwJnABkfwg40hiFJ/DDtzDpwbXTa6+g4g5hVZv5BMChC1s+f+XLDfabA+7gg1jvKgtfTd8YCKJmyh8TCjDnYPmByKfWRNN2lZ4eDWcjEa4G8ymDQWkgfoF+LhAWEoejnTsr0nvLh/+R66IL1O4vGI8Jv3SeMcXQOucQtVXz5zZx5RBmri7oJnkUbeec3jqiXkqP6yBQ6it2EvxH94qhVTENg+xP4GFmbq61+s3ro0Kah483ePRI9CQiKtGGtl5xLQo/glfR29ZNalUbo1yLeAMl0n1XemJ9/hi2qbT4kJT5WXNvY9+lGAoVArhwrSffrGPowbnzSDaNe8X01cjxufZR84c/8A8Sf6Ronv7a4u8LBe2NdRQRkomhO8MT9ag+EsCea2OP0vGof259xL95MIhAOfmJ+bhJ0yHJVdaT5mAonoB915G5uumiS+rc5QaqK/vEiE8j/vEXkEoRJy7mQ33X71DDi5ysyoBo7wO3MAWE0Pk3jeu608fzjTXaEq2KdnmzFkqqJCdby7bsyt8Dv8YqeJk5EG1PLe7OMHDB8O8meu6NuDSF6jiJDWjC3FrTntxFEWeB24asA2KmNRdIJNMBmG+nCwwnbdeQfZmjshQzkxDKXLeWXXX0fcyqeAiFfDD+sCQTsU+wr9YOUbZfp/ngh0Ze35z5xYsfufxia4qOZ+jL4wUEfxeBxRC1+Co+cRoFo2fzg96KC08u+blqaiGn9ZBHWqh/mZWlWgqnuYzaqBfJr1POM3eQfPadr+s5eirQ38uaohuzrjgB+M6TyykCFOHZdrxgl//DgU3y+Do9vAdrrAiJoipE22yj0KGsJgAABwHg9Y05smX/woHgNXquRxoTjcBVjw8k7uIRgwdA6icPE3zlv36Qlvd5a93ISPDpmNkASQSpXU/wBBc3dQ25KW4k0l6OcMRO0kAglFeDSrNI4+u4jzvgaNACcY7F/eDrBXPziphWxNw9j0tJ4XE0W3qANPIbH5ymXFyMravoDLm2eQP3MbvHFKfBDJHgE0frb+coBQ3pQ5PnDdcZZksJeDsSWYIKRqQe9H4wfdBNX3XZ841jHAA/MNfWaQ1oJ/DG0CtIyivDV46zSQd7qezkyIj9wSvmXEgpam33rJcd6QzGde21MV6JU+zCkE1Aj9i3GKTkD6O8KmieYXfU2Yb+1LYQAYBR++bjgcEje/Z37wEloooEOdFLjrYFGVPBWQzqCV8cm8aMLRpJvBtQFohtcQbQ1pePjDo0Y66MkVBk2XHUhtxZi0zTGwgG9+s9F2ItONpKDqo4tkhOJZioSxgA3br0b2YsyK1ZBoAgkq0mXBmgh6IH7XJdFKTnw+XzhaU4IfICjE9/8AXGMZVpsY+2/1jFGHRvHBhSN0PL8GI9FCZSAvaEaPL4lOMONiQ3j9f9MSQ0C8MfxkGoLABJ54wQjPBvNsQXvfV/xm+720CRUu/wA+cDqzaXHuJ+IwRlaD8Qp+7h4Cx/LA39Yp+IVTidzTyl5mKiTdbCfhMp1x3D+cGKL4l+nNLPiX+ee2pE4YBTmgQF45ztDDTShAREPwdP6/8qnLkyYGMrQl7g/QwRCgOPZ2SdRwKD56wH7E+8f5aa7DpFCwHdMSdJNbQonUmND24+ewhpONOQhQdAgg8qge3OcSAqcUagA9B7yxv1iabXgDb9ecGBgKEOwPVzmDKHLeef8AzW1YTeMGR07KXij+DgkQTpv4MZTHyfkccRfoUX0QxKeGr8RiYHyzCyBT3vCEQNroYRtiI7Pbxiinq2eZmwsvOrgp6egAoUIbIB185aoN/wC1fOWfCJv94bSRE2fwmNufgP1/bE54ClDd6ZpxLY8Xme/h8YUgm2c3wxPAtpy/msSQLNGH0P3jVoKDoATe6vwYpEjBN388YhZaOH9N5cu0F5PpNY1I5+3Fp2dHnh4xVEKorX9nN47RQMEPG3JIFtI0v2mB6OSwEqCt2/gwFIiUiWzbBMLChlCwiTzvGhSb4kuJ1LNe3PE585NfBdmDal5a6wAI57xa0mgnTgValQRUzuagSFzsGb7HBoSiO29sfb9YPKqQPiavfKbySN7TPyn9Y4cWKPonOET0sQvYD+8NtBAofyYxn4eBP1iB85tZ+sTHsm3yNaY7dO8GnoiUJ8x6xfCCEC/vFCLEFefOHQJoWf5zuvQjcx4Q2umK46rWC6t4jfZB3xJlwBWkF4iOLwLdEH2Bb6widBfDx2HsxktwVPh1nbgPzjzqTifiYi7/AOMWpKupOMHBRbBPdwY/4boFTy1X5yPcmkU224p5wLlyyRPWa4pfGJiBRAqvWJ50EpX4wWqRYCfdx4/DoTWLoIDtcuwSqklPkR5O2YZNwgs8N9k1yWMmeQ/GOr63kY0Wq7vCIT8qxlYmuDx+5iNAoy4AnWhe2ujFBQVeS7+CvyA5Y33FyFLVRVVVXFJyoYwPUZ34CcZzZveeMkSDHFQbRffBhxs0dZup6sPvIQaBCpwL4e1nrCc/fyXZeYc2AN94TnsdP2cZwTtUZdKps+DEcWLsp6f6DBZkdpCp86/WDuxMJkxwRojKNHnRUNxTeIkOC+0smoCkdmNUmp/eeaMStPIvwTIlBei/v/nPSTDfkowpptzQHZAl4wZTIXv0uT6BXdbCZAQRjhgLpLI4DzEmUDrWDADjaoIG0HWL1tAsQ8f1lVVNIofWKElmuQdk6PZrnCVnQt+bMr8LQ+Fl+Hj+3EbT2UBPbP5worZD0EcQUFZ84ge+dLZbmgGsEP8AaY6sEEZ58Y11XiHGbPE+MiG/wZt71C09RzFQgRF09ONi3Ulx8GGCK2E+KaybpQhiGmxsxsRs+UoCuidPOCBXCQ+EU8Fl7gp8tD+cTLlKV8Rf1iucWRUOtrj1nGNy/If3hP1G13+OCDzRyf7YuO60q/0ZsOI4by65YwpKIqofPBr3nN1IABefrHXGwoj9BiReSk69TzkxMr3D4NcYH0s8xK/2+M2vmJd8gX1b7xgeL/locaxwKWfGz6XEuBWitRqjxOnnLzsdwGcUV1hcdBd6AfWREvKUeHjPrAkxYzbwITHQYqlv2bYw1UGoeQ1i5klkAeYYt84M5cRcaQ5wfOaUfuC8/wBpgBs0x34OCL0qVcob+p94kJ2q15LF/OG6qKx00UI6Wp4yls218pTZdq2uaDGnjIw6hOYYnkiuj0g3TWoKzCuQeBP7ZRythF0HYo2iuH6I0iAPIUH3zc4GcMMqV2FjhrfBhB3vZA3rkwPpQKaBTbQsOB1imBFJshokeGGscyhNJIUdirt25tJR2E/AYOo0lTlrSqecDCJrUdBDz457wHhAqJbpVPpOMTJ4o1cNXQBo3mpnttrr9sJYgtXQ6jH6x01GpV7i+cHXTHZ/Cn1lrJirozgdPHzjgl0cEJ0ZB4g1K/hm5PIY1ahyPH3gqGTItOi029nONqJFv/shgevMGh+kTGM5djp6Q5fCc8F7UWPtI0chUXlJx75MAPWBp+X7LmzMNgDXreGKaScj1lwYYDv+OsAj7km269YjHCVL8Ok+8kxCjdVnkuTlwxCfrL2rjrbDgelTxjZGu2yP4yGc5hJRVQ4Y6kFAUe6Lv4xRltP9B+gcV1PNUjdXvZ2t6xGBelm89+sd34mqPq4pC6ArPvlwSt1EqTnWEARDt/6zTALweXNm2Gg8/wDzJ+iIpsuaQOhcm9EcULOMCPOXIBQXQ2Jqc5VG7i5+an6wxKgG99AP3iVmhevvdg/WV8LDfPgRykSDYIs4SYy9ACPrpimB3ImP4ZZDmz+SXEjidDvQ7dn4whlXnXXnDBwSUbkxpR0khHzvrBIqGifixs5wvDfQua00MUhOyH4wqHXUgtaPXGIN5AiH5/gYJNCims8AB6MHDtW6ZTsg0vnvJNbQadPjNiKiaZc0l7Zh1wbW6yiPkoPOyD5BxJIqAI+MYYLqoPfWEgDZUX+DNTi6poPjp+riFBo0L6nfDlcPyLunWm8kN1BoMRPhXfgCRq1Em2hm8gKUIaXRph0YuhX7McnfAND53ypNM0fElb1BvlWDBoZMVGS8oa4cPDUSqesFGz7bPGBwRtqLxisbelyt6Mc09sc/Iw3P5Rs78ZoY9p4win8UqLxY95rHujQe38MaloUQ934mcmEWNj9mESAXgUVIeOa9GMU76qNC6RI4pCvkJ4yICCuy/wA4U1GSuWCB3FJoPrGRhqsB4h7w7SSMa5IeU26ZvFs8gh39nOJbRosp8K4nUQ8QwCrd8Cfhc5B2gm1VWUjrnNmyI6Beu2KqUbSP8484o7pP5wIG6aYDxHWFKM2zR504NBalhvFp5/OdKKKE+8UlsSj/AKcNwIGgnAY5O+sQFCqfxHNdRkhRrsPWOpAVH8zV/BhXuGhmc0EL7mSlVFkIU9UzvCqC3mPV+TCQdRF4PfxiAjivS4PYEbhyd4IUC71nWtXk6Y8lGc6zul9dYrqLyhlcALTiy6yiDGir48UDoNfGVlnpaF2KJnHQ/k1tD7zXGdGn5C4tEGEI+dKj7xKk0ZY7V6OPUmKv/SfvJWw1nF83pjAVHID+FggADThYpRoN84hXjRYfk3gqJJXiZSVRAAn88ZtBCJqr+/OCn2z/AMBhx2oP1kINeUkNQu59YFYAE/qhig0IE16XfyXAOiLFkCcZOG95oJBXE5zewDwcfGcUC1f5xkb4H0LshzxCjR2A2HvBmBcIDrRUuzymDECmuj+Ya/OTUGzBr5xEtRGq+TN/S+t0aVqJIo4xoHa60fQYdRCl9DZvyHONxbCuL1oZDmAgqAaJP3m86BALVFh1/rCEEOGeu2EE2NRX68fL5yVCgGU7pRpw4zZewilVnD8+HEMMFU4kKWJ+F1g7YEQmy27NMW1mXaJJm3hF9rhybGiX+nwQxAPg9hr+H94LpEreeLgSRYMQkSIXnSO24OdqTqxCDp3E+uMMsQBuV2mxePjB7gBqK7FHReNYDjjbkHQbVeoQ85Cq/wAC/wAYT5o6M3bPDMIqfeyWN8QGvWaCJtq+HIbJrpxiESO4O8VAiXU4MRjUKU8DwmnKJfWAHM9iJw7csUlINZDtMPyYMRioApPo4I8EJvw6/wAZALzg6+6p+8dxzQNgJRf6xgWHyfrGImaew+zIqGOkte8RGs3VcWNkVT/ODcOEYPIeSDHBYcCmgmZha4B97cN0v1gsAaKH3h4ycKk/zkzUWseKSQn3hMD5cPmh3iK1sS6fVTJn29Ds2goBXAUqZy95R1H7RE/mYuwgfyY0SKa10fFwI2D2Rx29rx1i1BE3/WBZ3tJ6uTyV1rjFUAPo6x8G+ACpg2vMTjOPZ1m+Nh94ADL3Pslk7rAHn6HDFq0Dv1TFw7WW4eOcqiSfK+zIr3m0/WsOWTTA/YZGONgSaNk5TCPcp76ujjWCSAhl/SuSQBrqDXtwcsYLy04rjdMk/F0n944SKDyD8OBJUqiCsa+X24Ohn84ebG+OSXE7KU+nDL98NSECt6J271irauIn94e0XyO5m9JTBxPI+RX2tT5cVMypEDxV/ODZxD/RxuKmcur+DEgchgJ6Ub9YbAOWb1ZgqcVsVkgCt3sYZMLWVl2gihV3j0hbEXz3wZ4FpegLtNDlMA8g8poV8Y4/aEH2Db8XjENBCDZC93nHI4OdbfzhisnTBnWgHD/AbciDUDcxnoM05um5vu3jDJgiTXxrjnm5E2NKlenQAOJgXck0V5TgyAcqwmEAmotiFXXKEwtJgERvapyw/LhwhTgM9YnRuhjfs3io1eZRmkBk+cI1JKiDYgswY8MBtiboHjAYig6XNeOD94gHlp3qV4qXOaBWHtlHIpyvjNABt26ykBTz5cQlRcUo3p3ud5w2RqU5jB8S/OWxhQs9VP3hQHqfgGjhaCnmT+cE4MMUGXecGbIIddY61VBKjNbd0D84rjg2gBfGKBTgIFwusRivvf8A3WGZY5stzq5WsD84DS592OgrthZ3MNgQGt/g8e8a1R4CmjjrfeESGopPwrZMXdMwxb4jGOcfkDaKivM1NuNLUVj27n4y+IXjd3WBWmSG9YqV1ahMRW0+cI5C8uBhGHCYeDyjtf4x8KlVhpwVR2JB6wm5ItYICHVPnEAipMnp0/jEzRAlXiLf1jgobCp+stdihU/My44ef4DBVDDj+DIzvAm8BfaPZT5ztnXdCiVfkw0Xj/OnbDQSwQ1R54OMWbcwQ0+nJRQWAIX1vWCURI2X0rIMsHGCjZu5oKdDF+P64B99Hu90n4wJoSoQTnbF+MVKdQYW0DsgBl4SVKhO8rnSDJtH0qcOMFL6b+L9k394IowVFWIZd1PI55w7BdBaeVs0HRjyHyR3GiNegIldpZ8ZozzEIQjnkD94zRI65G1C89cYsLePlTcn6+sZxqE0ccltvHJh5cEE36EBJ3e8WBknYVAHVe3ChBstWUtjsp04+ejANx9cH3gmaFPIA/pciomvMn99GaE/G3TtAB/ONIi7foF0ffjIyn2Bg8DV47mBGqmgqOkvHeGwUkcRIOi+81tFWVK9uBw5uNalQ+P+4x5A6klPc2RNmWuYo8Mmth33glSAY0qVAPEyLvJCLxSj5DnEP/hTLgukh53j2QkSgR/CYl5oR+D6U+8c4bKFQA7SFPFZCTG/h8mdjo1zzhRoPVd5vQY8l3homvCaQNtNPxgwArKfGgo16wJs8EdfhfmZsWeiF9aCfzjkarsfujksmLUEQWvnjWR/44J1hUA/+1mIt+UfjNcYBJWEV+eGBgzUCF+Ypk9XmYC1yA6d7N4zdASR84cCmzS9R4fnBcIzXLC3g8vWFW2eQHwNwbjRXEcJWtdmd2Cgj9T9YgQ6cI+uB/GVMKELAPlu/DPDZxr2ZFGpy7G4ZAiM4aYyNKcozK7n7xjoIVX/ADjAxal24QlR8nOM6QPZvNjeS14PeL0pLTuYRssR4w01tbnzI/nA4qvK9jb+cS+gB48fyBcA0q02vdU/nJHpsWR1s2xYnOrcNgLC6T9/7ZZU4AX8ZRbNpDU0NhDxhwDto7/OF0xXR+2a9be3T6xiiVVvzlS7xNn9uKIbvL/HODWwMVTzuNOzDS3d0rmcH5xeLW1PDQZ84TyWhAdbFcj1rFkhCYjwPlz4Xxj3pEajog8iTWjhW2cQPB4zfosRvgH3AD3h9STedyHoR9DAw/fsV0kEk94wycAHX0+v71hFRBUoeAGpeWcYMRjRBou2wmvOUZE2efkwIeWjV8k581zf98XiBA81T1iDaTTCAIiS6OV5wk2sVQ+h+8tG0IaRsBQbOnKW0DHQA/S/OUJWr6Yl13Lb8PaWLx5D80o1EMVHIQGPw4YV6oLvsOdYiYNlCVns1z5yERdgAeJu77wquRBeGwWNiJJOLVYIaNTN4NhHipX+eOOsnKqv5qmTqRwCK9vHozUKNpwfSGORqp1Hd6vw4o6jFSAD8Qxx3wp7Ti5UoyhnMkfN4kmsQhSN0LvvEFPin63lzoIyv1nFwenCdndfpR+SXz31gN4AEn2k/liMwjZewYjgw6wWh9o19uBg+2S+RgfnJ40Ok2JNp3+sbGr21z8mAIDwJD4wKvWgcB4ubXlTTlPOsUVHJT/DeOihBlTkdD3l2d+jDJuKlG58a4AGuBQoaDguumEWA7HNWB4IINKbf+cvYFTbPCHH6cdyUn01hZ95xmpiChNaeDwSYCgBx7nlxKhoYJxlyQSvdifTiXaFcvgZ1xikaeoMdgl3W8YqVaJ7LgABVCMx3oVJ4c7uHlJHccVwp5pcDlTo9E5C93EiVEUfkOsj6BQZccThI6Iak5ab+8apCHZPUcIgSciPzhGsSpL/AM8YpTkJqfrD6tOIoXZ6wFaGtcWHpvlk/Fyl5JA0+FuJVLoBD3vWDigz/mXKXKTAIHrv1iWpq9J2o8XkwuTFCKnv+rFdA7Lk5Dg+sYTtp0BQPtZ5dZcXoaqGnzLD25Zstjt0ehr5vnCpAuMfV0nTC+kLPXG/bgENYvyxDhm9H8u94/Uukj7W38Y7DlU4iAml26h5wcdejKexGyPOKuLFgOAt6d5pfAM2DNvdzk2eXcg2aY+sPLwE0qlDd9SYLXhZGdA7cptjk0RJ7afGFBeRQVL5d3wYyQtzwIwJBYHPo8GORKqoM4L3kOKAEUKv2ODLGp1Ai0nYu+s3SurYVIJvbjrOMqNx7o0fn4wXJe6ICQcNnjGBuAGcwbzPnFgYSwtXv5YdJJ39/eS2Zxc9rmEaFwEu4Bs+eeWBYiPn0AxE1zgXqLdXzjm9hLbkfg/lkcI2DTfx3s+cO71jEPWAhl3OHIPkxVLv7f6xBxLV80U7jxj/AEoGufBX3vBFfrvAtI5eHk1f2YI3EVv5Nx+REdgNrj9ZF1kga43jRm64c4NAITNHM8C1xPURygeze8ZI4asHjQhxg95fjyqcp1Zf7YdrefmgTo05crR+DH27+MNirjI2CrzvxnJ5dq++YCv1l5u8kehf+GaC0DWy/a4ZGKPrWaKARsDIcZCWOC8t8eMgES1/nPYveCqTzteXBwIpU3/OU0T2a9YgGRw5ybVbIB5yyPHjxgiGx1T84g1B6GX3k42JrX7TDQDddB2S7yWbAgxo2HG7vPHxaADaT61h0IzUp8ccZcbk+ocPHWOKMROqOQJRKg/lkaAk4a4InhAmnzhtIxu/43ABBNkB/GTIfWofo6y0rQ01T3lYRCG2/jWM1VgbDC9j5JmtwEGjl+Br8ZpSa4GKVYlAFV+jAgryvQPot8rmx50lWk5HGO1g1XL2/wDOsBieht8Vf1haaHFIIA6/vBpiyFiNSyyzrIiQtiHt64wYXElsGnLcwCiFtsHkFG9N1goT0Uz0tmB8VCBemd/P3hAsFoFYLs5AcCSX3bAP1hKbr449/wBfeL6bkEv2Q37Yr40EafnhtUR9cdwnGsCVzQSpEeO5ik8oBewgIp7TBcCqmpCvFfV/rF5D/A5qrvR+MGHiNQ4zR+FxoKMeQA97fnGlAEWxvnKFvkX9ZCJHgOr/ANvBR9UL+ctINhIAr72L6xGisqaP7Yh1e0YlOnrrANkSJsAB4A/JkiSp0GplNFV3Xi+nnCbKr9JnJKa8zk84mjU0+HFINdr5cEPRGH3vAOrBqD1MAJZuosnB4YMTt4g9DdYoJIJL/JjCaE0HHUDjFKLuiP6yxypANfPGFFeqD+gwsViVY92M0LCVBPH+XrCWhWJ2BXUvvLgsSjEX7h6yILBWhTKSI40B/OF1o5ovrBjfveYRjS8B7wvqgjW4/wB5p4gAsA+MaGw9+TFlZ3i3SejhDKN8neE7CLzkSpeBNmDYrdQmbOwNpkqudanOVN4vJ1MTflw5wtq7VGVwTALxV4w3cHlbmgwk684kCJnjnCUHO9nWASNegxhdJxlFD0MqXVOa18ZaDVsecoWtyzyxCQV11qYBRS5j/wBrAe+cRAa8A1w6o27TuPN0DxhrV3N0X6HB6Mizy24gz6NTXoBfIsPPNDQLgdWJhueZ0ZXT18ZGxhVNSqcEL57xbHAQlSizeh3/AGPsSZUFVDmv58H1xRAQ+U1j0GCqHmF4MIXsw2X4B+Mt9XA0wBAV/TFhK98U9buCkqAUbTc+HBXBPeraPjYzrJ0oqnhUPxM0KgcSDx8LnI3N6Cib4cMp0Nog+i4ruCNUc14kk5y20UIPJrzMdRXF2vefLfeANaj3Lpfr5ygNwmEcKkanzh3ADhCwcaa3494NG/6jmccsJrgM2HyQj33o7waZHgU+tYAKiM2iTxluhH0085M7A7h01PP8YDoFKsMY9fw5qI3rDdIDJBv2E+8Iu5GgX+B/gyfnnHlHh+cSQCJ8Nn5uIGjbr3hJFoFnebEQVuHGEUJHOFWDdXCao/TrJLVwijkNF4whJ0a8GJFJBIefWbCvhXcyBGN7eM2pCOkd4gQJDcMogEauRkdFTc9YAbFavjEK34OspFtmtax4Gn0xXZrpd4OqFN1ZcW+VW4I2VppzxsdYuyMGa7chVZBa0wLRR8H3igBi63xnMI67HWSFFZswNdgrvOUBJN7mWRDcNYFJOOXpzbSh5FmBJoHSTnKoa7XjA0HwGU12b3gG0gcg4gV0py2esqAScy+MKIgKu7caHbeuZgiAmt1txG7ga1hrgJLwub6yKQ0ISpF7Wh8Ob+7jeC26ONXy3rFbQK6jhdq/jDSO5IYcnCrx0GHBY/MIbC6bMAlEN50xQfWQUqBwvPZ/eGUBpb4AVtZX0axdeYIujSEEDRoM8lZF4/Ms/jE3J7gPdjxSIt5oBVU8OpiOTWIZNMdBiogUQJ3Zz+Jhr8wzBHmPR6zbfdAKodVePWWgMAGmp3raX+D8GD8yoeOP0p95OECNp5XazAAO6o3d6v8AOKIKaLV46uT0IqB1gUIg08YNAk0VD1MyEt0gp/fBhRuGTpAqBfWQ7coeHSiW+Y4xnNeJL8usDBKIsDswYsA3Tw/thu9OfnN8maiUoQvp/wBM2BNWTlFShzDUweRDrHBGP5Iifkn24SqOV7Q8RL9YMhYjwyS4uRhHkOn6ofnOGhJrrIIHzecUUNXjznQnouAci84NobJzjh0veIQVVuhWsB6w48pgqBp7HvNi+A9M41GOcOx0baYgm06+cacR2q9Y7Ah7uv4wBFXSNX/OFEq2HRhudhReDrNoK6/+Y1NRvbLW7DTXePIjKd4piBy4vQfWLH5jtH0bwp20NE88i684gWiKwZ6wOo2EgfzwS7rKR9FFhwGCkROjj1k2qdrR3rBaR8TEKcJrnG49NebgtRIaHWLKKaHv4zQRRdh1m5BLSTrHorzo/wA4i5AXG8k1I831jX8A4mIjvkHznxF0PGPglTldOQABXC43csZstv8AIa+MPSpKwAPLufNfNy1EgVXkFdtXvB0peDWFpwvrEvT7zbYMDprAHrzhqVDEK7H6yb4Jl8HPWId9njNBoE+MY5KGb+zjN+BPblmtJecBu3PGCR4vjHNEnePVj5xikCe8HtHWbaCOucJKH3ceVZzTHXK+cDG0vkyEYj31hWg+sQ5V8sCeUT3goIv3vBG+MsUFa/ziAKAhKOh5fsYkW42qw/tjIORzrXv7jkC7+D+cEvse8W0QPOss6oCclckgiSzLy09DtxBs+Re8JJDZ+sRCqDjxhxOtm9/WCg23d7mIDwfz/jHVhQQ3/DEfk0DQ8pz+sEOwF6Xyqn4yVScnQ6O0/WA4RVi6gVN3WsSi4H5lYJHosKTOAcu1Lsas2mQ5KFAeX3kIifespXIm484GAdIsAKIq21cCCCdbx0H0ICA4Yy7Krwh1/l1jJAT13zdOUfTFJJ0jLjK8bAb+s5cggS/ocGS+iX6OU0V/wDJybzD+XGKaNIE+URh7c18zHmb1MHAxvpQZ8uE1UEqyht3dpx8IqiM9jsfTndQa5eLiBTW2DGHDD7HFkITfHJldBm4sxRHA6JkIQvOFoQVyArvyye7mqAkHS/HZfiYMpCntjv8AKdyd4BG3G/8Aw9ZziTpD38Za1IdFBPP+2GDzT3z3wxvKB6nPOEoEPLFhezHQU/jCZrdbYGDQWgounFtdeOJ93IzA8ZFkBbRx/IyKizt/w5QhvJb7A1iZAGdf6TAeP2v9pMWta7jzW5b+sSQLuaIe+TkYrwTQ840qIWNfxjjMngj+8qDHkGJ852koVq/jCdt3DXXw4GKzyxJT2OEec6EHiP5xGHpWU/tiChnjufRVxNHW+JPrFpEOkH73/rF5Aumd/OJF6BN+HUEyAP3xHYBtYD7Iwz6vroGkqicOhus2BjdZzVp62X4yNgVNPju+cR8yybBrCUDW2CEok1m8FQABQnGMo823jDQesXUwlKJW+MAGxdmxH4xo86Lg+LMq4M70/kzdaA5S9roP3jM7ioPk/rFAm6TR56L3+snSyKGwyWOQx/BjZVjhMqgZPp8nHsx+tQdRWkqO+xxItUCsUXtreHGCTSNQ9hwnAtPeMEnVH8Y0RH5DPM603WcBcPWQ60x+i1x+seGtwSvxmxdQQN45LvZPxhSA6ED9GAkEIXcw0AkKpSMDSM63iiRBwUdldyKTGi18xDXTPvE6jrL9AEvGkBvCs/3P4xBu0jfpofAxewFZR7gukR9j3oPFCPS+DAOnnin6zgMJxv8AjFUp3PjCAmy8zrKaodqvMzVBgoDlSBB9sHNAbwWbP1c+MldKAQHAHjHKCbu5YmvjFkUuQKNX1cENhAqb/wCLhs/dpfZrkHvAxG4J3285oc2i9fveHUhSofCflm4S/D+LP74sNiW0n6M02361gCugg73gyrRU4JwAFw9zWN3svFj/APMfyRVipCEasRjpxQSF2lejlxZ0sOvwcg2mtBA/b8dYuUoQAV6AwDeS1pvjjrBaZEVegYoLgAvsNDaiYP8APqkI/mfOLaagADbu5UsQIw/hMTVjVB/jI4UC8cY2UgEbtO9YIEU8t4kauCCQwIBTq2YKkQPW3+8TMaCreuYTrrASNjSeWi/gfrBpREQb8gvxkSiGTWopCaJO7ltFLXJ64wnDFmDaJFuv0ImV+S1HTr/vOFKHKjXS/wAHzljX4A784wGv3inoOIUfnI1RP2iEMHKpOqNXa89TAcEHgEmx4oYGwxTknkAfUwQqQFTd0Gs65MCs4I2rRLw3krr3gjFH3QfnE1d4msf4p3PcFNBdByujHKWTFyLgmzjrE5V4UKwUhOG+PeIBhwMXsVemvnEobZUPkOnDaIeLitQTxeRHSZvEKnDy3jzfjGRQHgjzDrv/ABiiaJzV+8tDpecHX+WVwaBT8hfjnJtFaIh8Dr6xiqWpQHgnGMxXAYfLLhlPCr/IYVEcCF+Z/WC+AiIPJBq+tZqksCDyFs9qYvNwkdDhm9dYRYhBYY0upviBjbUKhfBU5+vzjBQb5ExnPjDQiUqLai8a42w6xnYnjIGnQSTeWBUHRvjLyi8R2YaRkannNKUvIBhuCNCfzitIPXbCAFU+J7wlYh1DNh2XXWvObSoDtbfKAPIcYSpqIpdhBsbwymm2HRiA51hPiVTLxoi8d/vKSBoNxJ9uLhbO0v3XrOORKGDwbd+a94Ug/FF5sBXF4SRc93nH4UB19nR/7WFzPEYc7Pt1jbZAHJVTZLT9ZQCiwk+EeMR/Cm3dAD6MJ8mGdJ0qt/WDjdGu/bTXmrwTeLgxqez3rec9KtA3wHbEEuCqhcy/zzbUFA5++mO8qNxT3YswYF4NvwrHjjz8YIDaVhPOw4NYbO1+2WBcSAp6v/HODNqqJQ509/m4eQJNSrqLvzfrPBOZHovHW7x6wOvBVoupDKf4sgx5arrn4wcutQE9it+sqX2mr4J1P/uFUM2bD3UT84fBgtr14L6swmgsp8AOT4whOTaR3Abd1ri3ZgEpORqJzWfxk1hG+ChcL8DAYRGvJhp1vBuoQrc/6YNsX9KJs8jbLuE2OA1opDXd2XxMgV4Hr8ImTpN/lB/sywX4HSmxJv8AORMRyG7UEJpNazwrnc10aNkPDV4Y5EKC7Inz6R85w0HU1Pfk98OVlsNNZYM+WbcASwcgqenXjKSJzVB7MlZg6nBYqjRqOx6xZ1UkR5ivQj5md2kAnEFN15bM4yWoSuPBqEL3zMiqYk3Qw0w7ngzlhDNTcVgPJXj4uMcZYrfK78ExeXbIIpTtBTfPDhyzC1Aiuk6Vaux2gyWBWf5wY8m8hgk5/EqfxiwtaK+rxywEbrT85AHhVIfFwwVSNTZv63h0Vz8188+8LjCOUaWuxLpHnrrHLnLsiLdsRC4MuCtDYbYGapYOE69q3g6meAlH0f8AaM7sJfOnEcMoqJtQX9zu/OD2EI3h0N5y2CZtVV27wIF1x8/GDEGEgMOHYGwD94Sg/K7zoodNeMDWIRQP9iCfHzhWqAADaPPjEIum4E/jKGpTZ0cYhCQfGs4R75mdEVlvJknS4NdYhQ1Dt3iCLYbyArSnFxmhJ49+fj/GOo/AEX8c4npCzn4w9M0iW4sS7su31hEOxTWPV3jIMXdf7wjBU5L+8DCvUP2lecGJA0H/AHkhdMk0fWNGx8xmBwoldwC6KLFMMIU659YSMVrYH0xubPAUh8ZqI00q67rjmkDZTWMy4C2N/eIAFqWyYyVIWKK0voWfOBhJAgNde/nEFRubEPGWW6a8/T3lRyVsc409Tm2GSuAeFvziyBc5QgMukCw270/ximwvXoCmKIoF5+8ASTmIcFhR0J84f3YYTs2gqPa7mSY8uVhhaEhVTY8YaPmataU94mxF3rkzIUFsxfbs9OnOtVXqAHSZ3p43hUj7H5KGjfKp+cEmQuOsK6XmvOqYC/IHWUFjUAV7cDZdeM69YCOtC5qt9twnZ1u54BnK6w9DyGzZ8rifhi8PCfsYmR5ABOoW0naHFxcxUlvJ/Gb1XGjMjBX0YjgGnTF5G/Xv9PWcAjRZe0cE4wpWD2LjTpD1gkesDT47wQatCfwLIYmx3Bma2HziTUo7Yczbp6JjI+Egc444T+8joiQeDy7PUpjorQYwji29Hu68/jK3UBUL5cq8ZJeZJ9L/AIzkUNhI+un7wf4Og8vnBBoEvOJVKNTxmx2Ubc2Q2R76w2q223EOLWg96xasYbprK6KFRgCPV04+/UVrdouk+MhAHFL75yGiCrrGGW4lK2+At1k4hEb/AMlkc8AobPjCEIoLP1xcE8gf6WRSSA14D3l6MCUT6yO2nWy5oVgFoJ1N4/pQXlf3ihBjVOd/OCg+UCHN2nNoYzZObDRdfziIShCRwGhNCFf5wTDhso1guE8m2vOLQq2uv5x41S8K+LvC3YO2Jcs2vVhrxzrBOjfAH5wIs4Vv6ynLOLq+5gYceAP6y+F1wt/rEAMHSl+sFNNqjXDELh2GjQ/h2Yq2x1un6w06ba74RD+MaFBUlTCxkWiaphjJj4fGFT8OGjhrau/WTEd47O39uTUPi6UHDmxNsgBLR0w2Yvt8Uxev6YcLyXd48vpxDDadOXDpUHlh3eQA1Tp7DxkYhwonn0+M1zQrQXV1UPN4MHkKqTz5A18fDgkqzVRC8nfrHn71lRmgLivnO433MgfoUSfAD6xxD3Ye/BXAtCrCT1/bId9374l/hhAUgGAfPz6wIjNWJw9gdz9ZelwJPfHn0axF5FVAyNeg/N8zDgOqBopr1tS/WRsS8gogppxAIMUEXL0ZzY1lxKaoHob68Zdw5AJ55L3p8Yb4ApG65K/beSsgCEebpc/h1msOUpeA5+NGTjsD0fNr4w2CMBeRA4Wnc3gNz86Rb/WCBxV1JytFEJozQThKhZt/1htq7VvXr57xQzSRpzes2CxrRxmkVGcVkOGZpINXc8ZRNh03rJNUn8YqFSaMJZ3xTeMmW7keXNz7UMT1oxEBYVr/AAYDdBNXa4AoQFLWBa36LjYQ1hY4RngozpnWsSqHUkxpVN2Dx68FN06OMdcrdFtk7cktWmLR0NlBxAACUE294MMp4GsJDpNvOBqnkro+MGG0oM18YtVG+F+sBL/CpcDagoL/ALwGRJG8X1jFCERY1xm+DrYUzw4xssIgMnGsmVJwBQ/GKIsglc8cGbab0Jd15nGEhHdBE89YOJgKcHYa1jEHRdpi4b5G+/GBCObps914+MdjS6RfiuAKFQeDAqrwW3CtFAgH8FwEQTl4fmYrY8onXwbzSwN1W/CuBXxpKL6EJ83OXKT1ORJs3k7UAieMHb8MBqBrYnSP8Jl2P4SDtvR+TCBrEPGCjCwV5fWcwvHaeeMFDNDn6R/vE42v6u0dm9e9eMMgSJjCLfV48ca4w4glAXg6wGEFbBpMD0Iv2vLzOTq9FHN8PCHD2POOpHYBPQdP4PeFc8m9JXfwc5CYTlptE1WuR1pIthdpJ9XGxY1l86HP3my5gID4iPjZiszGkOlJp+Ke8X39t35KQ3aXiTGoHFt5MUbsda3xUz7wjqBufgRxPesZFvZ/WJ30LFfPtz2hm5kgAB1tOGeMM0IVrLtPGLbCGwrzzr0YJKUEl9d9+cvu93qSMQC3Y3GAC7zlBT9jfxlDzlCJ1+8l4wWTy0bX41hn8mzDxe/vNi7NbuNdGx3i9grV/jOAuhEnOKOlIbuBFD6XnPRtd3KUQIN4OU2ejrKNSeGKBOrVX4dYxWvZF4bHCXWHzv3g8GXh3+7/AAwL3bycOQU7PlOJisB10v6xHTlpF+riCd4n85c1OmT/AK4ifJtHf5wFik4P+64WDtn+wYFCE08P4M2EXe6T+MX5Ursp8zAmJIc6/wB46bWzYmINge8jaM8JfywFGMbC8/GMoc6T/DlciHT/AKxbBzwjFMnTUWJDsPi/nEA5eRMjWYos/vCxwCKb7wMXvvg5VambyJ1F6GVyAtrTBppDlv8AGPnFoIQwcwbsuIF+gFXIAnqL84767cIr94sJAdVuc6BZrAUmxFO+/rADnMnv6cnw5eBvKujW2vExs4PRXKOjscA/qL6FnDrnB9k4rAebRGznC7Pury2J4jhIlSF7Cg2RysApEHW1fhx6zqOUufuPPnjBwJsiPX8z34xUQPF59L3lmvPGMhi6v4/L9echkbBfKPWIAFVdteW4+WpwmP8A7Aw1yH6LnHSrDl6Nj84XlPYfK3gglrCRcknemw/EyP5OVZMEo5wKX4DLEIuhRP1m2mxTzuaoYq2ukNukn/TNrCVK38gQxwrGn1l4MM27blr5n6z70WB5A1PeHg1CBfl5/wCmNOg0E33z384Zc4aHTwe/njNcFBt+dJ+DAHknJnQS/TLSBB5MsmEN3vGER+mKq91WFeB1jEFbvKzf7whkOAJDKo1VHLIm9bBOWDKupGlw1qXe9P1m0Ref8TE6Cd9L8YMV0HgB+MZanQ5fPGAtdI1WHbYcL/xiIAhdkmGpFRQXBNMPtPjAE5XI3Nyi6tenC5UeEZn0LvZjrCl2+sVFLvFYog1eTxkiCxv3kAI6bPXw4DSyvGuTCQsPO/xigmhswIT8PjAThb2bygBV5jWaM6OlwvQ+Y5KQU3zhOw7UPbNjieX/ADWNOGnbfGJmO0Dz8Yo6oxroeh3gq7PNxUPaZO8XcVODhyZTky8z1giyaezHcA6gO3KsgVqGwxDavKOEVqVtcfWWmeosGS4eBgraF+hp74yFcYno27ehz85UWYkGQAjU1cgQwAlwcmnWAgrjdrPLy+8tlW1i/H9JzgzvaqnPNpnKAJenAhpG/OCX/sA7G1I78K3A7sWoPI5RvrHaoKnAe/GBgOygfPx8YVo0Ua+DQyxAb5APbMmPqDepiDtoRa8KWfcw0qagfBP9mDqztQPRw/RhRyFtPUan9feERLKNPZhI6rl/k/1iOGkHc3C61XeMoPYmztyvRjFaUQfR4/lxekDD9H/h84YPfsz6C7mLaM0ynDq1xBsKoHtxv1xkJdFIE6I8nJIpBX+eElA7/wDiyIRXU0ny4LHRGvn1cwaSdTBny3ChztjL+MflNqouQjaUUjvfPvI0cbBJ+cvScBhXpjkgnSkwPzmjQCrut26cEL0BrR7mVs1tWHzpxEC6XTT1cWEHl7nQYjKid+/jNbNhjZXe6Mc4cUdx/WOa+Sc47CP7xDsUGH+QXBoe3TX384DUqmKcYmdNMH0hhQELH/CZRVeAJ4zeFeFV+LjksF3B8/eaQQ6FHXw4BBCJJHibwB1FY/rKSkjQP4xKmUQPGA1cbXg6fTEbtbO38f3kii1x3eMcGTdkdfGKh7ANYEFuCDGQkx07feHmfpRvjrFPaOQgrg2jr5H958QeBn4B45zo39heuzABad3Z+V3gmpbBA/A4uygOiL+P7ZGq5p1vwYCvERMxM8HSN35xbGFVT345xbVLHQ/ziBFub/yYPCSx4925Ny2/2zJbH0SKfjEIq6In6YeIWxfnZiNpZBfDvABNKgP8mMS1WtP6w2Xgjf7cRhUeYl+smZcSlvrL5WwT1/eMC7WgCHS/Y8y4BiY69/F4ezWLUEfpTV9XIqXIPgOte940/SWZeUEycwTX84FQ0yrvHv7geH4GvzieiJDc19A5xyjTjn6PxgWi2GfL8vOS6Z/QYMwCiBy0v6yNMC7Dy+WVQK2eoGtYIWagD3V8syXm+mj9i/7xgpiGAOuMKasWXRhIj0jQuAeRcNDRXzhTEE3DvEghZ3nJBJvUwE23smTawNR58feQbKS18YJJ7D6ylE3vccLQRdTQd5AhBvkOcPN3gaT3guFQi4EivaWzvvOwEbTDikTQLrGg/GWJ6Jt240TgXv8AnAnCsAOUt4gMoA5xoTOQLwaP6wgGvYsMOIB4vOC6aDnSYNbIOmveHBPENGsswucIEXGlw0FT9sRRWiJWnChRIoqv7wG2OnQGbKCbwR7AQp841RWmq81ywwWWc5VDezePTEHUWY6qvt7MGtU7q4wNAoEVMBAUhaL/AHkMvOuW/wA5M2l7GEq14J+8WbY3An51ju3mwBhhy+iN/WKEaHyzDQSbq7wLJRQMMgF7MREBvamIsVRrXOJ2mp1gXkuLFwVU6hvjNhjej4ynUV3z1jHV+W8UAqy7wDrXfo+MTWnyddYPAM0Cav8AnGHRC7c+sWQd5MQ8JQDcKBszNbZ41tUcvmwDqE8ny09eMDonFy8ibXsmJUFs2p02JGrr7xsdg428hdv5cak/m96OzvgxkNwh38CGvzjadOwHsKv3nd6MQeQf3cqgrqHoGICjJwDX7xkFcA5Bm4qVaBpcSbidpsPWAVBbhdPeILANq8TEZW3uauRqAFhumLTqI69YiIh7XrCghBWFuLxFwYA0a2a1vGUq9Ud4AbAhE5M4iAKu5cYI1vcOsBNm8HxhQEOh1jFspwZCgIKaxUdb9vD4w1qHehMUjEJWHGRj1aZy5or2CB/2s2I6I4MqL6ac9RF0XeLGNl0Y1Ikt+TNgUBMBC0duC7I1GGs2pfksJ4xaL4a84xRua3syBOeDnKIFZpHIqdTvr4xpWAhXl85KkMe+vjIacSc83KI0riZLforho9PGsdtaJkBHPveBroMQENPU0OTYtftx2Sd9/wCGJDcNrzjobCR/3jQi75ece3aujl+MbuN8p5zVNn7YqcpqJoxUh9b1coGwdd/nA2sA2BzewnnK7BjQB5POJQXZBwJQIEI4FFip9DFHQVuTWUFG68bxEMBDU3MYvL9Ms7PXtgSOhrAUlTeu/eKRSm15uXgJ1H85IQ4SOstJweVbc3RIKOE/58awfVkafkHgSOnm41NAug4vCi058YujnGcG2LoSbfxjq4DRn5P1m9Pn6Yv8mbwV0j8nl+8BgIoGLxU4x0CCobX+8lrT1gpaTlIYwhva8YPtJ7/dwUwdAzpxOlH1zk7VB1op9ZsRK0eXvHv9EK+pjxsICx5xPIIFeDWAIAM17fOViz+44SNLfMxNcG11xiNkPmcDAQCnTefeJdFapty5KozE27KtLxmkRL4c4BhAs31iDZdxDjEgcn+HeWoQro6MNFb6MhFp0go+8RBAB4O8Y8SzFRo+TjDYUFsrN4mxK2w4zoycGJHB525QrY6cfeIAUCc4MUY93lwEQrm4yy8+DrAFbGKqKhsTKCnBbggXXK9mM5Q7a7xEoG9oPGL23594u9CukLfnKlqDkzSm3Fu8Ni75cYSWEdPWCuC1u2B2NjnkYFKnDvjG0Ctyjtwu4fY6xqgutTg+8hLfF3rfecMDdbrWX0BJs7wZwQHB3kV1E28byop0DEK3DjUxAD1zXkyLVQvKbPjF3A8ec0hYPOViFtNXPvrHrGyWBhcsj2Id5LsoqHOIrdddc4VBb+nKS4+Dh85SAPOr+N5DdQ7u8BAfIunIduRHXyeMXUWDqInCOHYYCE8EdPnNDy4gb9YI0JHc+BgICbUq5B2U5t68ZEOvka+sqHo85/DieZzZ7MO/nNHNWfzjdb6wDbfHOcz/AJvNqf8AbnG+jDkdeM1k4x09T/eINHi2Y6h2bwFaOGak6/8Auc73k1LW3HQTlyK7PeakNEziBjgdF1nV1/4GhOt/3iEITWeg+M5HvBF5vt9Zujt/wyxQ0s1gPzMFNWc4CWGd3eFRYvWG0dusceY6w6+zN2u3efq4nm7xs3/8t16mHzO2NUa2GeeNN+D+OA+jFRIzG8vS/vP3hm1N8c2S773hIwacfGfl3OT4xogUGX3mynbn6PExt5fxiUVc8brxmsGt5tTe3n4ziOAbTvAdTljw9XAQ6xzvWbq70zQjwwhIDbjDt7weCbwLhwHxCc+MAFBQIzhOumQGTlblli3xjyOtYheM/9k=', '', NULL, NULL, NULL);
INSERT INTO `users` VALUES (2, 'manager', '$2b$10$KFklzNkpZHDQZXHVqQmkCOqXQc3wRqtfWlw0JX8VdZMH.tnwXnmqe', NULL, NULL, 'manager', NULL, 1, '2025-03-25 11:00:39', '2025-03-25 11:00:39', NULL, '', NULL, NULL, NULL);
INSERT INTO `users` VALUES (3, 'user1', '$2b$10$KFklzNkpZHDQZXHVqQmkCOqXQc3wRqtfWlw0JX8VdZMH.tnwXnmqe', '510076394@qq.com', '', 'user', 2, 1, '2025-03-25 11:00:39', '2025-04-19 18:24:38', NULL, '', NULL, NULL, NULL);
INSERT INTO `users` VALUES (4, '王晓敏', '$2a$10$GMMAFbqWa2mqOF11DN3hUOEwzbuZCohrSKMp6j/TOiLyU68/K2t6W', 'a510076394@gmail.com', '', 'user', 1, 1, '2025-04-15 09:21:11', '2025-04-15 09:21:11', NULL, '', NULL, NULL, NULL);
INSERT INTO `users` VALUES (6, 'test', '$2a$10$/KHn.dZbSA6i8yO9aVO.dee4hK53KY6ySBrWBw61TroidrBJCSDee', '510076394@qq.com', '', 'user', 3, 1, '2025-04-19 18:26:17', '2025-04-19 18:26:17', NULL, '', NULL, NULL, NULL);
INSERT INTO `users` VALUES (7, 'lpr', '$2a$10$QoH93VOcyHDzukOT1dG0AOm4lgUWpVdreMZcFPHi.c7vFGPZFsO7C', 'a510076394@gmail.com', '', 'user', 1, 1, '2025-04-23 11:13:33', '2025-04-23 11:13:33', NULL, '', NULL, NULL, NULL);

-- ----------------------------
-- Procedure structure for generate_task_code
-- ----------------------------
DROP PROCEDURE IF EXISTS `generate_task_code`;
delimiter ;;
CREATE PROCEDURE `generate_task_code`()
BEGIN
        DECLARE prefix CHAR(3) DEFAULT 'SCT';
        DECLARE date_part CHAR(6);
        DECLARE max_seq INT;
        DECLARE new_code VARCHAR(20);
        
        -- 获取当前日期，格式为YYMMDD (250426)
        SET date_part = DATE_FORMAT(CURDATE(), '%y%m%d');
        
        -- 查找当天最大序号
        SELECT IFNULL(MAX(CAST(SUBSTRING(code, 10) AS UNSIGNED)), 0) 
        INTO max_seq 
        FROM production_tasks 
        WHERE code LIKE CONCAT(prefix, date_part, '%');
        
        -- 生成新编号，序号部分从001开始
        SET new_code = CONCAT(prefix, date_part, LPAD(max_seq + 1, 3, '0'));
        
        -- 设置输出变量
        SET @new_code = new_code;
      END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table locations
-- ----------------------------
DROP TRIGGER IF EXISTS `handle_deleted_location`;
delimiter ;;
CREATE TRIGGER `handle_deleted_location` BEFORE DELETE ON `locations` FOR EACH ROW BEGIN
    -- 将使用被删除location的materials的location_id和location_name设置为NULL
    UPDATE materials
    SET location_id = NULL,
        location_name = NULL
    WHERE location_id = OLD.id;
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table locations
-- ----------------------------
DROP TRIGGER IF EXISTS `update_material_location_name`;
delimiter ;;
CREATE TRIGGER `update_material_location_name` AFTER UPDATE ON `locations` FOR EACH ROW BEGIN
    -- 更新materials表中对应的location_name
    UPDATE materials
    SET location_name = NEW.name
    WHERE location_id = NEW.id;
END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
