# ERP + MES 系统技术架构文档

## 1. 系统概述

本系统是一个集成的企业资源规划(ERP)和制造执行系统(MES)平台，采用前后端分离架构，提供完整的生产管理、库存管理和订单管理功能。

## 2. 技术架构

### 2.1 整体架构

```
前端(Vue3) <-> API网关(Express) <-> 业务服务 <-> 数据层(MySQL/Redis)
```

### 2.2 技术栈详情

#### 前端技术栈
- 核心框架: Vue 3 + Composition API
- 状态管理: Pinia
- 路由管理: Vue Router
- UI组件库: Element Plus
- 构建工具: Vite
- HTTP客户端: Axios

#### 后端技术栈
- 运行环境: Node.js
- Web框架: Express
- 数据库: MySQL
- 缓存: Redis
- ORM: Sequelize

## 3. 系统模块

### 3.1 生产管理模块
- 生产计划管理
- BOM管理
- 生产任务管理
- 生产进度跟踪
- 生产报表

### 3.2 库存管理模块
- 入库管理
- 出库管理
- 库存盘点
- 库存调拨
- 库存预警

### 3.3 采购管理模块
- 采购申请
- 采购订单
- 供应商管理
- 采购统计

### 3.4 销售管理模块
- 销售报价
- 销售订单
- 客户管理
- 销售出库
- 销售退货

## 4. 数据流转

### 4.1 生产流程
1. 销售订单创建
2. 生产计划制定
3. 物料需求计算
4. 生产任务分配
5. 生产进度更新
6. 产品入库

### 4.2 库存流程
1. 采购入库
2. 生产领料
3. 成品入库
4. 销售出库
5. 库存盘点

## 5. 目录结构

```
project/
├── frontend/          # Vue3前端项目
│   ├── src/
│   │   ├── assets/   # 静态资源
│   │   ├── components/# 通用组件
│   │   ├── router/   # 路由配置
│   │   ├── stores/   # Pinia状态管理
│   │   ├── views/    # 页面组件
│   │   └── App.vue   # 根组件
├── backend/           # Node.js后端项目
│   ├── src/
│   │   ├── config/   # 配置文件
│   │   ├── controllers/# 业务控制器
│   │   ├── middleware/# 中间件
│   │   ├── models/   # 数据模型
│   │   ├── routes/   # API路由
│   │   └── index.js  # 应用入口
```

## 6. 数据库设计

### 6.1 主要数据表
- 生产相关: production_plans, production_tasks, bom_masters, bom_details
- 库存相关: inventory_stock, inventory_transactions, inventory_check
- 采购相关: purchase_orders, purchase_requisitions, suppliers
- 销售相关: sales_orders, sales_quotations, customers

### 6.2 关键关联
- 生产计划 -> 生产任务 -> 物料需求
- 销售订单 -> 生产计划 -> 采购申请
- 库存变动 -> 出入库记录 -> 库存盘点