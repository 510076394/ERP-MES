# 销售出库单明细数据显示问题修复

## 问题描述

销售出库单界面中，出库明细部分只显示了数量字段，其他字段（物料编码、物料名称、规格、单位）都没有正确显示。

## 原因分析

1. **数据关联不一致**：出库单明细表 (sales_outbound_items) 中的 product_id 字段应该关联到 materials 表中存在的记录，但系统没有验证这些关联是否有效。

2. **销售订单与出库单数据不同步**：销售出库单应该基于销售订单创建，并保持物料信息一致，但在实现中没有确保这一点。

## 解决方案

1. **数据验证与过滤**：
   - 修改后端API，验证物料ID是否存在于materials表中
   - 过滤无效的物料项，只处理有效的ID
   - 确保销售出库单与销售订单物料保持一致

2. **前端数据处理优化**：
   - 改进从订单获取物料项的逻辑
   - 增强错误处理和字段兼容性
   - 添加详细日志，便于调试

## 具体实施

1. **后端API改进**：
   ```javascript
   // 验证物料是否存在于materials表中
   const materialIds = items.map(item => item.material_id || item.product_id).filter(Boolean);
   
   if (materialIds.length > 0) {
     const [materialCheck] = await connection.query(
       'SELECT id FROM materials WHERE id IN (?)',
       [materialIds]
     );
     
     const validMaterialIds = materialCheck.map(m => m.id);
     
     // 过滤出有效的物料项
     const validItems = items.filter(item => {
       const materialId = item.material_id || item.product_id;
       return validMaterialIds.includes(materialId);
     });
     
     // 只处理有效的物料项
     // ...
   }
   ```

2. **前端订单选择逻辑改进**：
   ```javascript
   // 确保每个物料项都包含正确的ID
   outboundForm.value.items = orderDetails.items
     .filter(item => item.material_id || item.product_id) // 过滤掉没有ID的项
     .map(item => ({
       material_id: item.material_id || item.product_id, // 优先使用material_id
       product_id: item.material_id || item.product_id, // 兼容后端使用product_id
       product_name: item.material_name || item.name,
       // ... 其他字段处理和兼容性
     }))
   ```

3. **添加详细日志**：
   ```javascript
   console.log('订单物料项:', orderDetails.items)
   console.log('转换后的出库单物料项:', outboundForm.value.items)
   console.log('提交物料项:', validItems)
   console.log('提交数据:', submitData)
   ```

## 效果

1. 系统现在能够正确显示出库单明细的所有字段，包括物料编码、物料名称、规格和单位
2. 出库单物料项与销售订单物料保持一致
3. 无效的物料ID会被自动过滤，防止数据不一致问题

## 后续建议

1. **字段命名统一**：考虑将 sales_outbound_items 表中的 product_id 字段重命名为 material_id，保持系统的命名一致性

2. **外键约束**：添加数据库外键约束，确保 sales_outbound_items.product_id 引用 materials.id，从数据库层面防止出现无效引用

3. **前端字段验证**：在前端添加更严格的字段验证，确保只有有效的物料项才能提交

4. **更新相关模块**：检查其他可能使用类似逻辑的模块，统一更新以保持一致性 