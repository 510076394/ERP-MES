# 销售出库单与物料关联修复文档

## 问题描述

我们的销售出库管理模块中发现，出库单明细中显示的物料信息（如"INV-4, Raw Material A, kg, 20, kg"）不正确，这是因为后端代码中存在数据关联错误。

具体问题：
1. 销售出库单的物料项（sales_outbound_items表）中的 `product_id` 字段错误地关联到了 `inventory` 表，而不是 `materials` 表
2. 这导致前端显示的物料编码为"INV-4"（由后端拼接的前缀"INV-"加上inventory表的ID）
3. 物料名称也取自inventory表，而不是materials表，与销售订单中的物料不一致

## 解决方案

我们进行了以下修改：

1. 修改了后端代码中的关联查询：
   - `getSalesOutboundById` 方法中将查询改为与materials表关联
   - 更正了字段映射，product_code使用materials表的code字段，而不是拼接的"INV-id"
   - 单位信息从units表获取

2. 修复了出库单创建和更新逻辑：
   - 移除了硬编码的inventory ID映射（validProductIds = [4, 5, 6]）
   - 直接使用材料的material_id，不再转换为inventory ID

3. 创建了数据迁移脚本 `migrate-outbound-items.js`：
   - 识别现有的出库单物料项中关联的inventory记录
   - 查找对应的material记录（通过名称匹配）
   - 更新出库单物料项的product_id为正确的material_id

## 如何应用修复

1. 执行以下命令运行迁移脚本：
   ```bash
   node backend/migrate-outbound-items.js
   ```

2. 重启后端服务:
   ```bash
   npm run server
   ```

3. 重启前端服务:
   ```bash
   npm run dev
   ```

完成这些步骤后，销售出库单中的物料信息将正确显示，与销售订单中的物料保持一致。

## 后续优化建议

1. 考虑修改sales_outbound_items表结构，将product_id字段重命名为material_id，以便与其他表保持命名一致
2. 添加数据验证逻辑，确保创建出库单时物料ID在materials表中存在
3. 为materials表添加外键约束，防止类似问题再次发生 