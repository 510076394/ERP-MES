# 销售出库单与销售订单数据一致性保障

## 需求背景

销售出库单应当引用销售订单中的产品信息，保持两者之间的数据一致性。销售出库单涉及实际的库存变动，因此必须确保所引用的物料信息在系统中存在且有效。

## 实现方案

### 后端验证与过滤

1. **订单存在性验证**：
   ```javascript
   // 如果有order_id，验证订单存在
   if (order_id) {
     const [orderCheck] = await connection.query(
       'SELECT id FROM sales_orders WHERE id = ?',
       [order_id]
     );
     
     if (orderCheck.length === 0) {
       await connection.rollback();
       return res.status(400).json({ error: '关联的订单不存在' });
     }
   }
   ```

2. **物料有效性验证**：
   ```javascript
   // 验证物料是否存在于materials表中
   const materialIds = items.map(item => item.material_id || item.product_id).filter(Boolean);
   
   if (materialIds.length > 0) {
     const [materialCheck] = await connection.query(
       'SELECT id FROM materials WHERE id IN (?)',
       [materialIds]
     );
     
     const validMaterialIds = materialCheck.map(m => m.id);
     // 过滤出有效的物料项
     // ...
   }
   ```

3. **只处理有效物料**：
   ```javascript
   const validItems = items.filter(item => {
     const materialId = item.material_id || item.product_id;
     return validMaterialIds.includes(materialId);
   });
   
   if (validItems.length === 0) {
     console.warn('没有有效的物料项，出库单明细将为空');
   } else {
     // 只处理有效的物料项
     // ...
   }
   ```

### 前端数据处理

1. **订单物料同步**：
   ```javascript
   // 从订单中获取物料项
   if (orderDetails.items?.length > 0) {
     // 确保每个物料项都包含正确的ID
     outboundForm.value.items = orderDetails.items
       .filter(item => item.material_id || item.product_id) // 过滤掉没有ID的项
       .map(item => ({
         material_id: item.material_id || item.product_id,
         product_id: item.material_id || item.product_id,
         // ... 其他字段处理
       }))
   }
   ```

2. **提交前验证**：
   ```javascript
   // 过滤掉无效的物料项
   const validItems = outboundForm.value.items.filter(item => 
     (item.material_id || item.product_id) && item.quantity > 0
   )
   
   if (validItems.length === 0) {
     ElMessage.warning('请至少添加一个有效的物料项')
     return
   }
   ```

### 字段兼容与一致性

1. **字段兼容性处理**：
   ```javascript
   // 优先使用material_id，兼容使用product_id
   material_id: item.material_id || item.product_id,
   product_id: item.material_id || item.product_id,
   
   // 名称字段兼容
   product_name: item.material_name || item.name,
   
   // 编码字段兼容
   material_code: item.code || item.material_code,
   
   // 规格字段兼容
   specification: item.specification || item.specs,
   
   // 单位字段兼容
   unit_name: item.unit_name || item.unit,
   ```

2. **数据追踪与日志**：
   ```javascript
   console.log('订单物料项:', orderDetails.items)
   console.log('转换后的出库单物料项:', outboundForm.value.items)
   console.log('提交物料项:', validItems)
   ```

## 数据流程

1. 用户选择关联的销售订单
2. 系统自动加载订单中的物料信息
3. 前端过滤并标准化物料数据
4. 用户可以调整出库数量（不超过订单数量）
5. 提交时前端再次验证物料有效性
6. 后端接收数据后验证订单和物料的存在性
7. 后端过滤掉无效的物料项，只处理有效数据
8. 后端写入数据库，保证数据一致性

## 后续改进

1. **表结构优化**：将 sales_outbound_items 表中的 product_id 重命名为 material_id，保持系统中的字段命名一致性
2. **数据库约束**：添加外键约束，从数据库层面确保数据一致性
3. **统一命名**：在代码中统一使用 material_id，减少 product_id/material_id 混用带来的复杂性
4. **输入验证**：加强前端输入验证，确保所有必要字段都是有效的 