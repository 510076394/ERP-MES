# ERP + MES 系统开发指南

## 1. 开发环境搭建

### 1.1 必要软件
- Node.js (v16+)
- MySQL (v8.0+)
- Redis (v6+)
- Git

### 1.2 项目初始化
```bash
# 克隆项目
git clone [项目地址]

# 前端项目初始化
cd frontend
npm install

# 后端项目初始化
cd ../backend
npm install
```

### 1.3 环境配置
1. 前端配置（frontend/.env）
```
VITE_API_BASE_URL=http://localhost:3000
```

2. 后端配置（backend/.env）
```
PORT=3000
DB_HOST=localhost
DB_USER=root
DB_PASS=your_password
DB_NAME=erp_mes_db
REDIS_HOST=localhost
REDIS_PORT=6379
```

## 2. 开发规范

### 2.1 代码风格
- 使用ESLint + Prettier进行代码格式化
- 遵循Vue3组件命名规范
- 使用TypeScript类型注解
- 组件采用Composition API风格

### 2.2 Git工作流
- 主分支：main
- 开发分支：dev
- 功能分支：feature/*
- 修复分支：hotfix/*

### 2.3 提交规范
```
feat: 新功能
fix: 修复bug
docs: 文档更新
style: 代码格式（不影响代码运行的变动）
refactor: 重构（既不是新增功能，也不是修改bug的代码变动）
perf: 性能优化
test: 增加测试
chore: 构建过程或辅助工具的变动
```

## 3. 项目结构说明

### 3.1 前端结构
```
src/
├── assets/       # 静态资源
│   ├── images/   # 图片资源
│   ├── styles/   # 全局样式
│   └── icons/    # 图标资源
├── components/   # 通用组件
│   ├── common/   # 基础组件（按钮、表单等）
│   ├── layout/   # 布局组件（导航栏、侧边栏等）
│   └── business/ # 业务组件（生产、库存、采购等）
├── composables/  # 组合式函数
│   ├── auth/     # 认证相关
│   ├── api/      # API调用封装
│   └── utils/    # 工具函数
├── router/       # 路由配置
│   ├── index.js  # 路由入口
│   └── modules/  # 模块路由
├── stores/       # 状态管理
│   ├── user.js   # 用户状态
│   ├── app.js    # 应用状态
│   └── modules/  # 业务模块状态
├── views/        # 页面组件
│   ├── dashboard/    # 仪表盘
│   ├── production/   # 生产管理
│   ├── inventory/    # 库存管理
│   ├── purchase/     # 采购管理
│   └── system/       # 系统设置
└── services/     # API服务
    ├── api.js    # API配置
    ├── request.js # 请求封装
    └── modules/   # 业务模块API
```

### 3.2 后端结构
```
src/
├── config/      # 配置文件
│   ├── database.js  # 数据库配置
│   ├── redis.js     # Redis配置
│   └── auth.js      # 认证配置
├── controllers/ # 控制器
│   ├── production/  # 生产管理
│   ├── inventory/   # 库存管理
│   ├── purchase/    # 采购管理
│   └── system/      # 系统管理
├── middleware/  # 中间件
│   ├── auth.js      # 认证中间件
│   ├── validate.js  # 数据验证
│   └── error.js     # 错误处理
├── models/      # 数据模型
│   ├── production/  # 生产相关模型
│   ├── inventory/   # 库存相关模型
│   ├── purchase/    # 采购相关模型
│   └── system/      # 系统相关模型
├── routes/      # 路由定义
│   ├── index.js     # 路由入口
│   └── modules/     # 模块路由
└── utils/       # 工具函数
    ├── logger.js    # 日志工具
    ├── validator.js # 验证工具
    └── helper.js    # 辅助函数
```

### 3.3 数据库结构
```
数据库表结构
├── 生产管理
│   ├── production_plans        # 生产计划
│   ├── production_tasks        # 生产任务
│   ├── production_task_progress # 任务进度
│   ├── bom_masters            # 物料清单主表
│   └── bom_details            # 物料清单明细
├── 库存管理
│   ├── inventory_stock        # 库存信息
│   ├── inventory_transactions  # 库存事务
│   ├── inventory_inbound      # 入库单
│   ├── inventory_outbound     # 出库单
│   └── inventory_check        # 库存盘点
├── 采购管理
│   ├── purchase_requisitions  # 采购申请
│   ├── purchase_orders        # 采购订单
│   ├── suppliers             # 供应商
│   └── materials             # 物料
└── 系统管理
    ├── users                 # 用户信息
    ├── departments           # 部门信息
    ├── roles                 # 角色权限
    └── system_logs          # 系统日志
```

## 4. 开发流程

### 4.1 新功能开发
1. 从dev分支创建功能分支
2. 开发完成后提交PR到dev分支
3. 代码审查通过后合并
4. 定期将dev分支合并到main分支

### 4.2 Bug修复
1. 创建hotfix分支
2. 修复完成后提交PR
3. 合并到main和dev分支

## 5. 部署说明

### 5.1 前端部署
```bash
# 构建生产环境代码
cd frontend
npm run build

# 将dist目录部署到Web服务器
```

### 5.2 后端部署
```bash
# 安装生产依赖
cd backend
npm install --production

# 启动服务
pm2 start index.js
```

### 5.3 数据库部署
1. 创建数据库
2. 导入数据库脚本
3. 配置数据库连接

## 6. 常见问题

### 6.1 开发环境问题
- 端口占用：检查并修改配置文件中的端口号
- 数据库连接：确认MySQL服务是否启动
- Redis连接：检查Redis服务状态

### 6.2 部署问题
- 静态资源路径：确保正确配置API地址
- 数据库迁移：使用正确的字符集和排序规则
- 服务启动：检查进程和日志

## 7. 核心业务模块说明

### 7.1 生产管理模块
- 生产计划管理
  - 计划创建、审批、执行跟踪
  - BOM管理和物料需求计算
  - 生产进度监控和预警
- 生产任务管理
  - 任务分配和派工
  - 工序管理和进度跟踪
  - 生产数据采集和分析

### 7.2 库存管理模块
- 库存操作
  - 入库管理（采购、生产、退货）
  - 出库管理（销售、生产领料）
  - 库存调拨和转移
- 库存控制
  - 实时库存监控
  - 库存预警和补货管理
  - 库存盘点和账务核对

### 7.3 采购管理模块
- 采购申请
  - 需求收集和审批
  - 供应商询价和比价
  - 采购计划制定
- 采购执行
  - 订单创建和跟踪
  - 到货验收和入库
  - 供应商管理和评估

## 8. 系统架构

### 8.1 技术架构
- 前端：Vue3 + Vite + TypeScript
- 后端：Node.js + Express + TypeScript
- 数据库：MySQL + Redis
- 部署：Docker容器化

### 8.2 系统模块
```
系统架构图
├── 用户界面层
│   ├── Web客户端
│   └── 移动端适配
├── 应用服务层
│   ├── 业务模块（生产/库存/采购）
│   ├── 系统服务（认证/权限/日志）
│   └── 集成服务（消息/通知/报表）
├── 数据访问层
│   ├── 数据模型
│   ├── 缓存服务
│   └── 数据库服务
└── 基础设施层
    ├── 容器化部署
    ├── 监控告警
    └── 备份恢复
```

### 8.3 数据流转
1. 用户操作流
   - 用户请求 → 权限验证 → 业务处理 → 数据持久化 → 响应结果
2. 系统集成流
   - 外部系统 → API网关 → 服务路由 → 业务处理 → 数据同步
3. 数据处理流
   - 数据采集 → 清洗转换 → 业务处理 → 数据存储 → 数据展示

## 9. 性能优化

### 9.1 前端优化
- 路由懒加载
- 组件按需加载
- 静态资源压缩
- 合理使用缓存

### 9.2 后端优化
- 数据库索引优化
- 查询语句优化
- 使用Redis缓存
- API响应压缩