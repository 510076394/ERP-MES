<template>
  <div class="system-container">
    <router-view />
  </div>
</template>

<script setup>
// System管理模块主视图
</script>

<style scoped>
.system-container {
  width: 100%;
  height: 100%;
}
</style> 