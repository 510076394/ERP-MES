<template>
  <div class="base-data-content">
    <router-view></router-view>
  </div>
</template>

<script setup>
// 组件逻辑
</script>

<style scoped>
.base-data-content {
  padding: 20px;
}
</style>